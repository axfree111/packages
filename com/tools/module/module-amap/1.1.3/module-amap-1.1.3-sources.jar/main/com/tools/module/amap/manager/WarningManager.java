package com.tools.module.amap.manager;

import android.content.Context;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.speech.tts.UtteranceProgressListener;

import com.tools.module.amap.R;
import com.tools.module.amap.TextToSpeechManager;
import com.tools.module.amap.map.LocalMapConfig;
import com.tools.module.amap.utils.PreferencesUtils;
import com.tools.module.common.ContextStore;
import com.tools.module.common.utils.ResourceUtil;
import com.tools.module.common.utils.XAppLogger;


/**
 * Created by jiajie on 2019-08-03.
 */
public class WarningManager {

    public static final int IS_SPEECH = -10001000;
    private static WarningManager instance;
    private Vibrator vibrator;
    private VibrationEffect vibrationEffect;

    private SoundManager soundManager;
    private TextToSpeechManager speechManager;

    private WarningManager(Context context) {
        checkTool(context);
    }

    private void checkTool(Context context) {
        if (speechManager == null) {
            speechManager = new TextToSpeechManager();
        }
        if (soundManager == null) {
            soundManager = new SoundManager();
        }
        if (null == vibrator) {
            vibrator = (Vibrator) context.getSystemService(context.VIBRATOR_SERVICE);
        }
        if (vibrationEffect == null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrationEffect = VibrationEffect.createWaveform(new long[]{1000, 1000}, 0);
            }
        }
    }

    public static WarningManager getInstance() {
        if (instance == null) {
            synchronized (WarningManager.class) {
                if (instance == null) {
                    instance = new WarningManager(ContextStore.getContext());
                }
            }
        }
        return instance;
    }

    private void startAddPlay(int contentId, UtteranceProgressListener listener) {
        if (speechManager != null) {
            speechManager.startAddPlay(contentId, listener);
        }
    }

    public void startAddPlay(int contentId) {
        startAddPlay(contentId, false);
    }

    public void startAddPlay(int contentId, boolean isCheckSwitch) {
        startAddPlay(contentId, 1, isCheckSwitch);
    }

    public void startAddPlay(int contentId, int count, boolean isCheckSwitch) {
        startAddPlay(contentId, count, false, isCheckSwitch);
    }

    public void startAddPlay(int contentId, int count, boolean vibrator, boolean isCheckSwitch) {
        boolean isPlay = true;
        if (isCheckSwitch) {
            isPlay = PreferencesUtils.getSoundSwitch();
        }
        if (isPlay) {
            startAddPlay(contentId, new UtteranceProgressListener() {
                @Override
                public void onStart(String utteranceId) {
                    if (vibrator) {
                        startVibrator();
                    }
                }

                @Override
                public void onDone(String utteranceId) {
                    if (count > 1) {
                        startAddPlay(contentId, count - 1, vibrator);
                    } else {
                        stopVibrator();
                    }
                }

                @Override
                public void onError(String utteranceId) {
                    XAppLogger.getInstance().writeError("startAddPlay error " + utteranceId);
                }
            });
        }
    }

    public void startFlushPlay(String content) {
        startFlushPlay(content, false);
    }

    public void startFlushPlay(String content, boolean isCheckSwitch) {
        startFlushPlay(content, 1, isCheckSwitch);
    }

    public void startFlushPlay(String content, int count, boolean isCheckSwitch) {
        startFlushPlay(content, count, false, isCheckSwitch);
    }

    public void startFlushPlay(String content, boolean vibrator, boolean isCheckSwitch) {
        startFlushPlay(content, 1, vibrator, isCheckSwitch);
    }

    public void startFlushPlay(int contentId) {
        startFlushPlay(contentId, false);
    }

    public void startFlushPlay(int contentId, boolean isCheckSwitch) {
        startFlushPlay(contentId, 1, isCheckSwitch);
    }

    public void startFlushPlay(int contentId, int count, boolean isCheckSwitch) {
        startFlushPlay(contentId, count, false, isCheckSwitch);
    }

    public void startFlushPlay(int contentId, boolean vibrator, boolean isCheckSwitch) {
        startFlushPlay(contentId, 1, vibrator, isCheckSwitch);
    }

    public void startFlushPlay(int contentId, int count, boolean vibrator, boolean isCheckSwitch) {
        startFlushPlay(ResourceUtil.getContent(contentId), count, vibrator, isCheckSwitch);
    }

    public void startFlushPlay(String content, int count, boolean vibrator, boolean isCheckSwitch) {
        boolean isPlay = true;
        if (isCheckSwitch) {
            isPlay = PreferencesUtils.getSoundSwitch();
        }
        if (isPlay) {
            startFlushPlay(content, new UtteranceProgressListener() {
                @Override
                public void onStart(String utteranceId) {
                    if (vibrator) {
                        startVibrator();
                    }
                }

                @Override
                public void onDone(String utteranceId) {
                    if (count > 1) {
                        startFlushPlay(content, count - 1, vibrator);
                    } else {
                        stopVibrator();
                    }
                }

                @Override
                public void onError(String utteranceId) {

                }
            });
        }
    }

    private void startFlushPlay(String content, UtteranceProgressListener listener) {
        if (speechManager != null) {
            speechManager.startFlushPlay(content, listener);
        }
    }

    public synchronized int haveNewVideoStartPlay() {
        if (LocalMapConfig.USE_SPEAK) {
            return soundManager.haveNewVideoStartPlay();
        } else {
            startFlushPlay(R.string.speech_have_new_video_tip);
            return IS_SPEECH;
        }
    }

    public synchronized int createFencePointStartPlay() {
        startFlushPlay(R.string.speech_create_fence_start_tip);
        return soundManager.createFencePointStartPlay();
    }

    public synchronized int createFenceFinishStartPlay() {
        startFlushPlay(R.string.speech_create_fence_finish_tip);
        return soundManager.createFenceFinishStartPlay();
    }

    public synchronized int findDroneStartPlay() {
        startVibrator();
        return soundManager.findDroneWarningStartPlay();
    }

    public synchronized int deviceExceptionStartPlay() {
        startVibrator();
        return soundManager.deviceExceptionStartPlay();
    }

    public synchronized void stopWarning(int streamID) {
        soundManager.stopWarning(streamID);
    }

    public synchronized void stopAllSound() {
        soundManager.stopAllSound();
        speechManager.stop();
    }

    public synchronized void stopVibrator() {
        boolean stop = false;
        if (PreferencesUtils.getVibratorSwitch()) {
            if (LocalMapConfig.USE_SPEAK) {
                if (soundManager.getStreamIDList().size() <= 0) {
                    stop = true;
                }
            } else {
                stop = true;
            }
        } else {
            stop = true;
        }
        if (stop && vibrator != null) {
            vibrator.cancel();
        }
    }

    public synchronized void startVibrator() {
        if (vibrator != null && PreferencesUtils.getVibratorSwitch()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(vibrationEffect);
            } else {
                vibrator.vibrate(new long[]{1000, 1000}, 0);
            }
        }
    }
}
