package com.tools.module.amap.map

import android.os.Bundle
import android.os.Handler
import android.os.Message
import android.text.SpannableStringBuilder
import android.text.TextUtils
import com.drone.monitor.bean.BaseRouteHistoryData
import com.drone.monitor.bean.Drone
import com.drone.monitor.bean.FrequencyRangeInfo
import com.drone.monitor.bean.MonitorDevice
import com.drone.monitor.bean.ShipRouteHistoryData
import com.drone.monitor.bean.VideoInfo
import com.drone.monitor.bean.WarningAreaBaseInfo
import com.drone.monitor.bean.WarningAreaInfo
import com.drone.monitor.bean.custom.MyLatLng
import com.tools.module.amap.R
import com.tools.module.amap.manager.ColorManager
import com.tools.module.amap.manager.WarningManager
import com.tools.module.amap.map.contract.IGetDestinationInfoCallback
import com.tools.module.amap.map.contract.IMarkerInterceptorCallback
import com.tools.module.amap.map.proxy.IMapProxy
import com.tools.module.amap.map.utils.SpatialRelationUtil
import com.tools.module.amap.model.DistrictFenceModel
import com.tools.module.amap.model.DroneRecordInvadeModel
import com.tools.module.amap.model.MyGeocodeAddress
import com.tools.module.amap.model.MyLatLngBounds
import com.tools.module.amap.model.SelectAreaModel
import com.tools.module.amap.model.base.BaseDistrictFenceModel
import com.tools.module.amap.model.base.BaseDroneModel
import com.tools.module.amap.model.base.BaseMonitorModel
import com.tools.module.amap.model.base.BaseSelectAreaModel
import com.tools.module.amap.model.base.BaseVideoModel
import com.tools.module.amap.net.NetManager
import com.tools.module.amap.net.http.response.StringHttpResponseHandler
import com.tools.module.amap.observer.DataObserver
import com.tools.module.amap.observer.DataObserver.IDroneDistanceObserver
import com.tools.module.amap.observer.FloatWindowsObserver
import com.tools.module.amap.observer.MapObserver
import com.tools.module.amap.observer.MapObserver.ILatitudeLongitudeListener
import com.tools.module.amap.observer.MapObserver.IMapStatusListener
import com.tools.module.amap.observer.OperationObserver
import com.tools.module.amap.test.TestConstants
import com.tools.module.common.base.AppConfig
import com.tools.module.common.utils.HandlerUtils
import com.tools.module.common.utils.ResourceUtil
import com.tools.module.common.utils.ToastUtil
import com.tools.module.common.utils.XAppLogger
import java.util.Hashtable
import java.util.Vector
import java.util.concurrent.ConcurrentHashMap

object MapController {
    // 是否在选择任务路线
    @kotlin.jvm.JvmField
    var IS_SELECT_TASK_ROUTE: Boolean = false

    // 是否在选择攻击目标
    @kotlin.jvm.JvmField
    var IS_SELECT_TARGET: Boolean = false

    // 是否在编辑模式
    @kotlin.jvm.JvmField
    var IS_EDIT_MAP: Boolean = false

    @kotlin.jvm.JvmField
    var IS_SELECT_CENTER_POINT: Boolean = false
    const val LEVELS_MAX: Float = 22f
    const val LEVELS_MIN: Float = 3f
    const val LEVELS_ZOOM_DEFAULT: Float = 10.0f

    @kotlin.jvm.JvmField
    var CURRENT_ZOOM_LEVEL: Float = LEVELS_ZOOM_DEFAULT

    // 是否在圈定区域
    @kotlin.jvm.JvmField
    var IS_SELECT_AREA: Boolean = false

    @JvmStatic
    @Volatile
    var visibleBounds: MyLatLngBounds = MyLatLngBounds()

    /**
     * 武器设备列表
     */
    private val mMonitorModelMap = ConcurrentHashMap<String?, BaseMonitorModel>()

    /**
     * 在当前显示区域内的设备
     */
    private val mLookMonitorModelMap = ConcurrentHashMap<String, BaseMonitorModel>()

    /**
     * 无人机列表
     */
    private val mDroneMap = ConcurrentHashMap<String, BaseDroneModel>()

    /**
     * 飞机列表
     */
    private val mAircraftMap = ConcurrentHashMap<String, BaseDroneModel>()

    /**
     * 船舶列表
     */
    private val mShipMap = ConcurrentHashMap<String, BaseDroneModel>()

    /**
     * 民航机列表
     */
    private val mPlaneMap = ConcurrentHashMap<String, BaseDroneModel>()

    /**
     * 船舶所有的经纬度用户热力图实现
     */
    private val mShipPositionMap = ConcurrentHashMap<String?, MyLatLng?>()

    /**
     * 民航机的所有经纬度用户热力图实现
     */
    private val mPlanePositionMap = ConcurrentHashMap<String?, MyLatLng?>()

    /**
     * 电子围栏列表
     */
    private val mDistrictFenceMap = ConcurrentHashMap<String?, BaseDistrictFenceModel>()

    /**
     * 显示中的marker model记录
     */
    private val showedDroneModels = ConcurrentHashMap<String, BaseDroneModel>()

    /**
     * 视频model
     */
    private var videoModel: BaseVideoModel<*>? = null


    private var mCurrentEditFence: BaseDistrictFenceModel? = null

    @JvmStatic
    var mCurrentEditFenceId: String? = null


    private var mSelectAreaModel: BaseSelectAreaModel? = null

    /**
     * 显示无人机距离数据
     * key 需要是设备id_无人机id 或 无人机id
     */
    private val mShowDroneDistanceMap = ConcurrentHashMap<String, SpannableStringBuilder>()

    // 内存中当前选中的设备对应的帧率记录
    private var mMemoryCurrentFrequencyRangeList = Vector<FrequencyRangeInfo>()

    // 实时的当前选中的设备对应的频率记录
    @JvmStatic
    var currentFrequencyRangeList = mutableListOf<FrequencyRangeInfo>()
        get() = currentFrequencyRangeList
        set(value) {
            if (value != null) {
                field.clear()
                field.addAll(value)
            } else {
                field.clear()
            }
            DataObserver.getInstance().updateFPSList()
        }
    @JvmStatic

    var currentSelectMonitorModel: BaseMonitorModel? = null
    var mCurrentSelectMonitorId: String = ""
        set(value) {
            field = value
            currentSelectMonitorModel = getMonitorModel(value)
        }

    private const val soundIdDefault = 0

    /**
     * 设备异常警告声ID
     */
    private var soundIdExceptionWarning = soundIdDefault

    var mapProxy: IMapProxy? = null
    @JvmStatic
    var isMainPage = false
    @JvmStatic
    var isStop = false

    @JvmStatic
    fun onCreate() {
        isStop = false
        isMainPage = true
        mapProxy?.onCreate()
        MapObserver.registerMapObserver(mapStatusListener)
        MapObserver.registerLatitudeLongitudeObserver(latitudeLongitudeListener)
        DataObserver.getInstance().registerDroneDistanceObserver(droneDistanceObserver)
    }

    @JvmStatic
    fun onResume() {
        mapProxy?.onResume()
    }

    @JvmStatic
    fun onPause() {
        mapProxy?.onPause()
    }

    @JvmStatic
    fun onStop() {
        isStop = true
        mapProxy?.onDestroy()
    }

    @JvmStatic
    fun onSaveInstanceState(outState: Bundle) {
        mapProxy?.onSaveInstanceState(outState)
    }

    @JvmStatic
    fun onDestroy() {
        mapProxy?.onDestroy()
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_OTHER, "移除所有定时任务!!!")
        MapObserver.unRegisterMapObserver(mapStatusListener)
        MapObserver.unRegisterLatitudeLongitudeObserver(latitudeLongitudeListener)
        DataObserver.getInstance().unRegisterDroneDistanceObserver(droneDistanceObserver)

        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_OTHER, "清除所有数据!!!")
        isMainPage = false
        currentSelectMonitorId = ""
        showedDroneModels.clear()
        mMonitorModelMap.clear()
        mLookMonitorModelMap.clear()
        mDroneMap.clear()
        mAircraftMap.clear()
        mShipMap.clear()
        mShipPositionMap.clear()
        mPlanePositionMap.clear()
        mDistrictFenceMap.clear()
        if (videoModel != null) {
            videoModel?.clear()
            videoModel = null
        }
        mMemoryCurrentFrequencyRangeList.clear()
        currentFrequencyRangeList.clear()
        mShowDroneDistanceMap.clear()
    }

    @JvmStatic
    fun setMarkerClickInterceptor(markerClickInterceptor: IMarkerInterceptorCallback) {
        mapProxy?.setMarkerClickInterceptor(markerClickInterceptor)
    }

    @JvmStatic
    fun setZoom(latitude: Double, longitude: Double, zoom: Float) {
        mapProxy?.setZoom(latitude, longitude, zoom)
    }

    @JvmStatic
    fun setZoom(latitude: Double, longitude: Double) {
        mapProxy?.setZoom(latitude, longitude)
    }

    @JvmStatic
    fun removeVideoInfo(video: VideoInfo?) {
        HandlerUtils.getUIHandler().post {
            if (videoModel != null) {
                videoModel?.removeMarker(video)
                OperationObserver.notifyRemoveVideoInfo(video)
            }
        }
    }

    @JvmStatic
    fun hidVideoInfo(video: VideoInfo?) {
        HandlerUtils.getUIHandler().post {
            if (videoModel != null) {
                videoModel?.hideMarker(video)
                OperationObserver.notifyHidVideoInfo(video)
            }
        }
    }

    @JvmStatic
    val videos: Map<String, VideoInfo>?
        get() {
            if (videoModel != null) {
                return videoModel?.videos
            }
            return null
        }

    @JvmStatic
    fun addVideoInfo(videoInfo: VideoInfo) {
        checkVideoModel()
        HandlerUtils.getUIHandler().post {
            if (videoModel != null) {
                videoModel?.addMarker(videoInfo)
            }
        }
    }

    @JvmStatic
    fun updateVideoStatus(videoInfo: VideoInfo?) {
        HandlerUtils.getUIHandler().post {
            if (videoModel != null) {
                videoModel?.updateMarker(videoInfo)
            }
        }
    }

    private fun checkVideoModel() {
        if (videoModel == null) {
            videoModel = mapProxy?.createViewModel()
        }
    }

    /**
     * 相应视频marker点击事件
     *
     * @param videoInfo
     */
    @JvmStatic
    fun clickVideoMarker(videoInfo: VideoInfo?) {
        FloatWindowsObserver.getInstance().switchVideoFloatWindow(videoInfo)
    }

    @JvmStatic
    fun updateDistrictFenceMarker(infoModel: DistrictFenceModel?) {
        if (infoModel != null) {
            if (mCurrentEditFence != null) {
                mCurrentEditFence!!.updateMarkerLatLng(infoModel.fenceMarkerType, infoModel.latLng)
            }
        }
    }

    /**
     * 创建电子围栏时marker的点击事件
     *
     * @return
     */
    @JvmStatic
    fun onEditMapClickMarker() {
        if (IS_EDIT_MAP && mCurrentEditFence != null) {
            if (mCurrentEditFence!!.updateFenceCover()) {
                WarningManager.getInstance().createFenceFinishStartPlay()
            }
        }
    }

    @JvmStatic
    fun onClickMap(latitude: Double, longitude: Double): Boolean {
        if (IS_EDIT_MAP) {
            if (IS_SELECT_CENTER_POINT) {
                addDistrictFenceModel(
                    MyLatLng(latitude, longitude),
                    LocalMapConfig.DEFAULT_FENCE_RADIUS
                )
                IS_SELECT_CENTER_POINT = false
                return true
            }
        }
        return false
    }

    @JvmStatic
    fun onLongClickMap(latitude: Double, longitude: Double): Boolean {
        if (mapProxy?.onLongClickMapToEdit() == true) {
            for (fenceModel in mDistrictFenceMap.values) {
                if (fenceModel.isCanEdit) {
                    if (SpatialRelationUtil.isPolygonContainsPoint(
                            fenceModel.fenceLatLngs,
                            MyLatLng(
                                latitude,
                                longitude
                            )
                        )
                    ) {
                        // 表示需要编辑电子围栏
                        IS_EDIT_MAP = true
                        mCurrentEditFence = fenceModel
                        mCurrentEditFenceId = fenceModel.id
                        mCurrentEditFence!!.onStartEdit()
                        return true
                    }
                }
            }
        }
        return false
    }

    @JvmStatic
    fun selectArea() {
        if (mSelectAreaModel == null) {
            mSelectAreaModel = mapProxy?.createSelectAreaModel()
        }
        if (mSelectAreaModel != null) {
            mSelectAreaModel!!.removeAreaAndMarker()
            mSelectAreaModel!!.addMarker()
        }
    }

    @JvmStatic
    fun deleteSelectArea() {
        if (mSelectAreaModel != null) {
            mSelectAreaModel!!.removeAreaAndMarker()
        }
    }
    @JvmStatic
    val selectAreaLatLngs: List<MyLatLng>?
        get() {
            if (mSelectAreaModel != null) {
                return mSelectAreaModel!!.minAndMaxLatLng
            }
            return null
        }

    /**
     * 拖拽marker后通知位置更新
     *
     * @param selectAreaModel
     * @param latLng
     */
    @JvmStatic
    fun updateSelectAreaMarker(selectAreaModel: SelectAreaModel?, latLng: MyLatLng?) {
        if (selectAreaModel != null) {
            if (mSelectAreaModel != null) {
                mSelectAreaModel!!.updateCover()
            }
        }
    }

    @JvmStatic
    fun addDistrictFenceModel(latLng: MyLatLng, workRadius: Double) {
        IS_EDIT_MAP = true
        val areaInfo = WarningAreaInfo()
        areaInfo.centerLatLng = latLng
        areaInfo.radius = workRadius
        areaInfo.type = WarningAreaBaseInfo.WARNING_AREA_TYPE.CIRCLE
        val districtFenceModel: BaseDistrictFenceModel? = mapProxy?.createDistrictFenceModel()
        if (districtFenceModel != null) {
            mCurrentEditFence = districtFenceModel
            mCurrentEditFence!!.setFenceConfig(
                ResourceUtil.getColor(R.color.fence_cover_color),
                ResourceUtil.getColor(R.color.fence_cover_color),
                ColorManager.getDistrictFenceLineColor(),
                ResourceUtil.getColor(R.color.fence_scan_cover_color),
                ResourceUtil.getColor(R.color.fence_scan_line_color)
            )
            mCurrentEditFence!!.isCanEdit = true
            mCurrentEditFence!!.warningAreaInfo = areaInfo
        }
    }

    @JvmStatic
    fun addDistrictFenceModel(areaInfo: WarningAreaInfo) {
        val districtFenceModel: BaseDistrictFenceModel? = mapProxy?.createDistrictFenceModel()
        if (districtFenceModel != null) {
            districtFenceModel.setFenceConfig(
                ResourceUtil.getColor(R.color.fence_cover_color),
                ResourceUtil.getColor(R.color.fence_cover_color),
                ColorManager.getDistrictFenceLineColor(),
                ResourceUtil.getColor(R.color.fence_scan_cover_color),
                ResourceUtil.getColor(R.color.fence_scan_line_color)
            )
            districtFenceModel.isCanEdit = true
            districtFenceModel.updateWarningAreaInfo(areaInfo)
            // 添加到本地记录
            mDistrictFenceMap[areaInfo.id] = districtFenceModel
            if (LocalMapConfig.IS_NOFLY_ZONE_SHOW_DRONE) {
                for (monitorModel in mMonitorModelMap.values) {
                    if (monitorModel.data != null && monitorModel.data.status != MonitorDevice.DEVICE_STATUS.POWER_OFF) {
                        districtFenceModel.checkMonitorInFence(monitorModel)
                    }
                }
                for (droneModel in mDroneMap.values) {
                    if (droneModel?.data != null && droneModel.data.state != MonitorDevice.DEVICE_STATUS.POWER_OFF) {
                        districtFenceModel.checkDroneInFence(droneModel)
                    }
                }
                for (droneModel in mShipMap.values) {
                    if (droneModel.data != null && droneModel.data.state != MonitorDevice.DEVICE_STATUS.POWER_OFF) {
                        when (droneModel.data.type) {
                            Drone.DRONE_TYPE.SHIP_OFFICIAL, Drone.DRONE_TYPE.SHIP_CONTAINER,
                            Drone.DRONE_TYPE.SHIP_PASSENGER, Drone.DRONE_TYPE.SHIP_BULK,
                            Drone.DRONE_TYPE.SHIP_TUG, Drone.DRONE_TYPE.SHIP_CRUISE,
                            Drone.DRONE_TYPE.SHIP_OTHER ->
                                districtFenceModel.checkDroneInFence(droneModel)
                        }
                    }
                }
            }
        }
    }

    @JvmStatic
    fun currentEditFenceIsPolyon(): Boolean {
        if (mCurrentEditFence != null) {
            if (mCurrentEditFence!!.fenceLatLngs.size >= LocalMapConfig.FENCE_MIN_POINTS) {
                return true
            }
        }
        return false
    }

    @JvmStatic
    fun finishCurrentEditFence() {
        var isFinish = false
        if (mCurrentEditFence != null) {
            if (mCurrentEditFence!!.isCircle) {
                isFinish = true
            } else {
                if (mCurrentEditFence!!.fenceLatLngs.size >= LocalMapConfig.FENCE_MIN_POINTS) {
                    isFinish = true
                }
            }
            if (isFinish) {
                OperationObserver.notifyFinishCurrentEditFence(mCurrentEditFence?.warningAreaInfo) { success, warningAreaInfo ->
                    if (success) {
                        if (mCurrentEditFence != null && warningAreaInfo != null) {
                            mCurrentEditFence!!.id = warningAreaInfo.id
                            mCurrentEditFence!!.updateWarningAreaInfo(warningAreaInfo)
                            mCurrentEditFence!!.onEditFinish()
                            mDistrictFenceMap[warningAreaInfo.id] = mCurrentEditFence!!
                        } else {
                            mCurrentEditFence!!.erase()
                            mCurrentEditFence = null
                        }
                        mCurrentEditFenceId = ""
                    } else {
                        if (mCurrentEditFence != null) {
                            ToastUtil.makeShortText(R.string.toast_area_upload_fail)
                            if (TextUtils.isEmpty(mCurrentEditFence!!.id)) {
                                mCurrentEditFence!!.erase()
                                mCurrentEditFence = null
                            } else {
                                mCurrentEditFence!!.onEditFinish()
                            }
                        }
                        mCurrentEditFenceId = ""
                    }
                }
            }
        }
    }

    @JvmStatic
    fun deleteCurrentEditFenceModel() {
        if (mCurrentEditFence != null) {
            var isClearId = true
            if (!TextUtils.isEmpty(mCurrentEditFence!!.id)) {
                val districtFenceModel = mDistrictFenceMap.remove(
                    mCurrentEditFence!!.id
                )
                if (districtFenceModel != null) {
                    val warningAreaInfo = districtFenceModel.warningAreaInfo
                    if (warningAreaInfo != null && !TextUtils.isEmpty(warningAreaInfo.id)) {
                        isClearId = false
                        OperationObserver.notifyDeleteWarningArea(warningAreaInfo) { success, areaInfo ->
                            mCurrentEditFenceId = ""
                        }
                    }
                }
            }
            if (isClearId) {
                mCurrentEditFenceId = ""
            }
            mCurrentEditFence!!.erase()
        }
    }

    @Synchronized
    @JvmStatic
    fun stopAllSound() {
        for (monitorModel in mMonitorModelMap.values) {
            monitorModel.clearSound()
        }
        for (fenceModel in mDistrictFenceMap.values) {
            fenceModel.clearSound()
        }
        WarningManager.getInstance().stopAllSound()
    }

    @Synchronized
    @JvmStatic
    fun stopVibrator() {
        WarningManager.getInstance().stopVibrator()
    }

    @Synchronized
    @JvmStatic
    fun checkSound() {
        for (monitorModel in mMonitorModelMap.values) {
            monitorModel.checkSound()
        }
        for (fenceModel in mDistrictFenceMap.values) {
            fenceModel.checkSound()
        }
    }

    @Synchronized
    @JvmStatic
    fun checkVibrator() {
        var isVibrator = false
        for (monitorModel in mMonitorModelMap.values) {
            if (monitorModel.checkVibrator().also { isVibrator = it }) {
                break
            }
        }
        if (!isVibrator) {
            for (fenceModel in mDistrictFenceMap.values) {
                fenceModel.checkVibrator()
            }
        }
    }

    private val checkShowedTitleOverlayRunnable = Runnable { }

    @JvmStatic
    fun getShowedDroneModels(): Map<String, BaseDroneModel> {
        return showedDroneModels
    }

    @JvmStatic
    fun removeShowedDroneModel(id: String) {
        HandlerUtils.getDataHandler().post {
            if (showedDroneModels.containsKey(id)) {
                showedDroneModels.remove(id)
            }
        }
    }

    @JvmStatic
    fun recordShowedDroneModel(id: String, baseDroneModel: BaseDroneModel) {
        HandlerUtils.getDataHandler().post {
            if (!showedDroneModels.containsKey(id)) {
                showedDroneModels[id] = baseDroneModel
            }
        }
    }

    @JvmStatic
    fun checkShowedTitleOverlay() {
        HandlerUtils.getDataHandler().removeCallbacks(checkShowedTitleOverlayRunnable);
        HandlerUtils.getDataHandler().postDelayed(checkShowedTitleOverlayRunnable, 200);
        // 超管类用瓦片图显示
        if (mapProxy?.isShowTitleOverlay() == true) {
            // 超管类用瓦片图显示
            mapProxy?.showTitleOverlay(true)
            return
        }
        mapProxy?.showTitleOverlay(false)
    }

    private val droneDistanceObserver: IDroneDistanceObserver = object : IDroneDistanceObserver {
        override fun onAddShow(key: String, value: SpannableStringBuilder): Boolean {
            if (!mShowDroneDistanceMap.containsKey(key)) {
                mShowDroneDistanceMap[key] = value
                return true
            }
            return false
        }

        override fun onDeleteShow(key: String): Boolean {
            if (mShowDroneDistanceMap.containsKey(key)) {
                mShowDroneDistanceMap.remove(key)
                return true
            }
            return false
        }

        override fun onUpdate(key: String, value: SpannableStringBuilder): Boolean {
            if (mShowDroneDistanceMap.containsKey(key)) {
                mShowDroneDistanceMap[key] = value
                return true
            }
            return false
        }
    }

    private val latitudeLongitudeListener: ILatitudeLongitudeListener = object : ILatitudeLongitudeListener {
        override fun onArriveDestination(latLng: MyLatLng, isFirst: Boolean) {
            // 进行经纬度查询地址名称进行语音播报
            mapProxy?.getAddressNameByLatlng(latLng,
                object : IGetDestinationInfoCallback {
                    override fun onSearchKeywordSuccess(destinationName: List<MyGeocodeAddress>) {
                    }

                    override fun onSearchLatlngSuccess(
                        destinationName: String,
                        targetLatlng: MyLatLng
                    ) {
                        var tipContent: String? = ""
                        tipContent = if (isFirst) {
                            ResourceUtil.getContent(
                                R.string.speech_monitor_destination_create_tip,
                                destinationName
                            )
                        } else {
                            ResourceUtil.getContent(
                                R.string.speech_monitor_destination_changed_tip,
                                destinationName
                            )
                        }
                        if (!TextUtils.isEmpty(tipContent)) {
                            WarningManager.getInstance().startFlushPlay(tipContent, 2, false)
                        }
                    }
                })
        }

        override fun onPushArriveDestination(
            taskId: Long,
            monitorId: String?,
            latitude: Double,
            longitude: Double,
            complete: (Boolean) -> Unit
        ) {
            NetManager.arriveDestination(taskId,monitorId, latitude, longitude, object: StringHttpResponseHandler() {
                override fun onSuccess(statusCode: Int, content: String?) {
                    XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "setAttack statusCode:%d , content:%s", statusCode, content);
                    complete.invoke(true)
                }
            })
        }
    }

    private val mapStatusListener: IMapStatusListener = object : IMapStatusListener {
        override fun onMapLoaded() {
            onMapStatusChanged(CURRENT_ZOOM_LEVEL)
        }

        override fun onMapStatusChanged(currentZoomLevel: Float) {
            if (CURRENT_ZOOM_LEVEL < LocalMapConfig.SHOW_ANIMATION_LEVEL) {
                LocalMapConfig.SHOW_ANIMATION = false
            } else {
                LocalMapConfig.SHOW_ANIMATION = true
            }
            if (AppConfig.SHOW_MONITOR_ID) {
                if (CURRENT_ZOOM_LEVEL < LocalMapConfig.SHOW_NAME_TV_LEVEL) {
                    LocalMapConfig.SHOW_NAME_TV = false
                } else {
                    LocalMapConfig.SHOW_NAME_TV = true
                }
            }
            for (monitorModel in mMonitorModelMap.values) {
                if (monitorModel?.data != null && monitorModel.data.status != MonitorDevice.DEVICE_STATUS.POWER_OFF) {
                    monitorModel.onMapStatusChange(currentZoomLevel)
                }
            }
            for (droneModel in mDroneMap.values) {
                if (droneModel?.data != null && droneModel.data.state != MonitorDevice.DEVICE_STATUS.POWER_OFF) {
                    droneModel.onMapStatusChange(currentZoomLevel)
                }
            }
            for (droneModel in mAircraftMap.values) {
                if (droneModel?.data != null && droneModel.data.state != MonitorDevice.DEVICE_STATUS.POWER_OFF) {
                    droneModel.onMapStatusChange(currentZoomLevel)
                }
            }
            for (droneModel in mShipMap.values) {
                if (droneModel?.data != null && droneModel.data.state != MonitorDevice.DEVICE_STATUS.POWER_OFF) {
                    droneModel.onMapStatusChange(currentZoomLevel)
                }
            }
            // 遍历找到当前显示区域内的设备
            for (monitorModel in mMonitorModelMap.values) {
                if (monitorModel?.data != null && monitorModel.data.status != MonitorDevice.DEVICE_STATUS.POWER_OFF) {
                    if (visibleBounds.contains(monitorModel.data.myLatLng)) {
                        mLookMonitorModelMap[monitorModel.monitorId] = monitorModel
                    } else {
                        mLookMonitorModelMap.remove(monitorModel.monitorId)
                    }
                }
            }
            if (videoModel != null) {
                videoModel?.onMapStatusChange(currentZoomLevel)
            }
        }
    }

    @JvmStatic
    @get:Synchronized
    @set:Synchronized
    var currentSelectMonitorId: String?
        get() = mCurrentSelectMonitorId
        set(value) {
            if (TextUtils.isEmpty(value)
                && TextUtils.isEmpty(mCurrentSelectMonitorId)
            ) {
                return
            }
            mCurrentSelectMonitorId = value ?: ""
            if (!TextUtils.isEmpty(value)) {
                val monitorModel = getMonitorModel(mCurrentSelectMonitorId)
                if (monitorModel != null && monitorModel.data != null) {
                    setMemoryCurrentFrequencyRangeList(monitorModel.data.frequencyRange)
                     monitorModel.data.frequencyRange?.apply {
                         currentFrequencyRangeList = this
                    }
                }
            } else {
                clearMemoryCurrentFrequencyRangeList()
                clearCurrentFrequencyRangeList()
            }
        }

    val currentSelectDevice: MonitorDevice?
        get() {
            val baseMonitorModel = currentSelectMonitorModel
            if (baseMonitorModel != null) {
                return baseMonitorModel.data
            }
            return null
        }

    val currentSelectMonitorDefaultFrequency: List<FrequencyRangeInfo>?
        get() {
            val baseMonitorModel = currentSelectMonitorModel
            if (baseMonitorModel != null) {
                return baseMonitorModel.data.defaultFrequency
            }
            return null
        }

    @JvmStatic
    fun recevieVideoDatas(videos: List<VideoInfo?>?) {
        if (videoModel == null || videoModel?.videos == null || (videoModel?.videos?.size
                ?: 0) <= 0
        ) {
            if (videos != null) {
                for (video in videos) {
                    if (video != null && !TextUtils.isEmpty(video.videoId)) {
                        //坐标转换，原始数据时WGS-84
                        video.myLatLng = mapProxy?.convertWGS84LatLng(video.myLatLng)
                        addVideoInfo(video)
                    }
                }
            }
        } else {
            checkVideos(videos)
        }
    }

    @JvmStatic
    fun recevieHttpWarningAreaData(districtFenceModels: List<WarningAreaInfo?>?) {
        if (districtFenceModels != null) {
            // 请求回来的预警区id列表
            val warningAreaIds: MutableList<String?> = ArrayList()
            // 本地记录的预警区id列表
            val copyLocationItemIds: MutableSet<String?> = HashSet()
            copyLocationItemIds.addAll(mDistrictFenceMap.keys)
            // 移除正在编辑的电子围栏
            copyLocationItemIds.remove(mCurrentEditFenceId)
            val iterator: Iterator<String?> = copyLocationItemIds.iterator()

            // 处理新增预警区
            for (areaInfo in districtFenceModels) {
                if (areaInfo != null && !TextUtils.isEmpty(areaInfo.id) && areaInfo.id != mCurrentEditFenceId) {
                    //坐标转换，原始数据时WGS-84
                    areaInfo.centerLatLng = mapProxy?.convertWGS84LatLng(areaInfo.centerLatLng)
                    warningAreaIds.add(areaInfo.id)
                    // 不包含此预警区则新增到地图中
                    if (!copyLocationItemIds.contains(areaInfo.id)) {
                        addDistrictFenceModel(areaInfo)
                    } else {
                        // 包含的预警区 更新数据
                        val districtFenceModel = mDistrictFenceMap[areaInfo.id]
                        if (districtFenceModel != null) {
                            districtFenceModel.updateWarningAreaInfo(areaInfo)
                            if (LocalMapConfig.IS_NOFLY_ZONE_SHOW_DRONE) {
                                for (monitorModel in mMonitorModelMap.values) {
                                    if (monitorModel?.data != null && monitorModel.data.status != MonitorDevice.DEVICE_STATUS.POWER_OFF) {
                                        districtFenceModel.checkMonitorInFence(monitorModel)
                                    }
                                }
                                for (droneModel in mDroneMap.values) {
                                    if (droneModel?.data != null && droneModel.data.state != MonitorDevice.DEVICE_STATUS.POWER_OFF) {
                                        districtFenceModel.checkDroneInFence(droneModel)
                                    }
                                }
                                for (droneModel in mShipMap.values) {
                                    if (droneModel?.data != null && droneModel.data.state != MonitorDevice.DEVICE_STATUS.POWER_OFF) {
                                        when (droneModel.data.type) {
                                            Drone.DRONE_TYPE.SHIP_OFFICIAL, Drone.DRONE_TYPE.SHIP_CONTAINER,
                                            Drone.DRONE_TYPE.SHIP_PASSENGER, Drone.DRONE_TYPE.SHIP_BULK,
                                            Drone.DRONE_TYPE.SHIP_TUG, Drone.DRONE_TYPE.SHIP_CRUISE,
                                            Drone.DRONE_TYPE.SHIP_OTHER ->
                                                districtFenceModel.checkDroneInFence(droneModel)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 处理失效预警区
            while (iterator.hasNext()) {
                val itemId = iterator.next()
                if (!TextUtils.isEmpty(itemId)) {
                    // 不包含id时从地图上删除预警区
                    if (!warningAreaIds.contains(itemId)) {
                        val districtFenceModel = mDistrictFenceMap.remove(itemId)
                        districtFenceModel?.erase()
                    }
                }
            }

            //            int dataSize = warningAreaIds.size();
//            for (int i = 0; i < districtFenceCount; i++) {
//                Random random = new Random();
//                int index = random.nextInt(dataSize);
//                String itemId;
//                if (index < dataSize) {
//                    itemId = warningAreaIds.remove(index);
//                } else {
//                    itemId = warningAreaIds.remove(dataSize - 1);
//                }
//                BaseDistrictFenceModel districtFenceModel = mDistrictFenceMap.remove(itemId);
//                if (districtFenceModel != null) {
//                    // 从地图上移除预警区
//                    districtFenceModel.erase();
//                }
//            }
        }
    }

    @JvmStatic
    fun recevieHttpShipData(drones: List<Drone?>?) {
        if (drones != null) {
            val shipList: MutableList<Drone> = ArrayList()
            val shipPostionMap: MutableMap<String?, MyLatLng?> = HashMap()
            for (ship in drones) {
                if (ship != null) {
                    //坐标转换，原始数据时WGS-84
                    ship.setLatLng(mapProxy?.convertWGS84LatLng(ship.myLatLng))
                    shipList.add(ship)
                    shipPostionMap[ship.itemId] = ship.myLatLng
                }
            }
            mShipPositionMap.clear()
            mShipPositionMap.putAll(shipPostionMap)
            // 处理船类数据
            if (mShipMap.size <= 0) {
                for (drone in shipList) {
                    if (drone != null) {
                        if (drone.state == MonitorDevice.DEVICE_STATUS.POWER_ON) {
                            newShip(drone)
                        }
                    }
                }
            } else {
                checkShips(shipList)
            }
        }
    }

    @JvmStatic
    fun receiveScanDroneData(droneData: Drone) {
        val itemId = droneData.itemId
        if (itemId.isNullOrEmpty()) {
            return
        }
        //坐标转换，原始数据时WGS-84
        mapProxy?.convertWGS84LatLng(droneData.myLatLng)?.let {
            droneData.setLatLng(it)
        }
        // 处理无人机
        if (!containsDroneKey(itemId)) {
            newDrone(droneData)
        } else {
            // 包含的无人机 更新数据
            val droneModel = getDroneModel(itemId)
            if (droneModel?.updateDrone(droneData) == true) {
                // 无人机有更新的话检测是否在设备中
                checkInAreaDrone(droneModel)
                // 检测信息显示框
                mapProxy?.droneInfoUpdate(droneData)
            }
        }
    }

    @JvmStatic
    fun receiveHttpDroneData(drones: List<Drone?>?) {
        val droneList: MutableList<Drone> = ArrayList()
        //            List<Drone> aircraftList = new ArrayList<>();
        drones?.forEach { drone ->
            if (drone != null) {
                //坐标转换，原始数据时WGS-84
                mapProxy?.convertWGS84LatLng(drone.myLatLng)?.let {
                    drone.setLatLng(it)
                }
                when (drone.markerType) {
                    Drone.MARKER_TYPE.DRONE -> droneList.add(drone)
                    Drone.MARKER_TYPE.AIRCRAFT -> {}
                }
            }
        }
        // 处理无人机
        if (mDroneMap.size <= 0) {
            drones?.forEach { drone ->
                if (drone != null) {
                    if (drone.state == MonitorDevice.DEVICE_STATUS.POWER_ON) {
                        newDrone(drone)
                    }
                }
            }
        } else {
            checkDrones(droneList)
        }
        //            // 处理民航机战斗机等
//            if (mAircraftMap.size() <= 0) {
//                for (Drone drone : aircraftList) {
//                    if (drone != null) {
//                        if (drone.getState() == MonitorDevice.DEVICE_STATUS.POWER_ON) {
//                            newAircraft(drone);
//                        }
//                    }
//                }
//            } else {
//                checkAircrafts(aircraftList);
//            }
    }

    val shipPositions: List<MyLatLng?>
        // -------------- 用户热力图实现 ----------------------------------
        get() {
            val shipPositins: MutableList<MyLatLng?> =
                ArrayList()
            shipPositins.addAll(mShipPositionMap.values)
            return shipPositins
        }

    // -------------- 用户热力图实现 ----------------------------------
    @JvmStatic
    fun checkVideos(videos: List<VideoInfo?>?) {
        if (videos != null) {
            // 请求回来的视频id列表
            val newVideoIds: MutableList<String> = ArrayList()
            // 本地记录的视频id列表
            val copyLocationItemIds = ArrayList<String>()
            if (videoModel != null) {
                videoModel?.videos?.keys?.let {
                    copyLocationItemIds.addAll(it)
                }
            }
            val iterator: Iterator<String> = copyLocationItemIds.iterator()
            // 本地隐藏的视频id列表
            val copyLocationHideItemIds = HashSet<String>()
            if (videoModel != null) {
                videoModel?.hideVideos?.keys?.let {
                    copyLocationHideItemIds.addAll(it)
                }
            }
            val hideIterator: Iterator<String> = copyLocationHideItemIds.iterator()
            for (video in videos) {
                if (video != null && !TextUtils.isEmpty(video.videoId)) {
                    newVideoIds.add(video.videoId)
                    if (!copyLocationItemIds.contains(video.videoId)) {
                        if (!TestConstants.TEST_VIDEO) {
                            //坐标转换，原始数据时WGS-84
                            video.myLatLng = mapProxy?.convertWGS84LatLng(video.myLatLng)
                        }
                        addVideoInfo(video)
                    }
                }
            }
            // 处理删除的视频
            while (hideIterator.hasNext()) {
                val videoId = hideIterator.next()
                if (!TextUtils.isEmpty(videoId)) {
                    // 不包含id时从地图上删除视频
                    if (!newVideoIds.contains(videoId)) {
                        if (videoModel != null) {
                            // 从地图上移除视频
                            videoModel?.eraseMarker(videoId)
                        }
                    }
                }
            }
            // 处理删除的视频
            while (iterator.hasNext()) {
                val videoId = iterator.next()
                if (!TextUtils.isEmpty(videoId)) {
                    // 不包含id时从地图上删除视频
                    if (!newVideoIds.contains(videoId)) {
                        if (videoModel != null) {
                            // 从地图上移除视频
                            videoModel?.eraseMarker(videoId)
                        }
                    }
                }
            }

            //            int dataSize = newVideoIds.size();
//            for (int i = 0; i < videoCount; i++) {
//                Random random = new Random();
//                int index = random.nextInt(dataSize);
//                String videoItemId;
//                if (index < dataSize) {
//                    videoItemId = newVideoIds.remove(index);
//                } else {
//                    videoItemId = newVideoIds.remove(dataSize - 1);
//                }
//                if (videoModel != null) {
//                    dataSize--;
//                    videoModel.eraseMarker(videoItemId);
//                }
//            }
        } else {
            if (videoModel != null) {
                videoModel?.removeAllMarker()
            }
        }
    }

    /**
     * 检测失效的无人机
     */
    @JvmStatic
    fun checkDrones(drones: List<Drone>?) {
        if (null == drones) {
            return
        }
        // 请求回来的无人机id列表
        val droneItemIds: MutableList<String> = ArrayList()
        // 本地记录的无人机id列表
        val copyLocationItemIds: MutableSet<String> = HashSet()
        copyLocationItemIds.addAll(mDroneMap.keys)
        val iterator: Iterator<String> = copyLocationItemIds.iterator()

        // 处理新增无人机
        for (drone in drones) {
            val itemId = drone.itemId
            if (drone != null && itemId?.isNotEmpty() == true) {
                droneItemIds.add(itemId)
                // 不包含此无人机则新增到地图中
                if (!containsDroneKey(itemId)) {
                    newDrone(drone)
                } else {
                    // 包含的无人机 更新数据
                    val droneModel = getDroneModel(itemId)
                    if (droneModel != null) {
                        // TODO 先去掉进入禁飞区的无人机
                        if (!LocalMapConfig.IS_NOFLY_ZONE_SHOW_DRONE && inDistrictFence(drone.myLatLng)) {
                            delecteDistrictFenceDrone(droneModel)
                            droneModel.erase()
                        } else {
                            if (droneModel.updateDrone(drone)) {
                                // 无人机有更新的话检测是否在设备中
                                checkInAreaDrone(droneModel)
                                // 检测信息显示框
                                mapProxy?.droneInfoUpdate(drone)
                            }
                        }
                    }
                }
            }
        }

        // 处理失效无人机
        while (iterator.hasNext()) {
            val itemId = iterator.next()
            if (!TextUtils.isEmpty(itemId)) {
                // 不包含id时从地图上删除无人机
                if (!droneItemIds.contains(itemId)) {
                    val droneModel = getDroneModel(itemId)
                    // 判断是否是属于显示路线的无人机
                    if (droneModel != null && !droneModel.isShowRoute) {
                        // 从地图上移除无人机
                        removeDroneModel(itemId)
                    }
                }
            }
        }
    }

    @JvmStatic
    fun checkAircrafts(planes: List<Drone>?) {
        if (null == planes) {
            return
        }
        // 请求回来的飞机id列表
        val droneItemIds: MutableList<String> = ArrayList()
        // 本地记录的飞机id列表
        val copyLocationItemIds = ArrayList<String>()
        copyLocationItemIds.addAll(mAircraftMap.keys)
        val iterator: Iterator<String> = copyLocationItemIds.iterator()

        // 处理新增飞机
        for (plane in planes) {
            val itemId = plane.itemId
            if (plane != null && itemId?.isNotEmpty() == true) {
                //坐标转换，原始数据时WGS-84

                plane.setLatLng(mapProxy?.convertWGS84LatLng(plane.myLatLng))

                droneItemIds.add(itemId)
                // 不包含此飞机则新增到地图中
                if (!mAircraftMap.containsKey(itemId)) {
                    newAircraft(plane)
                } else {
                    // 包含的飞机 更新数据
                    val droneModel = getAircraftModel(itemId)
                    if (droneModel != null) {
                        if (droneModel.updateDrone(plane)) {
                            // 飞机有更新的话检测是否在设备中
                            checkInAreaDrone(droneModel)
                            // 检测信息显示框
                            mapProxy?.droneInfoUpdate(plane)
                        }
                    }
                }
            }
        }

        // 处理失效飞机
        while (iterator.hasNext()) {
            val itemId = iterator.next()
            if (!TextUtils.isEmpty(itemId)) {
                // 不包含id时从地图上删除飞机
                if (!droneItemIds.contains(itemId)) {
                    val droneModel = getAircraftModel(itemId)
                    // 判断是否是属于显示路线的飞机
                    if (droneModel != null && !droneModel.isShowRoute) {
                        // 从地图上移除飞机
                        removeAircraftModel(itemId)
                    }
                }
            }
        }

        //        int dataSize = droneItemIds.size();
//        for (int i = 0; i < airCount; i++) {
//            Random random = new Random();
//            int index = random.nextInt(dataSize);
//            String itemId;
//            if (index < dataSize) {
//                itemId = droneItemIds.remove(index);
//            } else {
//                itemId = droneItemIds.remove(dataSize - 1);
//            }
//            // 从地图上移除飞机
//            removeAircraftModel(itemId);
//        }
    }

    @JvmStatic
    fun checkShips(drones: List<Drone>?) {
        if (null == drones) {
            return
        }
        // 请求回来的船舶id列表
        val droneItemIds: MutableList<String> = ArrayList()
        // 本地记录的船舶id列表
        val copyLocationItemIds: MutableSet<String> = HashSet()
        copyLocationItemIds.addAll(mShipMap.keys)
        val iterator: Iterator<String> = copyLocationItemIds.iterator()

        // 处理新增船舶
        for (drone in drones) {
            if (drone == null || TextUtils.isEmpty(drone.itemId)) {
                continue
            }
            droneItemIds.add(drone.itemId)
            // 不包含此船舶则新增到地图中
            if (!containsShipKey(drone.itemId)) {
                newShip(drone)
            } else {
                // 包含的船舶 更新数据
                val droneModel = getShipModel(drone.itemId)
                if (droneModel != null) {
                    if (droneModel.updateDrone(drone)) {
                        // 船舶有更新的话检测是否在设备中
                        checkInAreaDrone(droneModel)
                        // 检测信息显示框
                        mapProxy?.droneInfoUpdate(drone)
                    }
                }
            }
        }

        // 处理失效船舶
        while (iterator.hasNext()) {
            val itemId = iterator.next()
            if (TextUtils.isEmpty(itemId)) {
                continue
            }
            // 不包含id时从地图上删除船舶
            if (droneItemIds.contains(itemId)) {
                continue
            }
            val droneModel = getShipModel(itemId)
            // 判断是否是属于显示路线的船舶
            if (!droneModel!!.isShowRoute) {
                // 从地图上移除船舶
                removeShipModel(itemId)
            }
        }
    }

    /**
     * 收到设备信息
     *
     * @param monitorDevices
     */
    @JvmStatic
    fun recevieMonitorsUpdate(monitorDevices: List<MonitorDevice?>?) {
        if (monitorDevices == null) {
            return
        }
        // 请求回来的设备id列表
        val monitorIds: MutableList<String?> = ArrayList()
        // 本地记录的设备id列表
        val copyLocationMonitorIds: MutableSet<String?> = HashSet()
        copyLocationMonitorIds.addAll(mMonitorModelMap.keys)
        val iterator: Iterator<String?> = copyLocationMonitorIds.iterator()

        // 当前设备数量不为0，表示需要更新
        for (device in monitorDevices) {
            // device是空或没有设备编号，不处理
            if (null == device || TextUtils.isEmpty(device.monitorId)) {
                continue
            }
            monitorIds.add(device.monitorId)
            receiveMonitorUpdate(device)
        }

        // 处理失效船舶
        while (iterator.hasNext()) {
            val monitorId = iterator.next()
            if (TextUtils.isEmpty(monitorId)) {
                continue
            }
            // 不包含id时从地图上删除船舶
            if (monitorIds.contains(monitorId)) {
                continue
            }
            removeMonitorModel(monitorId)
        }

        //        int dataSize = monitorIds.size();
//        for (int i = 0; i < monitorCount; i++) {
//            Random random = new Random();
//            int index = random.nextInt(dataSize);
//            String itemId;
//            if (index < dataSize) {
//                itemId = monitorIds.remove(index);
//            } else {
//                itemId = monitorIds.remove(dataSize - 1);
//            }
//            removeMonitorModel(itemId);
//        }
    }

    @JvmStatic
    fun receiveMonitorUpdate(monitor: MonitorDevice) {
        // TODO 可从这儿查单独设备的数据
//        if (monitor.getMonitorId().equals("Controlcenter-beijing")) {
//            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, Constants.TAG_TEST + "请求到设备数据:" + monitor.toString());
//        }
        if (!TestConstants.TEST_MONITOR) {
            //坐标转换，设备原始数据时WGS-84
            mapProxy?.convertLatLng(monitor)
        }
        // 当前设备是否在Map中
        if (containsMonitorKey(monitor.monitorId)) {
            val model = getMonitorModel(monitor.monitorId)
            // 处理掉线
            if (monitor.status == MonitorDevice.DEVICE_STATUS.POWER_OFF) {
                playExceptionWarning()
                model!!.erase()
                if (monitor.monitorId == mCurrentSelectMonitorId) {
                    // 通知外部状态变了，关闭当前的操作框
                    DataObserver.getInstance().clearSelectMonitor()
                    mapProxy?.hideWindowsInfo()
                }
            } else {
                model!!.updateMonitor(monitor)
                if (monitor.contains(mCurrentSelectMonitorId)) {
                    val childMonitor = monitor.childMonitorDeviceMap[mCurrentSelectMonitorId]
                    // 设置当前选择的设备的频段，用来展示使用
                    currentFrequencyRangeList = childMonitor?.frequencyRange ?: mutableListOf()
                    val markerDataModel = mapProxy?.getCurrentSelectedMKDataModel()
                    markerDataModel?.data = monitor
                    // 通知显示出来的弹窗信息
                    DataObserver.getInstance().notifyUpdateShowWindowData(markerDataModel)
                }
                // 检查当前显示的设备信息弹窗
                mapProxy?.monitorInfoUpdate(monitor)
            }
        } else {
            // 设备不在Map中，且设备在线，直接加载到地图上
            if (monitor.status >= MonitorDevice.DEVICE_STATUS.POWER_ON) {
                val model = newMonitor(monitor)

                // 检查所有无人机，是否在设备中
                checkMonitorWithDrone(model)

                // 检车所有电子围栏
                checkMonitorInFence(model)
            }
        }
    }

    private fun playExceptionWarning() {
//        if (soundIdExceptionWarning == soundIdDefault) {
//            soundIdExceptionWarning = WarningManager.getInstance().deviceExceptionStartPlay();
//            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "播放异常警报！！！ | soundIdExceptionWarning:%d", soundIdExceptionWarning);
//            HandlerUtils.getThreadHanlder().postDelayed(delayResetExceptionSoundId, 20 * 1000);
//        }
    }

    private val delayResetExceptionSoundId: Runnable = object : Runnable {
        override fun run() {
            WarningManager.getInstance().stopWarning(soundIdExceptionWarning)
            WarningManager.getInstance().stopVibrator()
            soundIdExceptionWarning = soundIdDefault
            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "暂停异常警报！！！")
            HandlerUtils.getThreadHanlder().removeCallbacks(this)
        }
    }

    /**
     * 新增设备，或者设备状态变化的时候，检查当前设备周边是否有无人机
     *
     * @param monitorModel
     */
    private fun checkMonitorWithDrone(monitorModel: BaseMonitorModel?) {
        if (monitorModel != null) {
            val iter: Iterator<*> = mDroneMap.entries.iterator()
            while (iter.hasNext()) {
                val entry = iter.next() as Map.Entry<String, BaseDroneModel>
                val droneModel = entry.value
                if (droneModel.isCheckAreaAndAlarm) {
                    val drone = droneModel.data
                    if (null != drone && drone.state == MonitorDevice.DEVICE_STATUS.POWER_ON) {
                        val checkResultModel = monitorModel.isPointInDeviceArea(droneModel.data)
                        if (!TextUtils.isEmpty(checkResultModel.id) && checkResultModel.invadeType != BaseMonitorModel.INVADE_AREA_TYPE.NO) {
                            val invadeMonitor = monitorModel.getMonitorModel(checkResultModel.id)
                            invadeMonitor.addDrone(drone, checkResultModel.invadeType)
                            droneModel.checkMonitorResultModel(checkResultModel)
                        }
                    }
                }
            }
        }
    }

    /**
     * 检查当前无人机在哪个设备中
     */
    private fun checkInAreaDrone(droneModel: BaseDroneModel?) {
        if (null == droneModel) {
            return
        }
        val drone = droneModel.data ?: return

        if (!droneModel.isCheckAreaAndAlarm) {
            XAppLogger.getInstance()
                .writeLog("检查无人机 类型不符合检测类型！！！")
            return
        }

        checkDroneInFence(droneModel)

        val checkResultModel = findPosition(drone)

        // 查找无人机所在的设备ID
        val currentMonitorId = checkResultModel.id
        val currentInvadeType = checkResultModel.invadeType

        //        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_DRONE, "碰撞设备ID:" + currentMonitorId);

        // 取消报警设备
        for (monitorResultModel in droneModel.invadeResultModels) {
            if (!TextUtils.isEmpty(monitorResultModel.id)) {
                // 获取无人机出现过的设备Model
                val monitorModel = getMonitorModel(monitorResultModel.id)
                if (monitorModel != null) {
                    var deleteDeviceAllAreaDrone = false
                    XAppLogger.getInstance().writeLog(
                        XAppLogger.LOG_TYPE.TYPE_MONITOR, "取消报警遍历 | currentMonitorId:" +
                                currentMonitorId + " | 中包含的id:" + monitorModel.data.monitorId
                    )
                    if (TextUtils.equals(currentMonitorId, monitorModel.data.monitorId)) {
                        XAppLogger.getInstance().writeLog(
                            XAppLogger.LOG_TYPE.TYPE_MONITOR,
                            ("设备id相同 | currentInvadeType:" + currentInvadeType
                                    + " | monitorResultModel.getInvadeType():" + monitorResultModel.invadeType)
                        )
                        if (currentInvadeType != monitorResultModel.invadeType) {
                            XAppLogger.getInstance()
                                .writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "区域类型不同")
                            deleteDeviceAllAreaDrone = true
                        }
                    } else {
                        XAppLogger.getInstance().writeLog(
                            XAppLogger.LOG_TYPE.TYPE_MONITOR,
                            "设备id不同需要删除无人机记录"
                        )
                        deleteDeviceAllAreaDrone = true
                    }
                    if (deleteDeviceAllAreaDrone) {
                        // 删除无人机id
                        monitorModel.deleteDrone(drone)
                        //删除无人机出现过的设备id
                        droneModel.deleteInvadeResultModel(monitorModel.data.monitorId)
                    }
                }
            }
        }

        // 找到设备ID
        if (!TextUtils.isEmpty(currentMonitorId)) {
            val monitorModel = getMonitorModel(currentMonitorId)

            if (monitorModel != null) {
                // 添加无人机到设备，设备添加到无人机

                monitorModel.addDrone(drone, checkResultModel.invadeType)
                droneModel.checkMonitorResultModel(checkResultModel)
            }
        }
    }

    /**
     * 新建一个设备
     *
     * @param device
     * @return
     */
    private fun newMonitor(device: MonitorDevice): BaseMonitorModel? {
        XAppLogger.getInstance().writeLog(
            XAppLogger.LOG_TYPE.TYPE_MONITOR,
            "增加新设备:$device"
        )
        val monitorModel: BaseMonitorModel? = mapProxy?.createMonitorModel(device)
        monitorModel?.updateMonitor()
        if (monitorModel != null) {
            device.monitorId?.let { putMonitorModel(it, monitorModel) }
        }
        return monitorModel
    }

    private fun newDrone(drone: Drone) {
        newDrone(drone, false, true)
    }

    private fun newAircraft(drone: Drone) {
        newAircraft(drone, false, false)
    }

    @JvmStatic
    fun delecteDistrictFenceDrone(droneModel: BaseDroneModel?) {
        if (droneModel == null) {
            return
        }
        val iter: Iterator<*> = mDistrictFenceMap.entries.iterator()
        while (iter.hasNext()) {
            val entry = iter.next() as Map.Entry<String, BaseDistrictFenceModel>
            val districtFenceModel = entry.value
            districtFenceModel.deleteDrone(droneModel)
        }
    }

    @JvmStatic
    fun inDistrictFence(latLng: MyLatLng?): Boolean {
        // TOOD 如果在禁飞区内则不显示处理
        val iter: Iterator<*> = mDistrictFenceMap.entries.iterator()
        while (iter.hasNext()) {
            val entry = iter.next() as Map.Entry<String, BaseDistrictFenceModel>
            val districtFenceModel = entry.value
            if (districtFenceModel.checkDroneInFence(latLng)) {
                return true
            }
        }
        return false
    }

    /**
     * 新建一个无人机
     *
     * @param drone
     */
    @JvmStatic
    fun newDrone(drone: Drone, showRoute: Boolean, isCheckInvade: Boolean) {
        val baseDroneModel: BaseDroneModel? = mapProxy?.createDroneModel(drone)
        val itemId = drone.itemId
        if (baseDroneModel != null && itemId?.isNotEmpty() == true) {
            putDroneModel(itemId, baseDroneModel)
            // 判断是否需要显示预警区内的无人机
            if (!LocalMapConfig.IS_NOFLY_ZONE_SHOW_DRONE && inDistrictFence(drone.myLatLng)) {
                baseDroneModel.erase()
            } else {
                if (baseDroneModel.isShowRoute != showRoute) {
                    baseDroneModel.isShowRoute = showRoute
                }
                baseDroneModel.updateDrone()
                if (isCheckInvade) {
                    checkInAreaDrone(baseDroneModel)
                    checkDroneInFence(baseDroneModel)
                }
            }
        }
    }

    private fun newAircraft(plane: Drone, showRoute: Boolean, isCheckInvade: Boolean) {
        val baseDroneModel: BaseDroneModel? = mapProxy?.createDroneModel(plane)
        if (baseDroneModel != null) {
            if (baseDroneModel.isShowRoute != showRoute) {
                baseDroneModel.isShowRoute = showRoute
            }
            baseDroneModel.updateDrone()
            plane.itemId?.let { putAircraftModel(it, baseDroneModel) }
        }
        if (isCheckInvade) {
            checkInAreaDrone(baseDroneModel)
        }
        if (baseDroneModel != null && isCheckInvade) {
            checkDroneInFence(baseDroneModel)
        }
    }

    private fun newShip(ship: Drone, showRoute: Boolean = false, isCheckInvade: Boolean = false) {
        val baseDroneModel: BaseDroneModel? = mapProxy?.createDroneModel(ship)
        if (baseDroneModel != null) {
            if (baseDroneModel.isShowRoute != showRoute) {
                baseDroneModel.isShowRoute = showRoute
            }
            baseDroneModel.updateDrone()
            ship.itemId?.let { putShipModel(it, baseDroneModel) }
        }
        if (isCheckInvade) {
            checkInAreaDrone(baseDroneModel)
        }
        if (baseDroneModel != null && isCheckInvade) {
            checkDroneInFence(baseDroneModel)
        }
    }
    @JvmStatic
    val memoryCurrentFrequencyRangeList: List<FrequencyRangeInfo>
        get() = mMemoryCurrentFrequencyRangeList

    /**
     * 更新最新数据到内存存储的频段列表,用来更新作战控制台频段的显示状态
     */
    @JvmStatic
    fun updateMemoryCurrentFrequencyRangeList() {
        setMemoryCurrentFrequencyRangeList(currentFrequencyRangeList)
    }

    private fun clearMemoryCurrentFrequencyRangeList() {
        mMemoryCurrentFrequencyRangeList.clear()
    }

    /**
     * 更新时机:
     * 1 选中设备时
     * 2 指令发送成功时
     *
     * @param currentFrequencyRangeList
     */
    private fun setMemoryCurrentFrequencyRangeList(currentFrequencyRangeList: MutableList<FrequencyRangeInfo>?) {
        if (currentFrequencyRangeList != null) {
            mMemoryCurrentFrequencyRangeList.clear()
            mMemoryCurrentFrequencyRangeList.addAll(currentFrequencyRangeList)
        } else {
            mMemoryCurrentFrequencyRangeList.clear()
        }
    }

    @JvmStatic
    fun clearCurrentFrequencyRangeList() {
        currentFrequencyRangeList.clear()
        DataObserver.getInstance().updateFPSList()
    }
    @JvmStatic
    val monitorModelMap: Map<String?, BaseMonitorModel>
        get() = mMonitorModelMap
    @JvmStatic
    val droneMap: Map<String, BaseDroneModel>
        get() = mDroneMap
    @JvmStatic
    val aircraftMap: Map<String, BaseDroneModel>
        get() = mAircraftMap
    @JvmStatic
    val shipMap: Map<String, BaseDroneModel>
        get() = mShipMap

    @JvmStatic
    fun containsDroneKey(id: String): Boolean {
        if (mDroneMap != null && mDroneMap.containsKey(id)) {
            return true
        }
        return false
    }

    @JvmStatic
    fun putDroneModel(id: String, data: BaseDroneModel): BaseDroneModel? {
        return mDroneMap.put(id, data)
    }

    @JvmStatic
    fun removeDroneModel(id: String): BaseDroneModel? {
        if (containsDroneKey(id)) {
            val baseDroneModel = mDroneMap.remove(id)
            baseDroneModel!!.erase()
            return baseDroneModel
        }
        return null
    }

    @JvmStatic
    fun getDroneModel(id: String): BaseDroneModel? {
        if (containsDroneKey(id)) {
            return mDroneMap[id]
        }
        return null
    }

    @JvmStatic
    fun containsAircraftKey(id: String): Boolean {
        if (mAircraftMap != null && mAircraftMap.containsKey(id)) {
            return true
        }
        return false
    }

    @JvmStatic
    fun putAircraftModel(id: String, data: BaseDroneModel): BaseDroneModel? {
        return mAircraftMap.put(id, data)
    }

    @JvmStatic
    fun removeAircraftModel(id: String): BaseDroneModel? {
        if (containsAircraftKey(id)) {
            val baseDroneModel = mAircraftMap.remove(id)
            baseDroneModel!!.erase()
            return baseDroneModel
        }
        return null
    }

    @JvmStatic
    fun getAircraftModel(id: String): BaseDroneModel? {
        if (mAircraftMap != null && mAircraftMap.containsKey(id)) {
            return mAircraftMap[id]
        }
        return null
    }

    private fun containsShipKey(id: String): Boolean {
        if (mShipMap != null && mShipMap.containsKey(id)) {
            return true
        }
        return false
    }

    private fun putShipModel(id: String, data: BaseDroneModel): BaseDroneModel? {
        return mShipMap.put(id, data)
    }

    @JvmStatic
    fun removeShipModel(id: String): BaseDroneModel? {
        if (containsShipKey(id)) {
            val baseDroneModel = mShipMap.remove(id)
            baseDroneModel!!.erase()
            return baseDroneModel
        }
        return null
    }

    @JvmStatic
    fun getShipModel(id: String): BaseDroneModel? {
        if (containsShipKey(id)) {
            return mShipMap[id]
        }
        return null
    }

    private fun containsMonitorKey(monitorId: String?): Boolean {
        if (mMonitorModelMap != null && mMonitorModelMap.containsKey(monitorId)) {
            return true
        }
        return false
    }

    @JvmStatic
    fun getMonitorModel(monitorId: String?): BaseMonitorModel? {
        if (containsMonitorKey(monitorId)) {
            return mMonitorModelMap[monitorId]
        }
        return null
    }

    private fun putMonitorModel(monitorId: String, data: BaseMonitorModel): BaseMonitorModel? {
        return mMonitorModelMap.put(monitorId, data)
    }

    private fun removeMonitorModel(monitorId: String?): BaseMonitorModel? {
        if (containsMonitorKey(monitorId)) {
            val baseMonitorModel = mMonitorModelMap.remove(monitorId)
            // 从地图上移除设备
            baseMonitorModel!!.erase()
            return baseMonitorModel
        }
        return null
    }

    @JvmStatic
    val showDroneDistanceList: List<SpannableStringBuilder>
        get() {
            val copyData: MutableList<SpannableStringBuilder> =
                ArrayList()
            copyData.addAll(mShowDroneDistanceMap.values)
            return copyData
        }

    private fun checkMonitorInFence(monitorModel: BaseMonitorModel?) {
        if (monitorModel == null) {
            return
        }
        // 遍历电子围栏
        val iter: Iterator<*> = mDistrictFenceMap.entries.iterator()
        while (iter.hasNext()) {
            val entry = iter.next() as Map.Entry<String, BaseDistrictFenceModel>
            val fenceModel = entry.value
            if (!fenceModel.isEditFinish) {
                fenceModel.checkMonitorInFence(monitorModel)
            }
        }
    }

    private fun checkDroneInFence(droneModel: BaseDroneModel?) {
        if (droneModel == null || droneModel.data == null) {
            return
        }
        if (!droneModel.data.isCheckTargetObject) {
            return
        }
        // 遍历电子围栏
        val iter: Iterator<*> = mDistrictFenceMap.entries.iterator()
        while (iter.hasNext()) {
            val entry = iter.next() as Map.Entry<String, BaseDistrictFenceModel>
            val fenceModel = entry.value
            if (!fenceModel.isEditFinish) {
                fenceModel.checkDroneInFence(droneModel)
            }
        }
    }

    /**
     * 返回设备id和区域类型
     *
     * @param drone
     * @return DroneRecordInvadeModel
     */
    @JvmStatic
    fun findPosition(drone: Drone): DroneRecordInvadeModel {
        var checkResultModel = DroneRecordInvadeModel()
        //判断点pt是否在位置点列表mPoints构成的多边形内。
        val iter: Iterator<*> = mMonitorModelMap.entries.iterator()
        while (iter.hasNext()) {
            val entry = iter.next() as Map.Entry<String, BaseMonitorModel>
            val monitorModel = entry.value
            if (monitorModel.data != null &&
                monitorModel.data.isDisturbDevice() && monitorModel.data.isCheckDroneStatus()
            ) {
                checkResultModel = monitorModel.isPointInDeviceArea(drone)
                if (checkResultModel.invadeType != BaseMonitorModel.INVADE_AREA_TYPE.NO) {
                    return checkResultModel
                }
            }
        }
        return checkResultModel
    }

    @JvmStatic
    fun clickPosition(latitude: Double, longitude: Double): String {
        //判断点pt是否在位置点列表mPoints构成的多边形内。
        val iter: Iterator<*> = mLookMonitorModelMap.entries.iterator()
        while (iter.hasNext()) {
            val entry = iter.next() as Map.Entry<String, BaseMonitorModel>
            val monitorModel = entry.value
            val monitorId = monitorModel.getPointInAttackAreaDeviceId(latitude, longitude)
            if (!TextUtils.isEmpty(monitorId)) {
                return monitorId
            }
        }
        return ""
    }

    /**
     * 移除所有无人机显示
     */
    @JvmStatic
    fun hideAllShips() {
        HandlerUtils.getDataHandler().post {
            mapProxy?.hideWindowsInfo()
            mapProxy?.showTitleOverlay(false)
            val iter: Iterator<*> = mShipMap.entries.iterator()
            while (iter.hasNext()) {
                val entry = iter.next() as Map.Entry<String, BaseDroneModel>
                val droneModel = entry.value
//            for (DroneRecordInvadeModel monitorResultModel : droneModel.getInvadeResultModels()) {
//                BaseMonitorModel monitorModel = getMonitorModel(monitorResultModel.getId());
//                if (monitorModel != null) {
//                    monitorModel.recoverArea(monitorResultModel.getInvadeType());
//                }
//            }
                droneModel.erase()
            }
        }
    }

    /**
     * 显示所有无人机显示
     */
    @JvmStatic
    fun showAllShips() {
        HandlerUtils.getDataHandler().post {
            if (mapProxy?.isShowTitleOverlay() == true) {
                mapProxy?.showTitleOverlay(true)
            } else {
                val iter1: Iterator<*> = mShipMap.entries.iterator()
                while (iter1.hasNext()) {
                    val entry = iter1.next() as Map.Entry<String, BaseDroneModel>
                    val droneModel = entry.value
//                        for (DroneRecordInvadeModel monitorResultModel : droneModel.getInvadeResultModels()) {
//                            BaseMonitorModel monitorModel = getMonitorModel(monitorResultModel.getId());
//                            if (monitorModel != null) {
//                                monitorModel.findDrone(monitorResultModel.getInvadeType());
//                            }
//                        }
                    droneModel.updateDrone()
                }
            }
        }
    }

    /**
     * 移除所有无人机显示
     */
    @JvmStatic
    fun hideAllAircrafts() {
        HandlerUtils.getDataHandler().post {
            mapProxy?.hideWindowsInfo()
            val iter: Iterator<*> = mAircraftMap.entries.iterator()
            while (iter.hasNext()) {
                val entry = iter.next() as Map.Entry<String, BaseDroneModel>
                val droneModel = entry.value
//                        for (DroneRecordInvadeModel monitorResultModel : droneModel.getInvadeResultModels()) {
//                            BaseMonitorModel monitorModel = getMonitorModel(monitorResultModel.getId());
//                            if (monitorModel != null) {
//                                monitorModel.recoverArea(monitorResultModel.getInvadeType());
//                            }
//                        }
                droneModel.erase()
            }
        }
    }

    /**
     * 显示所有无人机显示
     */
    @JvmStatic
    fun showAllAircrafts() {
        HandlerUtils.getDataHandler().post {
            val iter1: Iterator<*> = mAircraftMap.entries.iterator()
            while (iter1.hasNext()) {
                val entry = iter1.next() as Map.Entry<String, BaseDroneModel>
                val droneModel = entry.value
//                        for (DroneRecordInvadeModel monitorResultModel : droneModel.getInvadeResultModels()) {
//                            BaseMonitorModel monitorModel = getMonitorModel(monitorResultModel.getId());
//                            if (monitorModel != null) {
//                                monitorModel.findDrone(monitorResultModel.getInvadeType());
//                            }
//                        }
                droneModel.updateDrone()
            }
        }
    }

    /**
     * 移除所有无人机显示
     */
    @JvmStatic
    fun hideNoflyZoneDrones() {
        HandlerUtils.getDataHandler().post {
            mapProxy?.hideWindowsInfo()
            // 拿出电子围栏中的无人机进行清除处理
            val iter: Iterator<*> = mDistrictFenceMap.entries.iterator()
            while (iter.hasNext()) {
                val entry = iter.next() as Map.Entry<String, BaseDistrictFenceModel>
                val districtFenceModel = entry.value
                if (districtFenceModel.aviationInFenceDroneMap != null && districtFenceModel.aviationInFenceDroneMap.size > 0) {
                    // copy一份数据防止多线程操作异常
                    val copyAviationInFenceDroneMap = Hashtable<String, BaseDroneModel>()
                    copyAviationInFenceDroneMap.putAll(districtFenceModel.aviationInFenceDroneMap)
                    val iterator: Iterator<*> = copyAviationInFenceDroneMap.entries.iterator()
                    while (iterator.hasNext()) {
                        val droneModelEntry = iterator.next() as Map.Entry<String, BaseDroneModel>
                        val droneModel = droneModelEntry.value
                        // 移除电子围栏的记录
                        districtFenceModel.deleteDrone(droneModel)
                        // 移除入侵无人机
                        droneModel.erase()
                    }
                }
            }
        }
    }


    /**
     * 显示所有无人机显示
     */
    @JvmStatic
    fun showAllFlyZoneDrones() {
        HandlerUtils.getDataHandler().post {
            val iter1: Iterator<*> = mDroneMap.entries.iterator()
            while (iter1.hasNext()) {
                val entry = iter1.next() as Map.Entry<String, BaseDroneModel>
                val droneModel = entry.value
                droneModel.updateDrone()
                checkInAreaDrone(droneModel)
                checkDroneInFence(droneModel)
            }
        }
    }


    //##########################################################
    @JvmStatic
    fun showShipRoute(itemId: String, shipHistoryData: ShipRouteHistoryData?) {
        if (shipHistoryData != null) {
            val points = shipHistoryData.points
            if (points != null && !points.isEmpty()) {
                // 获取是否存在地图上
                val baseModel = getShipModel(itemId)
                // TODO 需要处理当船舶不在地图上时的情况，ShiHistoryData中需要鞋底啊船舶数据
                if (baseModel != null) {
                    val baseRouteHistoryData = BaseRouteHistoryData()
                    baseRouteHistoryData.copy(shipHistoryData)
                    baseModel.setRoutePointsData(baseRouteHistoryData)
                }
            }
        }
    }

    /**
     * 显示民航机路线
     *
     * @param planeItemId
     */
    @JvmStatic
    fun showPlaneRoute(planeItemId: String, routeHistoryData: BaseRouteHistoryData?) {
        if (!TextUtils.isEmpty(planeItemId)) {
            // 获取是否存在地图上
            val planeModel = getAircraftModel(planeItemId)
            if (planeModel != null) {
                planeModel.isShowRoute = true
                planeModel.setRoutePointsData(routeHistoryData)
            }
        }
    }

    /**
     * 移除民航机路线
     */
    @JvmStatic
    fun removePlaneRoute(planeItemId: String) {
        if (!TextUtils.isEmpty(planeItemId)) {
            // 获取是否存在地图上
            val planeModel = getAircraftModel(planeItemId)
            if (planeModel != null) {
                if (planeModel.data.state == MonitorDevice.DEVICE_STATUS.POWER_ON) {
                    planeModel.isShowRoute = false
                } else {
                    removeAircraftModel(planeItemId)
                }
            }
        }
    }

    private fun meSendEmptyMessageDelayed(handler: Handler?, what: Int, delayMillis: Long) {
        if (handler != null) {
            handler.removeMessages(what)
            handler.sendEmptyMessageDelayed(what, delayMillis)
        }
    }

    private fun meSendEmptyMessage(handler: Handler?, what: Int) {
        if (handler != null) {
            handler.removeMessages(what)
            handler.sendEmptyMessage(what)
        }
    }

    private fun meSendMessage(handler: Handler?, what: Int, obj: Any) {
        if (handler != null) {
            handler.removeMessages(what)
            val msg = Message.obtain()
            msg.what = what
            msg.obj = obj
            handler.sendMessage(msg)
        }
    }
    // TODO 优化 可以再后台进行请求最大时间和最大区域的数据进行记录
    // TODO 后期可以优化成一个Drone中带有所有经纬度信息
    //    private int monitorCount = 0;
    //    private int airCount = 0;
    //    private int districtFenceCount = 0;
    //    private int videoCount = 0;
    //    private Random rand = new Random();
    //    private CountDownTimer cdTimer;
}
