package com.tools.module.amap.map.amap;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.ZoomControls;

import androidx.annotation.Nullable;
import kotlin.jvm.JvmStatic;

import com.tools.module.amap.map.contract.IMarkerInterceptorCallback;
import com.tools.module.common.base.AppConfig;
import com.tools.module.amap.BaseConstants;
import com.tools.module.amap.R;
import com.tools.module.amap.contract.IGetBitmapCallback;
import com.tools.module.amap.manager.ParametersManager;
import com.tools.module.amap.map.MapConstants;
import com.tools.module.amap.map.amap.clusterutil.ClusterClickListener;
import com.tools.module.amap.map.amap.clusterutil.ClusterOverlay;
import com.tools.module.amap.map.amap.clusterutil.ClusterRender;
import com.tools.module.amap.map.contract.IGetDistrictLatLngsCallback;
import com.tools.module.amap.map.contract.IGetPoiItemListCallback;
import com.tools.module.amap.map.contract.IGetRoutePlanPointsCallback;
import com.tools.module.amap.map.contract.IScreenShotCallback;
import com.tools.module.amap.map.utils.BitmapManger;
import com.tools.module.amap.model.MyPoiItem;
import com.tools.module.amap.model.base.ClusterItem;
import com.tools.module.amap.net.NetManager;
import com.tools.module.amap.utils.DisplayUtil;
import com.tools.module.amap.utils.BaseFileUtil;
import com.amap.api.location.AMapLocation;
import com.amap.api.location.AMapLocationClient;
import com.amap.api.location.AMapLocationClientOption;
import com.amap.api.location.AMapLocationListener;
import com.amap.api.maps.AMap;
import com.amap.api.maps.CameraUpdateFactory;
import com.amap.api.maps.LocationSource;
import com.amap.api.maps.MapView;
import com.amap.api.maps.UiSettings;
import com.amap.api.maps.model.ArcOptions;
import com.amap.api.maps.model.BitmapDescriptor;
import com.amap.api.maps.model.BitmapDescriptorFactory;
import com.amap.api.maps.model.CameraPosition;
import com.amap.api.maps.model.CircleOptions;
import com.amap.api.maps.model.CustomMapStyleOptions;
import com.amap.api.maps.model.HeatmapTileProvider;
import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.Marker;
import com.amap.api.maps.model.MarkerOptions;
import com.amap.api.maps.model.MyLocationStyle;
import com.amap.api.maps.model.Poi;
import com.amap.api.maps.model.PolygonOptions;
import com.amap.api.maps.model.PolylineOptions;
import com.amap.api.maps.model.TextOptions;
import com.amap.api.maps.model.TileOverlay;
import com.amap.api.maps.model.TileOverlayOptions;
import com.amap.api.maps.model.UrlTileProvider;
import com.amap.api.maps.model.animation.AlphaAnimation;
import com.amap.api.maps.model.animation.Animation;
import com.amap.api.maps.model.animation.AnimationSet;
import com.amap.api.maps.model.animation.RotateAnimation;
import com.amap.api.maps.model.animation.ScaleAnimation;
import com.amap.api.maps.model.animation.TranslateAnimation;
import com.amap.api.services.core.LatLonPoint;
import com.amap.api.services.core.PoiItem;
import com.amap.api.services.district.DistrictItem;
import com.amap.api.services.district.DistrictResult;
import com.amap.api.services.district.DistrictSearch;
import com.amap.api.services.district.DistrictSearchQuery;
import com.amap.api.services.geocoder.GeocodeAddress;
import com.amap.api.services.geocoder.GeocodeQuery;
import com.amap.api.services.geocoder.GeocodeResult;
import com.amap.api.services.geocoder.GeocodeSearch;
import com.amap.api.services.geocoder.RegeocodeAddress;
import com.amap.api.services.geocoder.RegeocodeQuery;
import com.amap.api.services.geocoder.RegeocodeResult;
import com.amap.api.services.poisearch.PoiResult;
import com.amap.api.services.poisearch.PoiSearch;
import com.amap.api.services.route.BusRouteResult;
import com.amap.api.services.route.DrivePath;
import com.amap.api.services.route.DriveRouteResult;
import com.amap.api.services.route.DriveStep;
import com.amap.api.services.route.RideRouteResult;
import com.amap.api.services.route.RouteSearch;
import com.amap.api.services.route.WalkPath;
import com.amap.api.services.route.WalkRouteResult;
import com.amap.api.services.route.WalkStep;
import com.drone.monitor.bean.Drone;
import com.tools.module.amap.model.DistrictFenceModel;
import com.tools.module.amap.model.MarkerDataModel;
import com.tools.module.amap.model.MyGeocodeAddress;
import com.drone.monitor.bean.custom.MyLatLng;
import com.tools.module.amap.model.SelectAreaModel;
import com.tools.module.amap.model.base.BaseDroneModel;
import com.tools.module.amap.manager.ColorManager;
import com.tools.module.amap.map.LocalMapConfig;
import com.tools.module.amap.map.MapController;
import com.tools.module.amap.map.contract.IGetDestinationInfoCallback;
import com.tools.module.amap.observer.DataObserver;
import com.tools.module.amap.observer.MapObserver;

import com.drone.monitor.bean.MonitorDevice;
import com.drone.monitor.bean.VideoInfo;
import com.drone.monitor.bean.custom.MyArrayList;
import com.tools.module.common.ContextStore;
import com.tools.module.common.utils.ResourceUtil;
import com.tools.module.common.utils.HandlerUtils;
import com.tools.module.common.utils.TimeUtil;
import com.tools.module.common.utils.ToastUtil;
import com.tools.module.common.utils.XAppLogger;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 高德用的是GCJ-02火星坐标
 * Created by jiajie on 2019-12-21.
 */
public class MaMapUtils implements LocationSource {

    // 高德自定义地图配置
    public static final String MYSTYLE_A_HAVE_TV_FILE = "a_style_have_tv.data";
    public static final String MYSTYLE_A_HAVE_TV_EXTRA_FILE = "a_style_extra_have_tv.data";
    public static final String MYSTYLE_A_NO_TV_FILE = "a_style_no_tv.data";
    public static final String MYSTYLE_A_NO_TV_EXTRA_FILE = "a_style_extra_no_tv.data";
    public static final int POISEARCH_PAGE_SIZE = 15;
    private Context mContext;
    private MapView mapView;
    private AMap aMap;
    private ClusterOverlay mClusterOverlay;
    private HeatmapTileProvider.Builder mHeatMapBuilder;
    private TileOverlay mTileOverlay;
    private CustomMapStyleOptions mapStyleOptions = new CustomMapStyleOptions();

    private PoiSearch poiSearch;
    private RouteSearch mSearch;

    private GeocodeSearch geocodeSearch;
    //声明mlocationClient对象
    private AMapLocationClient mlocationClient;
    //声明mLocationOption对象
    private AMapLocationClientOption mLocationOption = null;
    private MyLocationStyle locationStyle;
    private OnLocationChangedListener mListener;
    private RotateAnimation rotateAnimation;

    private MyZoomListener myZoomListener;

    private CameraPosition mCurrentCameraPosition;

    private Marker currentShowMarker;

    // 当前显示的markerModel
    private MarkerDataModel currentSelectedMKDataModel;

    private boolean followMove = true;
    private boolean customStyleShowTv = true;
    private boolean isMoveCamera = false;
    private TileOverlay tileOverlay;

    @Nullable
    public AMap getMap() {
        return aMap;
    }

    private IMarkerInterceptorCallback markerInterceptorCallback;
    public void setMarkerClickInterceptor(IMarkerInterceptorCallback markerClickInterceptor) {
        this.markerInterceptorCallback = markerClickInterceptor;
    }

    public void showTitleOverlay() {
        if (tileOverlay == null) {
            tileOverlay = getMap().addTileOverlay(getTitleOverlayOptions());
        }
        if (MapConstants.needShowTitleOverlay()) {
            if (tileOverlay != null) {
                tileOverlay.setVisible(true);
            }
        }
    }

    public void hideTitleOverlay() {
        if (tileOverlay != null) {
            tileOverlay.setVisible(false);
        }
    }

    @Nullable
    public ClusterOverlay getClusterOverlay() {
        return mClusterOverlay;
    }

    public void drawShipHeatMap(List<MyLatLng> positions) {
        if (mHeatMapBuilder == null) {
            mHeatMapBuilder = new HeatmapTileProvider.Builder();
        }
        if (mTileOverlay == null) {
            List<LatLng> latLngs = AMapPositionsUtils.transformAMapPosition(positions);
            // 设置热力图绘制的数据
            mHeatMapBuilder.data(latLngs);
//            int[] DEFAULT_GRADIENT_COLORS = new int[]{Color.argb(0, 0, 255, 255),
//                    Color.argb(255 / 3 * 2, 0, 255, 0),
//                    Color.rgb(125, 191, 0),
//                    Color.rgb(185, 71, 0),
//                    Color.rgb(255, 0, 0)};
//            float[] DEFAULT_GRADIENT_START_POINTS = new float[]{0.0f, 0.10f, 0.20f, 0.60f, 1.0f};
//            // 设置热力图渐变，有默认值 DEFAULT_GRADIENT，可不设置该接口
//            Gradient gradient = new Gradient(new int[]{Color.rgb(0, 102, 0), Color.rgb(0, 255, 0)}, new float[]{0f, 1.0f});
//            mHeatMapBuilder.gradient(gradient);
            mHeatMapBuilder.radius(10);
            // 构造热力图对象
            HeatmapTileProvider heatmapTileProvider = mHeatMapBuilder.build();
            // 初始化 TileOverlayOptions
            TileOverlayOptions tileOverlayOptions = new TileOverlayOptions();
            tileOverlayOptions.tileProvider(heatmapTileProvider); // 设置瓦片图层的提供者
            // 向地图上添加 TileOverlayOptions 类对象
            mTileOverlay = getMap().addTileOverlay(tileOverlayOptions);
        } else {
            mTileOverlay.setVisible(true);
        }
    }

    public void eraseShipHeatMap() {
        if (mTileOverlay != null) {
            mTileOverlay.setVisible(false);
        }
    }

    public void changeMap() {
        if (aMap.getMapType() == AMap.MAP_TYPE_NORMAL) {
            aMap.setMapType(AMap.MAP_TYPE_SATELLITE);
        } else if (aMap.getMapType() == AMap.MAP_TYPE_SATELLITE) {
            aMap.setMapType(AMap.MAP_TYPE_NORMAL);
        }
    }

    private synchronized void setCurrentSelectedMKDataModelSelected(boolean selected) {
        if (this.currentSelectedMKDataModel != null) {
            this.currentSelectedMKDataModel.isSelected = selected;
        }
    }

    private synchronized void setCurrentSelectedMKDataModel(MarkerDataModel dataModel) {
        if (dataModel == null && currentSelectedMKDataModel != null) {
            this.currentSelectedMKDataModel.isSelected = false;
        }
        this.currentSelectedMKDataModel = dataModel;
        if (this.currentSelectedMKDataModel != null) {
            this.currentSelectedMKDataModel.isSelected = true;
        }
    }

    public synchronized MarkerDataModel getCurrentSelectedMKDataModel() {
        return currentSelectedMKDataModel;
    }

    /**
     * 当无人机信息有更新时检测是否是当前弹出来的信息框
     *
     * @param drone
     */
    public void droneInfoUpdate(Drone drone) {
        if (currentShowMarker == null || currentShowMarker.getObject() == null) {
            return;
        }
        // 显示信息有变更
        if (hasShowInfoWindow()) {
            MarkerDataModel markerDataModel = (MarkerDataModel) currentShowMarker.getObject();
            if (!markerDataModel.isList) {
                switch (markerDataModel.type) {
                    case Drone.MARKER_TYPE.DRONE:
                    case Drone.MARKER_TYPE.AIRCRAFT:
                    case Drone.MARKER_TYPE.SHIP:
                        Drone showDrone = (Drone) markerDataModel.data;
                        if (drone.getItemId().equals(showDrone.getItemId())) {
                            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_DRONE, "更新飞机信息时检测弹窗信息:" + drone.toString());
                            markerDataModel.data = drone;
                            currentShowMarker.setObject(markerDataModel);
                            currentShowMarker.showInfoWindow();
                        }
                        break;
                }
            } else {
                // TODO 暂时不更新列表状态的数据
            }
        }
    }

    /**
     * 当设备信息有更新时检测是否是当前弹出来的信息框
     *
     * @param monitor
     */
    public void monitorInfoUpdate(MonitorDevice monitor) {
        if (currentShowMarker == null) {
            return;
        }
        Object object = currentShowMarker.getObject();
        if (object == null) {
            return;
        }
        if (!(object instanceof Object[])) {
            MarkerDataModel mkData = (MarkerDataModel) currentShowMarker.getObject();
            if (hasShowInfoWindow() && mkData.data instanceof MonitorDevice) {
                MonitorDevice showMonitor = (MonitorDevice) mkData.data;
                if (monitor.getMonitorId().equals(showMonitor.getMonitorId())) {
                    XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "更新设备信息时检测弹窗信息:" + monitor.toString());
                    if (currentShowMarker != null) {
                        mkData.data = monitor;
                        currentShowMarker.setObject(mkData);
                    }
                }
            }
        }
    }

    private boolean hasShowInfoWindow() {
        if (currentShowMarker != null && currentShowMarker.isInfoWindowShown()) {
            return true;
        }
        return false;
    }

    public void hideWindowsInfo() {
        if (getCurrentSelectedMKDataModel() != null) {
            DataObserver.getInstance().notifyHideMarker();
            setCurrentSelectedMKDataModel(null);
        }
        MapController.INSTANCE.setCurrentSelectMonitorId("");
        if (currentShowMarker != null) {
            ArrayList<BitmapDescriptor> markerDescriptors = currentShowMarker.getIcons();
            if (markerDescriptors != null && markerDescriptors.size() > 0) {
                BitmapDescriptor descriptor = markerDescriptors.get(0);
                if (descriptor != null) {
                    descriptor = BitmapDescriptorFactory.fromBitmap(BitmapManger.scaleBitmap(descriptor.getBitmap(), 0.5f));
                    if (descriptor != null && currentShowMarker != null) {
                        currentShowMarker.setIcon(descriptor);
                    }
                }
            }
            if (currentShowMarker != null) {
                currentShowMarker.hideInfoWindow();
                currentShowMarker = null;
            }
        }
        MapController.IS_SELECT_TASK_ROUTE = false;
        MapController.IS_SELECT_TARGET = false;
    }

    public MarkerOptions getVideoMarkerOptions(VideoInfo video, boolean isSelected) {
        MarkerOptions markerOptions = new MarkerOptions()
                .position(new LatLng(video.latitude, video.longitude))
                .zIndex(LocalMapConfig.ZINDEX_ICON)
                .icon(AMapBitmapManager.getInstance().getVideoMarkerBitmap(MapController.CURRENT_ZOOM_LEVEL, isSelected));
        return markerOptions;
    }

    public MarkerOptions getDroneMarkerOptions(Drone drone, boolean anchor, boolean isShowAnimation, boolean isSelected) {
        MarkerOptions markerOptions = new MarkerOptions()
                .position(new LatLng(drone.getLatitude(), drone.getLongitude()))
                .zIndex(LocalMapConfig.ZINDEX_DRONE_ICON)
                .icon(AMapBitmapManager.getInstance().getDroneBitmap(drone.getType(), MapController.CURRENT_ZOOM_LEVEL, isSelected));
        if (anchor) {
            markerOptions.anchor(0.5f, 0.5f);
        }

        if (isShowAnimation) {
        }
        return markerOptions;
    }

    public RotateAnimation getRotateAnimation(Animation.AnimationListener animationListener) {
        if (rotateAnimation == null) {
            //构造RotateAnimation对象
            rotateAnimation = new RotateAnimation(0f, 360f);
            //旋转动画时间
            rotateAnimation.setDuration(2000);
            //设置动画重复模式
            rotateAnimation.setRepeatMode(Animation.RESTART);
            rotateAnimation.setInterpolator(new LinearInterpolator());
            //动画重复次数
            rotateAnimation.setRepeatCount(1);
            rotateAnimation.setAnimationListener(animationListener);
        }
        return rotateAnimation;
    }

    public void onSaveInstanceState(Bundle outState) {
        if (mapView != null) {
            mapView.onSaveInstanceState(outState);
        }
    }

    public void fiveMap(Activity activity) {
        isMoveCamera = false;
    }

    public synchronized void switchCustomStyleTv() {
        setCustomStyle(!customStyleShowTv);
    }

    /**
     * 设置自定义地图
     *
     * @param showTv
     */
    private void setCustomStyle(boolean showTv) {
        String customStyleFilePath;
        String customStyleExtraFilePath;
        customStyleShowTv = showTv;
        if (customStyleShowTv) {
            // 获取json文件路径
            customStyleFilePath = BaseFileUtil.getCustomStyleFilePath(MYSTYLE_A_HAVE_TV_FILE);
            customStyleExtraFilePath = BaseFileUtil.getCustomStyleFilePath(MYSTYLE_A_HAVE_TV_EXTRA_FILE);
            // 设置个性化地图样式文件的路径和加载方式
            mapStyleOptions.setStyleDataPath(customStyleFilePath);
            mapStyleOptions.setStyleExtraPath(customStyleExtraFilePath);
            mapStyleOptions.setEnable(true);
            aMap.setCustomMapStyle(mapStyleOptions);
        } else {
            // 获取json文件路径
            customStyleFilePath = BaseFileUtil.getCustomStyleFilePath(MYSTYLE_A_NO_TV_FILE);
            customStyleExtraFilePath = BaseFileUtil.getCustomStyleFilePath(MYSTYLE_A_NO_TV_EXTRA_FILE);
            // 设置个性化地图样式文件的路径和加载方式
            mapStyleOptions.setStyleDataPath(customStyleFilePath);
            mapStyleOptions.setStyleExtraPath(customStyleExtraFilePath);
            mapStyleOptions.setEnable(true);
            aMap.setCustomMapStyle(mapStyleOptions);
        }
    }

    public static CircleOptions getHollowCircleOptions(LatLng latLng, int radius, int color) {
        return getCircleOptions(latLng, radius, color, ResourceUtil.getColor(R.color.transparent));
    }


    public static CircleOptions getFillCircleOptions(LatLng latLng, int radius, int color) {
        return getCircleOptions(latLng, radius, color, color);
    }

    /**
     * 获取圆
     *
     * @param radius
     * @param color
     * @return
     */
    public static CircleOptions getCircleOptions(LatLng latLng, int radius, int color, int fillColor) {
        CircleOptions circleOptions = new CircleOptions().center(latLng).radius(radius)
                .strokeColor(color)
                .strokeWidth(LocalMapConfig.PAINT_WIDTH)
                .fillColor(fillColor)
                .zIndex(LocalMapConfig.ZINDEX_COVER);
        return circleOptions;
    }


    /**
     * 获取圆
     *
     * @param radius
     * @param color
     * @return
     */
    public static CircleOptions getCircleLineOptions(LatLng latLng, int radius, int color) {
        return new CircleOptions().center(latLng).radius(radius)
                .strokeColor(color)
                .strokeWidth(LocalMapConfig.DEVICE_POLYLINE_WIDTH)
                .fillColor(ResourceUtil.getColor(R.color.transparent))
                .zIndex(LocalMapConfig.ZINDEX_COVER);
    }

    /**
     * 获取弧线
     *
     * @param latLngs
     * @param color
     * @return
     */
    public static ArcOptions getArcLineOptions(List<LatLng> latLngs, int color) {
        return new ArcOptions()
                .point(latLngs.get(0), latLngs.get(1), latLngs.get(2))
                .strokeColor(color)
                .strokeWidth(LocalMapConfig.DEVICE_POLYLINE_WIDTH)
                .zIndex(LocalMapConfig.ZINDEX_RADIUS_LINE);
    }

    /**
     * 获取扫描线
     *
     * @return
     */
    public static PolylineOptions getScanPolylineOptions(List<LatLng> latLngs, int color) {
        PolylineOptions polylineOptions = new PolylineOptions()
                .color(color)
                .setDottedLine(false)
                .zIndex(LocalMapConfig.ZINDEX_SCAN_LINE)
                .width(LocalMapConfig.SCAN_LINE_WIDTH);
        polylineOptions.setPoints(latLngs);
        return polylineOptions;
    }

    /**
     * 获取路线
     *
     * @return
     */
    public static PolylineOptions getPolylineOptions(List<LatLng> latLngs, int color) {
        return getPolylineOptions(latLngs, color, LocalMapConfig.ROUTE_LINE_WIDTH, false);
    }

    /**
     * 获取路线
     *
     * @return
     */
    public static PolylineOptions getPolylineOptions(List<LatLng> latLngs, int color, boolean dottedLine) {
        return getPolylineOptions(latLngs, color, LocalMapConfig.ROUTE_LINE_WIDTH, dottedLine);
    }

    public static PolylineOptions getPolylineOptions(List<LatLng> latLngs, int color, int width, boolean dottedLine) {
        return new PolylineOptions()
                .color(color)
                .addAll(latLngs)
                .setDottedLine(dottedLine)
                .zIndex(LocalMapConfig.ZINDEX_RADIUS_LINE)
                .width(width);
    }

    /**
     * 获取多边形覆盖层
     *
     * @param latLngs
     * @param color
     * @return
     */
    public static PolygonOptions getPolygonOptions(List<LatLng> latLngs, int color) {
        PolygonOptions polygonOptions = new PolygonOptions()
                .fillColor(color)
                .strokeColor(ResourceUtil.getColor(R.color.transparent))
                .strokeWidth(0f)
                .zIndex(LocalMapConfig.ZINDEX_COVER);
        polygonOptions.setPoints(latLngs);
        return polygonOptions;
    }

    /**
     * 获取折线
     *
     * @return
     */
    public static PolylineOptions getBrokenPolylineOptions(List<LatLng> latLngs, int color) {
        PolylineOptions polylineOptions = new PolylineOptions()
                .color(color)
                .setDottedLine(true)
                .zIndex(LocalMapConfig.ZINDEX_RADIUS_LINE)
                .width(LocalMapConfig.BROKEN_LINE_WIDTH);
        polylineOptions.setPoints(latLngs);
        return polylineOptions;
    }

    /**
     * 获取多边形覆盖层
     *
     * @param latLngs
     * @param color
     * @return
     */
    public static PolygonOptions getCoverPolygonOptions(List<LatLng> latLngs, int color) {
        PolygonOptions polygonOptions = new PolygonOptions()
                .fillColor(color)
                .strokeColor(ResourceUtil.getColor(R.color.transparent))
                .strokeWidth(0f)
                .zIndex(LocalMapConfig.ZINDEX_COVER);
        polygonOptions.setPoints(latLngs);
        return polygonOptions;
    }

    /**
     * 获取圆形覆盖层
     *
     * @param radius
     * @param color
     * @return
     */
    public static CircleOptions getCoverCircleOptions(LatLng latLng, int radius, int color) {
        return new CircleOptions().center(latLng).radius(radius).fillColor(color)
                .strokeColor(ResourceUtil.getColor(R.color.transparent))
                .strokeWidth(0f)
                .zIndex(LocalMapConfig.ZINDEX_COVER);
    }

    /**
     * @param latLng
     * @param radius
     * @param strokeWidth
     * @param strokeColor
     * @return
     */
    public static CircleOptions getDroneWarningCircleLineOptions(LatLng latLng, int radius, int strokeWidth, int strokeColor) {
        return new CircleOptions()
                .center(latLng)
                .radius(radius)
                .strokeWidth(strokeWidth)
                .strokeColor(strokeColor)
                .zIndex(LocalMapConfig.ZINDEX_COVER)
                .fillColor(ResourceUtil.getColor(R.color.transparent));
    }

    /**
     * 获取marker
     *
     * @return
     */
    public static MarkerOptions getMarkOptions(MonitorDevice monitorDevice, int monitorStatus, boolean isSelected) {
        return getMarkOptions(monitorDevice, monitorStatus, isSelected, false);
    }

    public static MarkerOptions getMarkOptions(MonitorDevice monitorDevice, int monitorStatus, boolean isSelected, boolean isDraggable) {
        return getMarkOptions(monitorDevice, 0.5f, 1.0f, monitorStatus, isSelected, isDraggable);
    }

    /**
     * 获取marker
     *
     * @return
     */
    public static MarkerOptions getMarkOptions(MonitorDevice monitorDevice, float anchorX, float anchorY, int monitorStatus, boolean isSelected, boolean isDraggable) {
        BitmapDescriptor bitmapDescriptor =
                AMapBitmapManager.getInstance().getDescriptorBitmap(monitorDevice.getType(), monitorStatus, MapController.CURRENT_ZOOM_LEVEL, isSelected);
        if (bitmapDescriptor == null) {
            return null;
        }
        float centerAngle = monitorDevice.getCenterAngle();
        LatLng deviceLatLng = new LatLng(monitorDevice.getLatitude(), monitorDevice.getLongitude());
        // 计算设备的朝向中间角度
        MarkerOptions markerOptions = new MarkerOptions()
                .icon(bitmapDescriptor)
                .position(deviceLatLng)
                .anchor(anchorX, anchorY)
                .draggable(isDraggable)
                .zIndex(LocalMapConfig.ZINDEX_ICON)
                .title(monitorDevice.getMonitorId());
        // TODO 如果需要旋转角度加上
//        .rotateAngle(-centerAngle)
        return markerOptions;
    }

    /**
     * 获取可拖动的多边形覆盖层
     *
     * @param latLngs
     * @param lineColor
     * @param coverColor
     * @return
     */
    public static PolygonOptions getDraggableCoverPolygonOptions(List<LatLng> latLngs, int lineColor, int coverColor) {
        return new PolygonOptions().addAll(latLngs)
                .strokeColor(lineColor)
                .strokeWidth(LocalMapConfig.DISTRICT_FENCE_LINE_WIDTH)
                .zIndex(LocalMapConfig.ZINDEX_FENCE_COVER)
                .fillColor(coverColor);
    }

    /**
     * 获取可拖动的marker
     *
     * @return
     */
    public static MarkerOptions getFenceCenterMarkOptions(LatLng latLng) {
        return new MarkerOptions()
                .position(latLng)
                .draggable(true)
                .icon(AMapBitmapManager.getInstance().getFenceCenterMarkerBitmap(MapController.CURRENT_ZOOM_LEVEL))
                .zIndex(LocalMapConfig.ZINDEX_FENCE_ICON);
    }

    /**
     * 获取可拖动的marker
     *
     * @return
     */
    public static MarkerOptions getMarkOptions(LatLng latLng, BitmapDescriptor descriptor) {
        return new MarkerOptions()
                .position(latLng)
                .draggable(true)
                .anchor(0.5f, 0.5f)
                .icon(descriptor)
                .zIndex(LocalMapConfig.ZINDEX_FENCE_ICON);
    }

    /**
     * 获取半径文字
     *
     * @param content
     * @param latLng
     * @param centerAngle
     * @return
     */
    public static TextOptions getIntervalTextOptions(String content, LatLng latLng,
                                                     float centerAngle) {
        TextOptions textOptions = new TextOptions()
                .text(content)
                .position(latLng)
                .rotate(-centerAngle)
                .fontColor(ColorManager.getIntervalTvColor())
                .zIndex(LocalMapConfig.ZINDEX_RADIUS_TV)
                .fontSize(ParametersManager.getIntervalTvScale(MapController.CURRENT_ZOOM_LEVEL));
        return textOptions;
    }

    public static TextOptions getNameTextOptions(String content, LatLng latLng, float centerAngle) {
        TextOptions textOptions = new TextOptions()
                .text(content)
                .position(latLng)
                .rotate(-centerAngle)
                .fontColor(ColorManager.getNameTvColor())
                .zIndex(LocalMapConfig.ZINDEX_RADIUS_TV)
                .fontSize(ParametersManager.getNameTvScale(MapController.CURRENT_ZOOM_LEVEL));
        return textOptions;
    }

    public TextOptions getDroneWarningTextOptions(String content, LatLng latLng, float centerAngle) {
        TextOptions textOptions = new TextOptions()
                .text(content)
                .position(latLng)
                .rotate(-centerAngle)
                .fontColor(ColorManager.getDroneWarningTvColor())
                .backgroundColor(ColorManager.getDroneWaringTvBgColor())
                .zIndex(LocalMapConfig.ZINDEX_RADIUS_TV)
                .fontSize(ParametersManager.getNameTvScale(MapController.CURRENT_ZOOM_LEVEL));
        return textOptions;
    }

    public static TileOverlayOptions getTitleOverlayOptions() {
        TileOverlayOptions tileOverlayOptions =
                new TileOverlayOptions().tileProvider(new UrlTileProvider(256, 256) {

                    @Override
                    public URL getTileUrl(int x, int y, int zoom) {
                        try {
                            if (MapConstants.needShowTitleOverlay()) {
                                return new URL(String.format(NetManager.REQUST_URL.GET_SHIP_TITLE_URL, x, y, zoom));
                            }
                        } catch (Exception e) {
                            XAppLogger.getInstance().writeError("getTileUrl() %s", e.toString());
                        }
                        return null;
                    }
                });
        tileOverlayOptions.diskCacheEnabled(true)
                .diskCacheDir(BaseConstants.PATH_MAP_CACHE_DIR)
                .diskCacheSize(30 * 1024)
                .memoryCacheEnabled(true)
                .memCacheSize(30 * 1024)
                .zIndex(LocalMapConfig.ZINDEX_TILE_OVERLAY);
        return tileOverlayOptions;
    }

    /**
     * 获取行政区的经纬度集合
     *
     * @param keyWords
     * @param callback
     */
    public void getDistrictLatlngs(String keyWords, IGetDistrictLatLngsCallback callback) {
        try {
            DistrictSearch districtSearch = new DistrictSearch(mContext);
            DistrictSearchQuery query = new DistrictSearchQuery();
            query.setKeywords(keyWords);
            query.setShowBoundary(true);
            districtSearch.setOnDistrictSearchListener(new DistrictSearch.OnDistrictSearchListener() {
                @Override
                public void onDistrictSearched(DistrictResult districtResult) {

                    final DistrictItem item = districtResult.getDistrict().get(0);
                    if (item == null) {
                        XAppLogger.getInstance().writeError("AMap 搜索区域未找到结果");
                        ToastUtil.makeShortText(R.string.district_search_fail);
                        return;
                    }
                    //得到行政中心点坐标
                    LatLonPoint centerLatLng = item.getCenter();
                    if (centerLatLng != null) {
                        //地图加载时就显示行政区域
                        aMap.moveCamera(
                                CameraUpdateFactory.newLatLng(new LatLng(centerLatLng.getLatitude(), centerLatLng.getLongitude())));//13为缩放级别
                    }
                    String[] polyStr = item.districtBoundary();
                    if (polyStr == null || polyStr.length == 0) {
                        return;
                    }
                    List<MyLatLng> latLngs = new ArrayList<>();
                    for (String str : polyStr) {
                        String[] lat = str.split(";");
                        if (lat != null && lat.length > 0) {
                            String[] lats = lat[0].split(",");
                            latLngs.add(new MyLatLng(Double
                                    .parseDouble(lats[1]), Double
                                    .parseDouble(lats[0])));
                        }
                    }
                    if (callback != null) {
                        callback.onSuccess(latLngs);
                    }
                }
            });
            districtSearch.searchDistrictAsyn();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 根据名称搜索相关地址列表
     *
     * @param keyWord
     * @param callback
     */
    public void getAddressList(String keyWord, IGetDestinationInfoCallback callback) {
        GeocodeQuery geocodeQuery = new GeocodeQuery(keyWord.trim(), "29");
        if (geocodeSearch != null) {
            geocodeSearch.setOnGeocodeSearchListener(new GeocodeSearch.OnGeocodeSearchListener() {
                /**
                 *  得到逆地理编码异步查询结果
                 */
                @Override
                public void onRegeocodeSearched(RegeocodeResult regeocodeResult, int i) {
                }

                @Override
                public void onGeocodeSearched(GeocodeResult geocodeResult, int i) {
                    if (i == 1000) {
                        if (geocodeResult != null && geocodeResult.getGeocodeAddressList() != null &&
                                geocodeResult.getGeocodeAddressList().size() > 0) {
                            List<GeocodeAddress> geocodeAddresses = geocodeResult.getGeocodeAddressList();
                            int size = geocodeAddresses.size() > POISEARCH_PAGE_SIZE
                                    ? POISEARCH_PAGE_SIZE : geocodeAddresses.size();
                            List<MyGeocodeAddress> myGeocodeAddresses = new MyArrayList<>(size);
                            for (int n = 0; n < size; n++) {
                                GeocodeAddress geocodeAddress = geocodeAddresses.get(n);
                                double latitude = geocodeAddress.getLatLonPoint().getLatitude();//纬度
                                double longititude = geocodeAddress.getLatLonPoint().getLongitude();//经度
                                MyGeocodeAddress myGeocodeAddress = new MyGeocodeAddress();
                                myGeocodeAddress.latLng = new MyLatLng(latitude, longititude);
                                myGeocodeAddress.city = geocodeAddress.getCity();
                                myGeocodeAddress.district = geocodeAddress.getDistrict();
                                myGeocodeAddress.formatAddress = geocodeAddress.getFormatAddress();
                                String formatAddress = geocodeAddress.getFormatAddress();
                                String simpleAddress = formatAddress.substring(9);
                                myGeocodeAddress.sampleAddress = simpleAddress;
                                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_OTHER, "地理编码" + geocodeAddress.getAdcode() + "");
                                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_OTHER, "纬度latitude" + latitude + "");
                                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_OTHER, "经度longititude" + longititude + "");
                                myGeocodeAddresses.add(myGeocodeAddress);
                            }
                            if (callback != null) {
                                callback.onSearchKeywordSuccess(myGeocodeAddresses);
                            }
                        } else {
                            ToastUtil.makeLongText("地址名出错");
                        }
                    }
                }
            });
            geocodeSearch.getFromLocationNameAsyn(geocodeQuery);
        }
    }

    public void getAddressNameByLatlng(MyLatLng latLng, IGetDestinationInfoCallback callback) {
        //逆地理编码查询条件：逆地理编码查询的地理坐标点、查询范围、坐标类型。
        LatLonPoint latLonPoint = new LatLonPoint(latLng.latitude, latLng.longitude);
        RegeocodeQuery query = new RegeocodeQuery(latLonPoint, 100f, GeocodeSearch.AMAP);
        if (geocodeSearch != null) {
            geocodeSearch.setOnGeocodeSearchListener(new GeocodeSearch.OnGeocodeSearchListener() {
                /**
                 *  得到逆地理编码异步查询结果
                 */
                @Override
                public void onRegeocodeSearched(RegeocodeResult regeocodeResult, int i) {
                    RegeocodeAddress regeocodeAddress = regeocodeResult.getRegeocodeAddress();
                    String formatAddress = regeocodeAddress.getFormatAddress();
                    if (callback != null) {
                        callback.onSearchLatlngSuccess(formatAddress, latLng);
                    }
                }

                @Override
                public void onGeocodeSearched(GeocodeResult geocodeResult, int i) {
                }
            });
            //异步查询
            geocodeSearch.getFromLocationAsyn(query);
        }
    }

    /**
     * 开始进行poi搜索
     */
    public void doPoiSearchQuery(String keyWord, IGetPoiItemListCallback callback) {
        // 第一个参数表示搜索字符串，第二个参数表示poi搜索类型，第三个参数表示poi搜索区域（空字符串代表全国）
        PoiSearch.Query query = new PoiSearch.Query(keyWord, "", "");
        // 设置每页最多返回多少条poiitem
        query.setPageSize(POISEARCH_PAGE_SIZE);
        query.setPageNum(1);// 设置查第一页
        // 关键字搜索
        try {
            poiSearch = new PoiSearch(ContextStore.getContext(), query);
            poiSearch.setOnPoiSearchListener(new PoiSearch.OnPoiSearchListener() {
                @Override
                public void onPoiSearched(PoiResult poiResult, int i) {
                    List<MyPoiItem> myPoiItems = new ArrayList<>();
                    if (poiResult != null && poiResult.getPois() != null) {
                        for (PoiItem poiItem : poiResult.getPois()) {
                            if (poiItem != null) {
                                MyPoiItem myPoiItem = new MyPoiItem();
                                myPoiItem.setTitle(poiItem.getTitle());
                                myPoiItem.setSnippet(poiItem.getSnippet());
                                myPoiItem.setLatLonPoint(new MyLatLng(poiItem.getLatLonPoint().getLatitude(), poiItem.getLatLonPoint().getLongitude()));
                                myPoiItems.add(myPoiItem);
                            }
                        }
                    }
                    if (callback != null) {
                        callback.onSearchKeywordSuccess(myPoiItems);
                    }
                }

                @Override
                public void onPoiItemSearched(PoiItem poiItem, int i) {
                }
            });
            poiSearch.searchPOIAsyn();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setZoom(LatLng latLng, float zoom) {
        if (aMap != null) {
            if (latLng != null) {
                aMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, zoom));
            } else {
                setZoom(zoom);
            }
        }
    }

    public void setZoom(double latitude, double longitude, float zoom) {
        setZoom(new LatLng(latitude, longitude), zoom);
    }

    @JvmStatic
    public void setZoom(double latitude, double longitude) {
        if (aMap != null) {
            aMap.animateCamera(CameraUpdateFactory.newLatLng(new LatLng(latitude, longitude)));
        }
    }

    private void setZoom(float zoom) {
        if (aMap != null) {
            aMap.animateCamera(CameraUpdateFactory.zoomTo(zoom));
        }
    }

    public void getMapScreenShot(IScreenShotCallback callback) {
        getMapScreenShot(callback, true);
    }

    public void getMapScreenShot(IScreenShotCallback callback, boolean isSaveToMedia) {
        if (aMap != null) {
            aMap.getMapScreenShot(new AMap.OnMapScreenShotListener() {
                @Override
                public void onMapScreenShot(Bitmap bitmap) {

                }

                @Override
                public void onMapScreenShot(Bitmap bitmap, int i) {
                    if (callback != null) {
                        String filePath = BaseConstants.PATH_SREENSHOT + File.separator + TimeUtil.getFile1TimeStr();
                        if (isSaveToMedia) {
                            filePath += ".jpg";
                        }
                        File imgFile = new File(filePath);
                        if (!imgFile.exists()) {
                            try {
                                imgFile.createNewFile();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                        BaseFileUtil.saveToFile(bitmap, imgFile, isSaveToMedia);
                        callback.screenCapture(imgFile.getAbsolutePath());
                    }
                }
            });
        }
    }

    // 激活定位
    @Override
    public void activate(OnLocationChangedListener onLocationChangedListener) {
        mListener = onLocationChangedListener;
        startLocation();
    }

    // 停止定位
    @Override
    public void deactivate() {
        mListener = null;
        if (mlocationClient != null) {
            mlocationClient.onDestroy();
        }
        mlocationClient = null;
    }

    public void initMap(MapView mapView, Context context, Bundle savedInstanceState) {
        if (mapView == null) {
            return;
        }
        mContext = context;
        this.mapView = mapView;
        this.mapView.onCreate(savedInstanceState);
        //初始化地图控制器对象
        aMap = this.mapView.getMap();

        mClusterOverlay = new ClusterOverlay(aMap,
                DisplayUtil.dip2px(ContextStore.getContext(), 30),
                ContextStore.getContext());

        setClusterOverlayListener();
        // 设置自定义地图
//        setCustomStyle(customStyleShowTv);

        setupLocationStyle();
        setMapUi(aMap);
        View child = this.mapView.getChildAt(1);
        if (child != null && (child instanceof ImageView || child instanceof ZoomControls)) {
            child.setVisibility(View.GONE);
        }

        // 不显示室内地图
        aMap.showIndoorMap(false);
        aMap.setLocationSource(this);
        aMap.setLoadOfflineData(true);
        aMap.setMapType(AMap.MAP_TYPE_NORMAL);
        //开启交通图
        aMap.setTrafficEnabled(AppConfig.SHOW_TRAFFIC);
        // 一定要写到setLocationSource后边
        aMap.setMyLocationEnabled(true);

        try {
            // 逆搜索
            if (geocodeSearch == null) {
                geocodeSearch = new GeocodeSearch(mapView.getContext());
            }

            // 路线搜索
            mSearch = new RouteSearch(context);
        } catch (Exception e) {
            XAppLogger.getInstance().writeError("逆搜索或路线搜索初始化错误 %s", e.toString());
        }

        setListener();
    }

    private void setMapUi(AMap map) {
        UiSettings mUiSettings = map.getUiSettings();
        mUiSettings.setScrollGesturesEnabled(true);
        // 地图是否可以倾斜
        mUiSettings.setTiltGesturesEnabled(true);
        mUiSettings.setRotateGesturesEnabled(false);
        mUiSettings.setZoomGesturesEnabled(true);
        mUiSettings.setMyLocationButtonEnabled(false);
        mUiSettings.setZoomControlsEnabled(false);
        mUiSettings.setScaleControlsEnabled(false);

        map.setMinZoomLevel(MapController.LEVELS_MIN);
        map.setMaxZoomLevel(MapController.LEVELS_MAX);
    }

    private void setClusterOverlayListener() {
        // TODO 根据数目返回不同的样式图标
        mClusterOverlay.setClusterRenderer(new ClusterRender() {
            @Override
            public Drawable getDrawAble(int clusterNum) {
                return null;
            }
        });
        mClusterOverlay.setOnClusterClickListener(new ClusterClickListener() {
            @Override
            public boolean onClick(Marker marker, int markerType, Map<String, ClusterItem> clusterItems) {
                if (clusterItems != null && clusterItems.size() > 1) {
                    if (MapController.CURRENT_ZOOM_LEVEL < aMap.getMaxZoomLevel()) {
                        LatLng latLng = null;
                        if (marker != null) {
                            latLng = marker.getPosition();
                        }
                        float dv = aMap.getMaxZoomLevel() - MapController.CURRENT_ZOOM_LEVEL;
                        if (dv >= 1) {
                            setZoom(latLng, MapController.CURRENT_ZOOM_LEVEL + 1);
                        } else {
                            setZoom(latLng, aMap.getMaxZoomLevel());
                        }
                        return true;
                    } else {
                        switch (markerType) {
                            case Drone.MARKER_TYPE.DRONE:
                                if (clusterItems == null || clusterItems.size() <= 1)
                                    return false;
                                MarkerDataModel mkDroneDataModel = new MarkerDataModel();
                                mkDroneDataModel.type = Drone.MARKER_TYPE.DRONE;
                                for (ClusterItem item : clusterItems.values()) {
                                    if (item != null) {
                                        BaseDroneModel droneModel = MapController.getDroneModel(item.getId());
                                        if (droneModel != null) {
                                            mkDroneDataModel.datas.add(droneModel.getData());
                                        }
                                    }
                                }
                                if (markerInterceptorCallback != null
                                        && markerInterceptorCallback.click(mkDroneDataModel)) {
                                    return true;
                                }
                                if (mkDroneDataModel.datas.size() >= 2) {
                                    mkDroneDataModel.isList = true;
                                    marker.setObject(mkDroneDataModel);
                                    marker.showInfoWindow();
                                    return true;
                                }
                                break;
                            case Drone.MARKER_TYPE.AIRCRAFT:
                                if (clusterItems == null || clusterItems.size() <= 1)
                                    return false;
                                MarkerDataModel mkAircraftDataModel = new MarkerDataModel();
                                mkAircraftDataModel.type = Drone.MARKER_TYPE.AIRCRAFT;
                                for (ClusterItem item : clusterItems.values()) {
                                    if (item != null) {
                                        BaseDroneModel droneModel = MapController.getDroneModel(item.getId());
                                        if (droneModel != null) {
                                            mkAircraftDataModel.datas.add(droneModel.getData());
                                        }
                                    }
                                }
                                if (mkAircraftDataModel.datas.size() >= 2) {
                                    mkAircraftDataModel.isList = true;
                                    marker.setObject(mkAircraftDataModel);
                                    marker.showInfoWindow();
                                    return true;
                                }
                                break;
                            case Drone.MARKER_TYPE.SHIP:
                                if (clusterItems == null || clusterItems.size() <= 1)
                                    return false;
                                MarkerDataModel mkShipDataModel = new MarkerDataModel();
                                mkShipDataModel.type = Drone.MARKER_TYPE.SHIP;
                                for (ClusterItem item : clusterItems.values()) {
                                    if (item != null) {
                                        BaseDroneModel droneModel = MapController.getDroneModel(item.getId());
                                        if (droneModel != null) {
                                            mkShipDataModel.datas.add(droneModel.getData());
                                        }
                                    }
                                }
                                if (mkShipDataModel.datas.size() >= 2) {
                                    mkShipDataModel.isList = true;
                                    marker.setObject(mkShipDataModel);
                                    marker.showInfoWindow();
                                    return true;
                                }
                                break;
                            case Drone.MARKER_TYPE.VIDEO:
                                if (clusterItems == null || clusterItems.size() <= 1)
                                    return false;
                                Map<String, VideoInfo> videos = MapController.getVideos();
                                if (videos == null || videos.size() <= 0) {
                                    return false;
                                }
                                MarkerDataModel mkVideoDataModel = new MarkerDataModel();
                                mkVideoDataModel.type = Drone.MARKER_TYPE.VIDEO;
                                for (ClusterItem item : clusterItems.values()) {
                                    if (item != null) {
                                        VideoInfo videoInfo = videos.get(item.getId());
                                        if (videoInfo != null) {
                                            mkVideoDataModel.datas.add(videoInfo);
                                        }
                                    }
                                }
                                if (mkVideoDataModel.datas.size() >= 2) {
                                    mkVideoDataModel.isList = true;
                                    marker.setObject(mkVideoDataModel);
                                    marker.showInfoWindow();
                                    for (int i = 0; i < mkVideoDataModel.datas.size(); i++) {
                                        VideoInfo videoInfo = (VideoInfo) mkVideoDataModel.datas.get(i);
                                        if (i == 0) {
                                            MapController.INSTANCE.clickVideoMarker(videoInfo);
                                        } else {
                                            MapController.INSTANCE.addVideoInfo(videoInfo);
                                        }
                                    }
                                    return true;
                                }
                                break;
                        }
                    }
                }
                return false;
            }

            @Override
            public boolean onClick(Marker marker) {
                // 当选择任务时点击其他marker无效
                if (MapController.IS_SELECT_TASK_ROUTE) {
                    LatLng latLng = marker.getPosition();
                    DataObserver.getInstance().notifySetDestination(new MyLatLng(latLng.latitude, latLng.longitude));
                    return true;
                }
                MarkerDataModel mkDataModel = (MarkerDataModel) marker.getObject();
                if (mkDataModel != null && mkDataModel.equals(getCurrentSelectedMKDataModel())) {
                    if (getCurrentSelectedMKDataModel().isSelected) {
                        // 说明点击的是同一个marker
                        return true;
                    }
                }
                ArrayList<BitmapDescriptor> markerDescriptors = marker.getIcons();
                if (mkDataModel.type == Drone.MARKER_TYPE.DRONE) {
                    if (markerInterceptorCallback.click(mkDataModel)) {
                        return true;
                    }
                    if (MapController.IS_SELECT_TARGET) {
                        Drone drone = null;
                        if (!mkDataModel.isList) {
                            drone = (Drone) mkDataModel.data;
                        } else {
                            List<Drone> drones = (List<Drone>) mkDataModel.data;
                            if (drones != null && drones.size() > 0) {
                                drone = drones.get(0);
                            }
                        }
                        if (drone != null && getCurrentSelectedMKDataModel() != null) {
                            // 当前选择的设备必须是攻击设备
                            if (getCurrentSelectedMKDataModel().type == Drone.MARKER_TYPE.MONITOR) {
                                // 通知所点击的目标位置
                                DataObserver.getInstance().notifySetBattleTarge(drone);
                            }
                        }
                        return true;
                    }
                } else if (mkDataModel.type == Drone.MARKER_TYPE.DISTRICT_FENCE) {
                    DistrictFenceModel markerInfoModel = (DistrictFenceModel) mkDataModel.data;
                    if (markerInfoModel != null) {
                        MapController.INSTANCE.onEditMapClickMarker();
                        return true;
                    }
                } else if (mkDataModel.type == Drone.MARKER_TYPE.VIDEO) {
                    VideoInfo video = (VideoInfo) mkDataModel.data;
                    MapController.INSTANCE.clickVideoMarker(video);
                } else if (mkDataModel.type == Drone.MARKER_TYPE.MONITOR) {
                    MonitorDevice monitorDevice = (MonitorDevice) mkDataModel.data;
                    MapController.INSTANCE.setCurrentSelectMonitorId(monitorDevice.getMonitorId());
                }

                setCurrentSelectedMKDataModelSelected(false);

                if (currentShowMarker != null) {
                    ArrayList<BitmapDescriptor> oldMarkerDescriptors = currentShowMarker.getIcons();
                    if (oldMarkerDescriptors != null && oldMarkerDescriptors.size() > 0) {
                        BitmapDescriptor descriptor = oldMarkerDescriptors.get(0);
                        if (descriptor != null) {
                            descriptor = BitmapDescriptorFactory.fromBitmap(BitmapManger.scaleBitmap(descriptor.getBitmap(), 0.5f));
                            if (descriptor != null) {
                                currentShowMarker.setIcon(descriptor);
                            }
                        }
                    }
                }
                currentShowMarker = marker;
                setCurrentSelectedMKDataModel(mkDataModel);
                // 通知marker的点击事件
                DataObserver.getInstance().notifyClickMarker(mkDataModel);
                if (markerDescriptors != null && markerDescriptors.size() > 0) {
                    BitmapDescriptor descriptor = markerDescriptors.get(0);
                    if (descriptor != null) {
                        descriptor = BitmapDescriptorFactory.fromBitmap(BitmapManger.scaleBitmap(descriptor.getBitmap(), 2.0f));
                        if (descriptor != null) {
                            marker.setIcon(descriptor);
                        }
                    }
                }
                return true;
            }
        });
    }

    private void setListener() {
        if (myZoomListener == null) {
            myZoomListener = new MyZoomListener();
        }
        MapObserver.registerZoomClickObserver(myZoomListener);
        aMap.setOnMapLoadedListener(new AMap.OnMapLoadedListener() {
            @Override
            public void onMapLoaded() {
                LocalMapConfig.CURRENT_PX_IN_METERS = aMap.getScalePerPixel();
                MapObserver.onMapLoaded();
                CameraPosition cameraPosition = aMap.getCameraPosition();
                LocalMapConfig.CURRENT_VIEW_LATITUDE = cameraPosition.target.latitude;
                LocalMapConfig.CURRENT_VIEW_LONGITUDE = cameraPosition.target.longitude;
                //设置缩放级别
                setZoom(MapController.CURRENT_ZOOM_LEVEL);
                MapController.getVisibleBounds().setLatLng(
                        new MyLatLng(getMap().getProjection().getVisibleRegion().latLngBounds.southwest.latitude,
                                getMap().getProjection().getVisibleRegion().latLngBounds.southwest.longitude),
                        new MyLatLng(getMap().getProjection().getVisibleRegion().latLngBounds.northeast.latitude,
                                getMap().getProjection().getVisibleRegion().latLngBounds.northeast.longitude));
            }
        });
        aMap.setOnMapClickListener(new AMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {
                if (MapController.IS_SELECT_TASK_ROUTE) {
                    DataObserver.getInstance().notifySetDestination(new MyLatLng(latLng.latitude, latLng.longitude));
                    return;
                }
                MapObserver.onClickMap(latLng.latitude, latLng.longitude);
            }
        });
        aMap.setOnMapLongClickListener(new AMap.OnMapLongClickListener() {
            @Override
            public void onMapLongClick(LatLng latLng) {
                MapObserver.onLongClickMap(latLng.latitude, latLng.longitude);
            }
        });
        aMap.setOnPOIClickListener(new AMap.OnPOIClickListener() {
            @Override
            public void onPOIClick(Poi poi) {
                LatLng clickLatLng = poi.getCoordinate();
                if (MapController.IS_SELECT_TASK_ROUTE) {
                    DataObserver.getInstance().notifySetDestination(new MyLatLng(clickLatLng.latitude, clickLatLng.longitude));
                    return;
                }
                MapObserver.onClickMap(clickLatLng.latitude, clickLatLng.longitude);
            }
        });
        aMap.setOnMarkerDragListener(new AMap.OnMarkerDragListener() {
            @Override
            public void onMarkerDragStart(Marker marker) {

            }

            @Override
            public void onMarkerDrag(Marker marker) {
                if (marker != null) {
                    MarkerDataModel mkData = (MarkerDataModel) marker.getObject();
                    if (mkData != null) {
                        if (mkData.data instanceof DistrictFenceModel) {
                            DistrictFenceModel infoModel = (DistrictFenceModel) mkData.data;
                            if (infoModel != null) {
                                infoModel.latLng = AMapPositionsUtils.transforAMapToMyLatlngPosition(marker.getPosition());
                                MapController.INSTANCE.updateDistrictFenceMarker(infoModel);
                            }
                        } else if (mkData.data instanceof SelectAreaModel) {
                            SelectAreaModel selectAreaModel = (SelectAreaModel) mkData.data;
                            if (selectAreaModel != null) {
                                LatLng latLng = marker.getPosition();
                                MapController.INSTANCE.updateSelectAreaMarker(selectAreaModel, new MyLatLng(latLng.latitude, latLng.longitude));
                            }
                        }
                    }
                }
            }

            @Override
            public void onMarkerDragEnd(Marker marker) {

            }
        });
        aMap.setOnMapTouchListener(new AMap.OnMapTouchListener() {
            @Override
            public void onTouch(MotionEvent motionEvent) {
                if (followMove) {
                    //用户拖动地图后，不再跟随移动，需要跟随移动时再把这个改成true
                    followMove = false;
                }
            }
        });
        aMap.setOnCameraChangeListener(new AMap.OnCameraChangeListener() {
            @Override
            public void onCameraChange(CameraPosition cameraPosition) {

            }

            @Override
            public void onCameraChangeFinish(CameraPosition cameraPosition) {
                mCurrentCameraPosition = cameraPosition;
                HandlerUtils.getUIHandler().removeCallbacks(cameraUpateRunnable);
                HandlerUtils.getUIHandler().postDelayed(cameraUpateRunnable, 300);
            }
        });
    }

    public void searchRoutePlanAsyn(int deviceType, MyLatLng stLatlng, MyLatLng enLatlng, IGetRoutePlanPointsCallback callback) {
        if (stLatlng == null || enLatlng == null) {
            return;
        }
        RouteSearch.FromAndTo fromAndTo = new RouteSearch.FromAndTo(new LatLonPoint(stLatlng.latitude,
                stLatlng.longitude), new LatLonPoint(enLatlng.latitude, enLatlng.longitude));
        if (deviceType == MonitorDevice.DEVICE_TYPE.DISTURB_CAR) {
            setRouteSearchLis(callback, null);
            RouteSearch.DriveRouteQuery routeQuery = new RouteSearch.DriveRouteQuery(fromAndTo, RouteSearch.DrivingDefault, null, null, "");
            mSearch.calculateDriveRouteAsyn(routeQuery);
        } else {
            setRouteSearchLis(null, callback);
            RouteSearch.WalkRouteQuery routeQuery = new RouteSearch.WalkRouteQuery(fromAndTo);
            try {
                mSearch.calculateWalkRoute(routeQuery);
            } catch (Exception e) {
                XAppLogger.getInstance().writeError("calculateWalkRoute() %s", e);
                if (callback != null) {
                    callback.onFailed();
                }
            }
        }
    }

    private void setRouteSearchLis(IGetRoutePlanPointsCallback driveRouteCallback, IGetRoutePlanPointsCallback walkRouteCallback) {
        mSearch.setRouteSearchListener(new RouteSearch.OnRouteSearchListener() {
            @Override
            public void onBusRouteSearched(BusRouteResult busRouteResult, int i) {

            }

            @Override
            public void onDriveRouteSearched(DriveRouteResult driveRouteResult, int i) {
                if (driveRouteResult == null || driveRouteResult.getPaths() == null ||
                        driveRouteResult.getPaths().size() <= 0) {
                    return;
                }
                DrivePath drivePath = driveRouteResult.getPaths().get(0);
                List<MyLatLng> routePlanPoints = new ArrayList<>();
                if (drivePath != null) {
                    List<DriveStep> driveSteps = drivePath.getSteps();
                    if (driveSteps != null) {
                        for (DriveStep driveStep : driveSteps) {
                            if (driveStep != null) {
                                List<MyLatLng> polyline = AMapPositionsUtils.transforLatLonPointToMyLatlngPosition(driveStep.getPolyline());
                                if (polyline != null) {
                                    routePlanPoints.addAll(polyline);
                                }
                            }
                        }
                        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_OTHER, "寻路 成功");
                    }
                }
                if (driveRouteCallback != null) {
                    if (routePlanPoints.size() <= 0) {
                        driveRouteCallback.onFailed();
                    } else {
                        driveRouteCallback.onSuccess(routePlanPoints);
                    }
                }
            }

            @Override
            public void onWalkRouteSearched(WalkRouteResult walkRouteResult, int i) {
                if (walkRouteResult == null || walkRouteResult.getPaths() == null ||
                        walkRouteResult.getPaths().size() <= 0) {
                    return;
                }
                WalkPath walkPath = walkRouteResult.getPaths().get(0);
                List<MyLatLng> routePlanPoints = new ArrayList<>();
                if (walkPath != null) {
                    List<WalkStep> walkSteps = walkPath.getSteps();
                    if (walkSteps != null) {
                        for (WalkStep walkStep : walkSteps) {
                            if (walkStep != null) {
                                List<MyLatLng> polyline = AMapPositionsUtils.transforLatLonPointToMyLatlngPosition(walkStep.getPolyline());
                                if (polyline != null) {
                                    routePlanPoints.addAll(polyline);
                                }
                            }
                        }
                        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_OTHER, "寻路 成功");
                    }
                }
                if (walkRouteCallback != null) {
                    if (routePlanPoints.size() <= 0) {
                        walkRouteCallback.onFailed();
                    } else {
                        walkRouteCallback.onSuccess(routePlanPoints);
                    }
                }
            }

            @Override
            public void onRideRouteSearched(RideRouteResult rideRouteResult, int i) {

            }
        });
    }

    private float mChangedZoomLevel = MapController.CURRENT_ZOOM_LEVEL;
    private Runnable cameraUpateRunnable = new Runnable() {
        @Override
        public void run() {
            if (mCurrentCameraPosition == null) {
                return;
            }
            LocalMapConfig.CURRENT_VIEW_LATITUDE = mCurrentCameraPosition.target.latitude;
            LocalMapConfig.CURRENT_VIEW_LONGITUDE = mCurrentCameraPosition.target.longitude;
            MapController.getVisibleBounds().setLatLng(
                    new MyLatLng(getMap().getProjection().getVisibleRegion().latLngBounds.southwest.latitude,
                            getMap().getProjection().getVisibleRegion().latLngBounds.southwest.longitude),
                    new MyLatLng(getMap().getProjection().getVisibleRegion().latLngBounds.northeast.latitude,
                            getMap().getProjection().getVisibleRegion().latLngBounds.northeast.longitude));
            LocalMapConfig.CURRENT_PX_IN_METERS = aMap.getScalePerPixel();

            // 计算上一次和这次的变化值+上次的变化值
            float changedZoom = Math.abs(MapController.CURRENT_ZOOM_LEVEL - mCurrentCameraPosition.zoom) + mChangedZoomLevel;
            MapController.CURRENT_ZOOM_LEVEL = mCurrentCameraPosition.zoom;
            if (changedZoom >= 0.5) {
                mChangedZoomLevel = 0;
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "地图变化 | zoom:"
                        + MapController.CURRENT_ZOOM_LEVEL + " | 经纬度:" + mCurrentCameraPosition.target.toString());
                MapObserver.onMapStatusChanged(MapController.CURRENT_ZOOM_LEVEL);
                if (mClusterOverlay != null) {
                    mClusterOverlay.onCameraChangeFinish(mCurrentCameraPosition);
                }
            } else {
                mChangedZoomLevel = changedZoom;
            }

            MapController.INSTANCE.checkShowedTitleOverlay();
            if (MapConstants.isShowTitleOverlay()) {
                if (currentShowMarker != null) {
                    MarkerDataModel markerDataModel = (MarkerDataModel) currentShowMarker.getObject();
                    if (markerDataModel.type == Drone.MARKER_TYPE.SHIP ||
                            markerDataModel.type == Drone.MARKER_TYPE.AIRCRAFT) {
                        currentShowMarker.hideInfoWindow();
                    }
                }
            }
        }
    };

    private void startLocation() {
        if (mlocationClient == null) {
            try {
                mlocationClient = new AMapLocationClient(mapView.getContext());
            } catch (Exception e) {
                XAppLogger.getInstance().writeError("AMapLocationClient() %s", e.toString());
            }
        }
        if (mLocationOption == null) {
            mLocationOption = new AMapLocationClientOption();
        }
        //设置定位监听
        mlocationClient.setLocationListener(new AMapLocationListener() {
            @Override
            public void onLocationChanged(AMapLocation aMapLocation) {
                if (mListener != null && aMapLocation != null) {
                    if (aMapLocation.getErrorCode() == 0) {
                        double latitude = aMapLocation.getLatitude();    //获取纬度信息
                        double longitude = aMapLocation.getLongitude();    //获取经度信息
                        LocalMapConfig.LATITUDE = latitude;
                        LocalMapConfig.LONGITUDE = longitude;
                        if (!isMoveCamera) {
                            setZoom(latitude, longitude);
                            isMoveCamera = true;
                        }
                    } else {
                        String errText = "定位失败," + aMapLocation.getErrorCode() + ": " + aMapLocation.getErrorInfo();
                        XAppLogger.getInstance().writeError("AmapErr", errText);
                    }
                }
            }
        });
        // 设置为高精度定位模式
        mLocationOption.setLocationMode(AMapLocationClientOption.AMapLocationMode.Hight_Accuracy);
        // 可以wifi扫描
        mLocationOption.setWifiScan(true);
        // 需要详细地址
        mLocationOption.setNeedAddress(true);
        // 不至一次定位
        mLocationOption.setOnceLocation(false);
        // 是指定位间隔 5秒钟一次
        mLocationOption.setInterval(LocalMapConfig.LOCATION_SCANSPAN);
        // 设置定位参数
        mlocationClient.setLocationOption(mLocationOption);
        // 在定位结束后，在合适的生命周期调用onDestroy()方法
        // 在单次定位情况下，定位无论成功与否，都无需调用stopLocation()方法移除请求，定位sdk内部会移除
        mlocationClient.startLocation();
    }

    private void setupLocationStyle() {
        locationStyle = new MyLocationStyle();
//        locationStyle.myLocationIcon(AMapBitmapManager.getInstance().getBitmapDescriptor(R.drawable.defaultcluster, MapController.CURRENT_ZOOM_LEVEL));
//        // 定位一次，且将视角移动到地图中心点
//        locationStyle.myLocationType(MyLocationStyle.LOCATION_TYPE_LOCATE);
        // 不显示蓝点
        // 隐藏定位圈边框
        locationStyle.strokeWidth(0);
        // 隐藏定位圈填充色
//        locationStyle.radiusFillColor(Color.TRANSPARENT);
//        locationStyle.showMyLocation(false);
        // 设置定位蓝点的Style
        aMap.setMyLocationStyle(locationStyle);
    }


    private class MyZoomListener implements MapObserver.IZoomButtonClickListener {

        @Override
        public void onZoomIn() {
            if (aMap != null) {
                aMap.animateCamera(CameraUpdateFactory.zoomIn());
            }
        }

        @Override
        public void onZoomOut() {
            if (aMap != null) {
                aMap.animateCamera(CameraUpdateFactory.zoomOut());
            }
        }

    }

    /**
     * 对地图进行截屏
     */
    public void onMapScreenShot(IGetBitmapCallback callback) {
        aMap.getMapScreenShot(new AMap.OnMapScreenShotListener() {
            @Override
            public void onMapScreenShot(Bitmap bitmap) {
            }

            @Override
            public void onMapScreenShot(Bitmap bitmap, int status) {
                HandlerUtils.getUIHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        if (callback != null) {
                            callback.onMapScreenShot(bitmap, status);
                        }
                    }
                });
            }
        });
    }

    public void clear() {
        if (aMap != null) {
            aMap.clear();
        }
    }

    public void onStart() {

    }

    public void onStop() {
        deactivate();
    }

    public void onResume() {
        if (mapView != null) {
            mapView.onResume();
        }
    }

    public void onPause() {
        if (mapView != null) {
            mapView.onPause();
        }
    }

    public void onDestroy() {
        if (myZoomListener != null) {
            MapObserver.unRegisterZoomClickObserver(myZoomListener);
        }
        if (mClusterOverlay != null) {
            mClusterOverlay.onDestroy();
        }
        if (mapView != null) {
            mapView.onDestroy();
            mapView = null;
        }
        mHeatMapBuilder = null;
        if (mTileOverlay != null) {
            mTileOverlay.remove();
            mTileOverlay = null;
        }
        if (tileOverlay != null) {
            tileOverlay.remove();
            tileOverlay = null;
        }
        clear();
    }

    private static MaMapUtils instance;
    private MaMapUtils() {
    }

    public static MaMapUtils getInstance() {
        if (instance == null) {
            synchronized (MaMapUtils.class) {
                if (instance == null) {
                    instance = new MaMapUtils();
                }
            }
        }
        return instance;
    }

    public void stopAnimation(Marker marker) {
        if (marker != null) {
            marker.setTitle("0");
            marker.setAnimation(null);
        }
    }

    /**
     * 屏幕中心marker 跳动
     */
    public void startJumpAnimation(Marker marker) {
        if (marker == null) return;
        marker.setTitle("1");
        startTranslateAnimation(marker, new Animation.AnimationListener() {
            int maxCount = (int) (LocalMapConfig.NEW_VIDEO_TIME / 600);
            int currentCount = 3;

            @Override
            public void onAnimationStart() {

            }

            @Override
            public void onAnimationEnd() {
                if (marker != null && marker.getTitle().equals("1")) {
                    if (currentCount < maxCount) {
                        currentCount += 3;
                        startTranslateAnimation(marker, this);
                    }
                }
            }
        });
    }

    private void startTranslateAnimation(Marker marker, Animation.AnimationListener listener) {
        //根据屏幕距离计算需要移动的目标点
        final LatLng latLng = marker.getPosition();
        Point point = aMap.getProjection().toScreenLocation(latLng);
        point.y -= DisplayUtil.dip2px(ContextStore.getContext(), 30);
        LatLng target = aMap.getProjection().fromScreenLocation(point);
        //使用TranslateAnimation,填写一个需要移动的目标点
        Animation animation = new TranslateAnimation(target);
        animation.setInterpolator(new Interpolator() {
            @Override
            public float getInterpolation(float input) {
                // 模拟重加速度的interpolator
                if (input <= 0.5) {
                    return (float) (0.5f - 2 * (0.5 - input) * (0.5 - input));
                } else {
                    return (float) (0.5f - Math.sqrt((input - 0.5f) * (1.5f - input)));
                }
            }
        });
        animation.setAnimationListener(listener);
        //整个移动所需要的时间
        animation.setDuration(600);
        // 无限循环
        animation.setRepeatCount(3);
        //设置动画
        marker.setAnimation(animation);
        //开始动画
        marker.startAnimation();
    }

    private void startBreatheAnimation() {
        // 呼吸动画
//        if(breatheMarker == null) {
//            LatLng latLng = new LatLng(latlng.latitude - 0.02, latlng.longitude - 0.02);
//            breatheMarker = aMap.addMarker(new MarkerOptions().position(latLng).zIndex(1)
//                    .anchor(0.5f,0.5f).icon(BitmapDescriptorFactory.fromResource(R.drawable.marker_circle_64)));
//            // 中心的marker
//            breatheMarker_center = aMap.addMarker(new MarkerOptions().position(latLng).zIndex(2)
//                    .anchor(0.5f,0.5f).icon(BitmapDescriptorFactory.fromResource(R.drawable.marker_circle_64)));
//        }

        // 动画执行完成后，默认会保持到最后一帧的状态
        AnimationSet animationSet = new AnimationSet(true);

        AlphaAnimation alphaAnimation = new AlphaAnimation(0.5f, 0f);
        alphaAnimation.setDuration(2000);
        // 设置不断重复
        alphaAnimation.setRepeatCount(Animation.INFINITE);

        ScaleAnimation scaleAnimation = new ScaleAnimation(1, 3.5f, 1, 3.5f);
        scaleAnimation.setDuration(2000);
        // 设置不断重复
        scaleAnimation.setRepeatCount(Animation.INFINITE);


        animationSet.addAnimation(alphaAnimation);
        animationSet.addAnimation(scaleAnimation);
        animationSet.setInterpolator(new LinearInterpolator());
//        breatheMarker.setAnimation(animationSet);
//        breatheMarker.startAnimation();
    }

    /**
     * 添加一个从地上生长的Marker
     */
    public void addGrowMarker() {
//            MarkerOptions markerOptions = new MarkerOptions().icon(BitmapDescriptorFactory
//                    .defaultMarker(BitmapDescriptorFactory.HUE_AZURE))
//                    .position(latlng);
//            growMarker = aMap.addMarker(markerOptions);

        startGrowAnimation();
    }

    /**
     * 地上生长的Marker
     */
    private void startGrowAnimation() {
        Animation animation = new ScaleAnimation(0, 1, 0, 1);
        animation.setInterpolator(new LinearInterpolator());
        //整个移动所需要的时间
        animation.setDuration(1000);
//            //设置动画
//            growMarker.setAnimation(animation);
//            //开始动画
//            growMarker.startAnimation();
    }

}
