package com.drone.monitor.bean;

import com.drone.monitor.bean.custom.MyObject;
import com.tools.module.amap.model.RoutePointModel;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by jiajiecsf on 2020/6/1.
 */
public class BaseRouteHistoryData extends MyObject {

    public String itemId;
    public int status;
    public List<RoutePointModel> points;

    public void copy(ShipRouteHistoryData shipHistoryData) {
        itemId = shipHistoryData.itemId;
        status = shipHistoryData.status;
        BaseRouteHistoryData baseRouteHistoryData = new BaseRouteHistoryData();
        baseRouteHistoryData.itemId = shipHistoryData.itemId;
        List<RoutePointModel> routePointModels = new ArrayList<>();
        for (ShipRouteHistoryData.PositionPoint shipPoint : shipHistoryData.points) {
            RoutePointModel routePointModel = new RoutePointModel();
            routePointModel.copy(shipPoint);
            routePointModels.add(routePointModel);
        }
        points = routePointModels;
    }
}
