package com.tools.module.amap.model.amap;

import com.tools.module.amap.BuildConfig;
import com.tools.module.amap.map.amap.MaMapUtils;
import com.tools.module.amap.map.amap.clusterutil.model.AMapClusterItem;
import com.tools.module.amap.observer.FloatWindowsObserver;
import com.amap.api.maps.model.Marker;
import com.drone.monitor.bean.Drone;
import com.drone.monitor.bean.VideoInfo;
import com.tools.module.amap.model.MarkerDataModel;
import com.tools.module.amap.model.base.BaseVideoModel;
import com.tools.module.common.utils.XAppLogger;

/**
 * Created by jiajie on 2020-02-17.
 */
public class AMapVideoModel extends BaseVideoModel<Marker> {

    @Override
    public void addMarker(VideoInfo video) {
        super.addMarker(video);
        if (!isContainsVideo(video) && !isHideVideo(video)) {
            if (video.isNewVideo()) {
                FloatWindowsObserver.getInstance().addVideoShowFloatWindow(video);
            }
            AMapClusterItem item = new AMapClusterItem(video.videoId, video.getMyLatLng(),
                    Drone.MARKER_TYPE.VIDEO, 0);
            MarkerDataModel mkDataModel = new MarkerDataModel();
            mkDataModel.type = Drone.MARKER_TYPE.VIDEO;
            mkDataModel.data = video;
            item.setObject(mkDataModel);
            MaMapUtils.getInstance().getClusterOverlay().addClusterItem(item);
            addClusterItems(video.videoId, item);
            addVideo(video.videoId, video);
            if (BuildConfig.DEBUG) {
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_VIDEO, TAG + " video:" + video.toString());
            }
        }
    }

    @Override
    public void onMapStatusChange(float currentZoomLevel) {
        super.onMapStatusChange(currentZoomLevel);
    }

    @Override
    public void updateMarker(VideoInfo video) {
        if (isContainsVideo(video) && !isHideVideo(video)) {
            if (!video.isNewVideo()) {
                AMapClusterItem clusterItem = (AMapClusterItem) getClusterItem(video.videoId);
                if (clusterItem != null) {
                    clusterItem.setNeedJumpAnimation(false);
                    MaMapUtils.getInstance().getClusterOverlay().updateClusterItem(clusterItem);
                }
            }
        }
    }

    @Override
    public void removeMarker(VideoInfo video) {
        if (isContainsVideo(video)) {
            removeVideo(video.videoId);
            AMapClusterItem clusterItem = (AMapClusterItem) removeClusterItem(video.videoId);
            if (clusterItem != null) {
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_VIDEO, "removeMarker() | removeClusterItem:" + video.videoId);
                MaMapUtils.getInstance().getClusterOverlay().removeClusterItem(clusterItem);
            }
        }
    }

    @Override
    public void removeMarker(String videoId) {
        VideoInfo videoInfo = getVideoInfo(videoId);
        if (videoInfo != null) {
            removeMarker(videoInfo);
        }
    }

    @Override
    public void eraseMarker(String videoId) {
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_VIDEO, "eraseMarker() | videoId:" + videoId);
        removeMarker(videoId);
        removeHideVideo(videoId);
    }

    @Override
    public void eraseMarker(VideoInfo video) {
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_VIDEO, "eraseMarker() | video.videoId:" + video.videoId);
        removeMarker(video);
        if (video != null) {
            removeHideVideo(video.videoId);
        }
    }
}
