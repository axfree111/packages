package com.tools.module.amap.manager;

import com.tools.module.common.utils.ResourceUtil;
import com.tools.module.amap.map.LocalMapConfig;
import com.tools.module.amap.map.MapController;
import com.tools.module.amap.R;
import com.tools.module.amap.model.base.BaseMonitorModel;

import java.util.HashMap;
import java.util.Map;

import com.drone.monitor.bean.MonitorDevice;

/**
 * Created by jiajie on 2019-12-10.
 */
public class ColorManager {

    private static Map<Integer, String> mColorIds = new HashMap<>();
    private static Map<String, Integer> mColorStringToIds = new HashMap<>();

    public static void init() {
        mColorIds.put(ResourceUtil.getColor(R.color.black), "#000000");
        mColorIds.put(ResourceUtil.getColor(R.color.red), "#ffFF0000");
        mColorIds.put(ResourceUtil.getColor(R.color.yellow), "#ffffff00");
        mColorIds.put(ResourceUtil.getColor(R.color.green), "#ff00FF00");
        mColorIds.put(ResourceUtil.getColor(R.color.blue), "FF0000FF");
        mColorIds.put(ResourceUtil.getColor(R.color.purple), "#FF9B30FF");

        mColorStringToIds.put("#000000", ResourceUtil.getColor(R.color.black));
        mColorStringToIds.put("#ffFF0000", ResourceUtil.getColor(R.color.red));
        mColorStringToIds.put("#ffffff00", ResourceUtil.getColor(R.color.yellow));
        mColorStringToIds.put("#ff00FF00", ResourceUtil.getColor(R.color.green));
        mColorStringToIds.put("FF0000FF", ResourceUtil.getColor(R.color.blue));
        mColorStringToIds.put("#FF9B30FF", ResourceUtil.getColor(R.color.purple));
    }

    public static int getColorId(String colorStr) {
        if (mColorStringToIds != null && mColorStringToIds.containsKey(colorStr)) {
            return mColorStringToIds.get(colorStr);
        }
        return ResourceUtil.getColor(R.color.transparent);
    }

    public static String getColorStr(int color) {
        if (mColorIds != null && mColorIds.containsKey(color)) {
            return mColorIds.get(color);
        }
        return "#000000";
    }

    public static int getDroneAroundCirclelineColor() {
        return ResourceUtil.getColor(R.color.device_warning_or_distern_finddrone_color);
    }

    public static int getDroneWaringTvBgColor() {
        return ResourceUtil.getColor(R.color.white);
    }

    public static int getDroneWarningTvColor() {
        return ResourceUtil.getColor(R.color.device_warning_or_distern_finddrone_color);
    }

    public static int getAttackLineColor() {
        return ResourceUtil.getColor(R.color.red);
    }

    public static int getRouteLineColor() {
        return ResourceUtil.getColor(R.color.route_line_color);
    }

    public static int getDisconnectRouteLineColor() {
        return ResourceUtil.getColor(R.color.red);
    }

    public static int getNoteInfoLineColor() {
        return ResourceUtil.getColor(R.color.history_note_tv_bg_frame_color);
    }

    public static int getAttackTargetLineColor() {
        return ResourceUtil.getColor(R.color.device_warning_or_distern_finddrone_color);
    }

    public static int getMonitorRouteLineColor() {
        return ResourceUtil.getColor(R.color.history_note_tv_bg_frame_color);
    }

    public static int getNameTvColor() {
        return ResourceUtil.getColor(R.color.device_radii_text_color);
    }

    public static int getIntervalTvColor() {
        return ResourceUtil.getColor(R.color.device_radii_text_color);
    }

    public static int getLineColor() {
        return ResourceUtil.getColor(R.color.device_area_line_color);
    }

    public static int getDistrictFenceLineColor() {
        return ResourceUtil.getColor(R.color.fence_line_color);
    }

    public static int getDistrictFencCoverColor() {
        if (MapController.IS_EDIT_MAP) {
            return ResourceUtil.getColor(R.color.fence_cover_color);
        } else {
            return ResourceUtil.getColor(R.color.transparent);
        }
    }

    public static int getSelectAreaCoverColor() {
        return ResourceUtil.getColor(R.color.device_default_color);
    }

    public static int getScanCoverColor(int status) {
        int color;
        switch (status) {
            case MonitorDevice.DEVICE_STATUS.SELECTED:
                color = R.color.device_selected_color;
                break;
            case MonitorDevice.DEVICE_STATUS.FIND_AVIATION:
                color = R.color.device_findaviation_color;
                break;
            case MonitorDevice.DEVICE_STATUS.FIND_DRONE:
                color = R.color.device_finddrone_color;
                break;
            case MonitorDevice.DEVICE_STATUS.EXCEPTION:
            case MonitorDevice.DEVICE_STATUS.MAINTAIN:
                color = R.color.device_exception_color;
                break;
            case MonitorDevice.DEVICE_STATUS.WORK:
                color = R.color.device_work_color;
                break;
            case MonitorDevice.DEVICE_STATUS.POWER_ON:
            case MonitorDevice.DEVICE_STATUS.POWER_OFF:
                if (BaseMonitorModel.SHOW_AWAIT_COVER) {
                    color = R.color.device_default_color;
                } else {
                    color = R.color.transparent;
                }
                break;
            default:
                color = R.color.transparent;
                break;
        }
        return ResourceUtil.getColor(color);
    }

    public static int getScanLineColor(int status) {
        int color;
        switch (status) {
            case MonitorDevice.DEVICE_STATUS.SELECTED:
                color = R.color.device_selected_scan_line_color;
                break;
            case MonitorDevice.DEVICE_STATUS.FIND_AVIATION:
                color = R.color.device_findaviation_scan_line_color;
                break;
            case MonitorDevice.DEVICE_STATUS.FIND_DRONE:
                color = R.color.device_finddrone_scan_line_color;
                break;
            case MonitorDevice.DEVICE_STATUS.EXCEPTION:
            case MonitorDevice.DEVICE_STATUS.MAINTAIN:
                color = R.color.device_exception_scan_line_color;
                break;
            case MonitorDevice.DEVICE_STATUS.WORK:
                color = R.color.device_work_scan_line_color;
                break;
            case MonitorDevice.DEVICE_STATUS.POWER_ON:
            case MonitorDevice.DEVICE_STATUS.POWER_OFF:
                if (BaseMonitorModel.SHOW_AWAIT_COVER) {
                    color = R.color.device_default_scan_line_color;
                } else {
                    color = R.color.transparent;
                }
                break;
            default:
                color = R.color.transparent;
                break;
        }
        return ResourceUtil.getColor(color);
    }

    public static int getDeviceAttackAreasColor(boolean isShowAwaitCover, int status) {
        int color;
        switch (status) {
            case MonitorDevice.DEVICE_STATUS.SELECTED:
                color = R.color.device_selected_color;
                break;
            case MonitorDevice.DEVICE_STATUS.FIND_AVIATION:
                color = R.color.device_findaviation_color;
                break;
            case MonitorDevice.DEVICE_STATUS.FIND_DRONE:
                color = R.color.device_finddrone_color;
                break;
            case MonitorDevice.DEVICE_STATUS.EXCEPTION:
            case MonitorDevice.DEVICE_STATUS.MAINTAIN:
                color = R.color.device_exception_color;
                break;
            case MonitorDevice.DEVICE_STATUS.WORK:
                color = R.color.device_work_color;
                break;
            case MonitorDevice.DEVICE_STATUS.POWER_ON:
                if (isShowAwaitCover) {
                    color = R.color.device_default_color;
                } else {
                    color = R.color.transparent;
                }
                break;
            case MonitorDevice.DEVICE_STATUS.POWER_OFF:
                color = R.color.transparent;
                break;
            default:
                color = R.color.transparent;
                break;
        }
        return ResourceUtil.getColor(color);
    }

    public static int getDeviceWarningAreasColor(int warningStatus) {
        int color;
        if (LocalMapConfig.SHOW_AREA_DISTERN) {
            switch (warningStatus) {
                case MonitorDevice.DEVICE_STATUS.FIND_AVIATION:
                    color = R.color.device_findaviation_color;
                    break;
                case MonitorDevice.DEVICE_STATUS.FIND_DRONE:
                    color = R.color.device_warning_or_distern_finddrone_color;
                    break;
                default:
                    color = R.color.device_warning_color;
                    break;
            }
        } else {
            color = R.color.device_warning_color;
        }
        return ResourceUtil.getColor(color);
    }

    public static int getDroneWarningAreasColor() {
        return ResourceUtil.getColor(R.color.device_warning_or_distern_finddrone_color);
    }

    public static int getDeviceDiscernAreasColor(int currentDisternAreaStatus) {
        int color;
        if (LocalMapConfig.SHOW_AREA_DISTERN) {
            switch (currentDisternAreaStatus) {
                case MonitorDevice.DEVICE_STATUS.FIND_AVIATION:
                    color = R.color.device_findaviation_color;
                    break;
                case MonitorDevice.DEVICE_STATUS.FIND_DRONE:
                    color = R.color.device_warning_or_distern_finddrone_color;
                    break;
                default:
                    color = R.color.transparent;
                    break;
            }
        } else {
            color = R.color.transparent;
        }
        return ResourceUtil.getColor(color);
    }
}
