package com.tools.module.amap.model.base;

import com.drone.monitor.bean.custom.MyLatLng;

import androidx.annotation.Nullable;

/**
 * Created by yiyi.qi on 16/10/10.
 */

public interface ClusterItem {

    String getId();

    /**
     * 返回聚合元素的地理位置
     *
     * @return
     */
    MyLatLng getPosition();

    @Nullable
    Object getObject();

    int zIndex();

    int getMarkerType();

    int getType();

    int getStatus();

    int getRotateAngle();

    boolean needJumpAnimation();

    boolean isCircle();
}
