package com.tools.module.amap.model;

/**
 * Date: 2025/4/2
 * Desc:
 * <p>
 * author: jaje
 */
public class MonitorConfig {

    // 无人机入侵时的攻击动画
    public static final boolean SHOW_INVADEDRONE_ANIMATION = true;
    // 注意如果设备最大测试范围不能大于80公里
    public static final int MAX_RANGE = 160;
    // TODO 需要后台支持返回预警区域距离
    public static final int WARNING_DISTANCE = 0;
    public static final int DISTERN_DISTANCE = 0;
    // 闪动动画延迟检测
    public static final int ANIMATION_TWINKLE_DELAY_TIME = 500;
    // 设备外围区域点集合下角标位置
    public static final int POINTS_INDEX_ATTACK_POLYGON = 0;
    // 预警区域点集合下角标位置
    public static final int POINTS_INDEX_WARNING_POLYGON = 1;
    // 识别区域点集合下角标位置
    public static final int POINTS_INDEX_DISTERN_POLYGON = 2;
    // 折线点集合下角标位置
    public static final int POINTS_INDEX_BROKEN_LINE = 3;
    // 预警区弧线点集合下角标位置
    public static final int POINTS_INDEX_WARING_ARC_LINE = 4;
    // 识别区弧线点点集合下角标位置
    public static final int POINTS_INDEX_DISTERN_ARC_LINE = 5;
    // 防角度抖动临界值
    public static int PREVENT_SHAKE_ANGLE = 5;
}
