package com.drone.monitor.bean;

import com.drone.monitor.bean.custom.MyHasRouteObject;

/**
 * Created by jiajiecsf on 2020/11/25.
 */
public class BaseData extends MyHasRouteObject {
    protected int markerType;
    protected String showId;
    protected String showName;
    protected String showExt;
    protected double showLongitude;
    protected double showLatitude;

    public Object tag;

    public int getMarkerType() {
        return markerType;
    }

    public void setMarkerType(int markerType) {
        this.markerType = markerType;
    }

    public String getShowId() {
        return showId;
    }

    public void setShowId(String showId) {
        this.showId = showId;
    }

    public String getShowName() {
        return showName;
    }

    public void setShowName(String showName) {
        this.showName = showName;
    }

    public String getShowExt() {
        return showExt;
    }

    public void setShowExt(String showExt) {
        this.showExt = showExt;
    }

    public double getShowLongitude() {
        return showLongitude;
    }

    public void setShowLongitude(double showLongitude) {
        this.showLongitude = showLongitude;
    }

    public double getShowLatitude() {
        return showLatitude;
    }

    public void setShowLatitude(double showLatitude) {
        this.showLatitude = showLatitude;
    }

    public void copy(BaseData data) {
        setMarkerType(data.getMarkerType());
        setShowId(data.getShowId());
        setShowLatitude(data.getShowLatitude());
        setShowLongitude(data.getShowLongitude());
        setShowName(data.getShowName());
    }

    @Override
    public String toString() {
        return "BaseData{" +
                "markerType=" + markerType +
                ", showId='" + showId + '\'' +
                ", showName='" + showName + '\'' +
                ", showExt='" + showExt + '\'' +
                ", showLongitude=" + showLongitude +
                ", showLatitude=" + showLatitude +
                "} " + super.toString();
    }
}
