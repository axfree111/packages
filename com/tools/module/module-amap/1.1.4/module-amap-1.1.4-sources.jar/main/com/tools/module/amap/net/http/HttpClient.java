package com.tools.module.amap.net.http;

import android.content.Context;
import android.text.TextUtils;

import com.tools.module.amap.net.NetManager;
import com.tools.module.amap.net.http.request.HttpRequestWrapper;
import com.tools.module.amap.net.http.request.IRequestHost;
import com.tools.module.amap.net.http.response.HttpResponseHandler;
import com.tools.module.common.utils.XAppLogger;

import java.util.List;

import okhttp3.Headers;
import okhttp3.Response;

public class HttpClient {
    private static final String CONTENT_TYPE_JSON = "application/json";

    private static void addHeader(HttpRequestWrapper requestWrapper) {
        if (requestWrapper != null) {
            requestWrapper.addHeader("content-type", CONTENT_TYPE_JSON);

            if (!TextUtils.isEmpty(NetManager.getSession())) {
                requestWrapper.addHeader("cookie", NetManager.getSession());
            }

            if (!TextUtils.isEmpty(NetManager.getToken())) {
                requestWrapper.addHeader("access_token", NetManager.getToken());
            }
            requestWrapper.addHeader("client", "app");
        }
    }

    /**
     * *********************************************************************************************************************
     * **************************************** GET请求 *********************************************************************
     */
    public static HttpRequestWrapper get(String url) {
        return get(url, null);
    }

    public static HttpRequestWrapper get(String url, HttpResponseHandler<?> responseHandler) {
        return get(url, responseHandler, null);
    }

    /**
     * Get请求
     *
     * @param url
     * @param responseHandler
     * @param requestHost
     * @return
     */
    public static HttpRequestWrapper get(String url, HttpResponseHandler<?> responseHandler, IRequestHost requestHost) {
        if (NetManager.isDebug()) {
            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "get(), url: " + url);
        }
        HttpRequestWrapper requestWrapper = new HttpRequestWrapper(HttpRequestWrapper.HttpType.Get, url);
        addHeader(requestWrapper);
        requestWrapper.setResponseHandler(responseHandler)
                .setRequestHost(requestHost);
        return requestWrapper;
    }
    /**
     ****************************************** GET请求 *********************************************************************
     * *********************************************************************************************************************
     */


    /**
     * *********************************************************************************************************************
     * **************************************** POST请求 ********************************************************************
     */
    public static HttpRequestWrapper post(String url) {
        return post(url, null);
    }

    public static HttpRequestWrapper post(String url, HttpResponseHandler<?> responseHandler) {
        return post(url, responseHandler, null);
    }

    /**
     * Post 请求
     *
     * @param url
     * @param responseHandler
     * @param requestHost
     * @return
     */
    public static HttpRequestWrapper post(String url, HttpResponseHandler<?> responseHandler, IRequestHost requestHost) {
        if (NetManager.isDebug()) {
            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "post(), url: " + url);
        }
        HttpRequestWrapper requestWrapper = new HttpRequestWrapper(HttpRequestWrapper.HttpType.Post, url);
        addHeader(requestWrapper);
        requestWrapper.setResponseHandler(responseHandler)
                .setRequestHost(requestHost);
        return requestWrapper;
    }
    /**
     ****************************************** POST请求 ********************************************************************
     * *********************************************************************************************************************
     */

    /**
     * *********************************************************************************************************************
     * **************************************** 上传文件 ********************************************************************
     */
    public static HttpRequestWrapper upload(String url, String uploadFilePath, HttpResponseHandler<?> responseHandler) {
        return upload(url, uploadFilePath, null, responseHandler);
    }

    /**
     * 上传文件
     *
     * @param url
     * @param uploadFilePath
     * @param uploadParameterName
     * @param responseHandler
     * @return
     */
    public static HttpRequestWrapper upload(String url, String uploadFilePath, String uploadParameterName, HttpResponseHandler<?> responseHandler) {
        if (NetManager.isDebug()) {
            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "upload(), url: " + url + ", uploadFilePath: " + uploadFilePath);
        }
        HttpRequestWrapper requestWrapper = new HttpRequestWrapper(HttpRequestWrapper.HttpType.Post, url);
        requestWrapper.setResponseHandler(responseHandler)
                .uploadFile(uploadFilePath, uploadParameterName);
        return requestWrapper;
    }
    /**
     ****************************************** 上传文件 ********************************************************************
     * *********************************************************************************************************************
     */

    /**
     * 取消单个异步请求
     */
    public static void cancelRequests(HttpResponseHandler<?> responseHandler) {
        if (NetManager.isDebug()) {
            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "cancelRequests(), responseHandler: " + responseHandler.hashCode());
        }
        OkHttpUtils.cancelRequests(responseHandler.hashCode());
    }

    /**
     * 取消context对应的所有异步请求
     *
     * @param context =å
     */
    public static void cancelRequests(Context context) {
        if (NetManager.isDebug()) {
            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "cancelRequests(), context: " + context.getClass().getName());
        }
        OkHttpUtils.cancelRequests(context.hashCode());
    }

    /**
     * 停止所有的请求
     */
    public static void stopAll() {
        if (NetManager.isDebug()) {
            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "stopAll()");
        }
        OkHttpUtils.stopAll();
    }

    /**
     * 异步执行
     *
     * @param requestWeapper
     */
    public static void execute(HttpRequestWrapper requestWeapper) {
        if (requestWeapper != null) {
            if (NetManager.isDebug()) {
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, requestWeapper.getHeadersMap().toString());
            }
            OkHttpUtils.execute(requestWeapper);
        }
    }

    /**
     * 异步执行
     *
     * @param requestWeapper
     */
    public static void execute(HttpRequestWrapper requestWeapper, long timeOut) {
        if (requestWeapper != null) {
            if (NetManager.isDebug()) {
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, requestWeapper.getHeadersMap().toString());
            }
            OkHttpUtils.execute(requestWeapper, timeOut);
        }
    }

    public static void readHeaders(Response okhttpResponse) {
        Headers headers = okhttpResponse.headers();
        List<String> cookies = headers.values("Set-Cookie");

        for (String cookie : cookies) {
            if (cookie.toLowerCase().startsWith("session=")) {
                cookie = cookie.substring(0, cookie.indexOf(";"));
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_SOCKET, "cookie: " + cookie);
                NetManager.setSession(cookie);
                break;
            }
        }

        List<String> tokens = headers.values("access_token");
        if (tokens.size() > 0) {
            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_SOCKET, "token: " + tokens.get(0));
            NetManager.setToken(tokens.get(0));
        }
    }
}
