package com.tools.module.amap.net.http.response;

import com.tools.module.amap.net.http.request.HttpRequestWrapper;
import com.tools.module.common.utils.AppUtil;
import com.tools.module.common.utils.XAppLogger;


/**
 * HttpResponseHandler, 泛型HTTP回调接口类
 *
 * @param <T>
 * @author changjiajie
 */
public abstract class HttpResponseHandler<T> extends AbstractHttpResponseHandler<T> {
    //
    // Callbacks to be overridden, typically anonymously
    //

    private static final String TAG = "HttpResponseHandler";

    public HttpResponseHandler() {
        this(false);
    }

    public HttpResponseHandler(boolean uiCallback) {
        super(uiCallback);
    }

    /**
     * Fired when the request is started, override to handle in your own code
     */
    @Override
    public void onStart() {
    }

    /**
     * Fired in all cases when the request is finished, after both success and failure, override to handle in your own code
     */
    @Override
    public void onFinish() {
    }

    /**
     * Fired when a request fails to complete, override to handle in your own code
     *
     * @param error   the underlying cause of the failure
     * @param content the response body, if any
     */
    @Override
    public void onFailure(Throwable error, int statusCode, T content) {
        // By default, call the deprecated onFailure(Throwable) for compatibility
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "onFailure(), error: " + AppUtil.getExceptionString(error));
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "onFailure(), " + ", content: " + ((content != null) ? content.toString() : "null") + ", error: " + error);
        super.onFailure(error, statusCode, content);
    }

    /**
     * progress interface
     *
     * @param percent
     * @param byteCount
     */
    @Override
    public void onProgress(int percent, int byteCount) {
    }

    /**
     * 取消执行
     *
     * @return
     */
    @Override
    public void onCancel() {
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "onCancel()");
    }

    public void setHttpRequestWrapper(HttpRequestWrapper requestWrapper) {
        this.requestWrapper = requestWrapper;
    }
}
