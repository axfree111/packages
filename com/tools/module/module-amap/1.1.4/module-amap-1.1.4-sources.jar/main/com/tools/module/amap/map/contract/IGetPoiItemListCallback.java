package com.tools.module.amap.map.contract;

import com.tools.module.amap.model.MyPoiItem;

import java.util.List;

/**
 * Created by jiajie on 2020-01-19.
 */
public interface IGetPoiItemListCallback {
    // 搜索关键词对应的地址列表
    void onSearchKeywordSuccess(List<MyPoiItem> myPoiItems);
}
