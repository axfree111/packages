package com.tools.module.amap.model;

import java.io.Serializable;

/**
 * Created by jiajie on 2020-03-11.
 */
public class AircraftInfoModel implements Serializable {
    public String content;
    public boolean isOnlyLine = true;

    public AircraftInfoModel(String content) {
        this.content = content;
    }

    public AircraftInfoModel(String content, boolean isOnlyLine) {
        this.content = content;
        this.isOnlyLine = isOnlyLine;
    }
}
