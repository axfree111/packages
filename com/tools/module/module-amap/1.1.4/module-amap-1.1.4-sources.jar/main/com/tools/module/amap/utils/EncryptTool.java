package com.tools.module.amap.utils;

import android.util.Base64;

import com.tools.module.common.utils.XAppLogger;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;


/**
 * Created by jiajie on 2020-01-08.
 */
public class EncryptTool {
    /**
     * 加密
     *
     * @param str
     * @return
     * @throws NoSuchAlgorithmException
     * @throws UnsupportedEncodingException
     */
    public static String encoderBySHA1AndBase64(String str) {
        String newstr = str;
        try {
            byte[] digesta;
            MessageDigest alga = MessageDigest.getInstance("SHA-1");
            alga.update(str.getBytes());
            //加密
            digesta = alga.digest();
            newstr = byte2hex(digesta);
//            //加密
//            newstr = Base64.encodeToString(md5.digest(str.getBytes("UTF-8")), Base64.NO_WRAP);
            //解密
        } catch (Exception e) {
            XAppLogger.getInstance().writeError(e);
        }
        return newstr;
    }

    /**
     * 解密
     *
     * @param str
     * @return
     * @throws NoSuchAlgorithmException
     * @throws UnsupportedEncodingException
     */
    public static String decoderByMd5(String str) {
        try {
            return new String(Base64.decode(str, Base64.NO_WRAP), "UTF-8");
        } catch (Exception e) {
            XAppLogger.getInstance().writeError(e);
        }
        return str;
    }

    private static String byte2hex(byte[] b) {
        String hs = "";
        String stmp = "";
        for (int n = 0; n < b.length; n++) {
            stmp = (Integer.toHexString(b[n] & 0XFF));
            if (stmp.length() == 1) {
                hs = hs + "0" + stmp;
            } else {
                hs = hs + stmp;
            }
        }
        return hs;
    }
}
