package com.tools.module.amap.utils;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.telephony.TelephonyManager;

import com.tools.module.common.ContextStore;
import com.tools.module.common.utils.ToastUtil;
import com.tools.module.common.utils.XAppLogger;

/**
 * Created by jiajie on 2019-07-19.
 */
public class NetworkUtils {

    private static final String TAG = NetworkUtils.class.getSimpleName();

    private static NetworkInfo getNetworkInfo() {
        ConnectivityManager connectivityManager = (ConnectivityManager) ContextStore.getContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        return connectivityManager.getActiveNetworkInfo();
    }

    /**
     * 得到当前网络是否是正常联网下的非wifi状态
     *
     * @return
     */
    public static boolean isWifiAvailable() {
        NetworkInfo networkInfo = getNetworkInfo();
        if (networkInfo != null && networkInfo.isAvailable()) {//联网状态
            //网络状态正常的情况，判断是wifi：
            if (networkInfo != null && networkInfo.getType() == ConnectivityManager.TYPE_WIFI) {
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_OTHER, "  wifi状态");
                return true;
            }
            //非wifi
            else {
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_OTHER, "  正常联网的非wifi状态");
                return false;
            }
        }
        return false;
    }


    /**
     * 判断手机是否联网
     *
     * @return
     */
    public static boolean isNetworkAvailableWithToast() {
        NetworkInfo info = getNetworkInfo();
        if (info != null && info.isAvailable()) {// 联网状态
            return true;
        } else {// 断网状态 先断开连接
            ToastUtil.makeLongText("没有可用网络，请检查网络是否连接");
            return false;
        }
    }

    /**
     * 判断手机是否联网
     *
     * @return
     */
    public static boolean isNetworkAvailable() {
        NetworkInfo info = getNetworkInfo();
        if (info != null && info.isAvailable()) {// 联网状态
            return true;
        } else {// 断网状态 先断开连接
            return false;
        }
    }

    public interface NETWORK_TYPE {
        String WIFI = "wifi";
        String M_2G = "2G";
        String M_3G = "3G";
        String M_4G = "4G";
        String UNKNOWN = "unknown";
    }

    /**
     * 获取网络环境
     *
     * @return
     */
    public static String getNetworkType() {

        String strNetworkType = "";
        NetworkInfo networkInfo = getNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            if (networkInfo.getType() == ConnectivityManager.TYPE_WIFI) {
                strNetworkType = NETWORK_TYPE.WIFI;
            } else if (networkInfo.getType() == ConnectivityManager.TYPE_MOBILE) {

                String _strSubTypeName = networkInfo.getSubtypeName();

                // TD-SCDMA   networkType is 17
                int networkType = networkInfo.getSubtype();
                switch (networkType) {
                    case TelephonyManager.NETWORK_TYPE_GPRS:
                    case TelephonyManager.NETWORK_TYPE_EDGE:
                    case TelephonyManager.NETWORK_TYPE_CDMA:
                    case TelephonyManager.NETWORK_TYPE_1xRTT:
                    case TelephonyManager.NETWORK_TYPE_IDEN: //api<8 : replace by 11
                        strNetworkType = NETWORK_TYPE.M_2G;
                        break;
                    case TelephonyManager.NETWORK_TYPE_UMTS:
                    case TelephonyManager.NETWORK_TYPE_EVDO_0:
                    case TelephonyManager.NETWORK_TYPE_EVDO_A:
                    case TelephonyManager.NETWORK_TYPE_HSDPA:
                    case TelephonyManager.NETWORK_TYPE_HSUPA:
                    case TelephonyManager.NETWORK_TYPE_HSPA:
                    case TelephonyManager.NETWORK_TYPE_EVDO_B: //api<9 : replace by 14
                    case TelephonyManager.NETWORK_TYPE_EHRPD:  //api<11 : replace by 12
                    case TelephonyManager.NETWORK_TYPE_HSPAP:  //api<13 : replace by 15
                        strNetworkType = NETWORK_TYPE.M_3G;
                        break;
                    case TelephonyManager.NETWORK_TYPE_LTE:    //api<11 : replace by 13
                        strNetworkType = NETWORK_TYPE.M_4G;
                        break;
                    default:
                        // http://baike.baidu.com/item/TD-SCDMA 中国移动 联通 电信 三种3G制式
                        if (_strSubTypeName.equalsIgnoreCase("TD-SCDMA")
                                || _strSubTypeName.equalsIgnoreCase("WCDMA")
                                || _strSubTypeName.equalsIgnoreCase("CDMA2000")) {
                            strNetworkType = NETWORK_TYPE.M_3G;
                        } else {
                            strNetworkType = _strSubTypeName;
                        }

                        break;
                }
            }
        }

        return strNetworkType;
    }

    /**
     * 获取手机卡运营商名字
     *
     * @return
     */
    public static String getNetworkOperatorName() {
        TelephonyManager telephonyManager = (TelephonyManager) ContextStore.getContext().getSystemService(Context.TELEPHONY_SERVICE);
        return telephonyManager.getNetworkOperatorName();
    }
}
