package com.drone.monitor.bean;

import com.drone.monitor.bean.custom.MyLatLng;
import com.drone.monitor.bean.custom.MyObject;

public class WarningAreaBaseInfo extends MyObject {

    public String id;
    public double longitude;
    public double latitude;
    public int type = WARNING_AREA_TYPE.CIRCLE;
    public double radius;
    public int state = WARNING_AREA_STATUS_TYPE.SHOW_DRONE;//  -- 状态 0-正常显示且过滤区域内无人机   1-正常显示且不过滤区域内无人机  如果删除传入-1

    public MyLatLng getCenterLatLng() {
        return new MyLatLng(latitude, longitude);
    }

    public void setCenterLatLng(MyLatLng latLng) {
        latitude = latLng.latitude;
        longitude = latLng.longitude;
    }

    public void setCenterLatLng(double latitude, double longitude) {
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public void copy(WarningAreaBaseInfo areaInfo) {
        this.id = areaInfo.id;
        this.radius = areaInfo.radius;
        this.state = areaInfo.state;
        this.type = areaInfo.type;
        this.setCenterLatLng(areaInfo.getCenterLatLng());
    }

    /**
     * 净空区类型  0位默认  圆形，圆形必输字段中心点经纬度 类型 状态
     */
    public interface WARNING_AREA_TYPE {
        int CIRCLE = 0;
        int POLYGON = 1;
    }

    /**
     * 执行计划
     * 0 - 正常显示且过滤区域内无人机
     * 1 - 正常显示且不过滤区域内无人机
     * 2 - 删除传入
     */
    public interface WARNING_AREA_STATUS_TYPE {
        int HIDE_DRONE = 0;
        int SHOW_DRONE = 1;
        int DELETE = -1;
    }
}
