package com.tools.module.amap.utils;

import com.amap.api.services.core.LatLonPoint;
import com.drone.monitor.bean.custom.MyLatLng;
import com.tools.module.amap.map.MapController;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by jiajie on 2019-12-24.
 */
public abstract class PositionsUtils {

    public static boolean inVisibleBounds(MyLatLng latLng) {
        return MapController.getVisibleBounds().contains(latLng);
    }

    /**
     * 把LatLng对象转化为LatLonPoint对象
     */
    public static LatLonPoint convertToLatLonPoint(MyLatLng latlon) {
        return new LatLonPoint(latlon.latitude, latlon.longitude);
    }

    /**
     * 把LatLonPoint对象转化为LatLon对象
     */
    public static MyLatLng convertToLatLng(LatLonPoint latLonPoint) {
        return new MyLatLng(latLonPoint.getLatitude(), latLonPoint.getLongitude());
    }

    /**
     * 把集合体的LatLonPoint转化为集合体的LatLng
     */
    public static ArrayList<MyLatLng> convertArrList(List<LatLonPoint> shapes) {
        ArrayList<MyLatLng> lineShapes = new ArrayList<MyLatLng>();
        for (LatLonPoint point : shapes) {
            MyLatLng latLngTemp = convertToLatLng(point);
            lineShapes.add(latLngTemp);
        }
        return lineShapes;
    }
}
