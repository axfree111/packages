package com.drone.monitor.bean;

import com.drone.monitor.bean.custom.MyObject;

import java.util.Date;
import java.util.List;

/**
 * Created by jiajiecsf on 2020/6/1.
 */
public class ShipRouteHistoryData extends MyObject {

    public String itemId;
    public int status;
    public int notall;
    public List<PositionPoint> points;

    public static class PositionPoint extends MyObject {
        public int datatype;
        public Date utc;
        public double lng;
        public double lat;
        public int sog;
        public int cog;
        public double height = 0.0;
        public double speed = 0.0;
        public String name;
        public int angle;

        public void copy(PositionPoint shipPoint) {
            this.datatype = shipPoint.datatype;
            this.utc = shipPoint.utc;
            this.lng = shipPoint.lng;
            this.lat = shipPoint.lat;
            this.angle = shipPoint.angle;
            this.sog = shipPoint.sog;
            this.cog = shipPoint.cog;
            this.height = shipPoint.height;
            this.speed = shipPoint.speed;
            this.name = shipPoint.name;
        }
    }
}
