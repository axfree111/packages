package com.drone.monitor.bean.custom;


import com.tools.module.amap.map.utils.RoutePointUtils;
import com.tools.module.amap.model.DroneConfig;
import com.tools.module.amap.model.RoutePointModel;
import com.tools.module.amap.utils.ComputeUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 自定义一个toString,打印简洁log
 * Created by jiajie on 2019-09-24.
 */
public class MyHasRouteObject extends MyObject {

    public Date startSearchTime;
    public Date endSearchTime;
    // 集合中时间是从小到大排列顺序
    public List<RoutePointModel> historyPoints;

    public List<RoutePointModel> getHistoryPoints() {
        return historyPoints;
    }

    public RoutePointModel addBackSingleHistoryPoint(RoutePointModel pointModel, boolean isCheck) {
        if (historyPoints == null) {
            historyPoints = new ArrayList<>();
        }
        int size = historyPoints.size();
        if (size > 0) {
            RoutePointModel lastPos = historyPoints.get(size - 1);
            if (lastPos != null) {
                if (isCheck) {
                    long spaceTime = pointModel.time.getTime() - lastPos.time.getTime();
                    // 大于两分钟算是重起第二段路径
                    if (spaceTime >= DroneConfig.DRONE_MAX_TIME_IS_OFF) {
                        pointModel.pointType = RoutePointModel.PointType.END_POINT;
                        historyPoints.add(pointModel);
                        return null;
                    } else {
                        // TODO 对于一个在线设备,只判断移动点位大于十米则表示一个结点
                        if (spaceTime >= DroneConfig.DRONE_SHOW_INTERVAL_TIME
                                && ComputeUtils.getDistance(lastPos.point, pointModel.point) > 10) {
                            pointModel.pointType = RoutePointModel.PointType.CENTER_POINT;
                            historyPoints.add(pointModel);
                            return lastPos;
                        }
                    }
                } else {
                    pointModel.pointType = RoutePointModel.PointType.CENTER_POINT;
                    historyPoints.add(pointModel);
                    return lastPos;
                }
            }
        } else {
            pointModel.pointType = RoutePointModel.PointType.START_POINT;
            historyPoints.add(pointModel);
        }
        return null;
    }

    /**
     * 支持往前插入集合和往后插入集合
     *
     * @param historyPointModels
     */
    public void insertHistoryPointDatas(List<RoutePointModel> historyPointModels, boolean isCheckValidPoint) {
        if (this.historyPoints == null) {
            this.historyPoints = new ArrayList<>();
        }
        // 集合数据中第一个是最大时间
        boolean addBack = true;
        if (this.historyPoints.size() > 0 && historyPointModels != null && historyPointModels.size() > 0) {
            // 本地记录的最大时间和最小时间 对比 添加集合里的最大时间和最小时间
            RoutePointModel minTimePoint = historyPointModels.get(historyPointModels.size() - 1);
            RoutePointModel maxTimePoint = historyPointModels.get(0);
            if (minTimePoint.time.getTime() >= endSearchTime.getTime()) {
                // 在后边添加数据
                addBack = true;
            } else if (maxTimePoint.time.getTime() <= startSearchTime.getTime()) {
                // 在前边添加数据
                addBack = false;
            }
        }
        if (historyPointModels.size() > 0) {
            int startIndex = 0;
            if (this.historyPoints.size() == 0) {
                RoutePointModel minTimePoint = historyPointModels.get(historyPointModels.size() - 1);
                RoutePointModel startPointModel = new RoutePointModel();
                startPointModel.copy(minTimePoint);
                // 第一个点作为起始结点
                startPointModel.pointType = RoutePointModel.PointType.START_POINT;
                this.historyPoints.add(startPointModel);
                startIndex = 1;
            }
            if (addBack) {
                insertBack(historyPointModels, startIndex, isCheckValidPoint);
            } else {
                insertFront(historyPointModels, startIndex, isCheckValidPoint);
            }
        }
    }

    private void insertBack(List<RoutePointModel> historyPointModels, int startIndex, boolean isCheckValidPoint) {
        if (historyPointModels == null || historyPointModels.size() <= 0) {
            return;
        }
        List<RoutePointModel> validPoints = new ArrayList<>();
        // 取出最后一条数据
        RoutePointModel validLastTimePoint = null;
        if (isCheckValidPoint) {
            // 时间 大->小
            for (int i = startIndex; i < historyPointModels.size(); i++) {
                RoutePointModel currentPointModel = historyPointModels.get(i);
                // 首先对比最近的两条数据,找出断开的结点位
                RoutePointModel timeMinPointModel = null;
                if ((i + 1) < historyPointModels.size()) {
                    timeMinPointModel = historyPointModels.get(i + 1);
                }
                boolean isAdd1 = RoutePointUtils.checkPoint(currentPointModel, timeMinPointModel, validLastTimePoint, validPoints, i == (historyPointModels.size() - 1));
                if (validPoints.size() > 0) {
                    validLastTimePoint = validPoints.get(validPoints.size() - 1);
                }
                if (isAdd1) {
                    i++;
                }
            }
        } else {
            validPoints.addAll(historyPointModels);
            validLastTimePoint = validPoints.get(historyPointModels.size() - 1);
        }

        // 检查已经记录到本地集合的最后一个点(最小时间的点)是否是标记点，如果是需要移除
        RoutePointModel recordMinTimePoint = historyPoints.get(historyPoints.size() - 1);
        if (validPoints.size() > 0) {
            if (recordMinTimePoint != null && recordMinTimePoint.isLabelEndPoint) {
                // 有效点中最大时间的点
                RoutePointModel maxTimeValidPoint = validPoints.get(0);
                long spaceTime = recordMinTimePoint.time.getTime() - maxTimeValidPoint.time.getTime();
                // 如果是中间结点则判断连个结点位是否大于10米或大于大于两分钟,如果满足两个条件则表示为一个结点
                if (spaceTime < DroneConfig.DRONE_SHOW_INTERVAL_TIME ||
                        ComputeUtils.getDistance(validLastTimePoint.point, maxTimeValidPoint.point) <= 10) {
                    historyPoints.remove(historyPoints.size() - 1);
                }
            }
            historyPoints.addAll(validPoints);
        }
    }

    private void insertFront(List<RoutePointModel> historyPointModels, int startIndex, boolean isCheckValidPoint) {
        if (historyPointModels == null || historyPointModels.size() <= 0) {
            return;
        }
        // 时间顺序 从大到小
        List<RoutePointModel> validPoints = new ArrayList<>();
        // 取出最后一条数据
        RoutePointModel validLastTimePoint = null;
        if (isCheckValidPoint) {
            // 倒叙遍历
            for (int i = startIndex; i < historyPointModels.size(); i++) {
                RoutePointModel currentPointModel = historyPointModels.get(i);
                // 首先对比最近的两条数据,找出断开的结点位
                RoutePointModel timeMinPointModel = null;
                if ((i + 1) >= startIndex) {
                    timeMinPointModel = historyPointModels.get(i + 1);
                }
                boolean isAdd1 = RoutePointUtils.checkPoint(currentPointModel, timeMinPointModel, validLastTimePoint, validPoints, i == (historyPointModels.size() - 1));
                if (validPoints.size() > 0) {
                    validLastTimePoint = validPoints.get(validPoints.size() - 1);
                }
                if (isAdd1) {
                    i--;
                }
            }
        } else {
            validPoints.addAll(historyPointModels);
            validLastTimePoint = validPoints.get(historyPointModels.size() - 1);
        }

        // 检查已经记录到本地集合的第一个点(最大时间的点)是否是标记点，如果是需要移除
        RoutePointModel recordMaxTimePoint = historyPoints.get(0);
        if (validPoints.size() > 0) {
            if (recordMaxTimePoint != null && recordMaxTimePoint.isLabelEndPoint) {
                // validPoints集合中是时间从大到小，取出有效点中最大时间点
                RoutePointModel maxTimeValidPoint = validPoints.get(validPoints.size() - 1);
                long spaceTime = maxTimeValidPoint.time.getTime() - recordMaxTimePoint.time.getTime();
                // 如果是中间结点则判断连个结点位是否大于10米或大于大于两分钟,如果满足两个条件则表示为一个结点
                if (spaceTime < DroneConfig.DRONE_SHOW_INTERVAL_TIME ||
                        ComputeUtils.getDistance(validLastTimePoint.point, maxTimeValidPoint.point) <= 10) {
                    historyPoints.remove(historyPoints.size() - 1);
                }
            }
            historyPoints.addAll(0, validPoints);
        }
    }

    public void setHistoryPoints(List<RoutePointModel> historyPoints) {
        this.historyPoints = historyPoints;
    }
}
