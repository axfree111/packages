package com.drone.monitor.bean;

import com.drone.monitor.bean.custom.MyArrayList;
import com.drone.monitor.bean.custom.MyObject;

import java.util.List;

/**
 * Created by jiajiecsf on 2020/11/23.
 */
public class PlaneDetailData extends MyObject {
    /**
     * {"code":0,"message":"成功",
     * "data":"{\"leftTip\":\"\\u5168\\u7a0b1178\\u516c\\u91cc\",\"rightTip\":\"\\u5269\\u4f591\\u5c0f\\u65f638\\u5206\\u949f\\u5230\\u8fbe\",
     * \"distance\":1178,\"percentage\":\"10%\",\"routeAlltime\":6540,\"airModels\":\"B738\",\"flightStatus\":\"\\u8d77\\u98de\",\"AircraftNumber\":\"B1386\",
     * \"p_flightNo\":\"HU7615\",\"FlightCompany\":\"\\u6d77\\u5357\\u822a\\u7a7a\\u80a1\\u4efd\\u6709\\u9650\\u516c\\u53f8\",\"FlightDepAirport\":\"\\u5317\\u4eac\\u9996\\u90fd\",
     * \"FlightArrAirport\":\"\\u4e0a\\u6d77\\u6d66\\u4e1c\",\"airplaneAge\":2.8,
     * \"line\":[
     * {\"time\":1606184942,\"name\":\"\\u5317\\u4eac\",\"airportName\":\"\\u5317\\u4eac\\u9996\\u90fd\",\"code\":\"PEK\",\"position\":{\"lat\":40.10376,\"lng\":116.56805},\"height\":0,\"speed\":0,\"vspeed\":0,\"angle\":0,\"onground\":-1,\"tip\":\"\\u51fa\\u53d1\\u5730\"},
     * {\"time\":1606184942,\"name\":\"\",\"airportName\":\"\",\"code\":\"\",\"position\":{\"lat\":40.10376,\"lng\":116.56805},\"height\":251.46,\"speed\":285.208,\"vspeed\":0.07267082,\"angle\":353,\"onground\":0,\"tip\":\"\"},
     * {\"time\":1606184946,\"name\":\"\",\"airportName\":\"\",\"code\":\"\",\"position\":{\"lat\":40.10376,\"lng\":116.56805},\"height\":304.8,\"speed\":285.208,\"vspeed\":0.07267082,\"angle\":353,\"onground\":0,\"tip\":\"\"},
     * {\"time\":1606184951,\"name\":\"\",\"airportName\":\"\",\"code\":\"\",\"position\":{\"lat\":40.10376,\"lng\":116.56805},\"height\":358.14,\"speed\":290.764,\"vspeed\":0.067715995,\"angle\":320,\"onground\":0,\"tip\":\"\"},
     * {\"time\":1606184955,\"name\":\"\",\"airportName\":\"\",\"code\":\"\",\"position\":{\"lat\":40.10376,\"lng\":116.56805},\"height\":426.72,\"speed\":290.764,\"vspeed\":0.067715995,\"angle\":320,\"onground\":0,\"tip\":\"\"}
     * ]}","pageNumber":null,"pageSize":null,"pageCount":null,"total":null}
     */
    private String leftTip;
    private String rightTip;
    private long distance;
    private String percentage;
    private long routeAlltime;
    private String airModels;
    private String flightStatus;
    private String AircraftNumber;
    private String p_flightNo;
    private String FlightCompany;
    private String FlightDepAirport;
    private String FlightArrAirport;
    private float airplaneAge;
    private List<Line> line = new MyArrayList<>();

    public static class Line extends MyObject {
        private long time;
        private String name;
        private String airportName;
        private String code;
        private Position position;
        private double height;
        private double speed;
        private double vspeed;
        private int angle;
        private int onground;
        private String tip;

        public long getTime() {
            return time;
        }

        public void setTime(long time) {
            this.time = time;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getAirportName() {
            return airportName;
        }

        public void setAirportName(String airportName) {
            this.airportName = airportName;
        }

        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }

        public Position getPosition() {
            return position;
        }

        public void setPosition(Position position) {
            this.position = position;
        }

        public double getHeight() {
            return height;
        }

        public void setHeight(double height) {
            this.height = height;
        }

        public double getSpeed() {
            return speed;
        }

        public void setSpeed(double speed) {
            this.speed = speed;
        }

        public double getVspeed() {
            return vspeed;
        }

        public void setVspeed(double vspeed) {
            this.vspeed = vspeed;
        }

        public int getAngle() {
            return angle;
        }

        public void setAngle(int angle) {
            this.angle = angle;
        }

        public int getOnground() {
            return onground;
        }

        public void setOnground(int onground) {
            this.onground = onground;
        }

        public String getTip() {
            return tip;
        }

        public void setTip(String tip) {
            this.tip = tip;
        }

        public static class Position extends MyObject {
            private double lat;
            private double lng;

            public double getLat() {
                return lat;
            }

            public void setLat(double lat) {
                this.lat = lat;
            }

            public double getLng() {
                return lng;
            }

            public void setLng(double lng) {
                this.lng = lng;
            }

            @Override
            public String toString() {
                return "Position{" +
                        "lat=" + lat +
                        ", lng=" + lng +
                        "} " + super.toString();
            }
        }

        @Override
        public String toString() {
            return "Line{" +
                    "time=" + time +
                    ", name='" + name + '\'' +
                    ", airportName='" + airportName + '\'' +
                    ", code='" + code + '\'' +
                    ", position=" + position +
                    ", height=" + height +
                    ", speed=" + speed +
                    ", vspeed=" + vspeed +
                    ", angle=" + angle +
                    ", onground=" + onground +
                    ", tip='" + tip + '\'' +
                    "} " + super.toString();
        }
    }

    public String getLeftTip() {
        return leftTip;
    }

    public void setLeftTip(String leftTip) {
        this.leftTip = leftTip;
    }

    public String getRightTip() {
        return rightTip;
    }

    public void setRightTip(String rightTip) {
        this.rightTip = rightTip;
    }

    public long getDistance() {
        return distance;
    }

    public void setDistance(long distance) {
        this.distance = distance;
    }

    public String getPercentage() {
        return percentage;
    }

    public void setPercentage(String percentage) {
        this.percentage = percentage;
    }

    public long getRouteAlltime() {
        return routeAlltime;
    }

    public void setRouteAlltime(long routeAlltime) {
        this.routeAlltime = routeAlltime;
    }

    public String getAirModels() {
        return airModels;
    }

    public void setAirModels(String airModels) {
        this.airModels = airModels;
    }

    public String getFlightStatus() {
        return flightStatus;
    }

    public void setFlightStatus(String flightStatus) {
        this.flightStatus = flightStatus;
    }

    public String getAircraftNumber() {
        return AircraftNumber;
    }

    public void setAircraftNumber(String aircraftNumber) {
        AircraftNumber = aircraftNumber;
    }

    public String getP_flightNo() {
        return p_flightNo;
    }

    public void setP_flightNo(String p_flightNo) {
        this.p_flightNo = p_flightNo;
    }

    public String getFlightCompany() {
        return FlightCompany;
    }

    public void setFlightCompany(String flightCompany) {
        FlightCompany = flightCompany;
    }

    public String getFlightDepAirport() {
        return FlightDepAirport;
    }

    public void setFlightDepAirport(String flightDepAirport) {
        FlightDepAirport = flightDepAirport;
    }

    public String getFlightArrAirport() {
        return FlightArrAirport;
    }

    public void setFlightArrAirport(String flightArrAirport) {
        FlightArrAirport = flightArrAirport;
    }

    public float getAirplaneAge() {
        return airplaneAge;
    }

    public void setAirplaneAge(float airplaneAge) {
        this.airplaneAge = airplaneAge;
    }

    public List<Line> getLine() {
        return line;
    }

    public void setLine(List<Line> line) {
        this.line = line;
    }

    @Override
    public String toString() {
        return "PlaneDetailData{" +
                "leftTip='" + leftTip + '\'' +
                ", rightTip='" + rightTip + '\'' +
                ", distance=" + distance +
                ", percentage='" + percentage + '\'' +
                ", routeAlltime=" + routeAlltime +
                ", airModels='" + airModels + '\'' +
                ", flightStatus='" + flightStatus + '\'' +
                ", AircraftNumber='" + AircraftNumber + '\'' +
                ", p_flightNo='" + p_flightNo + '\'' +
                ", FlightCompany='" + FlightCompany + '\'' +
                ", FlightDepAirport='" + FlightDepAirport + '\'' +
                ", FlightArrAirport='" + FlightArrAirport + '\'' +
                ", airplaneAge=" + airplaneAge +
                ", line=" + line +
                "} " + super.toString();
    }
}
