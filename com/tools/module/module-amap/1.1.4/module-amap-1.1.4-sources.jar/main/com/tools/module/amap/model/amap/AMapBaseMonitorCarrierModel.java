package com.tools.module.amap.model.amap;

import android.text.TextUtils;

import com.amap.api.maps.model.BitmapDescriptor;
import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.MarkerOptions;
import com.drone.monitor.bean.Drone;
import com.drone.monitor.bean.MonitorDevice;
import com.tools.module.amap.map.amap.AMapBitmapManager;
import com.tools.module.amap.map.amap.MaMapUtils;
import com.tools.module.amap.map.MapController;
import com.tools.module.amap.model.DroneRecordInvadeModel;
import com.tools.module.amap.model.base.BaseMonitorModel;
import com.tools.module.common.utils.XAppLogger;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public abstract class AMapBaseMonitorCarrierModel extends AMapBaseMonitorModel {

    public AMapBaseMonitorCarrierModel(MonitorDevice monitor) {
        super(monitor);
        if (data != null) {
            if (data.getChildMonitorDevices() != null) {
                for (MonitorDevice child : data.getChildMonitorDevices()) {
                    if (child != null) {
                        AMapMonitorModel childMonitorModel = new AMapMonitorModel(child);
                        childMonitorModels.put(child.getMonitorId(), childMonitorModel);
                    }
                }
            } else {
                for (Map.Entry<String, BaseMonitorModel> entry : childMonitorModels.entrySet()) {
                    if (entry != null) {
                        BaseMonitorModel childMonitorModel = entry.getValue();
                        if (childMonitorModel != null) {
                            childMonitorModel.erase();
                        }
                    }
                }
            }
        }
    }

    protected abstract boolean markerIsDraggable();

    @Override
    protected float getCurrentZoomLevel() {
        return MapController.CURRENT_ZOOM_LEVEL;
    }

    @Override
    protected void updateMarker(boolean isStatusChanged, boolean isAngleChanged, boolean isPositionChanged) {
        if (needMarker()) {
            if (markerDevice == null) {

                if (markerDevice != null) {

                    markerDevice.remove();
                }

                MarkerOptions markOptions = MaMapUtils.getInstance().getMarkOptions(getData(), getCurrentMonitorStatus(), isSelected(), markerIsDraggable());

                if (markOptions != null) {

                    markerDevice = getMap().addMarker(markOptions);
                    markerDevice.setInfoWindowEnable(true);
                    markerDevice.setObject(getMarkerDataModel());

                    XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "添加设备图标 设备id:"
                            + getData().getAlias() + " | 类型:" + getData().getType() + " | 状态:" + getCurrentMonitorStatus());
                }
            } else {

                markerDevice.setObject(getMarkerDataModel());
                if (isStatusChanged) {
                    BitmapDescriptor bitmapDescriptor = AMapBitmapManager.getInstance().getDescriptorBitmap(getData().getType(),
                            getCurrentMonitorStatus(), getCurrentZoomLevel(), isSelected());
                    if (bitmapDescriptor != null) {
                        markerDevice.setIcon(bitmapDescriptor);
                        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "更新设备图标 设备id:"
                                + getData().getAlias() + " | 类型:" + getData().getType() + " | 状态:" + getCurrentMonitorStatus());
                    }
                }
                if (isPositionChanged) {
                    LatLng deviceLatLng = getLatLng();
                    if (deviceLatLng != null) {
                        markerDevice.setPosition(deviceLatLng);
                        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "更新设备位置 设备id:"
                                + getData().getAlias() + " | 位置:" + getData().getLatLngString());
                    }
                }
//                if (isAngleChanged) {
//                    //计算设备的朝向中间角度
//                    float centerAngle = getData().getCenterAngle();
//                    markerDevice.setRotate(-centerAngle);
//                    XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "更新设备角度 设备id:"
//                            + getData().getMonitorId() + " | 角度:" + centerAngle);
//                }
            }
        }
    }

    /**
     * 移除图标
     */
    @Override
    public synchronized void removeDeviceMarker() {

        if (markerDevice != null) {

            markerDevice.remove();
            markerDevice = null;
            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "移除设备图标 设备id:"
                    + getData().getAlias() + " | 类型:" + getData().getType() + " | 状态:" + getCurrentMonitorStatus());
        }
    }

    /**
     * 区别于MonitorModel的处理，更新方式是通知载体数据更新载体通知子设备进行数据监测是否需要更新
     *
     * @param monitor
     */
    @Override
    protected void setMonitorDevice(MonitorDevice monitor) {
        super.setMonitorDevice(monitor);
        if (data.getChildMonitorDevices() != null) {
            // 请求回来的设备id列表
            List<String> monitorIds = new ArrayList<>();
            // 本地记录的设备id列表
            Set<String> copyLocationItemIds = new HashSet<>();
            copyLocationItemIds.addAll(childMonitorModels.keySet());
            Iterator<String> iterator = copyLocationItemIds.iterator();
            for (MonitorDevice child : data.getChildMonitorDevices()) {
                if (child != null) {
                    monitorIds.add(child.getMonitorId());
                    AMapMonitorModel childMonitorModel;
                    if (childMonitorModels.containsKey(child.getMonitorId())) {
                        childMonitorModel = (AMapMonitorModel) childMonitorModels.get(child.getMonitorId());
                        childMonitorModel.updateMonitor(child);
                    } else {
                        childMonitorModel = new AMapMonitorModel(child);
                        childMonitorModels.put(child.getMonitorId(), childMonitorModel);
                    }
                }
            }
            // 处理失效设备
            while (iterator.hasNext()) {
                String itemId = iterator.next();
                if (!TextUtils.isEmpty(itemId)) {
                    // 不包含id时从地图上删除
                    if (!monitorIds.contains(itemId)) {
                        BaseMonitorModel childMonitorModel = childMonitorModels.remove(itemId);
                        if (childMonitorModel != null) {
                            // 从地图上移除
                            childMonitorModel.erase();
                        }
                    }
                }
            }
        } else {
            for (Map.Entry<String, BaseMonitorModel> entry : childMonitorModels.entrySet()) {
                if (entry != null) {
                    BaseMonitorModel childMonitorModel = entry.getValue();
                    if (childMonitorModel != null) {
                        childMonitorModel.erase();
                    }
                }
            }
        }
    }

    // --------------------------- 操作数据相关 -----------------------------------

    @Override
    public DroneRecordInvadeModel isPointInDeviceArea(Drone drone) {
        DroneRecordInvadeModel invadeModel = new DroneRecordInvadeModel();
        clearDroneRecordInvadeModelData(invadeModel);
        if (childMonitorModels != null) {
            for (Map.Entry<String, BaseMonitorModel> entry : childMonitorModels.entrySet()) {
                BaseMonitorModel childDevice = entry.getValue();
                if (childDevice != null) {
                    invadeModel = childDevice.isPointInDeviceArea(drone);
                    if (invadeModel != null) {
                        return invadeModel;
                    }
                }
            }
        } else {
            return super.isPointInDeviceArea(drone);
        }
        return invadeModel;
    }
}
