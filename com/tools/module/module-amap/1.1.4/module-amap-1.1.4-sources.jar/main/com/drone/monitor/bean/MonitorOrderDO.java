package com.drone.monitor.bean;

import com.drone.monitor.bean.custom.MyLatLng;
import com.drone.monitor.bean.custom.MyObject;

/**
 * Created by jiajiecsf on 2020/11/13.
 */
public class MonitorOrderDO extends MyObject {

    private long id;

    private String monitorId;

    /**
     * 经度
     */
    private double longitude;

    /**
     * 维度
     */
    private double latitude;

    /**
     * Constants.ATTACK_STATE
     * 0 创建，1 取消，2 完成
     */
    private int state = MonitorDevice.ATTACK_STATE.CREATE;

    /**
     * 存储的是无人机id
     */
    private String info;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public MyLatLng getLatLng() {
        if (longitude == 0 || latitude == 0) {
            return null;
        }
        return new MyLatLng(latitude, longitude);
    }

    public void setLatLng(MyLatLng latLng) {
        if (latLng == null) {
            return;
        }
        latitude = latLng.latitude;
        longitude = latLng.longitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public String getMonitorId() {
        return monitorId;
    }

    public void setMonitorId(String monitorId) {
        this.monitorId = monitorId;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    @Override
    public String toString() {
        return "monitorOrderDO{" +
                "longitude=" + longitude +
                ", latitude=" + latitude +
                ", monitorId='" + monitorId + '\'' +
                ", state=" + state +
                ", info='" + info + '\'' +
                "} " + super.toString();
    }

    //指令类型 1迫降   2驱离 3停止
    public interface ORDER_TYPE {
        int FIGHT_SHOT = 1;
        int EXPEL = 2;
        int STOP = 3;
    }

    /**
     * 执行计划
     * 0 - 立即执行
     * 1 - 延迟执行
     * 2 - 停止
     */
    public interface ORDER_RUN_TYPE {
        int NOW = 1;
        int DELAY = 2;
        int STOP = 3;
    }
}
