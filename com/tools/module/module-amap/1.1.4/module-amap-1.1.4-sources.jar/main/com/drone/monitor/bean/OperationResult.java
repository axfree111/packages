package com.drone.monitor.bean;

import com.drone.monitor.bean.custom.MyObject;

public class OperationResult extends MyObject {

    private int code;

    private String message;

    private Object data;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public OperationResult(int code) {
        this.code = code;
    }

    public void buildErr(ERROR error) {
        code = error.getCode();
        message = error.getExtMsg();
    }
}
