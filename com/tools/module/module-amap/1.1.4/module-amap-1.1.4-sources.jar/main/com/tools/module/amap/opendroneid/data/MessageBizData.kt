package com.tools.module.amap.opendroneid.data

import android.os.SystemClock
import com.tools.module.amap.opendroneid.OpenDroneIdConstants
import java.sql.Timestamp
import java.util.Locale

open class MessageBizData {
    @JvmField
    var msgCounter: Int = 0
    @JvmField
    var timestamp: Long = 0
    @JvmField
    var msgVersion: Int = 0

    val msgCounterAsString: String
        get() = String.format(Locale.US, "%3d", this.msgCounter)

    val timestampAsString: String
        get() {
            val msSinceEvent =
                (SystemClock.elapsedRealtimeNanos() - timestamp) / 1000000L
            val actualTime = System.currentTimeMillis() - msSinceEvent
            val time = Timestamp(actualTime)
            return time.toString()
        }

    val msgVersionAsString: String
        get() = String.format(Locale.US, "v.%d", this.msgVersion)

    fun msgVersionUnsupported(): Boolean {
        return msgVersion > OpenDroneIdConstants.MAX_MSG_VERSION
    }
}
