package com.tools.module.amap.net.http;

import android.text.TextUtils;

import com.tools.module.amap.net.http.request.IRequestHost;
import com.tools.module.amap.net.http.response.FileHttpResponseHandler;
import com.tools.module.common.utils.AppUtil;
import com.tools.module.common.utils.XAppLogger;

import java.io.File;


/**
 * 文件下载类, 模拟AsyncHttpRequest类实现, 简化参数
 *
 * @author changjiajie
 */
public class FileDownloader {

    /**
     * 异步下载
     *
     * @param url
     * @param savePath
     * @param responseHandler
     */
    public static void downloadAsync(String url, String savePath, FileHttpResponseHandler responseHandler, IRequestHost requestHost) {
        if (TextUtils.isEmpty(url) || responseHandler == null) {
            // 设置默认的response, 方便查看http返回信息以及上传网络日志
            responseHandler = new FileHttpResponseHandler() {
                @Override
                public void onSuccess(int statusCode, File content) {
                    // do nothing
                }
            };
        }
        // 开始
        responseHandler.sendStartMessage();

        try {
            OkHttpUtils.downloadAsync(url, savePath, responseHandler, requestHost);
        } catch (Exception e) {
            XAppLogger.getInstance().writeError(e);
        }
    }

    /**
     * 同步下载
     *
     * @param url
     * @param savePath
     * @param responseHandler
     */
    public static void download(String url, String savePath, FileHttpResponseHandler responseHandler) {
        download(url, savePath, responseHandler, null);
    }

    /**
     * 同步下载
     *
     * @param url
     * @param savePath
     * @param responseHandler
     * @param requestHost
     */
    public static void download(String url, String savePath, FileHttpResponseHandler responseHandler, IRequestHost requestHost) {
        if (TextUtils.isEmpty(url) || responseHandler == null) {
            // 设置默认的response, 方便查看http返回信息以及上传网络日志
            responseHandler = new FileHttpResponseHandler() {
                @Override
                public void onSuccess(int statusCode, File content) {
                    // do nothing
                }
            };
        }
        // 开始
        responseHandler.sendStartMessage();

        // 先尝试使用OkHttp进行下载，如果出现OkHttpException的话，再使用HttpUrlConnection再试一次
        try {
            OkHttpUtils.download(url, savePath, responseHandler, requestHost);
        } catch (Exception oke) {
            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_ERROR, "文件下载失败, url:" + url + ", exception:" + AppUtil.getExceptionString(oke));
        }
    }
}
