package com.tools.module.amap.opendroneid.parser

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.Charset
import java.nio.charset.StandardCharsets


/**
 * Date: 2025/4/7
 * Desc:
 *
 * author: jaje
 */

// 扩展函数实现
fun ByteArray.toHexStringCsf(): String {
    val hexChars = "0123456789ABCDEF".toCharArray()
    val result = StringBuilder(size * 2)
    for (byte in this) {
        val unsigned = byte.toInt() and 0xFF
        result.append(hexChars[unsigned shr 4])    // 高四位
        result.append(hexChars[unsigned and 0x0F])// 低四位
    }
    return result.toString()
}

// 扩展函数实现（含容错处理）
fun String.hexStringToByteArray(): ByteArray {
    val normalizedHex = if (length % 2 != 0) "0$this" else this
    return ByteArray(normalizedHex.length / 2).apply {
        for (i in indices) {
            val start = i * 2
            val end = start + 2
            val byteStr = normalizedHex.substring(start, end)
            this[i] = byteStr.toInt(16).toByte()
        }
    }
}

fun ByteBuffer.toHexStringCsf(): String {
    val hexChars = "0123456789ABCDEF".toCharArray()
    val buffer = getBufferForReading() // 确保为读模式

    return StringBuilder(buffer.remaining() * 2).apply {
        while (buffer.hasRemaining()) {
            val byte = buffer.get()
            val unsigned = byte.toInt() and 0xFF
            append(hexChars[unsigned shr 4])
            append(hexChars[unsigned and 0x0F])
        }
    }.toString()
}

fun ByteBuffer.getBufferForReading(): ByteBuffer {
    return if (isReadOnly) {
        // 直接缓冲区无法复制，返回只读视图
        slice().asReadOnlyBuffer().apply { position(0) }
    } else {
        // 堆缓冲区创建副本避免修改原缓冲区状态
        duplicate().apply { position(0); limit(this@getBufferForReading.limit()) }
    }
}

fun String.hexStringToByteBuffer(): ByteBuffer {
    require(length % 2 == 0) { "Hex 字符串长度必须为偶数" }

    val bytes = ByteArray(length / 2).apply {
        var i = 0
        var pos = 0
        while (i < length) {
            val high = Character.digit(this@hexStringToByteBuffer[i], 16) shl 4
            val low = Character.digit(this@hexStringToByteBuffer[i + 1], 16)
            require(high != -1 && low != -1) { "非法十六进制字符: ${substring(i..i+1)}" }

            this[pos++] = (high or low).toByte()
            i += 2
        }
    }
    return ByteBuffer.wrap(bytes)
}

fun ByteArray.toInt(startIndex: Int): Int {
    return this.copyOfRange(startIndex, startIndex + 1)[0].toInt() and 0xFF
}

fun ByteArray.toSymbolInt(startIndex: Int): Int {
    return this.copyOfRange(startIndex, startIndex + 1)[0].toInt()
}

fun ByteArray.toShort(startIndex: Int): Short {
    val byteArray = this.copyOfRange(startIndex, startIndex + 2)
    // 包装为ByteBuffer并设置字节序
    // 根据协议选择 LITTLE_ENDIAN 或 BIG_ENDIAN
    val buffer = ByteBuffer.wrap(byteArray)
        .order(ByteOrder.LITTLE_ENDIAN)

    return buffer.getShort()
}

fun ByteArray.toFloat(startIndex: Int): Float {
    val byteArray = this.copyOfRange(startIndex, startIndex + 4)
    // 包装为ByteBuffer并设置字节序
    // 根据协议选择 LITTLE_ENDIAN 或 BIG_ENDIAN
    val buffer = ByteBuffer.wrap(byteArray)
        .order(ByteOrder.LITTLE_ENDIAN)

    return buffer.getFloat()
}

fun ByteArray.toDouble(startIndex: Int): Double {
    val byteArray = this.copyOfRange(startIndex, startIndex + 8)
    // 包装为ByteBuffer并设置字节序
    // 根据协议选择 LITTLE_ENDIAN 或 BIG_ENDIAN
    val buffer = ByteBuffer.wrap(byteArray)
        .order(ByteOrder.LITTLE_ENDIAN)

    return buffer.getDouble()
}

/**
 * TODO 解析美标和欧标时这块应该使用大端还是小端需要确定
 */
fun ByteArray.toPartString(startIndex: Int,
                           length: Int,
                           charset: Charset = StandardCharsets.UTF_8,
                           byteOrder: ByteOrder = ByteOrder.LITTLE_ENDIAN): String {
    if (charset == StandardCharsets.US_ASCII) {
        val buffer = ByteBuffer.wrap(this).order(ByteOrder.BIG_ENDIAN)
        return StringBuilder().apply {
            while (buffer.hasRemaining()) {
                append(buffer.get().toInt().toChar())
            }
        }.toString()
    } else {
        val buffer = ByteBuffer.wrap(this)
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes).order(byteOrder)
        val result = String(bytes, charset)
        return result
    }
}

fun ByteArray.toPartString(charset: Charset = StandardCharsets.UTF_8,
                           byteOrder: ByteOrder = ByteOrder.LITTLE_ENDIAN): String {
    if (charset == StandardCharsets.US_ASCII) {
        // 字符类型需要用大端序
        val buffer = ByteBuffer.wrap(this).order(ByteOrder.BIG_ENDIAN)
        return StringBuilder().apply {
            while (buffer.hasRemaining()) {
                append(buffer.get().toInt().toChar())
            }
        }.toString()
    } else {
        val buffer = ByteBuffer.wrap(this)
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes).order(byteOrder)
        val result = String(bytes, charset)
        return result
    }
}

data object BytesHexUtils {


}