package com.tools.module.amap.map.contract;

import com.tools.module.amap.model.MarkerDataModel;


/**
 * Created by jiajie on 2020-01-19.
 */
public interface IMarkerInterceptorCallback {
    boolean click(MarkerDataModel mkDroneDataModel);
}
