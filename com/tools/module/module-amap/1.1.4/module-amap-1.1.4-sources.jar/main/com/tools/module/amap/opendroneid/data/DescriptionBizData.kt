package com.tools.module.amap.opendroneid.data

import com.tools.module.amap.R
import com.tools.module.amap.opendroneid.OpenDroneIdConstants
import com.tools.module.amap.opendroneid.parser.toPartString
import com.tools.module.common.utils.ResourceUtil
import java.nio.charset.StandardCharsets

class DescriptionBizData : MessageBizData() {
    private var descriptionType: DescriptionTypeEnum
    private var operationDescription: ByteArray?

    init {
        descriptionType = DescriptionTypeEnum.Text
        operationDescription = ByteArray(0)
    }

    enum class DescriptionTypeEnum(val key: Int, val description: String) {
        Text(0, ResourceUtil.getContent(R.string.ground)),
        Emergency(1, ResourceUtil.getContent(R.string.emergency)),
        StateLoseNoEmergency(2, ResourceUtil.getContent(R.string.state_lose_no_emergency)),
        StateLoseEmergency(3, ResourceUtil.getContent(R.string.state_lose_emergency)),
        Invalid(0, ResourceUtil.getContent(R.string.unknown));

        companion object {
            fun keyOfType(key: Int): DescriptionTypeEnum {
                for (type in DescriptionTypeEnum.entries) {
                    if (type.key == key) {
                        return type
                    }
                }
                return DescriptionTypeEnum.Invalid
            }
        }
    }

    fun setDescriptionType(descriptionType: Int) {
        this.descriptionType = DescriptionTypeEnum.keyOfType(descriptionType)
    }

    fun getDescriptionType(): DescriptionTypeEnum {
        return descriptionType
    }

    fun setOperationDescription(operationDescription: ByteArray) {
        if (operationDescription.size <= OpenDroneIdConstants.MAX_STRING_BYTE_SIZE) {
            this.operationDescription = operationDescription
        }
    }

    fun getOperationDescription(): ByteArray? {
        return operationDescription
    }

    fun getOperationDescriptionForAsciiString(): String {
        return operationDescription?.toPartString(StandardCharsets.US_ASCII)
            ?: ResourceUtil.getContent(R.string.unknown)
    }

    fun getOperationDescriptionForUtf8String(): String {
        return operationDescription?.toPartString(StandardCharsets.UTF_8)
            ?: ResourceUtil.getContent(R.string.unknown)
    }

//    val operationDescriptionAsString: String
//        get() {
//            if (operationDescription != null) {
//                for (c in operationDescription!!) {
//                    if ((c <= 31 || c >= 127) && c.toInt() != 0) {
//                        return "Invalid String"
//                    }
//                }
//                return String(operationDescription!!)
//            }
//            return ""
//        }
}
