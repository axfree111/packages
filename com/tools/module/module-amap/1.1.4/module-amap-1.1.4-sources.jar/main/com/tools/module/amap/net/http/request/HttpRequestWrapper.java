package com.tools.module.amap.net.http.request;

import android.content.Context;

import com.tools.module.amap.net.http.OkHttpUtils;
import com.tools.module.amap.net.http.response.HttpResponseHandler;
import com.tools.module.amap.net.http.response.StringHttpResponseHandler;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import okhttp3.Call;

/**
 * HTTP请求封装类
 *
 * @author changjiajie
 */
public class HttpRequestWrapper {

    private static final String HEADER_ACCEPT_ENCODING = "Accept-Encoding";
    private static final String ENCODING_GZIP = "gzip";

    /**
     * HTTP 类型
     */
    public enum HttpType {
        Get,
        Post,
        Put,
        Delete
    }

    private int contextHashCode;
    private HttpType type = HttpType.Get;
    private String url;
    private String contentType;
    private RequestParams params;
    private Map<String, String> headerMap = new HashMap<>();
    private HttpResponseHandler<?> responseHandler;
    private IRequestHost requestHost = null;
    private Call request = null;

    private Object data = null;
    /**
     * 是否启用httpdns
     */
    private boolean httpdnsEnable = false;

    public HttpRequestWrapper(HttpType type, String url) {
        this.type = type;
        this.url = url;
    }

    /**
     * 下载文件
     *
     * @param saveFilePath
     * @return
     */
    public HttpRequestWrapper downloadFile(String saveFilePath) {
        getRequestParamsLocale().downloadFile(saveFilePath);
        return this;
    }

    /**
     * 上传文件
     *
     * @param uploadFilePath
     * @return
     */
    public HttpRequestWrapper uploadFile(String uploadFilePath, String uploadParameterName) {
        getRequestParamsLocale().uploadFile(uploadFilePath, uploadParameterName);
        return this;
    }


    // 可单独进行页面请求取消处理
    public HttpRequestWrapper setContext(Context context) {
        this.contextHashCode = context.hashCode();
        return this;
    }

    public int getContextHashCode() {
        return contextHashCode;
    }

    public HttpRequestWrapper setType(HttpType type) {
        this.type = type;
        return this;
    }

    public HttpType getType() {
        return type;
    }

    public HttpRequestWrapper setUrl(String url) {
        this.url = url;
        return this;
    }

    public String getUrl() {
        return url;
    }

    public HttpRequestWrapper setContentType(String contentType) {
        this.contentType = contentType;
        return this;
    }

    public String getContentType() {
        return contentType;
    }

    public HttpRequestWrapper addRequestParams(String key, String value) {
        getRequestParamsLocale().put(key, value);
        return this;
    }

    public HttpRequestWrapper addRequestParams(Map<String, String> params) {
        if (params == null || params.size() <= 0) {
            return this;
        }
        Iterator<Map.Entry<String, String>> paramsIter = params.entrySet().iterator();
        while (paramsIter.hasNext()) {
            Map.Entry<String, String> paramEntery = paramsIter.next();
            addRequestParams(paramEntery.getKey(), paramEntery.getValue());
        }
        return this;
    }

    public RequestParams getRequestParams() {
        return params;
    }

    public HttpRequestWrapper setResponseHandler(HttpResponseHandler<?> responseHandler) {
        this.responseHandler = responseHandler;
        // 设置默认的response, 方便查看http返回信息以及上传网络日志
        if (this.responseHandler == null) {
            this.responseHandler = new StringHttpResponseHandler() {
                @Override
                public void onSuccess(int statusCode, String content) {
                    // do nothing
                }
            };
        }else{
            this.contextHashCode = responseHandler.hashCode();
        }
        if (this.responseHandler != null) {
            this.responseHandler.setHttpRequestWrapper(this);
        }
        return this;
    }

    public HttpResponseHandler<?> getResponseHandler() {
        return responseHandler;
    }

    public HttpRequestWrapper setRequestHost(IRequestHost requestHost) {
        this.requestHost = requestHost;
        return this;
    }

    public IRequestHost getRequestHost() {
        return requestHost;
    }

    public HttpRequestWrapper setHeaders(HashMap<String, String> headers) {
        headerMap = headers;
        return this;
    }

    public HttpRequestWrapper addHeader(String key, String value) {
        headerMap.put(key, value);
        return this;
    }

    public HttpRequestWrapper addHeader(Map<String, String> headers) {
        if (headers == null || headers.size() <= 0) {
            return this;
        }
        headerMap.putAll(headers);
        return this;
    }

    public Map<String, String> getHeadersMap() {
        return headerMap;
    }

    public HttpRequestWrapper setCall(Call request) {
        this.request = request;
        return this;
    }

    public HttpRequestWrapper setJsonBody(String jsonBody) {
        getRequestParamsLocale().setJsonBody(jsonBody);
        this.contentType = "application/json";
        return this;
    }

    public HttpRequestWrapper setFormBody(Map<String, String> formMap) {
        getRequestParamsLocale().setFormBody(formMap);
        this.contentType = "application/x-www-form-urlencoded";
        return this;
    }

    public HttpRequestWrapper setBytesBody(byte[] bytesBody) {
        getRequestParamsLocale().setBytesBody(bytesBody);
        this.contentType = "application/octet-stream";
        return this;
    }

    public HttpRequestWrapper setData(Object data) {
        this.data = data;
        return this;
    }

    public Object getData() {
        return data;
    }

    public HttpRequestWrapper setHttpdnsEnable(boolean enable) {
        this.httpdnsEnable = enable;
        return this;
    }

    public boolean getHttpdnsEnable() {
        return this.httpdnsEnable;
    }

    /**
     * 异步执行
     *
     * @return this
     */
    public HttpRequestWrapper execute() {
        OkHttpUtils.execute(this);
        return this;
    }

    /**
     * 取消执行
     */
    public synchronized void cancel() {
        if (request != null) {
            request.cancel();
            request = null;
        }
    }

    private RequestParams getRequestParamsLocale() {
        if (params == null) {
            params = new RequestParams();
        }
        return params;
    }

    public String getRealUrl() {
        String realUrl = getUrl();
        if (getType() == HttpType.Get && getRequestParams() != null) {
            realUrl = RequestParams.getUrlWithQueryString(realUrl, getRequestParams());
        }
        return realUrl;
    }
}
