package com.tools.module.amap.map.amap.clusterutil;

import androidx.annotation.Nullable;

import com.tools.module.amap.model.base.ClusterItem;
import com.amap.api.maps.model.Marker;
import com.drone.monitor.bean.custom.MyLatLng;
import com.tools.module.amap.map.LocalMapConfig;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by yiyi.qi on 16/10/10.
 */

public class Cluster {
    private String temporaryId;
    private MyLatLng mLatLng;
    private Map<String, ClusterItem> mClusterItems;
    private Marker mMarker;
    // 只仅限于cluster聚合类使用,通过距离计算是否需要旋转角度,方便点击处理
    private float angle;
    private int markerType;
    private int type;
    private int status;
    private boolean isCicle;
    private boolean needJumpAnimation;
    @Nullable
    private Object object;


    public Cluster(String id, MyLatLng latLng, int markerType, int type) {
        temporaryId = id;
        mLatLng = latLng;
        mClusterItems = new ConcurrentHashMap<>();
        this.markerType = markerType;
        this.type = type;
    }

    public Cluster(String id, MyLatLng latLng, int markerType, int type, int status, boolean isCicle) {
        temporaryId = id;
        mLatLng = latLng;
        mClusterItems = new ConcurrentHashMap<>();
        this.markerType = markerType;
        this.type = type;
        this.status = status;
        this.isCicle = isCicle;
    }

    void addClusterItem(ClusterItem clusterItem) {
        if (!mClusterItems.containsKey(clusterItem.getId())) {
            mClusterItems.put(clusterItem.getId(), clusterItem);
        }
    }

    void updateClusterItem(ClusterItem clusterItem) {
        if (mClusterItems.containsKey(clusterItem.getId())) {
            mClusterItems.put(clusterItem.getId(), clusterItem);
        }
    }

    boolean isContainsClusterItem(ClusterItem clusterItem) {
        if (mClusterItems.containsKey(clusterItem.getId())) {
            return true;
        }
        return false;
    }

    int removeClusterItem(ClusterItem clusterItem) {
        if (mClusterItems.containsKey(clusterItem.getId())) {
            mClusterItems.remove(clusterItem.getId());
        }
        return mClusterItems.size();
    }

    int getClusterCount() {
        return mClusterItems.size();
    }

    MyLatLng getCenterLatLng() {
        return mLatLng;
    }

    void setMarker(Marker marker) {
        mMarker = marker;
    }

    Marker getMarker() {
        return mMarker;
    }

    Map<String, ClusterItem> getClusterItems() {
        return mClusterItems;
    }

    public int zIndex() {
        return LocalMapConfig.ZINDEX_ICON;
    }

    public Object getObject() {
        return object;
    }

    public void setObject(Object object) {
        this.object = object;
    }

    public int getMarkerType() {
        return markerType;
    }

    public int getType() {
        return type;
    }

    public int getStatus() {
        return status;
    }

    public boolean isCicle() {
        return isCicle;
    }

    public float getAngle() {
        return angle;
    }

    public void setAngle(float angle) {
        this.angle = angle;
    }

    public boolean needJumpAnimation() {
        return needJumpAnimation;
    }

    public void setNeedJumpAnimation(boolean needJumpAnimation) {
        this.needJumpAnimation = needJumpAnimation;
    }

    public String getTemporaryId() {
        return temporaryId;
    }

    @Override
    public String toString() {
        return "Cluster{" +
                "mLatLng=" + mLatLng +
                ", mClusterItems=" + mClusterItems +
                ", angle=" + angle +
                ", markerType=" + markerType +
                ", type=" + type +
                ", status=" + status +
                ", isCicle=" + isCicle +
                ", needJumpAnimation=" + needJumpAnimation +
                ", object=" + object +
                '}';
    }
}
