package com.drone.monitor.bean.custom;

import android.os.Parcel;
import android.os.Parcelable;

import com.drone.monitor.bean.PlaneDetailData;


/**
 * Created by jiajie on 2019-12-24.
 */
public class MyLatLng implements Parcelable, Cloneable {
    public double latitude;
    public double longitude;

    public MyLatLng(double latitude, double longitude) {
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public MyLatLng(PlaneDetailData.Line.Position latLng) {
        this.latitude = latLng.getLat();
        this.longitude = latLng.getLng();
    }

    protected MyLatLng(Parcel in) {
        latitude = in.readDouble();
        longitude = in.readDouble();
    }

    public boolean equals(MyLatLng latLng) {
        if (latLng == null) {
            return false;
        }
        if (latitude == latLng.latitude && longitude == latLng.longitude) {
            return true;
        }
        return false;
    }

    public static final Creator<MyLatLng> CREATOR = new Creator<MyLatLng>() {
        @Override
        public MyLatLng createFromParcel(Parcel in) {
            return new MyLatLng(in);
        }

        @Override
        public MyLatLng[] newArray(int size) {
            return new MyLatLng[size];
        }
    };

    public final MyLatLng clone() {
        return new MyLatLng(this.latitude, this.longitude);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public final void writeToParcel(Parcel var1, int var2) {
        var1.writeDouble(this.longitude);
        var1.writeDouble(this.latitude);
    }

    public String getLatLngString() {
        return String.format("%.4f", latitude) + "," + String.format("%.4f", longitude);
    }

    @Override
    public String toString() {
        return "MyLatLng{" +
                "latitude=" + latitude +
                ", longitude=" + longitude +
                '}';
    }
}
