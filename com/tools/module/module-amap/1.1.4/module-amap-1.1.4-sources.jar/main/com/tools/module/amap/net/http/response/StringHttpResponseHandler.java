/*
    Android Asynchronous Http Client
    Copyright (c) 2011 James Smith <james@loopj.com>
    http://loopj.com

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

package com.tools.module.amap.net.http.response;

import java.io.IOException;

import okhttp3.ResponseBody;

public abstract class StringHttpResponseHandler extends HttpResponseHandler<String> {

    /**
     * Creates a new AsyncHttpResponseHandler
     * 注：使用这个构造方法, 所有的回调会在子线程回调, 不允许执行ui操作
     */
    public StringHttpResponseHandler() {
        super();
    }

    /**
     * 不推荐使用这个构造函数, 这会导致在ui线程进行数据解析, 既影响ui效率, 又无法捕获解析异常
     */
    public StringHttpResponseHandler(boolean uiCallback) {
        super(uiCallback);
    }

    protected String parseResponse(int statusCode, ResponseBody body) throws IOException {
        return body == null ? null : body.string();
    }

}
