package com.tools.module.amap.contract;

import android.app.Activity;

/**
 * Created by kzl on 2016/5/17
 */
public interface IStatusBarFontHelper {
     boolean setStatusBarLightMode(Activity activity, boolean isFontColorDark);
}
