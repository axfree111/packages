package com.tools.module.amap.model.amap;

import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.Marker;
import com.amap.api.maps.model.Polygon;
import com.amap.api.maps.model.PolygonOptions;
import com.amap.api.maps.model.Polyline;
import com.amap.api.maps.model.PolylineOptions;
import com.drone.monitor.bean.Drone;
import com.drone.monitor.bean.custom.MyLatLng;
import com.tools.module.common.utils.HandlerUtils;
import com.tools.module.common.utils.XAppLogger;
import com.tools.module.amap.manager.ThreadPoolHelper;
import com.tools.module.amap.map.LocalMapConfig;
import com.tools.module.amap.map.MapController;
import com.tools.module.amap.map.amap.AMapBitmapManager;
import com.tools.module.amap.map.amap.AMapPositionsUtils;
import com.tools.module.amap.map.amap.MaMapUtils;
import com.tools.module.amap.model.DistrictFenceModel;
import com.tools.module.amap.model.DroneConfig;
import com.tools.module.amap.model.MarkerDataModel;
import com.tools.module.amap.model.base.BaseDistrictFenceModel;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

/**
 * Created by jiajie on 2020-01-20.
 */
public class AMapDistrictFenceModel extends BaseDistrictFenceModel {
    private Vector<Marker> markers = new Vector<>();
    private Marker centerMarker;
    private Marker circleMarker;
    private Polyline radiusLine;
    private Polygon fenceCover;
    private Polyline fenceLine;

    private volatile Polygon coverScanPolygon;
    private volatile Polyline coverScanPolygonLine;

    public AMapDistrictFenceModel() {
        super();
    }

    @Override
    public boolean updateFenceCover() {
        if (super.updateFenceCover()) {
            List<LatLng> latLngs = AMapPositionsUtils.transformAMapPosition(getFenceLatLngs());
            if (latLngs != null && latLngs.size() >= 3) {
                if (fenceCover == null) {
                    fenceCover = MaMapUtils.getInstance().getMap().addPolygon(
                            MaMapUtils.getInstance().getDraggableCoverPolygonOptions(latLngs, fenceLineColor, fenceCoverColor));
                } else {
                    fenceCover.setPoints(latLngs);
                    fenceCover.setFillColor(fenceCoverColor);
                }
                return true;
            } else {
                removeCover();
            }
        }
        return false;
    }

    @Override
    public void onEditFinish() {
        super.onEditFinish();
        if (pointsCanIsPolyon()) {
            if (fenceCover == null) {
                updateFenceCover();
            }
            fenceCover.setFillColor(fenceFinishCoverColor);
        }
        if (isCircle()) {
            updateScanCover();
        } else {
            removeScanCover();
        }
    }

    /**
     * 只提供给多边形使用
     *
     * @return
     */
    @Override
    public boolean isEditFinish() {
        if (markers.size() > 0) {
            return true;
        }
        return false;
    }

    @Override
    public void updateScanCover() {
        if (!isCircle()) {
            return;
        }
        // 显示扫描线
        int scanSize = positionsScanPolygons.size();

        if (scanSize > 0) {
            List<LatLng> latLngs = AMapPositionsUtils.transformAMapPosition(positionsScanPolygons.get(currentScanIndex));
            if (coverScanPolygon == null) {
                removeScanCover();
                PolygonOptions ooPolygon = MaMapUtils.getInstance().getCoverPolygonOptions(latLngs, scanCoverColor);
                coverScanPolygon = MaMapUtils.getInstance().getMap().addPolygon(ooPolygon);
            }
            if (coverScanPolygonLine == null) {
                currentScanIndex = 0;
                List<LatLng> lineSacnLatLngs = new ArrayList<>();
                lineSacnLatLngs.add(latLngs.get(0));
                lineSacnLatLngs.add(latLngs.get(2));
                PolylineOptions ooPolyline = MaMapUtils.getInstance().getScanPolylineOptions(lineSacnLatLngs, scanLineColor);
                coverScanPolygonLine = MaMapUtils.getInstance().getMap().addPolyline(ooPolyline);

                currentScanIndex = scanSize - 1;

                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "添加警戒区扫描浮层");
            }
            if (isCircle()) {
                HandlerUtils.getUIHandler().removeCallbacks(scanRunnable);
                HandlerUtils.getUIHandler().postDelayed(scanRunnable, DroneConfig.ANIMATION_DELAY_TIME);
            }
        }
    }

    @Override
    public synchronized void removeScanCover() {
        if (coverScanPolygon != null) {
            coverScanPolygon.remove();
            coverScanPolygon = null;
        }
        if (coverScanPolygonLine != null) {
            coverScanPolygonLine.remove();
            coverScanPolygonLine = null;
        }
    }

    @Override
    protected void removeCover() {
        if (fenceCover != null) {
            fenceCover.remove();
            fenceCover = null;
        }
    }

    @Override
    public void updateFenceLine() {
        List<MyLatLng> radiuPoints = new ArrayList<>();
        radiuPoints.add(getCenterLatLng());
        radiuPoints.add(circlePoint);
        if (radiusLine == null) {
            radiusLine = MaMapUtils.getInstance().getMap().addPolyline(
                    MaMapUtils.getInstance().getPolylineOptions(
                            AMapPositionsUtils.transformAMapPosition(radiuPoints), radiusLineColor, LocalMapConfig.FENCE_RADIUS_LINE_WIDTH, false));
        } else {
            radiusLine.setPoints(AMapPositionsUtils.transformAMapPosition(radiuPoints));
        }
        if (!isCircle()) {
            if (fenceLine == null) {
                if (markers.size() >= 2) {
                    fenceLine = MaMapUtils.getInstance().getMap().addPolyline(
                            MaMapUtils.getInstance().getPolylineOptions(
                                    AMapPositionsUtils.transformAMapPosition(getFenceLatLngs()), fenceLineColor, true));
                }
            } else {
                fenceLine.setPoints(AMapPositionsUtils.transformAMapPosition(getFenceLatLngs()));
            }
        }
    }

    @Override
    protected void removeFeceLine() {
        if (radiusLine != null) {
            radiusLine.remove();
            radiusLine = null;
        }
        if (fenceLine != null) {
            fenceLine.remove();
        }
    }

    @Override
    public void updateMarkers() {
        if (isCircle()) {
            if (centerMarker == null) {
                centerMarker = MaMapUtils.getInstance().getMap().addMarker(
                        MaMapUtils.getFenceCenterMarkOptions(AMapPositionsUtils.transformAMapPosition(getCenterLatLng())
                        ));
                MarkerDataModel mkModel = new MarkerDataModel();
                mkModel.type = Drone.MARKER_TYPE.DISTRICT_FENCE;
                DistrictFenceModel fenceModel = new DistrictFenceModel();
                fenceModel.id = getId();
                fenceModel.fenceMarkerType = MarkerId.CENTER;
                mkModel.data = fenceModel;
                centerMarker.setObject(mkModel);
            }
            if (circleMarker == null) {
                circleMarker = MaMapUtils.getInstance().getMap().addMarker(
                        MaMapUtils.getInstance().getMarkOptions(AMapPositionsUtils.transformAMapPosition(getCirclePoint()),
                                AMapBitmapManager.getInstance().getFenceMarkerBitmap(MapController.CURRENT_ZOOM_LEVEL)));
                MarkerDataModel mkModel = new MarkerDataModel();
                mkModel.type = Drone.MARKER_TYPE.DISTRICT_FENCE;
                DistrictFenceModel fenceModel = new DistrictFenceModel();
                fenceModel.id = getId();
                fenceModel.fenceMarkerType = MarkerId.CIRCLE;
                mkModel.data = fenceModel;
                circleMarker.setObject(mkModel);
            }
        } else {
            if (markers.size() > 0) {
                removeMarkers();
            }
            for (int n = 0; n < getFenceLatLngs().size(); n++) {
                Marker marker = MaMapUtils.getInstance().getMap().addMarker(
                        MaMapUtils.getFenceCenterMarkOptions(
                                AMapPositionsUtils.transformAMapPosition(getFenceLatLngs().get(n))));
                markers.add(marker);
                MarkerDataModel mkModel = new MarkerDataModel();
                mkModel.type = Drone.MARKER_TYPE.DISTRICT_FENCE;
                DistrictFenceModel fenceModel = new DistrictFenceModel();
                fenceModel.id = getClassKey();
                fenceModel.index = n;
                fenceModel.fenceMarkerType = MarkerId.CIRCLE;
                mkModel.data = fenceModel;
                marker.setObject(mkModel);
            }
        }
    }

    @Override
    public boolean addMarker(MyLatLng latLng) {
        if (!isCircle()) {
            if (isNeedMarker()) {
                if (super.addMarker(latLng)) {
                    Marker marker = MaMapUtils.getInstance().getMap().addMarker(
                            MaMapUtils.getFenceCenterMarkOptions(AMapPositionsUtils.transformAMapPosition(latLng)));
                    markers.add(marker);
                    MarkerDataModel mkModel = new MarkerDataModel();
                    mkModel.type = Drone.MARKER_TYPE.DISTRICT_FENCE;
                    DistrictFenceModel fenceModel = new DistrictFenceModel();
                    fenceModel.id = getClassKey();
                    fenceModel.index = markers.size() - 1;
                    fenceModel.fenceMarkerType = MarkerId.CIRCLE;
                    mkModel.data = fenceModel;
                    marker.setObject(mkModel);
                    updateFenceLine();
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public void removeMarkers() {
        if (centerMarker != null) {
            centerMarker.remove();
            centerMarker = null;
        }
        if (circleMarker != null) {
            circleMarker.remove();
            circleMarker = null;
        }
        if (markers != null) {
            for (Marker marker : markers) {
                marker.remove();
            }
            markers.clear();
        }
    }

    @Override
    public void erase() {
        HandlerUtils.getUIHandler().removeCallbacks(scanRunnable);
        super.erase();
    }

    private ThreadPoolHelper.MyThread scanRunnable = new ThreadPoolHelper.MyThread("fence" + "_scanRunnable") {
        @Override
        public void run() {
            if (MapController.INSTANCE.isMainPage()) {
                if (!isEdit && !isErase && !MapController.INSTANCE.isStop()) {
                    try {
                        int scanSize = positionsScanPolygons.size();
                        currentScanIndex--;
                        if (currentScanIndex > 0) {
                            currentScanIndex = (currentScanIndex - 1) % scanSize;
                        } else {
                            currentScanIndex = scanSize - 1;
                        }
                        List<LatLng> polygonPositions = AMapPositionsUtils.transformAMapPosition(positionsScanPolygons.get(currentScanIndex));
                        if (coverScanPolygon != null) {
                            coverScanPolygon.setPoints(polygonPositions);
                        }
                        if (coverScanPolygonLine != null) {
                            List<LatLng> lineSacnLatLngs = new ArrayList<>();
                            lineSacnLatLngs.add(polygonPositions.get(0));
                            lineSacnLatLngs.add(polygonPositions.get(2));
                            coverScanPolygonLine.setPoints(lineSacnLatLngs);
                        }
                        HandlerUtils.getUIHandler().removeCallbacks(this);
                        HandlerUtils.getUIHandler().postDelayed(this, 100);
                    } catch (Exception e) {
                        XAppLogger.getInstance().writeError(e);
                    }
                } else {
                    HandlerUtils.getUIHandler().removeCallbacks(this);
                    HandlerUtils.getUIHandler().postDelayed(this, DroneConfig.ANIMATION_DELAY_TIME);
                }
            }
        }
    };
}
