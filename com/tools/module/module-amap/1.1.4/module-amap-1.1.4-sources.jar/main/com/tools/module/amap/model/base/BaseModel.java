package com.tools.module.amap.model.base;

import com.tools.module.amap.map.amap.overlay.HistoryRouteOverlay;
import com.tools.module.amap.model.MarkerDataModel;
import com.tools.module.amap.model.RoutePointModel;
import com.drone.monitor.bean.custom.MyHasRouteObject;

public abstract class BaseModel<T extends MyHasRouteObject> {

    protected MarkerDataModel mkModel = new MarkerDataModel();
    // TODO 后期 历史路线应该放到地图控制器中，从这儿抽离出去
    private volatile HistoryRouteOverlay historyRouteOverlay;
    protected volatile T data;
    protected Object monitorLock = new Object();

    public abstract int getMarkerType();

    public abstract int getObjType();

    public void onMapStatusChange(float currentZoomLevel) {
        if (historyRouteOverlay != null) {
            historyRouteOverlay.onMapStatusChange(currentZoomLevel);
        }
    }

    public void removeRoute() {
        if (historyRouteOverlay != null) {
            historyRouteOverlay.removeFromMap();
            historyRouteOverlay = null;
        }
    }

    public void addRoute(RoutePointModel firstPoint, RoutePointModel twoPoint) {
        if (historyRouteOverlay != null) {
            historyRouteOverlay.addRoutePolyLine(firstPoint, twoPoint);
        }
    }

    protected synchronized void updateRoute() {
        if (getData().getHistoryPoints() == null || getData().getHistoryPoints().size() < 2) {
            return;
        }
        if (historyRouteOverlay == null) {
            historyRouteOverlay = new HistoryRouteOverlay(getMarkerType(), getObjType());
        }
        historyRouteOverlay.insertDatas(getData().getHistoryPoints());
    }

    public synchronized MyHasRouteObject getData() {
        return data;
    }

    public boolean isSelected() {
        if (mkModel != null) {
            return mkModel.isSelected;
        }
        return false;
    }

    protected static final String TAG = BaseModel.class.getSimpleName();

    public String getClassKey() {
        return Integer.toHexString(hashCode());
    }
}
