package com.drone.monitor.bean;

import com.drone.monitor.bean.custom.MyObject;
import com.google.gson.annotations.SerializedName;

import io.protostuff.Tag;

public class FrequencyRangeInfo extends MyObject {

    @Tag(1)
    private int status;

    /**
     * 电压
     */
    @Tag(2)
    private float voltage;

    /**
     * 电流
     */
    @Tag(3)
    private float current;

    /**
     * 温度
     */
    @Tag(4)
    private float temperature;

    /**
     * 正功率
     */
    @Tag(5)
    private float positivePower;

    /**
     * 反功率
     */
    @Tag(6)
    private float reversePower;

    /**
     * 驻波比
     */
    @Tag(7)
    private float vswr;

    @Tag(8)
    private float frequency;

    /**
     * 0-关
     * 1-开
     */

    @SerializedName("switch")
    @Tag(9)
    public int bgswitch;

    @Tag(10)
    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public float getVoltage() {
        return voltage;
    }

    public void setVoltage(float voltage) {
        this.voltage = voltage;
    }

    public float getCurrent() {
        return current;
    }

    public void setCurrent(float current) {
        this.current = current;
    }

    public float getTemperature() {
        return temperature;
    }

    public void setTemperature(float temperature) {
        this.temperature = temperature;
    }

    public float getPositivePower() {
        return positivePower;
    }

    public void setPositivePower(float positivePower) {
        this.positivePower = positivePower;
    }

    public float getReversePower() {
        return reversePower;
    }

    public void setReversePower(float reversePower) {
        this.reversePower = reversePower;
    }

    public float getVswr() {
        return vswr;
    }

    public void setVswr(float vswr) {
        this.vswr = vswr;
    }

    public float getFrequency() {
        return frequency;
    }

    public void setFrequency(float frequency) {
        this.frequency = frequency;
    }

    @Override
    public String toStringConcise() {
        return "FrequencyRangeInfo{" +
                "status=" + status +
                ", bgswitch=" + bgswitch +
                ", frequency=" + frequency +
                ", id=" + id +
                '}';
    }

    @Override
    public String toString() {
        return "FrequencyRangeInfo{" +
                "status=" + status +
                ", voltage=" + voltage +
                ", current=" + current +
                ", temperature=" + temperature +
                ", positivePower=" + positivePower +
                ", reversePower=" + reversePower +
                ", vswr=" + vswr +
                ", frequency=" + frequency +
                ", bgswitch=" + bgswitch +
                ", id=" + id +
                '}';
    }

    public void copy(FrequencyRangeInfo info) {
        this.setStatus(info.getStatus());
        this.setVoltage(info.getVoltage());
        this.setCurrent(info.getCurrent());
        this.setTemperature(info.getTemperature());
        this.setPositivePower(info.getPositivePower());
        this.setReversePower(info.getReversePower());
        this.setVswr(info.getVswr());
        this.setFrequency(info.getFrequency());
        this.bgswitch = info.bgswitch;
        this.setId(info.getId());
    }

}
