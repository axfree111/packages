package com.drone.monitor.bean;

import android.text.TextUtils;

import com.drone.monitor.bean.custom.MyObject;
import com.google.gson.reflect.TypeToken;
import com.tools.module.common.utils.GsonUtils;

import java.util.Date;

public class AuthorityInfo extends MyObject {

    private static int OPEN = 1;
    public long gmtCreate;
    public Date gmtCreateDate;
    public long gmtModified;
    public Date gmtModifiedDate;
    public int id;
    public String name;
    public String detail;
    private Detail detailObj;

    public Detail getDetail() {
        if (!TextUtils.isEmpty(detail) && detailObj == null) {
            detailObj = GsonUtils.getGson().fromJson(detail, new TypeToken<Detail>() {
            }.getType());
        }
        return detailObj;
    }

    public static class Detail extends MyObject {

        public int add_fence; // 绘制警报区（电子围栏）按钮是否可见
        public int record_video; // 视频是否可见
        public int screen_capture; // 截屏是否可见

        public int data_show; // 无人机、民航机等数据是否可见，是否可查询历史和轨迹

        public int device_show; // 设备数据是否可见

        public int auto_mode; // 自动半自动模式是否可设置

        public int draw_graph; // 沙盘是否可见
        public int draw_send; // 沙盘保存按钮是否可见

        public int set_destination; // 设置目的地按钮是否可见
        public int set_battletarget; // 设置打击目标按钮是否可见

        @Override
        public String toString() {
            return "Detail{" +
                    "add_fence=" + add_fence +
                    ", record_video=" + record_video +
                    ", screen_capture=" + screen_capture +
                    ", data_show=" + data_show +
                    ", device_show=" + device_show +
                    ", auto_mode=" + auto_mode +
                    ", draw_graph=" + draw_graph +
                    ", draw_send=" + draw_send +
                    ", set_destination=" + set_destination +
                    ", set_battletarget=" + set_battletarget +
                    "} " + super.toString();
        }
    }

    public boolean isAutoMode() {
        if (getDetail() == null) {
            return true;
        }
        return getDetail().auto_mode == OPEN;
    }

    public boolean getCanOperationData() {
        if (getDetail() == null) {
            return true;
        }
        return getDetail().data_show == OPEN;
    }

    public boolean getCanOperationDevice() {
        if (getDetail() == null) {
            return true;
        }
        return getDetail().device_show == OPEN;
    }

    public boolean getCanOperationFence() {
        if (getDetail() == null) {
            return true;
        }
        return getDetail().add_fence == OPEN;
    }

    public boolean getShowSearch() {
        if (getDetail() == null) {
            return true;
        }
        return getDetail().data_show == OPEN;
    }

    public boolean getCanOperationVideo() {
        if (getDetail() == null) {
            return true;
        }
        return getDetail().record_video == OPEN;
    }

    public boolean getShowScreenCapture() {
        if (getDetail() == null) {
            return true;
        }
        return getDetail().screen_capture == OPEN;
    }

    public boolean getShowDrawGraph() {
        if (getDetail() == null) {
            return true;
        }
        return getDetail().draw_graph == OPEN;
    }

    public boolean getShowDrawSend() {
        if (getDetail() == null) {
            return true;
        }
        return getDetail().draw_send == OPEN;
    }

    public boolean getCanOperationSetDestination() {
        if (getDetail() == null) {
            return true;
        }
        return getDetail().set_destination == OPEN;
    }

    public boolean getCanOperationSetBattletarget() {
        if (getDetail() == null) {
            return true;
        }
        return getDetail().set_battletarget == OPEN;
    }

    public Date getGmtCreate() {
        if (gmtCreateDate == null) {
            gmtCreateDate = new Date();
        }
        gmtCreateDate.setTime(gmtCreate);
        return gmtCreateDate;
    }

    public Date getGmtModified() {
        if (gmtModifiedDate == null) {
            gmtModifiedDate = new Date();
        }
        gmtModifiedDate.setTime(gmtModified);
        return gmtModifiedDate;
    }
}
