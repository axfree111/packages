package com.tools.module.amap.net.webSocket;

import android.text.TextUtils;

import com.tools.module.common.utils.ToastUtil;
import com.tools.module.common.utils.XAppLogger;
import com.tools.module.amap.R;
import com.tools.module.amap.net.NetManager;
import com.tools.module.amap.observer.DataObserver;
import com.tools.module.amap.utils.ProtostuffSerializerUtils;
import com.drone.monitor.bean.Order;
import com.drone.monitor.bean.WebSocketBean;

import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okio.ByteString;

public class WebSocketClient {

    private static final int NORMAL_CLOSURE_STATUS = 1000;

    private static final int MAX_RECONNECT_DELAY_TIME = 15 * 60000;
    // 心跳延迟时长
    public static final int HEARTBEAT_DELAY_TIME = 3 * 1000;
    // 心跳丢失时间
    public static final int HEARTBEAT_LOSE_TIME = 15 * 1000;
    // socket重连延迟时间
    public static final int RECONNECT_DELAY_STEP = 3 * 1000;

    private static WebSocketClient instance;

    private WebSocketClient() {
    }

    public static WebSocketClient getInstance() {
        if (null == instance) {
            synchronized (WebSocketClient.class) {
                if (null == instance) {
                    instance = new WebSocketClient();
                }
            }
        }
        return instance;
    }

    private WebSocket mWebSocket;

    private String wsAddress;
    private WebSocketResponse wsResponse;

    private int reconnectDelayTime = 0;
    private int recounectCount = 0;


    /**
     * 连接状态
     */
    enum CONNECT_STATUS {
        /**
         * 未连接
         */
        DISCONNECT,
        /**
         * 连接中
         */
        CONNECTING,
        /**
         * 已连接
         */
        CONNECTED
    }

    private CONNECT_STATUS connectStatus = CONNECT_STATUS.DISCONNECT;

    /**
     * 首次连接
     *
     * @param url
     * @param response
     */
    public void connect(String url, final WebSocketResponse response) {
        if (TextUtils.isEmpty(url) || connectStatus == CONNECT_STATUS.CONNECTED) {
            return;
        }

        wsAddress = url;
        wsResponse = response;

        realConnect(false);
    }

    /**
     * 失败重连,实际连接情况
     */
    private void realConnect(boolean isShowToast) {
        if (connectStatus == CONNECT_STATUS.DISCONNECT) {
            if (TextUtils.isEmpty(wsAddress)) {
                return;
            }

            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_SOCKET, "开始连接");

            if (isShowToast) {
                ToastUtil.makeLongText(R.string.toast_net_connecting);
            }

            Request.Builder requestBuilder = new Request.Builder().url(wsAddress);

            if (!TextUtils.isEmpty(NetManager.getSession())) {
                requestBuilder.addHeader("cookie", NetManager.getSession());
            }

            if (!TextUtils.isEmpty(NetManager.getToken())) {
                requestBuilder.addHeader("access_token", NetManager.getToken());
            }

            connectStatus = CONNECT_STATUS.CONNECTING;
            NetManager.getOkHttpClient().newWebSocket(requestBuilder.build(), getWebSocketListener());
        }
    }

    public void reconnectSocket(boolean outLogin) {
        // 重连时间限制为 MAX_RECONNECT_DELAY_TIME 最大时间
        reconnectDelayTime += RECONNECT_DELAY_STEP;
        if (reconnectDelayTime >= MAX_RECONNECT_DELAY_TIME) {
            reconnectDelayTime = 0;
            String content = "由于重连次数过多,登录已失效请重新登录！";
            XAppLogger.getInstance().writeError(content);
            ToastUtil.makeShortText(content);
            if (outLogin) {
                DataObserver.getInstance().onOutLogin();
            }
            return;
        }

        // 重连的时 每15秒提示一次数据连接丢失
        if (recounectCount == 0) {
            ToastUtil.makeShortText("数据连接已丢失");
        }

        recounectCount++;
        if (recounectCount >= 3) {
            recounectCount = 0;
        }

        realConnect(true);
    }

    /**
     * @return
     */
    private WebSocketListener getWebSocketListener() {
        return new WebSocketListener() {
            @Override
            public void onOpen(WebSocket webSocket, Response response) {
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_SOCKET, "websocket 已打开: response=%s", response.toString());

                mWebSocket = webSocket;

                if (connectStatus == CONNECT_STATUS.DISCONNECT) {

                    ToastUtil.makeShortText("已建立数据连接");
                }

                connectStatus = CONNECT_STATUS.CONNECTED;

                reconnectDelayTime = 0;

                if (null != wsResponse) {
                    wsResponse.onWebSocketOpen();
                }
            }

            @Override
            public void onMessage(WebSocket webSocket, String text) {
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_SOCKET, "websocket 收到文本消息: message=%s", text);
            }

            @Override
            public void onMessage(WebSocket webSocket, ByteString bytes) {
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_SOCKET, "websocket 收到字节消息: message=%s", bytes);

                WebSocketBean newBean = ProtostuffSerializerUtils.unmarshall(bytes.toByteArray(), WebSocketBean.class);

                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_OTHER, "websocket 收到消息: " + newBean.getOperation() + " result=%s", newBean.toString());

                if (null != wsResponse && null != newBean) {
                    wsResponse.onReceiveMessage(newBean);
                }
            }

            @Override
            public void onClosing(WebSocket webSocket, int code, String reason) {
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_SOCKET, "websocket 连接正在关闭: code=%d, reason=%s", code, reason);
                webSocket.close(NORMAL_CLOSURE_STATUS, "normal close");
            }

            @Override
            public void onClosed(WebSocket webSocket, int code, String reason) {
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_SOCKET, "websocket 连接已经关闭: code=%d, reason=%s", code, reason);

                connectStatus = CONNECT_STATUS.DISCONNECT;

                mWebSocket = null;

                if (null != wsResponse) {
                    wsResponse.onWebSocketClose();
                }
            }

            @Override
            public void onFailure(WebSocket webSocket, Throwable t, Response response) {
                if (t != null) {
                    t.printStackTrace();
                }
                String error = (t == null ? "null" : t.getMessage());
                String responseContent = (null == response ? "null" : response.toString());

                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_SOCKET, "websocket 连接失败: t=%s, response=%s", error, responseContent);

                connectStatus = CONNECT_STATUS.DISCONNECT;

                mWebSocket = null;

                if (null != wsResponse) {
                    wsResponse.onWebSocketClose();
                }
            }
        };
    }

    /**
     * 请求设备
     */
    public void requestMonitors() {
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "请求设备数据");
        WebSocketBean bean = new WebSocketBean();
        bean.setOperation(WebSocketBean.OPERATION_TYPE.MONITOR);
        sendMessage(bean);
    }

    /**
     * 请求无人机
     */
    public void requestDrones() {
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_DRONE, "请求无人机数据");
        WebSocketBean bean = new WebSocketBean();
        bean.setOperation(WebSocketBean.OPERATION_TYPE.DRONE);
        sendMessage(bean);
    }

    /**
     * 发送心跳
     */
    public boolean sendHeartbeat() {
        WebSocketBean bean = new WebSocketBean();
        bean.setOperation(WebSocketBean.OPERATION_TYPE.HEARTBEAT);
        return sendMessage(bean);
    }

    /**
     * 发送指令
     *
     * @param order
     */
    public void sendOrder(Order order) {
        if (null != order) {
            WebSocketBean bean = new WebSocketBean();
            bean.setObj(order);
            bean.setOperation(WebSocketBean.OPERATION_TYPE.ORDER);
            sendMessage(bean);
            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_ORDER, "发送指令：" + bean.toStringConcise());
        }
    }

    /**
     * 发送信息
     *
     * @param bean
     */
    public boolean sendMessage(WebSocketBean bean) {
        if (null != bean) {
            bean.setToken(NetManager.getToken());
            return sendMessage(ProtostuffSerializerUtils.marshall(bean));
        }
        return false;
    }

    /**
     * @param data
     */
    private boolean sendMessage(byte[] data) {
        if (null != mWebSocket) {
            if (null != data && data.length > 0) {
                ByteString byteStr = ByteString.of(data);
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_ORDER, byteStr.toString());
                mWebSocket.send(byteStr);
                return true;
            }
        } else {
            XAppLogger.getInstance().writeError("socket 已断开连接！！！");
        }
        return false;
    }

    public void close() {
        if (null != mWebSocket) {
            mWebSocket.close(NORMAL_CLOSURE_STATUS, "initiative close");
        }
    }
}
