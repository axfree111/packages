package com.tools.module.amap.map.contract;

import com.tools.module.amap.model.MyGeocodeAddress;
import com.drone.monitor.bean.custom.MyLatLng;

import java.util.List;

/**
 * Created by jiajie on 2020-01-19.
 */
public interface IGetDestinationInfoCallback {
    // 搜索关键词对应的地址列表
    void onSearchKeywordSuccess(List<MyGeocodeAddress> destinationName);

    // 搜索经纬度对应的地址列表
    void onSearchLatlngSuccess(String destinationName, MyLatLng targetLatlng);
}
