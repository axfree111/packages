package com.tools.module.amap.temp;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import com.tools.module.amap.R;
import com.tools.module.amap.view.weight.CustomDialog;
import com.tools.module.common.ContextStore;
import com.tools.module.common.utils.ResourceUtil;


/**
 * Created by changjiajie on 20/2/17.
 * 6.0以上系统检查"是否允许在其他应用之上"和小米手机弹窗提示打开悬浮窗权限
 */
public class FloatDialog extends CustomDialog {

    public static final int REQUEST_OVERLAY_PERMISSION = 1;

    private Activity context;
    View mRootView;

    public FloatDialog(Activity context) {
        super(context, R.style.TranslucentBackground);
        this.context = context;
    }


    @Override
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        mRootView = LayoutInflater.from(ContextStore.getContext()).inflate(R.layout.common_dialog, null);
        TextView titleView = (TextView) mRootView.findViewById(R.id.tv_title);
        titleView.setText(R.string.float_dialog_title);
        titleView.setVisibility(View.GONE);

        TextView cancelView = (TextView) mRootView.findViewById(R.id.tv_cancel);
        cancelView.setText(ResourceUtil.getContent(R.string.cancel));
        cancelView.setVisibility(View.GONE);
        View divideView = mRootView.findViewById(R.id.tv_divide);
        divideView.setVisibility(View.GONE);

        TextView continueView = (TextView) mRootView.findViewById(R.id.tv_ok);
        continueView.setText(R.string.float_dialog_open);
        continueView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + ContextStore.getContext().getPackageName()));
                    context.startActivityForResult(intent, REQUEST_OVERLAY_PERMISSION);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                dismiss();
            }
        });

        setCanceledOnTouchOutside(true);

        TextView msgTv = (TextView) mRootView.findViewById(R.id.tv_des);

        msgTv.setText(ResourceUtil.getContent(R.string.float_dialog_des));

        showDialog(mRootView, new OnBackCallBack() {
            @Override
            public void onBackPressed() {
                dismiss();
            }
        });
    }
}
