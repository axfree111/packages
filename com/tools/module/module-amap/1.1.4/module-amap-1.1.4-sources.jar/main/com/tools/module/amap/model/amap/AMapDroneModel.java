package com.tools.module.amap.model.amap;

import android.text.SpannableStringBuilder;
import android.text.TextUtils;

import com.amap.api.maps.model.BitmapDescriptor;
import com.amap.api.maps.model.Circle;
import com.amap.api.maps.model.CircleOptions;
import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.Marker;
import com.amap.api.maps.model.MarkerOptions;
import com.amap.api.maps.model.Polyline;
import com.amap.api.maps.model.Text;
import com.drone.monitor.bean.Drone;
import com.drone.monitor.bean.custom.MyLatLng;
import com.tools.module.common.utils.HandlerUtils;
import com.tools.module.amap.manager.ColorManager;
import com.tools.module.amap.manager.ThreadPoolHelper;
import com.tools.module.amap.map.MapController;
import com.tools.module.amap.map.amap.AMapBitmapManager;
import com.tools.module.amap.map.amap.AMapPositionsUtils;
import com.tools.module.amap.map.amap.MaMapUtils;
import com.tools.module.amap.map.amap.clusterutil.model.AMapClusterItem;
import com.tools.module.amap.model.DroneConfig;
import com.tools.module.amap.model.DroneRecordInvadeModel;
import com.tools.module.amap.model.base.BaseDroneModel;
import com.tools.module.common.utils.HandlerUtils;
import com.tools.module.common.utils.XAppLogger;

import java.util.Hashtable;
import java.util.Map;
import java.util.Vector;

/**
 * Created by jiajie on 2019-07-20.
 */
public class AMapDroneModel extends BaseDroneModel {

    private volatile Marker mMarker;
    private volatile AMapClusterItem mClusterItem;
    private volatile Vector<CircleOptions> circleWarningOptions = new Vector<>();
    private volatile Vector<Circle> coverWarningPolygons = new Vector<>();
    private volatile Text distanceText;
    private volatile Circle aroundIconCircle;
    private volatile Hashtable<String, Polyline> mToMonitorLineMap = new Hashtable<>();

    private int currentIndex = warningRadius - 1;

    public AMapDroneModel(Drone drone) {
        super(drone);
    }

    private LatLng getLatLng() {
        return new LatLng(getData().getLatitude(), getData().getLongitude());
    }

    private ThreadPoolHelper.MyThread warningIntroRunnable;
    private ThreadPoolHelper.MyThread toMonitorRouteRunnable;

    @Override
    public synchronized void onWarningTwinkle() {
        if (DroneConfig.SHOW_DRONE_TO_MONITOE_ROUTE_LINE) {
            if (toMonitorRouteRunnable == null) {
                toMonitorRouteRunnable = new ThreadPoolHelper.MyThread(getData().getItemId() + "_WaringRunnable") {
                    @Override
                    public void run() {
                        if (showDrone()) {
                            if (!MapController.INSTANCE.isStop()) {
                                if (getInvadeResultModels().size() > 0
                                        && attackRouteLinePositions.size() > 0) {
                                    for (Map.Entry<String, Vector<MyLatLng>> attackRouteLine : attackRouteLinePositions.entrySet()) {
                                        if (attackRouteLine != null) {
                                            Polyline polyline = mToMonitorLineMap.get(attackRouteLine.getKey());
                                            int index = 0;
                                            if (mToMonitorLineIndexMap.get(attackRouteLine.getKey()) != null) {
                                                index = mToMonitorLineIndexMap.get(attackRouteLine.getKey());
                                                if (polyline != null && attackRouteLine.getValue() != null) {
                                                    polyline.setPoints(AMapPositionsUtils.transformAMapPosition(attackRouteLine.getValue().subList(0, index)));
                                                }
                                            }
                                            index++;
                                            mToMonitorLineIndexMap.put(attackRouteLine.getKey(), index);
                                        }
                                    }
                                    HandlerUtils.getUIHandler().removeCallbacks(this);
                                    HandlerUtils.getUIHandler().postDelayed(this, 200);
                                }
                            } else {
                                HandlerUtils.getUIHandler().removeCallbacks(this);
                                HandlerUtils.getUIHandler().postDelayed(this, DroneConfig.ANIMATION_DELAY_TIME);
                            }
                        } else {
                            onCancelWaringTwinkle();
                        }
                    }
                };
            }
            HandlerUtils.getUIHandler().removeCallbacks(toMonitorRouteRunnable);
            HandlerUtils.getUIHandler().post(toMonitorRouteRunnable);
        }
        if (DroneConfig.SHOW_DRONE_WEARING_LINE) {
            HandlerUtils.getUIHandler().post(new Runnable() {
                @Override
                public void run() {
                    updateWaringCover();
                    if (getInvadeResultModels().size() > 0 && coverWarningPolygons.size() <= 0) {
                        for (CircleOptions options : circleWarningOptions) {
                            Circle circle = MaMapUtils.getInstance().getMap().addCircle(options);
                            coverWarningPolygons.add(circle);
                        }
                    }
                    if (warningIntroRunnable == null) {
                        warningIntroRunnable = new ThreadPoolHelper.MyThread(getData().getItemId() + "_WaringRunnable") {
                            @Override
                            public void run() {
                                if (showDrone()) {
                                    if (!MapController.INSTANCE.isStop()) {
                                        if (getInvadeResultModels().size() > 0
                                                && coverWarningPolygons.size() > 0) {
                                            if (currentIndex >= 0) {
                                                int index = currentIndex % warningRadius;
                                                if (coverWarningPolygons.size() > index) {
                                                    Circle circle = coverWarningPolygons.get(index);
                                                    circle.setVisible(false);
                                                    currentIndex = (currentIndex - 1) % warningRadius;
                                                }
                                            } else {
                                                currentIndex = warningRadius - 1;
                                                for (Circle circle : coverWarningPolygons) {
                                                    circle.setVisible(true);
                                                    circle.setCenter(getLatLng());
                                                }
                                            }
                                            HandlerUtils.getUIHandler().removeCallbacks(this);
                                            HandlerUtils.getUIHandler().postDelayed(this, 200);
                                        }
                                    } else {
                                        HandlerUtils.getUIHandler().removeCallbacks(this);
                                        HandlerUtils.getUIHandler().postDelayed(this, DroneConfig.ANIMATION_DELAY_TIME);
                                    }
                                } else {
                                    onCancelWaringTwinkle();
                                }
                            }
                        };
                    }
                    HandlerUtils.getUIHandler().removeCallbacks(warningIntroRunnable);
                    HandlerUtils.getUIHandler().post(warningIntroRunnable);
                }
            });
        }
    }

    @Override
    public synchronized void onCancelWaringTwinkle() {
        if (warningIntroRunnable != null) {
            HandlerUtils.getTwinkleHanlder().removeCallbacks(warningIntroRunnable);
        }
        if (toMonitorRouteRunnable != null) {
            HandlerUtils.getTwinkleHanlder().removeCallbacks(toMonitorRouteRunnable);
        }
        if (DroneConfig.SHOW_DRONE_WEARING_LINE) {
            // 取消动画
            for (Circle circle : coverWarningPolygons) {
                circle.remove();
            }
            coverWarningPolygons.clear();
        }
        if (DroneConfig.SHOW_DRONE_TO_MONITOE_ROUTE_LINE) {
            for (Map.Entry<String, Polyline> polylineEntry : mToMonitorLineMap.entrySet()) {
                if (polylineEntry != null) {
                    polylineEntry.getValue().remove();
                }
            }
            mToMonitorLineMap.clear();
            mToMonitorLineIndexMap.clear();
        }
    }

    private void updateWaringCover() {
        if (!showDrone()) {
            return;
        }
        if (getData().isCheckTargetObject()) {
            // 创建预警区域多边形的覆盖层
            if (circleWarningOptions.size() <= 0) {
                for (int i = 1; i <= warningRadius; i++) {
                    CircleOptions options = MaMapUtils.getInstance().getDroneWarningCircleLineOptions(
                            getLatLng(), getCircleRadius(i), getCircleWidthRadius(i), warningColor);
                    circleWarningOptions.add(options);
                }
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_DRONE, "配置无人机报警浮层 设备id:"
                        + getData().getItemId() + " | 类型:" + getData().getType());
            } else {
                for (CircleOptions options : circleWarningOptions) {
                    options.center(getLatLng());
                }
                for (Circle circle : coverWarningPolygons) {
                    circle.setCenter(getLatLng());
                }
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_DRONE, "更新无人机报警浮层 设备id:"
                        + getData().getItemId() + " | 类型:" + getData().getType());
            }
        }
    }

    /**
     * 添加无人机marker
     */
    @Override
    protected synchronized void updateDroneMarker() {
        if (getData().isShowClusterObject()) {
            if (mClusterItem != null) {
                mClusterItem.setPosition(getData().getMyLatLng());
                mClusterItem.setObject(getMarkerDataModel());
                MaMapUtils.getInstance().getClusterOverlay().updateClusterItem(mClusterItem);
            } else {
                mClusterItem = new AMapClusterItem(getData().getItemId(), getData().getMyLatLng(), markerType, getData().getType());
                mClusterItem.setObject(getMarkerDataModel());
                MaMapUtils.getInstance().getClusterOverlay().addClusterItem(mClusterItem);
            }
        } else {
            if (isShowMarker()) {
                if (mMarker != null) {
                    LatLng latLng = getLatLng();
                    mMarker.setVisible(true);
                    mMarker.setPosition(latLng);
                    mMarker.setObject(getMarkerDataModel());
                    if (getData().isNeedShowOrientation()) {
                        mMarker.setRotateAngle(-getData().yaw);
                    }
                } else {
                    addMarker();
                }
                if (markerType == Drone.MARKER_TYPE.SHIP
                        || markerType == Drone.MARKER_TYPE.AIRCRAFT) {
                    MapController.INSTANCE.recordShowedDroneModel(getData().getItemId(), this);
                }
            } else {
                removeMarker();
            }
        }
//        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_DRONE, "updateDroneMarker: mDroneId=" + getData().getItemId());
    }

    @Override
    protected void addMarker() {
        MarkerOptions markerOptions = MaMapUtils.getInstance().getDroneMarkerOptions(getData(), isMarkerAnchor(), isShowAnimation(), isSelected());
        mMarker = MaMapUtils.getInstance().getMap().addMarker(markerOptions);
        mMarker.setObject(getMarkerDataModel());
        if (getData().isNeedShowOrientation()) {
            mMarker.setRotateAngle(-getData().yaw);
        }
        startAnimation();
    }

    @Override
    public void setShowRoute(boolean showRoute) {
        super.setShowRoute(showRoute);
        if (getData().isShowClusterObject()) {
            if (getData().isShowRouteObject()) {
                if (mClusterItem != null) {
                    // TODO 解决隐藏轨迹按钮不能隐藏问题
                    mClusterItem.setObject(getMarkerDataModel());
//                    MaMapUtils.getInstance().getClusterOverlay().updateClusterItem(mClusterItem);
                }
            }
        } else {
            if (mMarker != null) {
                mMarker.setObject(getMarkerDataModel());
            }
        }
    }

    @Override
    public void onMapStatusChange(float currentZoomLevel) {
        if (!showDrone()) {
            return;
        }
        super.onMapStatusChange(currentZoomLevel);
        startAnimation();
        if (isShowMarker()) {
            if (mMarker != null) {
                BitmapDescriptor markerIcon = AMapBitmapManager.getInstance().getDroneBitmap(getData().getType(), MapController.CURRENT_ZOOM_LEVEL, isSelected());
                if (markerIcon != null) {
                    mMarker.setIcon(markerIcon);
                    if (getData().isNeedShowOrientation()) {
                        mMarker.setRotateAngle(-getData().yaw);
                    }
                }
            } else {
                addMarker();
            }
            if (markerType == Drone.MARKER_TYPE.SHIP
                    || markerType == Drone.MARKER_TYPE.AIRCRAFT) {
                MapController.INSTANCE.recordShowedDroneModel(getData().getItemId(), this);
            }
        } else {
            removeMarker();
        }
        for (int i = 0; i < circleWarningOptions.size(); i++) {
            CircleOptions options = circleWarningOptions.get(i);
            options.center(getLatLng());
            options.radius(getCircleRadius(i + 1));
            options.strokeWidth(getCircleWidthRadius(i + 1));
        }
        for (int j = 0; j < coverWarningPolygons.size(); j++) {
            Circle circle = coverWarningPolygons.get(j);
            circle.setCenter(getLatLng());
            circle.setRadius(getCircleRadius(j + 1));
            circle.setStrokeWidth(getCircleWidthRadius(j + 1));
        }
    }

    @Override
    public void startAnimation() {
    }

    @Override
    public void showMarkerWindow() {
        if (!showDrone()) {
            return;
        }
        if (mMarker != null) {
            mMarker.showInfoWindow();
        }
    }

    @Override
    public void hideMarkerWindow() {
        MaMapUtils.getInstance().hideWindowsInfo();
    }

    @Override
    protected synchronized void updateDroneToMonitorRouteLine(DroneRecordInvadeModel resultModel) {
        super.updateDroneToMonitorRouteLine(resultModel);
        if (aroundIconCircle == null) {
            CircleOptions options = MaMapUtils.getInstance().getCircleLineOptions(getLatLng(), DroneConfig.AROUND_DRONE_CIRCLE_LINE_RADIUS,
                    ColorManager.getDroneAroundCirclelineColor());
            aroundIconCircle = MaMapUtils.getInstance().getMap().addCircle(options);
        } else {
            aroundIconCircle.setCenter(getLatLng());
        }

    }

    @Override
    public void showDistanceInfo() {
        if (!showDrone()) {
            return;
        }
        String content = null;
        for (SpannableStringBuilder str : getDistanceInfos()) {
            if (TextUtils.isEmpty(content)) {
                content = str.toString();
            } else {
                content += "\n";
                content += str;
            }
        }
        if (distanceText == null) {
            distanceText = MaMapUtils.getInstance().getMap().addText(
                    MaMapUtils.getInstance().getDroneWarningTextOptions(content, getLatLng(), 0));
        } else {
            distanceText.setText(content);
            // 设置位置进行在圈上旋转
//            distanceText.setPosition();
        }
    }

    @Override
    public void hideDistanceInfo() {
        if (distanceText != null) {
            distanceText.remove();
            distanceText = null;
        }
    }

    /**
     * 擦除无人机
     */
    @Override
    public synchronized void erase() {
        super.erase();
        HandlerUtils.getUIHandler().post(new Runnable() {
            @Override
            public void run() {
                if (mClusterItem != null) {
                    mClusterItem = null;
                }
            }
        });
    }

    @Override
    protected void removeMarker() {
        if (mMarker != null) {
            // 首先清除marker的全局记录
            if (markerType == Drone.MARKER_TYPE.SHIP
                    || markerType == Drone.MARKER_TYPE.AIRCRAFT) {
                MapController.INSTANCE.removeShowedDroneModel(getData().getItemId());
            }
            mMarker.remove();
            mMarker = null;
        }
    }
}
