package com.tools.module.amap.observer;

import com.drone.monitor.bean.VideoInfo;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by jiajie on 2020-02-17.
 */
public class FloatWindowsObserver {

    private List<IFloatWindowsOperationCallback> mIOperationObservers = new ArrayList<>();
    private List<IFloatWindowsClickCallback> mIClickObservers = new ArrayList<>();

    public synchronized void registerOperationObserver(IFloatWindowsOperationCallback observer) {
        if (observer != null && !mIOperationObservers.contains(observer)) {
            mIOperationObservers.add(observer);
        }
    }

    public synchronized void unRegisterOperationObserver(IFloatWindowsOperationCallback observer) {
        if (observer != null) {
            mIOperationObservers.remove(observer);
        }
    }

    public synchronized void registerClickObserver(IFloatWindowsClickCallback observer) {
        if (observer != null && !mIClickObservers.contains(observer)) {
            mIClickObservers.add(observer);
        }
    }

    public synchronized void unRegisterClickObserver(IFloatWindowsClickCallback observer) {
        if (observer != null) {
            mIClickObservers.remove(observer);
        }
    }

    public void onClicked(VideoInfo videoInfo) {
        for (IFloatWindowsClickCallback observer : mIClickObservers) {
            if (observer != null) {
                observer.onClicked(videoInfo);
            }
        }
    }

    public void addVideoShowFloatWindow(VideoInfo videoInfo) {
        for (IFloatWindowsOperationCallback observer : mIOperationObservers) {
            if (observer != null) {
                observer.addVideoShowFloatWindow(videoInfo);
            }
        }
    }

    /**
     * 切换射频
     *
     * @param videoInfo
     */
    public void switchVideoFloatWindow(VideoInfo videoInfo) {
        for (IFloatWindowsOperationCallback observer : mIOperationObservers) {
            if (observer != null) {
                observer.switchVideoShowFloatWindow(videoInfo);
            }
        }
    }

    /**
     * 关闭悬浮窗
     */
    public void closeFloatWindow() {
        for (IFloatWindowsOperationCallback observer : mIOperationObservers) {
            if (observer != null) {
                observer.closeFloatWindow();
            }
        }
    }

    public interface IFloatWindowsClickCallback {
        void onClicked(VideoInfo videoInfo);
    }

    public interface IFloatWindowsOperationCallback {

        void switchVideoShowFloatWindow(VideoInfo videoInfo);

        void addVideoShowFloatWindow(VideoInfo videoInfo);

        void closeFloatWindow();

    }

    private static FloatWindowsObserver instance;

    public static FloatWindowsObserver getInstance() {
        if (instance == null) {
            synchronized (FloatWindowsObserver.class) {
                if (instance == null) {
                    instance = new FloatWindowsObserver();
                }
            }
        }
        return instance;
    }
}
