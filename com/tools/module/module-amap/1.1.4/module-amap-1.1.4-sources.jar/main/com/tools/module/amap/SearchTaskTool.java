package com.tools.module.amap;

import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * 单独使用此类时，需要设置EditText android:singleLine="true"或者android:inputType="text",否则会出现点击搜索或者回撤回掉两次startSearch的情况
 * addTaskListener 用来设置接受任务通知
 * setDelaymillis 用来设置任务延迟时间(单位毫秒)
 * cancelSearchTask 用来取消将要执行任务的通知
 * setEditorActionListener 用来设置键盘的回车键是否执行任务，false为不执行，true为执行
 */
public class SearchTaskTool implements TextWatcher, TextView.OnEditorActionListener {

    private static final int STARTTASK = 1;
    private long DELAYMILLIS = 500;
    private List<TaskListener> mTaskLisList;
    private EditText mEditText;
    private String mLastContent;

    private Handler handler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            if (msg.obj != null) {
                final String content = msg.obj.toString();
                if (msg.what == STARTTASK) {
                    notifyTask(content);
                }
            }
            return false;
        }
    });

    public SearchTaskTool(EditText editText) {
        mEditText = editText;
        initTools();
    }

    public SearchTaskTool(EditText editText, TaskListener taskListener) {
        mEditText = editText;
        initTools();
        if (mTaskLisList != null) {
            mTaskLisList.add(taskListener);
        }
    }

    public synchronized void addTaskListener(TaskListener taskListener) {
        if (mTaskLisList != null) {
            mTaskLisList.add(taskListener);
        }
    }

    public synchronized void removeTaskListener(TaskListener taskListener) {
        if (mTaskLisList != null && mTaskLisList.contains(taskListener)) {
            mTaskLisList.remove(taskListener);
        }
    }

    public void setEditorActionListener(boolean isListener) {
        if (isListener) {
            if (mEditText != null) {
                mEditText.setOnEditorActionListener(this);
            }
        }
    }

    public void setDelaymillis(long delaymillis) {
        DELAYMILLIS = delaymillis;
    }

    public void cancelSearchTask() {
        if (handler != null) {
            handler.removeMessages(STARTTASK);
        }
    }

    private void initTools() {
        mTaskLisList = new ArrayList<>();
        if (mEditText != null) {
            mEditText.addTextChangedListener(this);
        }
    }


    private void notifyTask(String content) {
        if (!TextUtils.isEmpty(content)) {
            mLastContent = content.replaceAll("\\r\\n", "").replaceAll("\\n", "");
        } else {
            mLastContent = "";
        }
        if (mTaskLisList != null && mTaskLisList.size() > 0) {
            for (TaskListener taskListener : mTaskLisList) {
                taskListener.startSearch(content);
            }
        }
    }

    private void readyTask(String content) {
        readyTask(content, 0);
    }

    private void readyTask(String content, long delayMillis) {
        String newContent = "";
        if (!TextUtils.isEmpty(content)) {
            newContent = content.replaceAll("\\r\\n", "").replaceAll("\\n", "");
        }
        if ((!TextUtils.isEmpty(mLastContent) && newContent.equals(mLastContent))
                || mTaskLisList == null || mTaskLisList.size() <= 0 || handler == null)
            return;
        handler.removeMessages(STARTTASK);
        Message msg = handler.obtainMessage();
        msg.what = STARTTASK;
        msg.obj = content;
        if (delayMillis > 0) {
            handler.sendMessageDelayed(msg, delayMillis);
        } else {
            handler.sendMessage(msg);
        }
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

    }

    @Override
    public void afterTextChanged(Editable s) {
        if (!TextUtils.isEmpty(s.toString())) {
            readyTask(s.toString(), DELAYMILLIS);
        } else {
            readyTask(s.toString());
        }
    }

    @Override
    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE
                || (event != null && event.getKeyCode() == KeyEvent.ACTION_DOWN)) {
            readyTask(v.getText().toString());
            return true;
        }
        return false;
    }

    public interface TaskListener {
        void startSearch(String content);
    }
}
