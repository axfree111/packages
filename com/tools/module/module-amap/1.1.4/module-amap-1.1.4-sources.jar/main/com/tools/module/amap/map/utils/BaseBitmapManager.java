package com.tools.module.amap.map.utils;

import android.graphics.Bitmap;
import android.view.View;

import com.drone.monitor.bean.Drone;
import com.drone.monitor.bean.MonitorDevice;
import com.tools.module.common.utils.ResourceUtil;
import com.tools.module.amap.R;
import com.tools.module.amap.map.MapConstants;
import com.tools.module.amap.model.DeviceBitModel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import static com.drone.monitor.bean.MonitorDevice.DEVICE_TYPE.SCAN_OPERATOR;

public abstract class BaseBitmapManager<T> {

    protected static BaseBitmapManager instance;

    // 热力点图标
    private Bitmap heatIconBitmap;
    // 起点图标
    private Bitmap routeStartNoteBitmap;
    // 终点图标
    private Bitmap routeEndNoteBitmap;
    // 路线方向箭头图标
    private Bitmap routeJiantouBitmap;
    // 路线断开方向箭头图标
    private Bitmap routeDisconnectJiantouBitmap;
    // 路线节点图标
    private Bitmap routeNoteBitmap;
    // 电子围栏图标
    private Bitmap fenceCenterMarkerBitmap;
    private Bitmap fenceMarkerBitmap;
    // 视频图标
    private Bitmap videoMarkerBitmap;

    // ------------------ 干扰 ----------
    //默认图标
    private Bitmap defaultBitmap;

    //不能识别的无人机
    private Bitmap droneUfoBitmap;

    private HashMap<Integer, Integer> deviceIds = new HashMap<>();
    private HashMap<Integer, Integer> deviceIdToTypes = new HashMap<>();
    private HashMap<Integer, Bitmap> deviceBitmaps = new HashMap<>();
    private HashMap<Integer, Integer> droneIds = new HashMap<>();
    private HashMap<Integer, Bitmap> droneBitmaps = new HashMap<>();

    public List<DeviceBitModel> getDeviceBitmapModels() {
        List<DeviceBitModel> bitModels = new ArrayList<>();
        Iterator<Map.Entry<Integer, Integer>> iterator = deviceIds.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<Integer, Integer> entry = iterator.next();
            if (entry != null) {
                Integer type = entry.getKey();
                Integer resId = entry.getValue();
                if (type != null && resId != null) {
                    DeviceBitModel bitModel = new DeviceBitModel();
                    bitModel.resId = resId;
                    bitModel.type = type;
                    bitModels.add(bitModel);
                }
            }
        }
        return bitModels;
    }

    protected void init() {
        if (heatIconBitmap == null) {
            heatIconBitmap = BitmapManger.scaleBitmap(ResourceUtil.getBitmap(R.drawable.heat_icon), 0.67f);
        }
        if (routeStartNoteBitmap == null) {
            routeStartNoteBitmap = BitmapManger.scaleBitmap(ResourceUtil.getBitmap(R.drawable.route_start_note), 0.72f);
        }
        if (routeEndNoteBitmap == null) {
            routeEndNoteBitmap = BitmapManger.scaleBitmap(ResourceUtil.getBitmap(R.drawable.route_end_note), 0.7f);
        }
        if (routeJiantouBitmap == null) {
            routeJiantouBitmap = BitmapManger.scaleBitmap(ResourceUtil.getBitmap(R.drawable.route_jiantou), 0.7f);
        }
        if (routeDisconnectJiantouBitmap == null) {
            routeDisconnectJiantouBitmap = BitmapManger.scaleBitmap(ResourceUtil.getBitmap(R.drawable.route_disconnect_jiantou), 0.72f);
        }
        if (routeNoteBitmap == null) {
            routeNoteBitmap = BitmapManger.scaleBitmap(ResourceUtil.getBitmap(R.drawable.route_note_marker), 0.71f);
        }
        if (fenceCenterMarkerBitmap == null) {
            fenceCenterMarkerBitmap = ResourceUtil.getBitmap(R.drawable.fence_center_point_marker);
        }
        if (fenceMarkerBitmap == null) {
            fenceMarkerBitmap = ResourceUtil.getBitmap(R.drawable.fence_point_marker);
        }
        if (videoMarkerBitmap == null) {
            videoMarkerBitmap = ResourceUtil.getBitmap(R.drawable.ic_video_marker);
        }

        // -------------------- 干扰 ----------
        if (defaultBitmap != null) {
            defaultBitmap = ResourceUtil.getBitmap(R.drawable.ic_disturb_portable_hemi);
        }
        if (!deviceBitmaps.containsKey(MonitorDevice.DEVICE_TYPE.DISTURB_PORTABLE_09B01)) {
            deviceIds.put(MonitorDevice.DEVICE_TYPE.DISTURB_PORTABLE_09B01, R.drawable.ic_disturb_portable_09b01);
            deviceIdToTypes.put(R.drawable.ic_disturb_portable_09b01, MonitorDevice.DEVICE_TYPE.DISTURB_PORTABLE_09B01);
            deviceBitmaps.put(MonitorDevice.DEVICE_TYPE.DISTURB_PORTABLE_09B01, ResourceUtil.getBitmap(R.drawable.ic_disturb_portable_09b01));
        }
        if (!deviceBitmaps.containsKey(MonitorDevice.DEVICE_TYPE.DISTURB_PORTABLE_09B02)) {
            deviceIds.put(MonitorDevice.DEVICE_TYPE.DISTURB_PORTABLE_09B02, R.drawable.ic_disturb_portable_09b02);
            deviceIdToTypes.put(R.drawable.ic_disturb_portable_09b02, MonitorDevice.DEVICE_TYPE.DISTURB_PORTABLE_09B02);
            deviceBitmaps.put(MonitorDevice.DEVICE_TYPE.DISTURB_PORTABLE_09B02, ResourceUtil.getBitmap(R.drawable.ic_disturb_portable_09b02));
        }
        if (!deviceBitmaps.containsKey(MonitorDevice.DEVICE_TYPE.DISTURB_PORTABLE_PL120D01)) {
            deviceIds.put(MonitorDevice.DEVICE_TYPE.DISTURB_PORTABLE_PL120D01, R.drawable.ic_disturb_portable_pl120d01);
            deviceIdToTypes.put(R.drawable.ic_disturb_portable_pl120d01, MonitorDevice.DEVICE_TYPE.DISTURB_PORTABLE_PL120D01);
            deviceBitmaps.put(MonitorDevice.DEVICE_TYPE.DISTURB_PORTABLE_PL120D01, ResourceUtil.getBitmap(R.drawable.ic_disturb_portable_pl120d01));
        }
        if (!deviceBitmaps.containsKey(MonitorDevice.DEVICE_TYPE.DISTURB_PORTABLE_CK120D01)) {
            deviceIds.put(MonitorDevice.DEVICE_TYPE.DISTURB_PORTABLE_CK120D01, R.drawable.ic_disturb_portable_ck120d01);
            deviceIdToTypes.put(R.drawable.ic_disturb_portable_ck120d01, MonitorDevice.DEVICE_TYPE.DISTURB_PORTABLE_CK120D01);
            deviceBitmaps.put(MonitorDevice.DEVICE_TYPE.DISTURB_PORTABLE_CK120D01, ResourceUtil.getBitmap(R.drawable.ic_disturb_portable_ck120d01));
        }
        if (!deviceBitmaps.containsKey(MonitorDevice.DEVICE_TYPE.DISTURB_PORTABLE_CK120D02)) {
            deviceIds.put(MonitorDevice.DEVICE_TYPE.DISTURB_PORTABLE_CK120D02, R.drawable.ic_disturb_portable_ck120d02);
            deviceIdToTypes.put(R.drawable.ic_disturb_portable_ck120d02, MonitorDevice.DEVICE_TYPE.DISTURB_PORTABLE_CK120D02);
            deviceBitmaps.put(MonitorDevice.DEVICE_TYPE.DISTURB_PORTABLE_CK120D02, ResourceUtil.getBitmap(R.drawable.ic_disturb_portable_ck120d02));
        }
        if (!deviceBitmaps.containsKey(MonitorDevice.DEVICE_TYPE.DISTURB_PORTABLE_8QX360B01)) {
            deviceIds.put(MonitorDevice.DEVICE_TYPE.DISTURB_PORTABLE_8QX360B01, R.drawable.ic_disturb_portable_omnibearing);
            deviceIdToTypes.put(R.drawable.ic_disturb_portable_omnibearing, MonitorDevice.DEVICE_TYPE.DISTURB_PORTABLE_8QX360B01);
            deviceBitmaps.put(MonitorDevice.DEVICE_TYPE.DISTURB_PORTABLE_8QX360B01, ResourceUtil.getBitmap(R.drawable.ic_disturb_portable_omnibearing));
        }
        if (!deviceBitmaps.containsKey(MonitorDevice.DEVICE_TYPE.DISTURB_CAR)) {
            deviceIds.put(MonitorDevice.DEVICE_TYPE.DISTURB_CAR, R.drawable.ic_disturb_car);
            deviceIdToTypes.put(R.drawable.ic_disturb_car, MonitorDevice.DEVICE_TYPE.DISTURB_CAR);
            deviceBitmaps.put(MonitorDevice.DEVICE_TYPE.DISTURB_CAR, ResourceUtil.getBitmap(R.drawable.ic_disturb_car));
        }
        if (!deviceBitmaps.containsKey(MonitorDevice.DEVICE_TYPE.DISTURB_RAILWAY_PROTECTION)) {
            deviceIds.put(MonitorDevice.DEVICE_TYPE.DISTURB_RAILWAY_PROTECTION, R.drawable.ic_disturb_railway_protection);
            deviceIdToTypes.put(R.drawable.ic_disturb_railway_protection, MonitorDevice.DEVICE_TYPE.DISTURB_RAILWAY_PROTECTION);
            deviceBitmaps.put(MonitorDevice.DEVICE_TYPE.DISTURB_RAILWAY_PROTECTION, ResourceUtil.getBitmap(R.drawable.ic_disturb_railway_protection));
        }
        if (!deviceBitmaps.containsKey(MonitorDevice.DEVICE_TYPE.DISTURB_HAND_06S01)) {
            deviceIds.put(MonitorDevice.DEVICE_TYPE.DISTURB_HAND_06S01, R.drawable.ic_disturb_hand);
            deviceIdToTypes.put(R.drawable.ic_disturb_hand, MonitorDevice.DEVICE_TYPE.DISTURB_HAND_06S01);
            deviceBitmaps.put(MonitorDevice.DEVICE_TYPE.DISTURB_HAND_06S01, ResourceUtil.getBitmap(R.drawable.ic_disturb_hand));
        }
        if (!deviceBitmaps.containsKey(MonitorDevice.DEVICE_TYPE.DISTURB_PISTOL)) {
            deviceIds.put(MonitorDevice.DEVICE_TYPE.DISTURB_PISTOL, R.drawable.ic_disturb_pistol);
            deviceIdToTypes.put(R.drawable.ic_disturb_pistol, MonitorDevice.DEVICE_TYPE.DISTURB_PISTOL);
            deviceBitmaps.put(MonitorDevice.DEVICE_TYPE.DISTURB_PISTOL, ResourceUtil.getBitmap(R.drawable.ic_disturb_pistol));
        }
        if (!deviceBitmaps.containsKey(MonitorDevice.DEVICE_TYPE.DISTURB_SHIP_ON)) {
            deviceIds.put(MonitorDevice.DEVICE_TYPE.DISTURB_SHIP_ON, R.drawable.ic_disturb_ship_on);
            deviceIdToTypes.put(R.drawable.ic_disturb_ship_on, MonitorDevice.DEVICE_TYPE.DISTURB_SHIP_ON);
            deviceBitmaps.put(MonitorDevice.DEVICE_TYPE.DISTURB_SHIP_ON, ResourceUtil.getBitmap(R.drawable.ic_disturb_ship_on));
        }
        if (!deviceBitmaps.containsKey(MonitorDevice.DEVICE_TYPE.DETECT_ABS_B)) {
            deviceIds.put(MonitorDevice.DEVICE_TYPE.DETECT_ABS_B, R.drawable.ic_detect_abs_b);
            deviceIdToTypes.put(R.drawable.ic_detect_abs_b, MonitorDevice.DEVICE_TYPE.DETECT_ABS_B);
            deviceBitmaps.put(MonitorDevice.DEVICE_TYPE.DETECT_ABS_B, ResourceUtil.getBitmap(R.drawable.ic_detect_abs_b));
        }
        if (!deviceBitmaps.containsKey(MonitorDevice.DEVICE_TYPE.DETECT_YUNSHAO)) {
            deviceIds.put(MonitorDevice.DEVICE_TYPE.DETECT_YUNSHAO, R.drawable.ic_detect_yunshao);
            deviceIdToTypes.put(R.drawable.ic_detect_yunshao, MonitorDevice.DEVICE_TYPE.DETECT_YUNSHAO);
            deviceBitmaps.put(MonitorDevice.DEVICE_TYPE.DETECT_YUNSHAO, ResourceUtil.getBitmap(R.drawable.ic_detect_yunshao));
        }
        if (!deviceBitmaps.containsKey(MonitorDevice.DEVICE_TYPE.DETECT_LEIDA)) {
            deviceIds.put(MonitorDevice.DEVICE_TYPE.DETECT_LEIDA, R.drawable.ic_detect_leida);
            deviceIdToTypes.put(R.drawable.ic_detect_leida, MonitorDevice.DEVICE_TYPE.DETECT_LEIDA);
            deviceBitmaps.put(MonitorDevice.DEVICE_TYPE.DETECT_LEIDA, ResourceUtil.getBitmap(R.drawable.ic_detect_leida));
        }
        if (!deviceBitmaps.containsKey(MonitorDevice.DEVICE_TYPE.DETECT_WEIBO)) {
            deviceIds.put(MonitorDevice.DEVICE_TYPE.DETECT_WEIBO, R.drawable.ic_detect_weibo);
            deviceIdToTypes.put(R.drawable.ic_detect_weibo, MonitorDevice.DEVICE_TYPE.DETECT_WEIBO);
            deviceBitmaps.put(MonitorDevice.DEVICE_TYPE.DETECT_WEIBO, ResourceUtil.getBitmap(R.drawable.ic_detect_weibo));
        }
        if (!deviceBitmaps.containsKey(MonitorDevice.DEVICE_TYPE.DETECT_YUNTAI_PORTABLE)) {
            deviceIds.put(MonitorDevice.DEVICE_TYPE.DETECT_YUNTAI_PORTABLE, R.drawable.ic_detect_yuntai_portable);
            deviceIdToTypes.put(R.drawable.ic_detect_yuntai_portable, MonitorDevice.DEVICE_TYPE.DETECT_YUNTAI_PORTABLE);
            deviceBitmaps.put(MonitorDevice.DEVICE_TYPE.DETECT_YUNTAI_PORTABLE, ResourceUtil.getBitmap(R.drawable.ic_detect_yuntai_portable));
        }
        if (!deviceBitmaps.containsKey(MonitorDevice.DEVICE_TYPE.DETECT_GPS)) {
            deviceIds.put(MonitorDevice.DEVICE_TYPE.DETECT_GPS, R.drawable.ic_defense_gps);
            deviceIdToTypes.put(R.drawable.ic_defense_gps, MonitorDevice.DEVICE_TYPE.DETECT_GPS);
            deviceBitmaps.put(MonitorDevice.DEVICE_TYPE.DETECT_GPS, ResourceUtil.getBitmap(R.drawable.ic_defense_gps));
        }
        if (!deviceBitmaps.containsKey(MonitorDevice.DEVICE_TYPE.WEAPON)) {
            deviceIds.put(MonitorDevice.DEVICE_TYPE.WEAPON, R.drawable.ic_weapon);
            deviceIdToTypes.put(R.drawable.ic_weapon, MonitorDevice.DEVICE_TYPE.WEAPON);
            deviceBitmaps.put(MonitorDevice.DEVICE_TYPE.WEAPON, ResourceUtil.getBitmap(R.drawable.ic_weapon));
        }
        if (!deviceBitmaps.containsKey(MonitorDevice.DEVICE_TYPE.WEAPON_GUANGDIAN)) {
            deviceIds.put(MonitorDevice.DEVICE_TYPE.WEAPON_GUANGDIAN, R.drawable.ic_weapon_guangdian);
            deviceIdToTypes.put(R.drawable.ic_weapon_guangdian, MonitorDevice.DEVICE_TYPE.WEAPON_GUANGDIAN);
            deviceBitmaps.put(MonitorDevice.DEVICE_TYPE.WEAPON_GUANGDIAN, ResourceUtil.getBitmap(R.drawable.ic_weapon_guangdian));
        }
        if (!deviceBitmaps.containsKey(MonitorDevice.DEVICE_TYPE.COMMAND_CENTER_PRIMARY)) {
            deviceIds.put(MonitorDevice.DEVICE_TYPE.COMMAND_CENTER_PRIMARY, R.drawable.command_center_primary);
            deviceIdToTypes.put(R.drawable.command_center_primary, MonitorDevice.DEVICE_TYPE.COMMAND_CENTER_PRIMARY);
            deviceBitmaps.put(MonitorDevice.DEVICE_TYPE.COMMAND_CENTER_PRIMARY, ResourceUtil.getBitmap(R.drawable.command_center_primary));
        }
        if (!deviceBitmaps.containsKey(MonitorDevice.DEVICE_TYPE.COMMAND_CENTER_SECONDARY)) {
            deviceIds.put(MonitorDevice.DEVICE_TYPE.COMMAND_CENTER_SECONDARY, R.drawable.command_center_secondary);
            deviceIdToTypes.put(R.drawable.command_center_secondary, MonitorDevice.DEVICE_TYPE.COMMAND_CENTER_SECONDARY);
            deviceBitmaps.put(MonitorDevice.DEVICE_TYPE.COMMAND_CENTER_SECONDARY, ResourceUtil.getBitmap(R.drawable.command_center_secondary));
        }
        if (!deviceBitmaps.containsKey(MonitorDevice.DEVICE_TYPE.COMMAND_CENTER_TERTIARY)) {
            deviceIds.put(MonitorDevice.DEVICE_TYPE.COMMAND_CENTER_TERTIARY, R.drawable.command_center_tertiary);
            deviceIdToTypes.put(R.drawable.command_center_tertiary, MonitorDevice.DEVICE_TYPE.COMMAND_CENTER_TERTIARY);
            deviceBitmaps.put(MonitorDevice.DEVICE_TYPE.COMMAND_CENTER_TERTIARY, ResourceUtil.getBitmap(R.drawable.command_center_tertiary));
        }
        if (!deviceBitmaps.containsKey(MonitorDevice.DEVICE_TYPE.ANALOG_DEVICES)) {
//            deviceIds.put(Constants.DEVICE_TYPE.ANALOG_DEVICES, R.drawable.analog_devices);
//            deviceIdToTypes.put(R.drawable.analog_devices, Constants.DEVICE_TYPE.ANALOG_DEVICES);
//            deviceBitmaps.put(Constants.DEVICE_TYPE.ANALOG_DEVICES, ResourceUtil.getBitmap(R.drawable.analog_devices));

            deviceIds.put(MonitorDevice.DEVICE_TYPE.ANALOG_DEVICES, R.drawable.ic_drone_police);
            deviceIdToTypes.put(R.drawable.ic_drone_police, MonitorDevice.DEVICE_TYPE.ANALOG_DEVICES);
            deviceBitmaps.put(MonitorDevice.DEVICE_TYPE.ANALOG_DEVICES, ResourceUtil.getBitmap(R.drawable.ic_drone_police));
        }
        if (!deviceBitmaps.containsKey(MonitorDevice.DEVICE_TYPE.SCAN_OPERATOR)) {
            deviceIds.put(MonitorDevice.DEVICE_TYPE.SCAN_OPERATOR, R.drawable.ic_pilot);
            deviceIdToTypes.put(R.drawable.ic_pilot, MonitorDevice.DEVICE_TYPE.SCAN_OPERATOR);
            deviceBitmaps.put(MonitorDevice.DEVICE_TYPE.SCAN_OPERATOR, ResourceUtil.getBitmap(R.drawable.ic_pilot));
        }

        // ----------------- 无人机 ----------
        if (!droneBitmaps.containsKey(Drone.DRONE_TYPE.DRONE_FROM_DJ)) {
            droneIds.put(Drone.DRONE_TYPE.DRONE_FROM_DJ, R.drawable.ic_drone_from_dj);
            droneBitmaps.put(Drone.DRONE_TYPE.DRONE_FROM_DJ, ResourceUtil.getBitmap(R.drawable.ic_drone_from_dj));
        }
        if (!droneBitmaps.containsKey(Drone.DRONE_TYPE.DRONE_FROM_CAA)) {
            droneIds.put(Drone.DRONE_TYPE.DRONE_FROM_CAA, R.drawable.ic_drone_from_caa);
            droneBitmaps.put(Drone.DRONE_TYPE.DRONE_FROM_CAA, ResourceUtil.getBitmap(R.drawable.ic_drone_from_caa));
        }
        if (!droneBitmaps.containsKey(Drone.DRONE_TYPE.DRONE_FROME_QIYE)) {
            droneIds.put(Drone.DRONE_TYPE.DRONE_FROME_QIYE, R.drawable.ic_drone_from_qiyexinxi);
            droneBitmaps.put(Drone.DRONE_TYPE.DRONE_FROME_QIYE, ResourceUtil.getBitmap(R.drawable.ic_drone_from_qiyexinxi));
        }
        if (!droneBitmaps.containsKey(Drone.DRONE_TYPE.DRONE_FROM_WUXIANDIAN)) {
            droneIds.put(Drone.DRONE_TYPE.DRONE_FROM_WUXIANDIAN, R.drawable.ic_drone_from_wuxiandian);
            droneBitmaps.put(Drone.DRONE_TYPE.DRONE_FROM_WUXIANDIAN, ResourceUtil.getBitmap(R.drawable.ic_drone_from_wuxiandian));
        }
        if (!droneBitmaps.containsKey(Drone.DRONE_TYPE.DRONE_FROM_YUNSHAO)) {
            droneIds.put(Drone.DRONE_TYPE.DRONE_FROM_YUNSHAO, R.drawable.ic_drone_from_yunshao);
            droneBitmaps.put(Drone.DRONE_TYPE.DRONE_FROM_YUNSHAO, ResourceUtil.getBitmap(R.drawable.ic_drone_from_yunshao));
        }
        if (!droneBitmaps.containsKey(Drone.DRONE_TYPE.DRONE_FROM_OTHER1)) {
            droneIds.put(Drone.DRONE_TYPE.DRONE_FROM_OTHER1, R.drawable.ic_drone_from_other1);
            droneBitmaps.put(Drone.DRONE_TYPE.DRONE_FROM_OTHER1, ResourceUtil.getBitmap(R.drawable.ic_drone_from_other1));
        }
        if (!droneBitmaps.containsKey(Drone.DRONE_TYPE.DRONE_FROM_OTHER2)) {
            droneIds.put(Drone.DRONE_TYPE.DRONE_FROM_OTHER2, R.drawable.ic_drone_from_other2);
            droneBitmaps.put(Drone.DRONE_TYPE.DRONE_FROM_OTHER2, ResourceUtil.getBitmap(R.drawable.ic_drone_from_other2));
        }
        if (!droneBitmaps.containsKey(Drone.DRONE_TYPE.DRONE_FROM_OTHER3)) {
            droneIds.put(Drone.DRONE_TYPE.DRONE_FROM_OTHER3, R.drawable.ic_drone_from_other3);
            droneBitmaps.put(Drone.DRONE_TYPE.DRONE_FROM_OTHER3, ResourceUtil.getBitmap(R.drawable.ic_drone_from_other3));
        }
        if (!droneBitmaps.containsKey(Drone.DRONE_TYPE.DRONE_FROM_OTHER4)) {
            droneIds.put(Drone.DRONE_TYPE.DRONE_FROM_OTHER4, R.drawable.ic_drone_from_other4);
            droneBitmaps.put(Drone.DRONE_TYPE.DRONE_FROM_OTHER4, ResourceUtil.getBitmap(R.drawable.ic_drone_from_other4));
        }
        if (!droneBitmaps.containsKey(Drone.DRONE_TYPE.DRONE_FROM_OTHER5)) {
            droneIds.put(Drone.DRONE_TYPE.DRONE_FROM_OTHER5, R.drawable.ic_drone_from_other5);
            droneBitmaps.put(Drone.DRONE_TYPE.DRONE_FROM_OTHER5, ResourceUtil.getBitmap(R.drawable.ic_drone_from_other5));
        }
        if (!droneBitmaps.containsKey(Drone.DRONE_TYPE.DRONE_FROM_OTHER6)) {
            droneIds.put(Drone.DRONE_TYPE.DRONE_FROM_OTHER6, R.drawable.ic_drone_from_other6);
            droneBitmaps.put(Drone.DRONE_TYPE.DRONE_FROM_OTHER6, ResourceUtil.getBitmap(R.drawable.ic_drone_from_other6));
        }
        if (!droneBitmaps.containsKey(Drone.DRONE_TYPE.DRONE_FROM_OTHER7)) {
            droneIds.put(Drone.DRONE_TYPE.DRONE_FROM_OTHER7, R.drawable.ic_drone_from_other7);
            droneBitmaps.put(Drone.DRONE_TYPE.DRONE_FROM_OTHER7, ResourceUtil.getBitmap(R.drawable.ic_drone_from_other7));
        }
        if (!droneBitmaps.containsKey(Drone.DRONE_TYPE.DRONE_NONGYEZHIBAO)) {
            droneIds.put(Drone.DRONE_TYPE.DRONE_NONGYEZHIBAO, R.drawable.ic_drone_nongyezhibao);
            droneBitmaps.put(Drone.DRONE_TYPE.DRONE_NONGYEZHIBAO, ResourceUtil.getBitmap(R.drawable.ic_drone_nongyezhibao));
        }
        if (!droneBitmaps.containsKey(Drone.DRONE_TYPE.DRONE_POLICE)) {
            droneIds.put(Drone.DRONE_TYPE.DRONE_POLICE, R.drawable.ic_drone_police);
            droneBitmaps.put(Drone.DRONE_TYPE.DRONE_POLICE, ResourceUtil.getBitmap(R.drawable.ic_drone_police));
        }
        if (!droneBitmaps.containsKey(Drone.DRONE_TYPE.DRONE_FROM_LOCAL)) {
            droneIds.put(Drone.DRONE_TYPE.DRONE_FROM_LOCAL, R.drawable.ic_drone_cluster_marker);
            droneBitmaps.put(Drone.DRONE_TYPE.DRONE_FROM_LOCAL, ResourceUtil.getBitmap(R.drawable.ic_drone_cluster_marker));
        }
        if (droneUfoBitmap == null) {
            droneUfoBitmap = ResourceUtil.getBitmap(R.drawable.icon_ufo);
        }

        // ----------------- 无人机 ----------

        // ----------------- 飞行器 ----------
        if (!droneBitmaps.containsKey(Drone.DRONE_TYPE.AIRCRAFT_AVIATION)) {
            droneIds.put(Drone.DRONE_TYPE.DRONE_POLICE, R.drawable.ic_drone_police);
            droneBitmaps.put(Drone.DRONE_TYPE.AIRCRAFT_AVIATION, BitmapManger.scaleBitmap(ResourceUtil.getBitmap(R.drawable.ic_aircraft_minhang), 0.7f));
        }
        if (!droneBitmaps.containsKey(Drone.DRONE_TYPE.AIRCRAFT_FIGHTER)) {
            droneIds.put(Drone.DRONE_TYPE.DRONE_POLICE, R.drawable.ic_drone_police);
            droneBitmaps.put(Drone.DRONE_TYPE.AIRCRAFT_FIGHTER, BitmapManger.scaleBitmap(ResourceUtil.getBitmap(R.drawable.ic_aircraft_fighter), 0.7f));
        }
        if (!droneBitmaps.containsKey(Drone.DRONE_TYPE.AIRCRAFT_ZHISHENGJI)) {
            droneIds.put(Drone.DRONE_TYPE.DRONE_POLICE, R.drawable.ic_drone_police);
            droneBitmaps.put(Drone.DRONE_TYPE.AIRCRAFT_ZHISHENGJI, BitmapManger.scaleBitmap(ResourceUtil.getBitmap(R.drawable.ic_aircraft_zhishengji), 0.7f));
        }
        if (!droneBitmaps.containsKey(Drone.DRONE_TYPE.AIRCRAFT_TONGHANG)) {
            droneIds.put(Drone.DRONE_TYPE.DRONE_POLICE, R.drawable.ic_drone_police);
            droneBitmaps.put(Drone.DRONE_TYPE.AIRCRAFT_TONGHANG, BitmapManger.scaleBitmap(ResourceUtil.getBitmap(R.drawable.ic_aircraft_tonghang), 0.7f));
        }
        if (!droneBitmaps.containsKey(Drone.DRONE_TYPE.AIRCRAFT_OTHER_DIKONGYOUREN)) {
            droneIds.put(Drone.DRONE_TYPE.DRONE_POLICE, R.drawable.ic_drone_police);
            droneBitmaps.put(Drone.DRONE_TYPE.AIRCRAFT_OTHER_DIKONGYOUREN, BitmapManger.scaleBitmap(ResourceUtil.getBitmap(R.drawable.ic_aircraft_other_dikongyouren), 0.7f));
        }
        // ------------------- 飞行器 ----------

        // ----------------- 船舶 ----------
        if (!droneBitmaps.containsKey(Drone.DRONE_TYPE.SHIP_DISTURB_OWNER)) {
            droneIds.put(Drone.DRONE_TYPE.SHIP_DISTURB_OWNER, R.drawable.ic_ship_owned);
            droneBitmaps.put(Drone.DRONE_TYPE.SHIP_DISTURB_OWNER, BitmapManger.scaleBitmap(ResourceUtil.getBitmap(R.drawable.ic_ship_owned), 0.7f));
        }
        if (!droneBitmaps.containsKey(Drone.DRONE_TYPE.SHIP_DISTURB_TROOPS)) {
            droneIds.put(Drone.DRONE_TYPE.SHIP_DISTURB_TROOPS, R.drawable.ic_ship_troops);
            droneBitmaps.put(Drone.DRONE_TYPE.SHIP_DISTURB_TROOPS, BitmapManger.scaleBitmap(ResourceUtil.getBitmap(R.drawable.ic_ship_troops), 0.7f));
        }
        if (!droneBitmaps.containsKey(Drone.DRONE_TYPE.SHIP_DISTURB_ENFORCE)) {
            droneIds.put(Drone.DRONE_TYPE.SHIP_DISTURB_ENFORCE, R.drawable.ic_ship_enforce);
            droneBitmaps.put(Drone.DRONE_TYPE.SHIP_DISTURB_ENFORCE, BitmapManger.scaleBitmap(ResourceUtil.getBitmap(R.drawable.ic_ship_enforce), 0.7f));
        }
        if (!droneBitmaps.containsKey(Drone.DRONE_TYPE.SHIP_OFFICIAL)) {
            droneIds.put(Drone.DRONE_TYPE.SHIP_OFFICIAL, R.drawable.ic_ship_official);
            droneBitmaps.put(Drone.DRONE_TYPE.SHIP_OFFICIAL, BitmapManger.scaleBitmap(ResourceUtil.getBitmap(R.drawable.ic_ship_official), 0.7f));
        }
        if (!droneBitmaps.containsKey(Drone.DRONE_TYPE.SHIP_CONTAINER)) {
            droneIds.put(Drone.DRONE_TYPE.SHIP_CONTAINER, R.drawable.ic_ship_container);
            droneBitmaps.put(Drone.DRONE_TYPE.SHIP_CONTAINER, BitmapManger.scaleBitmap(ResourceUtil.getBitmap(R.drawable.ic_ship_container), 0.7f));
        }
        if (!droneBitmaps.containsKey(Drone.DRONE_TYPE.SHIP_PASSENGER)) {
            droneIds.put(Drone.DRONE_TYPE.SHIP_PASSENGER, R.drawable.ic_ship_passenger);
            droneBitmaps.put(Drone.DRONE_TYPE.SHIP_PASSENGER, BitmapManger.scaleBitmap(ResourceUtil.getBitmap(R.drawable.ic_ship_passenger), 0.7f));
        }
        if (!droneBitmaps.containsKey(Drone.DRONE_TYPE.SHIP_BULK)) {
            droneIds.put(Drone.DRONE_TYPE.SHIP_BULK, R.drawable.ic_ship_bulk);
            droneBitmaps.put(Drone.DRONE_TYPE.SHIP_BULK, BitmapManger.scaleBitmap(ResourceUtil.getBitmap(R.drawable.ic_ship_bulk), 0.7f));
        }
        if (!droneBitmaps.containsKey(Drone.DRONE_TYPE.SHIP_TUG)) {
            droneIds.put(Drone.DRONE_TYPE.SHIP_TUG, R.drawable.ic_ship_tug);
            droneBitmaps.put(Drone.DRONE_TYPE.SHIP_TUG, BitmapManger.scaleBitmap(ResourceUtil.getBitmap(R.drawable.ic_ship_tug), 0.7f));
        }
        if (!droneBitmaps.containsKey(Drone.DRONE_TYPE.SHIP_CRUISE)) {
            droneIds.put(Drone.DRONE_TYPE.SHIP_CRUISE, R.drawable.ic_ship_cruise);
            droneBitmaps.put(Drone.DRONE_TYPE.SHIP_CRUISE, BitmapManger.scaleBitmap(ResourceUtil.getBitmap(R.drawable.ic_ship_cruise), 0.7f));
        }
        if (!droneBitmaps.containsKey(Drone.DRONE_TYPE.SHIP_OTHER)) {
            droneIds.put(Drone.DRONE_TYPE.SHIP_OTHER, R.drawable.ic_ship_other);
            droneBitmaps.put(Drone.DRONE_TYPE.SHIP_OTHER, BitmapManger.scaleBitmap(ResourceUtil.getBitmap(R.drawable.ic_ship_other), 0.7f));
        }
        // ----------------- 船舶 ----------
    }

    public int getDeviceIdToType(int resId) {
        if (deviceIdToTypes.containsKey(resId)) {
            return deviceIdToTypes.get(resId);
        }
        return 0;
    }

    public Bitmap getBitmapfromView(View view) {
        if (view == null) {
            return null;
        } else {
            view.measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
            view.layout(0, 0, view.getMeasuredWidth(), view.getMeasuredHeight());
            view.buildDrawingCache();
            Bitmap bitmap = view.getDrawingCache();
            return bitmap;
        }
    }

    public abstract T getBitmapDescriptor(int resId, float currentZoomLevel);

    public abstract T getOriginalBitmapDescriptor(Bitmap bitmap, float currentZoomLevel);

    public abstract T getBitmapDescriptor(View view, float currentZoomLevel, boolean isSelected);

    protected abstract T getDroneBitmapDescriptor(Bitmap bitmap, float currentZoomLevel, boolean isSelected);

    protected abstract T getMonitorBitmapDescriptor(Bitmap bitmap, float currentZoomLevel, boolean isSelected);

    protected abstract T getBitmapDescriptor(Bitmap bitmap, float currentZoomLevel);

    protected abstract T getVideoBitmapDescriptor(Bitmap bitmap, float currentZoomLevel, boolean isSelected);

    public T getRouteJiantouBitmap(float currentZoomLevel) {
        return getBitmapDescriptor(routeJiantouBitmap, currentZoomLevel);
    }

    public T getRouteDisconnectJiantouBitmap(float currentZoomLevel) {
        return getBitmapDescriptor(routeDisconnectJiantouBitmap, currentZoomLevel);
    }

    public T getRouteNoteBitmap(float currentZoomLevel) {
        return getBitmapDescriptor(routeNoteBitmap, currentZoomLevel);
    }

    public T getVideoMarkerBitmap(float currentZoomLevel, boolean isSelected) {
        return getVideoBitmapDescriptor(videoMarkerBitmap, currentZoomLevel, isSelected);
    }

    public T getFenceCenterMarkerBitmap(float currentZoomLevel) {
        return getBitmapDescriptor(fenceCenterMarkerBitmap, currentZoomLevel);
    }

    public T getFenceMarkerBitmap(float currentZoomLevel) {
        return getBitmapDescriptor(fenceMarkerBitmap, currentZoomLevel);
    }

    private T getDefaultBitmap(float currentZoomLevel, boolean isSelected) {
        return getMonitorBitmapDescriptor(defaultBitmap, currentZoomLevel, isSelected);
    }

    public T getRouteStartNoteBitmap(float currentZoomLevel) {
        return getBitmapDescriptor(routeStartNoteBitmap, currentZoomLevel);
    }

    public T getRouteEndNoteBitmap(float currentZoomLevel) {
        return getBitmapDescriptor(routeEndNoteBitmap, currentZoomLevel);
    }

    public T getDroneBitmap(int type, float currentZoomLevel, boolean isSelected) {
        int markerType = Drone.getMarkerType(type);
        // 只有船只和民航才用绿点表示
        switch (markerType) {
            case Drone.MARKER_TYPE.SHIP:
                if (MapConstants.isShowTitleOverlay()) {
                    return getBitmapDescriptor(heatIconBitmap, currentZoomLevel);
                }
                break;
        }
        if (!droneBitmaps.containsKey(type)) {
            return getDroneBitmapDescriptor(droneUfoBitmap, currentZoomLevel, isSelected);
        }
        Bitmap bitmap = droneBitmaps.get(type);
        if (bitmap == null) {
            return getDroneBitmapDescriptor(droneUfoBitmap, currentZoomLevel, isSelected);
        }
        return getDroneBitmapDescriptor(bitmap, currentZoomLevel, isSelected);
    }

    public T getDescriptorBitmap(int type, int status, float currentZoomLevel, boolean isSelected) {
        if (!deviceBitmaps.containsKey(type)) {
            return getDefaultBitmap(currentZoomLevel, isSelected);
        }
        Bitmap bitmap = deviceBitmaps.get(type);
        if (bitmap == null) {
            return getDefaultBitmap(currentZoomLevel, isSelected);
        }
        switch (status) {
            case MonitorDevice.DEVICE_STATUS.POWER_OFF:
                return getMonitorBitmapDescriptor(bitmap, currentZoomLevel, isSelected);
            default:
                return getMonitorBitmapDescriptor(bitmap, currentZoomLevel, isSelected);
        }
    }

    public int getVideoMarkerResId() {
        return R.drawable.ic_video_marker;
    }

    public int getDroneResId(int type, float currentZoomLevel) {
        int markerType = Drone.getMarkerType(type);
        // 只有船只和民航才用绿点表示
        switch (markerType) {
            case Drone.MARKER_TYPE.SHIP:
                if (MapConstants.isShowTitleOverlay()) {
                    return R.drawable.heat_icon;
                }
                break;
        }
        if (!droneIds.containsKey(type)) {
            return R.drawable.icon_ufo;
        }
        return droneIds.get(type);
    }

    public int getDescriptorResId(int type, int status, boolean isOmnibearing, float currentZoomLevel) {
        if (!deviceIds.containsKey(type)) {
            return R.drawable.ic_disturb_portable_hemi;
        }
        switch (type) {
            case MonitorDevice.DEVICE_TYPE.DISTURB_PORTABLE_09B01:
            case MonitorDevice.DEVICE_TYPE.DISTURB_PORTABLE_09B02:
            case MonitorDevice.DEVICE_TYPE.DISTURB_PORTABLE_PL120D01:
            case MonitorDevice.DEVICE_TYPE.DISTURB_PORTABLE_CK120D01:
            case MonitorDevice.DEVICE_TYPE.DISTURB_PORTABLE_CK120D02:
                if (isOmnibearing) {
                    return deviceIds.get(MonitorDevice.DEVICE_TYPE.DISTURB_PORTABLE_8QX360B01);
                } else {
                    return deviceIds.get(type);
                }
            default: {
                return deviceIds.get(type);
            }
        }
    }
}
