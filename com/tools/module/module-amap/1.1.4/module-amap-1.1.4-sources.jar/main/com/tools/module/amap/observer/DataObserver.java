package com.tools.module.amap.observer;

import android.text.SpannableStringBuilder;

import com.tools.module.amap.map.MapController;
import com.tools.module.amap.model.MarkerDataModel;
import com.drone.monitor.bean.custom.MyLatLng;
import com.drone.monitor.bean.BaseData;
import com.drone.monitor.bean.BaseRouteHistoryData;
import com.drone.monitor.bean.Drone;
import com.drone.monitor.bean.VideoInfo;
import com.tools.module.common.utils.HandlerUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by jiajie on 2019-07-21.
 */
public class DataObserver {
    private static DataObserver instance;

    public static DataObserver getInstance() {
        if (instance == null) {
            synchronized (DataObserver.class) {
                if (instance == null) {
                    instance = new DataObserver();
                }
            }
        }
        return instance;
    }

    private final List<IUpdateSelectMonitorObserver> mClearSelectMonitorObservers = new ArrayList<>();
    private final List<IUpdateDataObserver> mUpdateDataObservers = new ArrayList<>();
    private final List<IUpdateUIObserver> mUpdateUIObservers = new ArrayList<>();
    private final List<IOutLogin> mIOutLoginObservers = new ArrayList<>();
    private final List<IDroneDistanceObserver> mDroneDistanceObservers = new ArrayList<>();
    private final List<IDroneDistanceDataChangeListener> mDroneDistanceDataChangedObservers = new ArrayList<>();
    private final List<IVideoUploadDataChangeListener> mVideoUploadDataChangedObservers = new ArrayList<>();
    private final List<ISearchHistoryDataChangeListener> mSearchDroneHistoryDataChangedObservers = new ArrayList<>();
    private final List<ITaskChangedListener> mTaskChangedObservers = new ArrayList<>();
    private final List<IMarkerOperationListener> mMarkerOperationObservers = new ArrayList<>();
    private final List<IPaintMarkerOperationListener> mPaintMarkerOperationObservers = new ArrayList<>();
    private final List<IUpdateSystemConfigListener> mUpdateSystemConfigObservers = new ArrayList<>();


    public void notifySystemChanged() {
        HandlerUtils.getUIHandler().post(new Runnable() {
            @Override
            public void run() {
                for (IUpdateSystemConfigListener observer : mUpdateSystemConfigObservers) {
                    if (observer != null) {
                        observer.onSystemChanged();
                    }
                }
            }
        });
    }

    public synchronized void registerUpdateSystemConfigObserver(IUpdateSystemConfigListener observer) {
        if (observer != null && !mUpdateSystemConfigObservers.contains(observer)) {
            mUpdateSystemConfigObservers.add(observer);
        }
    }

    public synchronized void unRegisterUpdateSystemConfigObserver(IUpdateSystemConfigListener observer) {
        if (observer != null) {
            mUpdateSystemConfigObservers.remove(observer);
        }
    }


    public void notifyClickPaintMarker(MarkerDataModel mkDataModel) {
        HandlerUtils.getUIHandler().post(new Runnable() {
            @Override
            public void run() {
                for (IPaintMarkerOperationListener observer : mPaintMarkerOperationObservers) {
                    if (observer != null) {
                        observer.onPaintMarkerClick(mkDataModel);
                    }
                }
            }
        });
    }

    public synchronized void registerPaintMarkerOperationObserver(IPaintMarkerOperationListener observer) {
        if (observer != null && !mPaintMarkerOperationObservers.contains(observer)) {
            mPaintMarkerOperationObservers.add(observer);
        }
    }

    public synchronized void unRegisterPaintMarkerOperationObserver(IPaintMarkerOperationListener observer) {
        if (observer != null) {
            mPaintMarkerOperationObservers.remove(observer);
        }
    }


    public void notifyClickMarker(MarkerDataModel mkDataModel) {
        HandlerUtils.getUIHandler().post(new Runnable() {
            @Override
            public void run() {
                for (IMarkerOperationListener observer : mMarkerOperationObservers) {
                    if (observer != null) {
                        observer.onMarkerClick(mkDataModel);
                    }
                }
            }
        });
    }

    public void notifyUpdateShowWindowData(MarkerDataModel mkDataModel) {
        HandlerUtils.getUIHandler().post(new Runnable() {
            @Override
            public void run() {
                for (IMarkerOperationListener observer : mMarkerOperationObservers) {
                    if (observer != null) {
                        observer.onUpdateData(mkDataModel);
                    }
                }
            }
        });
    }

    public void notifyHideMarker() {
        HandlerUtils.getUIHandler().post(new Runnable() {
            @Override
            public void run() {
                for (IMarkerOperationListener observer : mMarkerOperationObservers) {
                    if (observer != null) {
                        observer.onHideMarker();
                    }
                }
            }
        });
    }

    public synchronized void registerMarkerOperationObserver(IMarkerOperationListener observer) {
        if (observer != null && !mMarkerOperationObservers.contains(observer)) {
            mMarkerOperationObservers.add(observer);
        }
    }

    public synchronized void unRegisterMarkerOperationObserver(IMarkerOperationListener observer) {
        if (observer != null) {
            mMarkerOperationObservers.remove(observer);
        }
    }


    public void notifyCancelBattleTarge() {
        HandlerUtils.getThreadHanlder().post(new Runnable() {
            @Override
            public void run() {
                MapController.IS_SELECT_TARGET = false;
                for (ITaskChangedListener observer : mTaskChangedObservers) {
                    if (observer != null) {
                        observer.onCancelBattleTarget();
                    }
                }
            }
        });
    }


    public void notifySetBattleTarge(Drone drone) {
        HandlerUtils.getThreadHanlder().post(new Runnable() {
            @Override
            public void run() {
                MapController.IS_SELECT_TARGET = false;
                for (ITaskChangedListener observer : mTaskChangedObservers) {
                    if (observer != null) {
                        observer.onSetBattleTarget(drone);
                    }
                }
            }
        });
    }

    public void notifySetDestination(MyLatLng targetLatlng) {
        HandlerUtils.getThreadHanlder().post(new Runnable() {
            @Override
            public void run() {
                MapController.IS_SELECT_TASK_ROUTE = false;
                for (ITaskChangedListener observer : mTaskChangedObservers) {
                    if (observer != null) {
                        observer.onSetDestination(targetLatlng);
                    }
                }
            }
        });
    }

    public void notifyCancelDestination() {
        HandlerUtils.getThreadHanlder().post(new Runnable() {
            @Override
            public void run() {
                MapController.IS_SELECT_TASK_ROUTE = false;
                for (ITaskChangedListener observer : mTaskChangedObservers) {
                    if (observer != null) {
                        observer.onCancelDestination();
                    }
                }
            }
        });
    }

    public void notifyCancelAllTask() {
        HandlerUtils.getThreadHanlder().post(new Runnable() {
            @Override
            public void run() {
                MapController.IS_SELECT_TARGET = false;
                MapController.IS_SELECT_TASK_ROUTE = false;
                for (ITaskChangedListener observer : mTaskChangedObservers) {
                    if (observer != null) {
                        observer.onCancelAll();
                    }
                }
            }
        });
    }

    public synchronized void registerTaskChangedObserver(ITaskChangedListener observer) {
        if (observer != null && !mTaskChangedObservers.contains(observer)) {
            mTaskChangedObservers.add(observer);
        }
    }

    public synchronized void unRegisterTaskChangedObserver(ITaskChangedListener observer) {
        if (observer != null) {
            mTaskChangedObservers.remove(observer);
        }
    }



    public void orderRunDone() {
        HandlerUtils.getUIHandler().post(new Runnable() {
            @Override
            public void run() {
                for (IUpdateDataObserver observer : mUpdateDataObservers) {
                    if (observer != null) {
                        observer.orderRunDone();
                    }
                }
            }
        });
    }

    public void updateFPSList() {
        HandlerUtils.getUIHandler().post(new Runnable() {
            @Override
            public void run() {
                for (IUpdateDataObserver observer : mUpdateDataObservers) {
                    if (observer != null) {
                        observer.updateFPS();
                    }
                }
            }
        });
    }
    public synchronized void registerUpdateDataObserver(IUpdateDataObserver observer) {
        if (observer != null && !mUpdateDataObservers.contains(observer)) {
            mUpdateDataObservers.add(observer);
        }
    }

    public synchronized void unRegisterUpdateDataObserver(IUpdateDataObserver observer) {
        if (observer != null) {
            mUpdateDataObservers.remove(observer);
        }
    }


    public void updateUI() {
        HandlerUtils.getUIHandler().post(new Runnable() {
            @Override
            public void run() {
                for (IUpdateUIObserver observer : mUpdateUIObservers) {
                    if (observer != null) {
                        observer.updateUI();
                    }
                }
            }
        });
    }

    public synchronized void registerUpdateUIObserver(IUpdateUIObserver observer) {
        if (observer != null && !mUpdateUIObservers.contains(observer)) {
            mUpdateUIObservers.add(observer);
        }
    }

    public synchronized void unRegisterUpdateUIObserver(IUpdateUIObserver observer) {
        if (observer != null) {
            mUpdateUIObservers.remove(observer);
        }
    }

    public void clearSelectMonitor() {
        HandlerUtils.getUIHandler().post(new Runnable() {
            @Override
            public void run() {
                for (IUpdateSelectMonitorObserver observer : mClearSelectMonitorObservers) {
                    if (observer != null) {
                        observer.clearSelectMonitor();
                    }
                }
            }
        });
    }

    public synchronized void registerUpdateSelectMonitorObserver(IUpdateSelectMonitorObserver observer) {
        if (observer != null && !mClearSelectMonitorObservers.contains(observer)) {
            mClearSelectMonitorObservers.add(observer);
        }
    }

    public synchronized void unRegisterUpdateSelectMonitorObserver(IUpdateSelectMonitorObserver observer) {
        if (observer != null) {
            mClearSelectMonitorObservers.remove(observer);
        }
    }

    public void onAddShow(String key, SpannableStringBuilder value) {
        for (IDroneDistanceObserver observer : mDroneDistanceObservers) {
            if (observer != null) {
                if (observer.onAddShow(key, value)) {
                    updateData(MapController.getShowDroneDistanceList());
                }
            }
        }
    }

    public void onDeleteShow(String key) {
        for (IDroneDistanceObserver observer : mDroneDistanceObservers) {
            if (observer != null) {
                observer.onDeleteShow(key);
                updateData(MapController.getShowDroneDistanceList());
            }
        }
    }

    public void onUpdate(String key, SpannableStringBuilder value) {
        for (IDroneDistanceObserver observer : mDroneDistanceObservers) {
            if (observer != null) {
                if (observer.onUpdate(key, value)) {
                    updateData(MapController.getShowDroneDistanceList());
                }
            }
        }
    }

    public synchronized void registerDroneDistanceObserver(IDroneDistanceObserver observer) {
        if (observer != null && !mDroneDistanceObservers.contains(observer)) {
            mDroneDistanceObservers.add(observer);
        }
    }

    public synchronized void unRegisterDroneDistanceObserver(IDroneDistanceObserver observer) {
        if (observer != null) {
            mDroneDistanceObservers.remove(observer);
        }
    }


    public void updateData(List<SpannableStringBuilder> data) {
        HandlerUtils.getUIHandler().post(new Runnable() {
            @Override
            public void run() {
                for (IDroneDistanceDataChangeListener observer : mDroneDistanceDataChangedObservers) {
                    if (observer != null) {
                        observer.updateData(data);
                    }
                }
            }
        });
    }

    public synchronized void registerDroneDistanceChangedObserver(IDroneDistanceDataChangeListener observer) {
        if (observer != null && !mDroneDistanceDataChangedObservers.contains(observer)) {
            mDroneDistanceDataChangedObservers.add(observer);
        }
    }

    public synchronized void unRegisterDroneDistanceChangedObserver(IDroneDistanceDataChangeListener observer) {
        if (observer != null) {
            mDroneDistanceDataChangedObservers.remove(observer);
        }
    }


    public void onOutLogin() {
        HandlerUtils.getUIHandler().post(new Runnable() {
            @Override
            public void run() {
                for (IOutLogin observer : mIOutLoginObservers) {
                    if (observer != null) {
                        observer.onOutLogin();
                    }
                }
            }
        });
    }


    public synchronized void registerOutLoginObserver(IOutLogin observer) {
        if (observer != null && !mIOutLoginObservers.contains(observer)) {
            mIOutLoginObservers.add(observer);
        }
    }

    public synchronized void unRegisterOutLoginObserver(IOutLogin observer) {
        if (observer != null) {
            mIOutLoginObservers.remove(observer);
        }
    }


    public void updateVideoUploadData(String nameKey, VideoInfo data) {
        HandlerUtils.getUIHandler().post(new Runnable() {
            @Override
            public void run() {
                for (IVideoUploadDataChangeListener observer : mVideoUploadDataChangedObservers) {
                    if (observer != null) {
                        observer.updateData(nameKey, data);
                    }
                }
            }
        });
    }

    public void removeVideoUploadData(String nameKey, VideoInfo data) {
        HandlerUtils.getUIHandler().post(new Runnable() {
            @Override
            public void run() {
                for (IVideoUploadDataChangeListener observer : mVideoUploadDataChangedObservers) {
                    if (observer != null) {
                        observer.removeData(nameKey, data);
                    }
                }
            }
        });
    }

    public synchronized void registerVideoUploadDataObserver(IVideoUploadDataChangeListener observer) {
        if (observer != null && !mVideoUploadDataChangedObservers.contains(observer)) {
            mVideoUploadDataChangedObservers.add(observer);
        }
    }

    public synchronized void unRegisterVideoUploadDataObserver(IVideoUploadDataChangeListener observer) {
        if (observer != null) {
            mVideoUploadDataChangedObservers.remove(observer);
        }
    }

    public void notifySearchFinishDroneDatas(List<BaseData> droneHistory) {
        HandlerUtils.getUIHandler().post(new Runnable() {
            @Override
            public void run() {
                for (ISearchHistoryDataChangeListener observer : mSearchDroneHistoryDataChangedObservers) {
                    if (observer != null) {
                        observer.setHistoryDatas(droneHistory);
                    }
                }
            }
        });
    }

    public void notifySearchFinishSingleDroneDatas(List<BaseData> droneHistory, BaseRouteHistoryData routeHistoryData) {
        HandlerUtils.getUIHandler().post(new Runnable() {
            @Override
            public void run() {
                for (ISearchHistoryDataChangeListener observer : mSearchDroneHistoryDataChangedObservers) {
                    if (observer != null) {
                        observer.setSingleDatas(droneHistory, routeHistoryData);
                    }
                }
            }
        });
    }

    public synchronized void registerSearchDroneHistoryDataObserver(ISearchHistoryDataChangeListener observer) {
        if (observer != null && !mSearchDroneHistoryDataChangedObservers.contains(observer)) {
            mSearchDroneHistoryDataChangedObservers.add(observer);
        }
    }

    public synchronized void unRegisterSearchDroneHistoryDataObserver(ISearchHistoryDataChangeListener observer) {
        if (observer != null) {
            mSearchDroneHistoryDataChangedObservers.remove(observer);
        }
    }

    public interface IUpdateSelectMonitorObserver {
        void clearSelectMonitor();
    }

    public interface IUpdateDataObserver extends IUpdateSelectMonitorObserver {
        void updateFPS();

        void orderRunDone();
    }

    public interface IUpdateUIObserver {
        void updateUI();
    }

    public interface IOutLogin {
        void onOutLogin();
    }

    public interface IDroneDistanceObserver {
        /**
         * key 电子围栏id+无人机id综合key
         *
         * @param key
         * @param value
         * @return
         */
        boolean onAddShow(String key, SpannableStringBuilder value);

        boolean onDeleteShow(String key);

        boolean onUpdate(String key, SpannableStringBuilder value);
    }

    public interface IDroneDistanceDataChangeListener {
        void updateData(List<SpannableStringBuilder> data);
    }

    public interface IVideoUploadDataChangeListener {
        void updateData(String nameKey, VideoInfo data);

        void removeData(String nameKey, VideoInfo data);
    }

    public interface ISearchHistoryDataChangeListener {
        void setHistoryDatas(List<BaseData> historyDatas);

        void setSingleDatas(List<BaseData> historyDatas, BaseRouteHistoryData routeHistoryData);
    }

    public interface ITaskChangedListener {
        void onCancelBattleTarget();

        void onSetBattleTarget(Drone drone);

        void onCancelDestination();

        void onSetDestination(MyLatLng targetLatlng);

        void onCancelAll();
    }

    public interface IPaintMarkerOperationListener {
        void onPaintMarkerClick(MarkerDataModel mkDataModel);
    }

    public interface IMarkerOperationListener {
        void onMarkerClick(MarkerDataModel mkDataModel);

        void onUpdateData(MarkerDataModel mkDataModel);

        void onHideMarker();
    }

    public interface IUpdateSystemConfigListener {
        void onSystemChanged();
    }
}
