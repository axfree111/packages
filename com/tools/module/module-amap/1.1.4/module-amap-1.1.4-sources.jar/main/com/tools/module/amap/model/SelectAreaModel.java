package com.tools.module.amap.model;

import java.io.Serializable;

/**
 * Created by jiajie on 2019-12-23.
 */
public class SelectAreaModel implements Serializable {
    public int id;
    public String key;
}
