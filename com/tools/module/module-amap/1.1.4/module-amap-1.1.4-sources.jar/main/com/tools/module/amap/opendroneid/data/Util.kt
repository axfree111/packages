package com.tools.module.amap.opendroneid.data

import androidx.lifecycle.Observer

object Util {
    /** OTHER - SET  */
    private fun <E> difference(set: Set<E>, other: Set<E>): Set<E> {
        val diff = HashSet<E>()
        for (e in set) {
            if (!other.contains(e)) {
                diff.add(e)
            }
        }
        return diff
    }

    class SetDifference<T> internal constructor(newSet: Set<T>, oldSet: Set<T>) {
        val added: Set<T> =
            difference(newSet, oldSet)
        val removed: Set<T> =
            difference(oldSet, newSet)
    }

    /**
     * set - other, what is not in other
     */
    class DiffObserver<T> : Observer<Set<T>> {
        var last: Set<T> = emptySet()

        override fun onChanged(newSet: Set<T>) {
            val difference = SetDifference(newSet, last)

            if (!difference.added.isEmpty()) {
                onAdded(difference.added)
            }
            if (!difference.removed.isEmpty()) {
                onRemoved(difference.removed)
            }
            last = newSet
        }

        fun onAdded(added: Collection<T>?) {}
        fun onRemoved(removed: Collection<T>?) {}
    }
}
