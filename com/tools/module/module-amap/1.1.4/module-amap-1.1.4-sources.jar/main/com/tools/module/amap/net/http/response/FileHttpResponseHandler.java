package com.tools.module.amap.net.http.response;

import android.text.TextUtils;

import com.tools.module.amap.net.http.request.RequestParams;
import com.tools.module.common.utils.ByteArrayPool;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import okhttp3.ResponseBody;


/**
 * 文件下载响应回调
 *
 * @author changjiajie
 */
public abstract class FileHttpResponseHandler extends HttpResponseHandler<File> {

    @Override
    protected File parseResponse(int statusCode, ResponseBody body) throws IOException {
        if (isCancelled()) {
            this.sendCancelMessage("request is cancelled");
            return null;
        }
        if (requestWrapper != null) {
            String downloadFilePath = null;
            RequestParams requestParams = requestWrapper.getRequestParams();
            if (requestParams != null) {
                downloadFilePath = requestParams.getDownloadFilePath();
            }
            if (!TextUtils.isEmpty(downloadFilePath)) {
                FileOutputStream fileOs = null;
                InputStream input = null;
                File downloadFile = null;
                byte[] buff = null;
                try {
                    downloadFile = new File(downloadFilePath);
                    downloadFile.createNewFile();
                    fileOs = new FileOutputStream(downloadFilePath);
                    long totalLength = body.contentLength();
                    input = body.byteStream();
                    if (totalLength == 0) {
                        totalLength = 1;
                    }
                    int readLen = 0;
                    int count = 0;
                    buff = ByteArrayPool.sDefaultPool.getBuf(1024);
                    //未全部读取
                    while ((readLen = input.read(buff, 0, 1024)) > 0) {
                        if (isCancelled()) {
                            this.sendCancelMessage("request is cancelled");
                            downloadFile = null;
                            break;
                        }
                        fileOs.write(buff, 0, readLen);
                        count += readLen;
                        this.sendProgressMessage((int) (((float) count * 100) / totalLength), count);
                    }
                    return downloadFile;
                } catch (IOException e) {
                    throw e;
                } finally {
                    ByteArrayPool.sDefaultPool.returnBuf(buff);
                    body.close();
                    if (fileOs != null) {
                        try {
                            fileOs.flush();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        try {
                            fileOs.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }
        return null;
    }

    @Override
    public String getResponseType() {
        return "file";
    }

    @Override
    public long getResponseLength(File content) {
        if (content == null) {
            return 0;
        } else {
            return content.length();
        }
    }
}
