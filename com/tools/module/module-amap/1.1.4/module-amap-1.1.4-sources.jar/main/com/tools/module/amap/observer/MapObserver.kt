package com.tools.module.amap.observer

import com.drone.monitor.bean.custom.MyLatLng
import com.tools.module.common.utils.HandlerUtils
import com.tools.module.amap.map.MapController

/**
 * Created by jiajie on 2019-07-21.
 */
object MapObserver {
    private val mIMapObservers: MutableList<IMapStatusListener> = mutableListOf()
    private val mIMapClickObservers: MutableList<IMapOnClickListener> = ArrayList()
    private val mIMapLongClickObservers: MutableList<IMapOnLongClickListener> = ArrayList()
    private val mZoomButtonClickObservers: MutableList<IZoomButtonClickListener> = ArrayList()
    private val mFenceRadiusChangedObservers: MutableList<IFenceRadiusChangedListener> = ArrayList()
    private val mScreenShortChangedObservers: MutableList<IScreenShotChangedListener> = ArrayList()
    private val mLatitudeLongitudeObservers: MutableList<ILatitudeLongitudeListener> = ArrayList()

    @JvmStatic
    fun notifyArriveDestination(latLng: MyLatLng, isFirst: Boolean) {
        for (observer in mLatitudeLongitudeObservers) {
            observer.onArriveDestination(latLng, isFirst)
        }
    }

    @JvmStatic
    fun notifyPushArriveDestination(
        taskId: Long,
        monitorId: String?,
        latitude: Double,
        longitude: Double,
        complete: (Boolean) -> Unit
    ) {
        for (observer in mLatitudeLongitudeObservers) {
            observer.onPushArriveDestination(taskId, monitorId, latitude, longitude, complete)
        }
    }

    @JvmStatic
    @Synchronized
    fun registerLatitudeLongitudeObserver(observer: ILatitudeLongitudeListener?) {
        if (observer != null && !mLatitudeLongitudeObservers.contains(observer)) {
            mLatitudeLongitudeObservers.add(observer)
        }
    }

    @JvmStatic
    @Synchronized
    fun unRegisterLatitudeLongitudeObserver(observer: ILatitudeLongitudeListener?) {
        if (observer != null) {
            mLatitudeLongitudeObservers.remove(observer)
        }
    }

    @JvmStatic
    fun onScreenCapture(filePath: String?) {
        for (observer in mScreenShortChangedObservers) {
            observer.screenCapture(filePath)
        }
    }

    @JvmStatic
    @Synchronized
    fun registerScreenShotObserver(observer: IScreenShotChangedListener?) {
        if (observer != null && !mScreenShortChangedObservers.contains(observer)) {
            mScreenShortChangedObservers.add(observer)
        }
    }

    @JvmStatic
    @Synchronized
    fun unRegisterScreenShotObserver(observer: IScreenShotChangedListener?) {
        if (observer != null) {
            mScreenShortChangedObservers.remove(observer)
        }
    }

    @JvmStatic
    fun onMapLoaded() {
        for (observer in mIMapObservers) {
            observer.onMapLoaded()
        }
    }

    @JvmStatic
    fun onMapStatusChanged(currentZoomLevel: Float) {
        HandlerUtils.getThreadHanlder().removeCallbacks(mapStatusChangedRunnable)
        HandlerUtils.getThreadHanlder().postDelayed(mapStatusChangedRunnable, 200)
    }

    private val mapStatusChangedRunnable = Runnable {
        for (observer in mIMapObservers) {
            observer.onMapStatusChanged(MapController.CURRENT_ZOOM_LEVEL)
        }
    }

    @JvmStatic
    @Synchronized
    fun registerMapObserver(observer: IMapStatusListener?) {
        if (observer != null && !mIMapObservers.contains(observer)) {
            mIMapObservers.add(observer)
        }
    }

    @JvmStatic
    @Synchronized
    fun unRegisterMapObserver(observer: IMapStatusListener?) {
        if (observer != null) {
            mIMapObservers.remove(observer)
        }
    }

    @JvmStatic
    fun onLongClickMap(latitude: Double, longitude: Double) {
        for (observer in mIMapLongClickObservers) {
            observer.onLongClickMap(latitude, longitude)
        }
    }

    @JvmStatic
    @Synchronized
    fun registerMapLongClickObserver(observer: IMapOnLongClickListener?) {
        if (observer != null && !mIMapLongClickObservers.contains(observer)) {
            mIMapLongClickObservers.add(observer)
        }
    }

    @JvmStatic
    @Synchronized
    fun unRegisterMapLongClickObserver(observer: IMapOnLongClickListener?) {
        if (observer != null) {
            mIMapLongClickObservers.remove(observer)
        }
    }

    @JvmStatic
    fun onClickMap(latitude: Double, longitude: Double) {
        for (observer in mIMapClickObservers) {
            observer.onClickMap(latitude, longitude)
        }
    }

    @JvmStatic
    @Synchronized
    fun registerMapClickObserver(observer: IMapOnClickListener?) {
        if (observer != null && !mIMapClickObservers.contains(observer)) {
            mIMapClickObservers.add(observer)
        }
    }

    @JvmStatic
    @Synchronized
    fun unRegisterMapClickObserver(observer: IMapOnClickListener?) {
        if (observer != null) {
            mIMapClickObservers.remove(observer)
        }
    }

    @JvmStatic
    fun onZoomIn() {
        for (observer in mZoomButtonClickObservers) {
            observer.onZoomIn()
        }
    }

    @JvmStatic
    fun onZoomOut() {
        for (observer in mZoomButtonClickObservers) {
            observer.onZoomOut()
        }
    }

    @JvmStatic
    @Synchronized
    fun registerZoomClickObserver(observer: IZoomButtonClickListener?) {
        if (observer != null && !mZoomButtonClickObservers.contains(observer)) {
            mZoomButtonClickObservers.add(observer)
        }
    }

    @JvmStatic
    @Synchronized
    fun unRegisterZoomClickObserver(observer: IZoomButtonClickListener?) {
        if (observer != null) {
            mZoomButtonClickObservers.remove(observer)
        }
    }

    @JvmStatic
    fun onFenceRadiusChanged(content: String?) {
        for (observer in mFenceRadiusChangedObservers) {
            observer.onFenceRadiusChanged(content)
        }
    }
    
    @JvmStatic
    @Synchronized
    fun registerFenceRadiusChangedObserver(observer: IFenceRadiusChangedListener?) {
        if (observer != null && !mFenceRadiusChangedObservers.contains(observer)) {
            mFenceRadiusChangedObservers.add(observer)
        }
    }

    @JvmStatic
    @Synchronized
    fun unRegisterFenceRadiusChangedObserver(observer: IFenceRadiusChangedListener?) {
        if (observer != null) {
            mFenceRadiusChangedObservers.remove(observer)
        }
    }

    interface IMapStatusListener {
        fun onMapLoaded()

        fun onMapStatusChanged(currentZoomLevel: Float)
    }

    interface IMapOnClickListener {
        fun onClickMap(latitude: Double, longitude: Double)
    }

    interface IMapOnLongClickListener {
        fun onLongClickMap(latitude: Double, longitude: Double)
    }

    interface IZoomButtonClickListener {
        fun onZoomIn()

        fun onZoomOut()
    }

    interface IFenceRadiusChangedListener {
        fun onFenceRadiusChanged(content: String?)
    }

    interface IScreenShotChangedListener {
        fun screenCapture(filePath: String?)
    }

    // 主要在MapController中监听实现地图分发请求
    interface ILatitudeLongitudeListener {
        fun onArriveDestination(latLng: MyLatLng, isFirst: Boolean)
        fun onPushArriveDestination(taskId: Long,
                                    monitorId: String?,
                                    latitude: Double,
                                    longitude: Double,
                                    complete: (Boolean) -> Unit)
    }
}
