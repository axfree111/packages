package com.tools.module.amap.contract;

import android.graphics.Bitmap;

/**
 * Date: 2025/4/3
 * Desc:
 * <p>
 * author: jaje
 */
public interface IGetBitmapCallback {
    void onMapScreenShot(Bitmap bitmap, int status);
}
