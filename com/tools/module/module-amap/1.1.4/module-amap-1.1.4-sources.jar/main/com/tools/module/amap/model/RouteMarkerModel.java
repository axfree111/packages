package com.tools.module.amap.model;

import com.drone.monitor.bean.custom.MyLatLng;

/**
 * Created by jiajie on 2020-03-27.
 */
public class RouteMarkerModel {

    public int type = RouteMarkerType.NOTE;
    // marker朝向角
    public float angle;
    // 表示是否属于断开的箭头表示
    public boolean isDisconnect = false;
    // 表示朝向那个方向
    public boolean isLeft = true;
    // 表示当前显示的位置
    public MyLatLng showLatLng;
    public RoutePointModel pointModel;

    public interface RouteMarkerType {
        int NOTE = 0;
        int JIANTOU = 1;
        int INFO = 2;
    }
}
