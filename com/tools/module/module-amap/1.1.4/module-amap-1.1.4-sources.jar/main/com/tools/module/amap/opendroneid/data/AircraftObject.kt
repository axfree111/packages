package com.tools.module.amap.opendroneid.data

import com.tools.module.amap.map.MapController
import com.tools.module.amap.opendroneid.OpenDroneIdConstants
import com.tools.module.amap.opendroneid.utils.BizDataConverter
import com.tools.module.common.utils.CsfMutableLiveData

class AircraftObject(val macAddress: Long) {

    val connection: CsfMutableLiveData<ConnectionBiz> = CsfMutableLiveData() { it ->

    }
    val noneBaseBizData: CsfMutableLiveData<BasicIdBiz> = CsfMutableLiveData()
    val serialNumberBaseBizData: CsfMutableLiveData<BasicIdBiz> = CsfMutableLiveData()
    val caaRegistrationIdBaseBizData: CsfMutableLiveData<BasicIdBiz> = CsfMutableLiveData()
    val utmAssignedIdBaseBizData: CsfMutableLiveData<BasicIdBiz> = CsfMutableLiveData()
    val specificSessionIdBaseBizData: CsfMutableLiveData<BasicIdBiz> = CsfMutableLiveData()
    val location: CsfMutableLiveData<LocationBizData> = CsfMutableLiveData() { it ->
        BizDataConverter.aircraftToDroneData(this)?.apply {
            MapController.run { receiveScanDroneData(this@apply) }
        }
    }
    val authentication: CsfMutableLiveData<AuthenticationBizData> = CsfMutableLiveData()
    val description: CsfMutableLiveData<DescriptionBizData> = CsfMutableLiveData()
    val system: CsfMutableLiveData<SystemBizData> = CsfMutableLiveData() { it ->
        BizDataConverter.aircraftToMonitorData(this)?.apply {
            MapController.run { receiveMonitorUpdate(this@apply) }
        }
    }
    val operatorid: CsfMutableLiveData<OperatorIdBizData> = CsfMutableLiveData()

    fun getConnectionValue(): ConnectionBiz? {
        return connection.value
    }

    fun getSerialNumberBaseBizDataValue(): BasicIdBiz? {
        return serialNumberBaseBizData.value
    }

    fun getLocationValue(): LocationBizData? {
        return location.value
    }

    fun getAuthenticationValue(): AuthenticationBizData? {
        return authentication.value
    }

    val descriptionDataValue: DescriptionBizData?
        get() = description.value

    fun getSystemValue(): SystemBizData? {
        return system.value
    }

    val operatorIDValue: OperatorIdBizData?
        get() = operatorid.value

    // Non-zero authentication data pages do not contain the following fields. Save them for displaying
    private var authLastPageIndexSave = 0
    private var authLengthSave = 0
    private var authTimestampSave: Long = 0

    // Multiple authentication messages are possible, each transmitting a part of the
    // authentication signature. Collect the data into authDataCombined.
    private val authDataCombined = ByteArray(OpenDroneIdConstants.MAX_AUTH_DATA)

    fun combineAuthentication(newData: AuthenticationBizData): AuthenticationBizData {
        var currData = authentication.value
        if (currData == null) currData = AuthenticationBizData()

        currData.msgCounter = newData.msgCounter
        currData.timestamp = newData.timestamp
        currData.msgVersion = newData.msgVersion

        var offset = 0
        var amount = OpenDroneIdConstants.MAX_AUTH_PAGE_ZERO_SIZE
        if (newData.getAuthDataPage() == 0) {
            authLastPageIndexSave = newData.getAuthLastPageIndex()
            authLengthSave = newData.getAuthLength()
            authTimestampSave = newData.authTimestamp
        } else {
            offset =
                OpenDroneIdConstants.MAX_AUTH_PAGE_ZERO_SIZE + (newData.getAuthDataPage() - 1) * OpenDroneIdConstants.MAX_AUTH_PAGE_NON_ZERO_SIZE
            amount = OpenDroneIdConstants.MAX_AUTH_PAGE_NON_ZERO_SIZE
        }
        for (i in offset until offset + amount) authDataCombined[i] = newData.authData[i]

        currData.authType = newData.authType
        currData.setAuthLastPageIndex(authLastPageIndexSave)
        currData.setAuthLength(authLengthSave)
        currData.authTimestamp = authTimestampSave
        currData.authData = authDataCombined
        return currData
    }

    private var idToShow = 0

    // 当接收到两条不同的基本ID报文时，本函数用于强制在列表视图中对其飞行器识别码(uasId)进行周期性轮换。
    // 本函数设计为每秒调用一次，但实际更换逻辑会降低频率至每三秒执行一次。
    fun updateShadowBasicId() {
        // TODO 后期看需求可以修改
//        when (idToShow) {
//            0 -> {
//                deviceIdShadow.value = serialNumberBaseBizData.getValue()
//                idToShow++
//            }
//
//            3 -> {
//                val id2 = caaRegistrationIdBaseBizData.value
//                if (id2 != null && id2.idType != BaseBizData.IdTypeEnum.None) {
//                    caaUsaShadow.value = caaRegistrationIdBaseBizData.getValue()
//                }
//                idToShow++
//            }
//
//            6 -> idToShow = 0
//            else -> idToShow++
//        }
    }

    override fun toString(): String {
        return "AircraftObject{" +
                "macAddress=" + macAddress +
                ", identification1=" + serialNumberBaseBizData +
                ", identification2=" + caaRegistrationIdBaseBizData +
                '}'
    }
}
