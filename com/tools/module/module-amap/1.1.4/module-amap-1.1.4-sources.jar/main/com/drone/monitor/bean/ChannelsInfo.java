package com.drone.monitor.bean;

import android.text.TextUtils;

import com.drone.monitor.bean.custom.MyObject;
import com.google.gson.reflect.TypeToken;
import com.tools.module.common.utils.GsonUtils;

import java.util.Date;

public class ChannelsInfo extends MyObject {

    private int id;
    private Date gmtCreate;
    private Date gmtModified;
    private String name;
    private String info;
    private String webConfig;
    public boolean isSelected = false;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getWebConfigStr() {
        return webConfig;
    }

    public WebConfigInfo getWebConfig() {
        if (TextUtils.isEmpty(webConfig)) {
            return null;
        }
        WebConfigInfo webConfigInfo = GsonUtils.getGson().fromJson(webConfig, new TypeToken<WebConfigInfo>() {
        }.getType());
        return webConfigInfo;
    }

    public void setWebConfig(String webConfig) {
        this.webConfig = webConfig;
    }

    public void copy(ChannelsInfo data) {
        setId(getId());
        setGmtCreate(getGmtCreate());
        setGmtModified(getGmtModified());
        setName(getName());
        setInfo(getInfo());
        setWebConfig(getWebConfigStr());
    }

    @Override
    public String toString() {
        return "LoginInfo{" +
                "id='" + id + '\'' +
                ", gmtCreate=" + gmtCreate +
                ", gmtModified=" + gmtModified +
                ", name='" + name + '\'' +
                ", info='" + info + '\'' +
                ", webConfig='" + webConfig + '\'' +
                "} " + super.toString();
    }
}
