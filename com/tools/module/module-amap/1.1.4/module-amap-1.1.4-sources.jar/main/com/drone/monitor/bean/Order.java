package com.drone.monitor.bean;

import com.drone.monitor.bean.custom.MyArrayList;
import com.drone.monitor.bean.custom.MyObject;

import java.util.Date;
import java.util.List;

import io.protostuff.Tag;

public class Order extends MyObject {

    @Tag(1)
    private String id;

    @Tag(2)
    private String monitorId;
    /**
     * 频段
     */
    @Tag(3)
    private List<FrequencyRangeInfo> frequencyRange = new MyArrayList<>();

    @Tag(4)
    private String direct;

    @Tag(5)
    private String directAngle;

    /**
     * 执行计划
     * 0 - 立即执行
     * 1 - 延迟执行
     * 2 - 停止
     */
    @Tag(6)
    private int runType;

    /**
     * 延迟时间
     */
    @Tag(7)
    private int delay;

    @Tag(8)
    private int workRadius;

    @Tag(9)
    private Date createTime;

    @Tag(10)
    private Date runTime;

    /**
     * 0 - 等待执行
     * 1 - 正在执行
     * 2 - 执行成功
     * 4 - 执行失败
     */
    @Tag(11)
    private int status;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMonitorId() {
        return monitorId;
    }

    public void setMonitorId(String monitorId) {
        this.monitorId = monitorId;
    }

    public List<FrequencyRangeInfo> getFrequencyRange() {
        return frequencyRange;
    }

    public void setFrequencyRange(List<FrequencyRangeInfo> frequencyRange) {
        this.frequencyRange = frequencyRange;
    }

    public String getDirect() {
        return direct;
    }

    public void setDirect(String direct) {
        this.direct = direct;
    }

    public String getDirectAngle() {
        return directAngle;
    }

    public void setDirectAngle(String directAngle) {
        this.directAngle = directAngle;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getRunTime() {
        return runTime;
    }

    public void setRunTime(Date runTime) {
        this.runTime = runTime;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getRunType() {
        return runType;
    }

    public void setRunType(int runType) {
        this.runType = runType;
    }

    public int getDelay() {
        return delay;
    }

    public void setDelay(int delay) {
        this.delay = delay;
    }

    public int getWorkRadius() {
        return workRadius;
    }

    public void setWorkRadius(int workRadius) {
        this.workRadius = workRadius;
    }

    @Override
    public String toStringConcise() {
        return "Order{" +
                "id='" + id + '\'' +
                ", monitorId='" + monitorId + '\'' +
                ", runType=" + runType +
                ", delay=" + delay +
                ", status=" + status +
                ", frequencyRange=" +
                (frequencyRange == null ? frequencyRange :
                        (frequencyRange instanceof MyArrayList ? ((MyArrayList) frequencyRange).toStringConcise() :
                                frequencyRange.toString())) +
                ", createTime=" + createTime +
                ", runTime=" + runTime +
                '}';
    }

    @Override
    public String toString() {
        return "Order{" +
                "id='" + id + '\'' +
                ", monitorId='" + monitorId + '\'' +
                ", runType=" + runType +
                ", delay=" + delay +
                ", runTime=" + runTime +
                ", status=" + status +
                ", frequencyRange=" + frequencyRange +
                ", direct='" + direct + '\'' +
                ", directAngle='" + directAngle + '\'' +
                ", workRadius=" + workRadius +
                ", createTime=" + createTime +
                '}';
    }
}
