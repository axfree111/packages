package com.tools.module.amap.map.amap;

import com.amap.api.location.CoordinateConverter;
import com.amap.api.location.DPoint;
import com.amap.api.maps.model.LatLng;
import com.drone.monitor.bean.custom.MyLatLng;
import com.tools.module.common.ContextStore;
import com.tools.module.common.utils.XAppLogger;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2019/4/20 0020.
 */

public class AMapPositionsUtils {

    public static DPoint converterWGS84LatLng(LatLng sourceLatLng) {
        DPoint dPoint = new DPoint();
        dPoint.setLatitude(sourceLatLng.latitude);
        dPoint.setLongitude(sourceLatLng.longitude);
        CoordinateConverter converter = null;
        try {
            converter = new CoordinateConverter(ContextStore.getContext())
                    .from(CoordinateConverter.CoordType.GPS)
                    .coord(dPoint);
            //转换坐标
            return converter.convert();
        } catch (Exception e) {
            XAppLogger.getInstance().writeError(e);
        }
        return dPoint;
    }

    public static LatLng transformAMapPosition(MyLatLng sources) {
        return new LatLng(sources.latitude, sources.longitude);
    }

    public static List<LatLng> transformAMapPosition(List<MyLatLng> sources) {
        List<LatLng> data = new ArrayList<>();
        for (MyLatLng latLng : sources) {
            data.add(new LatLng(latLng.latitude, latLng.longitude));
        }
        return data;
    }

    public static MyLatLng transforAMapToMyLatlngPosition(LatLng sources) {
        return new MyLatLng(sources.latitude, sources.longitude);
    }

    public static List<MyLatLng> transforAMapToMyLatlngPosition(List<LatLng> sources) {
        List<MyLatLng> data = new ArrayList<>();
        for (LatLng latLng : sources) {
            data.add(new MyLatLng(latLng.latitude, latLng.longitude));
        }
        return data;
    }

    public static List<MyLatLng> transforLatLonPointToMyLatlngPosition(List<com.amap.api.services.core.LatLonPoint> sources) {
        if (sources == null) {
            return null;
        }
        List<MyLatLng> data = new ArrayList<>();
        for (com.amap.api.services.core.LatLonPoint latLng : sources) {
            data.add(new MyLatLng(latLng.getLatitude(), latLng.getLongitude()));
        }
        return data;
    }


}
