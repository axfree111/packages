package com.tools.module.amap.model

import com.drone.monitor.bean.BaseRouteHistoryData
import com.drone.monitor.bean.PlaneDetailData
import kotlin.math.abs

/**
 * Date: 2025/4/1
 * Desc:
 *
 * author: jaje
 */
object ModelUtils {

    fun transToRouteHistoryData(planeDetailData: PlaneDetailData?): BaseRouteHistoryData? {
        if (planeDetailData == null || planeDetailData.line == null || planeDetailData.line.size <= 0) {
            return null
        }
        val routeHistoryData = BaseRouteHistoryData()
        val points = mutableListOf<RoutePointModel?>()
        var preLine: PlaneDetailData.Line? = null
        for (i in planeDetailData.line.indices) {
            val line = planeDetailData.line[i]
            if (line != null && line.position != null) {
                if (preLine == null || abs((line.angle - preLine.angle).toDouble()) > 5) {
                    val point = RoutePointModel()
                    point.copy(line)
                    points.add(point)
                    preLine = line
                }
            }
        }
        routeHistoryData.points = points
        return routeHistoryData
    }
}