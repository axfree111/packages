package com.tools.module.amap.model.amap;

import com.amap.api.maps.AMap;
import com.drone.monitor.bean.custom.MyLatLng;
import com.tools.module.common.utils.HandlerUtils;
import com.tools.module.common.base.AppConfig;
import com.tools.module.amap.manager.ColorManager;
import com.tools.module.amap.manager.ParametersManager;
import com.tools.module.amap.map.amap.AMapBitmapManager;
import com.tools.module.amap.map.amap.AMapPositionsUtils;
import com.tools.module.amap.map.amap.MaMapUtils;
import com.tools.module.amap.map.contract.IGetRoutePlanPointsCallback;
import com.amap.api.maps.model.ArcOptions;
import com.amap.api.maps.model.BaseOverlay;
import com.amap.api.maps.model.BitmapDescriptor;
import com.amap.api.maps.model.Circle;
import com.amap.api.maps.model.CircleOptions;
import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.Marker;
import com.amap.api.maps.model.Polygon;
import com.amap.api.maps.model.PolygonOptions;
import com.amap.api.maps.model.Polyline;
import com.amap.api.maps.model.PolylineOptions;
import com.amap.api.maps.model.Text;
import com.amap.api.maps.model.TextOptions;
import com.drone.monitor.bean.Drone;

import com.drone.monitor.bean.MonitorDevice;
import com.tools.module.amap.manager.ThreadPoolHelper;
import com.tools.module.amap.map.LocalMapConfig;
import com.tools.module.amap.map.MapController;
import com.tools.module.amap.model.DroneConfig;
import com.tools.module.amap.model.MonitorConfig;
import com.tools.module.amap.model.base.BaseMonitorModel;
import com.tools.module.amap.utils.ComputeUtils;
import com.tools.module.common.utils.HandlerUtils;
import com.tools.module.common.utils.XAppLogger;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public abstract class AMapBaseMonitorModel extends BaseMonitorModel {

    /**
     * 存放画到地图上的OverLay
     */
    private volatile Polygon coverAttackPolygon;
    private volatile Polyline coverScanPolygonLine;
    private volatile Polygon coverScanPolygon;
    private volatile Polygon coverWarningPolygon;
    private volatile Polygon coverDisternPolygon;

    // 攻击线
    private volatile Polyline battleTargePolygonline;
    // 目标地址路线
    private volatile Polyline routePolygonline;
    private volatile List<MyLatLng> routePlanPoints = new ArrayList<>();

    protected Marker markerDevice;
    private Vector<BaseOverlay> overlayLines = new Vector<>();
    private Polyline overlayBrokenlines;
    private Vector<Text> overlayRadiusTvs = new Vector<>();
    private Vector<Polyline> coverAttackLines = new Vector<>();
    private Text overlayWarningRadiusTvs;
    private Text overlayNameTv;

    public AMapBaseMonitorModel(MonitorDevice monitor) {
        super(monitor);
    }

    /**
     * @return
     */
    protected LatLng getLatLng() {
        return new LatLng(getData().getLatitude(), getData().getLongitude());
    }

    protected abstract AMap getMap();

    protected abstract float getCurrentZoomLevel();

    @Override
    public void setVisible(boolean visible) {
        if (markerDevice != null) {
            markerDevice.setVisible(visible);
        }
    }

    @Override
    protected void updateAttackTargetLine(String targetDroneId, MyLatLng latLng) {
        List<LatLng> lineSacnLatLngs = new ArrayList<>();
        lineSacnLatLngs.add(getLatLng());
        lineSacnLatLngs.add(AMapPositionsUtils.transformAMapPosition(latLng));
        if (battleTargePolygonline == null) {
            PolylineOptions ooPolyline = MaMapUtils.getPolylineOptions(lineSacnLatLngs,
                    ColorManager.getAttackTargetLineColor(), LocalMapConfig.BATTLE_TARGET_WIDTH, false);
            battleTargePolygonline = getMap().addPolyline(ooPolyline);
        } else {
            battleTargePolygonline.setPoints(lineSacnLatLngs);
        }
    }

    @Override
    protected void removeAttackTargetLine() {
        if (battleTargePolygonline != null) {
            battleTargePolygonline.remove();
            battleTargePolygonline = null;
        }
    }

    @Override
    protected void updateDestinationRouteLine(MyLatLng latLng) {
        if (latLng == null) {
            removeDestinationRouteLine();
            return;
        }
        boolean isCalculateRoute = true;
        if (routePlanPoints.size() > 0) {
            MyLatLng lastPoint = routePlanPoints.get(routePlanPoints.size() - 1);
            // 和之前设置的目的地相差不到20米时不进行重新计算
            if (lastPoint != null &&
                    ComputeUtils.calculateDistance(lastPoint.longitude, lastPoint.latitude, latLng.longitude, latLng.latitude) <= 20) {
                isCalculateRoute = false;
            }
        }
        if (isCalculateRoute) {
            MaMapUtils.getInstance().searchRoutePlanAsyn(getObjType(), getMyLatLng(), latLng, new IGetRoutePlanPointsCallback() {
                @Override
                public void onSuccess(List<MyLatLng> latLngs) {
                    XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "绘制目的地路线 设备id:"
                            + getData().getAlias() + " | 设备经纬度：" + latLng.toString());
                    routePlanPoints = latLngs;
                    List<LatLng> routePlanPoints = AMapPositionsUtils.transformAMapPosition(latLngs);
                    if (routePolygonline == null) {
                        PolylineOptions ooPolyline = MaMapUtils.getPolylineOptions(routePlanPoints,
                                ColorManager.getMonitorRouteLineColor(), LocalMapConfig.ROUTE_WIDTH, false);
                        routePolygonline = getMap().addPolyline(ooPolyline);
                    } else {
                        routePolygonline.setPoints(routePlanPoints);
                    }
                }

                @Override
                public void onFailed() {
                    removeDestinationRouteLine();
                }
            });
        }
    }

    @Override
    protected void removeDestinationRouteLine() {
        if (routePolygonline != null) {
            routePolygonline.remove();
            routePolygonline = null;
        }
    }

    // ------------------ 动画相关 -------------------------------
    private ThreadPoolHelper.MyThread attackRunnable = new ThreadPoolHelper.MyThread(getData().getMonitorId() + "_attackRunnable") {
        @Override
        public void run() {
            if (MapController.INSTANCE.isMainPage()) {
                if (!MapController.INSTANCE.isStop()) {
                    if (!isErase && LocalMapConfig.SHOW_ANIMATION && (getCurrentMonitorStatus() == MonitorDevice.DEVICE_STATUS.FIND_DRONE
                            || (getCurrentMonitorStatus() == MonitorDevice.DEVICE_STATUS.SELECTED
                            && (getPrevMonitorWorkStatus() == MonitorDevice.DEVICE_STATUS.FIND_DRONE)))) {
                        try {
                            if (currentAttackIndex >= coverAttackLines.size()) {
                                currentAttackIndex = 0;
                                HandlerUtils.getUIHandler().post(new Runnable() {
                                    @Override
                                    public void run() {
                                        if (coverAttackLines.size() > 0) {
                                            for (Polyline polyline : coverAttackLines) {
                                                polyline.setVisible(false);
                                            }
                                        }
                                    }
                                });
                            } else {
                                HandlerUtils.getUIHandler().post(new Runnable() {
                                    @Override
                                    public void run() {
                                        if (coverAttackLines.size() > 0) {
                                            Polyline polyline = coverAttackLines.get(currentAttackIndex % coverAttackLines.size());
                                            polyline.setVisible(true);
                                        }
                                    }
                                });
                                currentAttackIndex++;
                            }
                            HandlerUtils.getTwinkleHanlder().removeCallbacks(this);
                            HandlerUtils.getTwinkleHanlder().postDelayed(this, 150);
                        } catch (Exception e) {
                            XAppLogger.getInstance().writeError(e);
                        }
                    }
                } else {
                    HandlerUtils.getTwinkleHanlder().removeCallbacks(this);
                    HandlerUtils.getTwinkleHanlder().postDelayed(this, DroneConfig.ANIMATION_DELAY_TIME);
                }
            }
        }
    };

    private ThreadPoolHelper.MyThread scanRunnable = new ThreadPoolHelper.MyThread(getData().getAlias() + "_scanRunnable") {
        @Override
        public void run() {
            if (MapController.INSTANCE.isMainPage()) {
                if (!isErase && LocalMapConfig.SHOW_ANIMATION && !MapController.INSTANCE.isStop()) {
                    try {
                        int scanSize = positionsScanPolygons.size();
                        currentScanIndex--;
                        if (currentScanIndex > 0) {
                            currentScanIndex = (currentScanIndex - 1) % scanSize;
                        } else {
                            currentScanIndex = scanSize - 1;
                        }
                        List<LatLng> polygonPositions = AMapPositionsUtils.transformAMapPosition(positionsScanPolygons.get(currentScanIndex));
                        if (coverScanPolygon != null) {
                            coverScanPolygon.setPoints(polygonPositions);
                        }
                        if (coverScanPolygonLine != null) {
                            List<LatLng> lineSacnLatLngs = new ArrayList<>();
                            lineSacnLatLngs.add(polygonPositions.get(0));
                            lineSacnLatLngs.add(polygonPositions.get(2));
                            coverScanPolygonLine.setPoints(lineSacnLatLngs);
                        }
                        HandlerUtils.getUIHandler().removeCallbacks(this);
                        HandlerUtils.getUIHandler().postDelayed(this, 100);
                    } catch (Exception e) {
                        XAppLogger.getInstance().writeError(e);
                    }
                } else {
                    HandlerUtils.getUIHandler().removeCallbacks(this);
                    HandlerUtils.getUIHandler().postDelayed(this, DroneConfig.ANIMATION_DELAY_TIME);
                }
            }
        }
    };

    @Override
    protected synchronized void startScanAnimation() {
        if (needShowScanLine()) {
            if (AppConfig.SHOW_SCAN) {
                HandlerUtils.getUIHandler().removeCallbacks(scanRunnable);
                HandlerUtils.getUIHandler().post(scanRunnable);
            }
        }
    }

    private boolean isShowAttackColor = false;
    private ThreadPoolHelper.MyThread twinkleAttackRunnable = new ThreadPoolHelper.MyThread(getData().getAlias() + "_twinkleAttackRunnable") {
        @Override
        public void run() {
            if (MapController.INSTANCE.isMainPage()) {
                if (AppConfig.SHOW_TWINKLE) {
                    if (!isErase && (getCurrentMonitorStatus() == MonitorDevice.DEVICE_STATUS.FIND_DRONE ||
                            getCurrentMonitorStatus() == MonitorDevice.DEVICE_STATUS.FIND_AVIATION ||
                            getCurrentMonitorStatus() == MonitorDevice.DEVICE_STATUS.EXCEPTION)
                            && !MapController.INSTANCE.isStop()) {
                        try {
                            if (isShowAttackColor) {
                                if (coverAttackPolygon != null) {
                                    isShowAttackColor = false;
                                    coverAttackPolygon.setVisible(false);
                                }
                            } else {
                                if (coverAttackPolygon != null) {
                                    isShowAttackColor = true;
                                    coverAttackPolygon.setVisible(true);
                                }
                            }
                            HandlerUtils.getTwinkleHanlder().removeCallbacks(this);
                            HandlerUtils.getTwinkleHanlder().postDelayed(this, isShowAttackColor ? 300 : 200);
                            return;
                        } catch (Exception e) {
                            XAppLogger.getInstance().writeError(e);
                        }
                    } else {
                        HandlerUtils.getTwinkleHanlder().removeCallbacks(this);
                        HandlerUtils.getTwinkleHanlder().postDelayed(this, MonitorConfig.ANIMATION_TWINKLE_DELAY_TIME);
                        return;
                    }
                }
                HandlerUtils.getTwinkleHanlder().removeCallbacks(this);
                HandlerUtils.getTwinkleHanlder().postDelayed(this, DroneConfig.ANIMATION_DELAY_TIME);
            }
        }
    };
    private boolean isShowWarningColor = false;
    private ThreadPoolHelper.MyThread twinkleWarningRunnable = new ThreadPoolHelper.MyThread(getData().getAlias() + "_twinkleWarningRunnable") {
        @Override
        public void run() {
            if (MapController.INSTANCE.isMainPage()) {
                if (AppConfig.SHOW_TWINKLE) {
                    if (!isErase && (getCurrentWarningStatus() == MonitorDevice.DEVICE_STATUS.FIND_DRONE ||
                            getCurrentWarningStatus() == MonitorDevice.DEVICE_STATUS.FIND_AVIATION)
                            && !MapController.INSTANCE.isStop()) {
                        try {
                            if (isShowWarningColor) {
                                if (coverWarningPolygon != null) {
                                    isShowWarningColor = false;
                                    coverWarningPolygon.setVisible(false);
                                }
                            } else {
                                if (coverWarningPolygon != null) {
                                    isShowWarningColor = true;
                                    coverWarningPolygon.setVisible(true);
                                }
                            }
                            HandlerUtils.getTwinkleHanlder().removeCallbacks(this);
                            HandlerUtils.getTwinkleHanlder().postDelayed(this, isShowWarningColor ? 300 : 200);
                            return;
                        } catch (Exception e) {
                            XAppLogger.getInstance().writeError(e);
                        }
                    } else {
                        HandlerUtils.getTwinkleHanlder().removeCallbacks(this);
                        HandlerUtils.getTwinkleHanlder().postDelayed(this, MonitorConfig.ANIMATION_TWINKLE_DELAY_TIME);
                        return;
                    }
                }
                HandlerUtils.getTwinkleHanlder().removeCallbacks(this);
                HandlerUtils.getTwinkleHanlder().postDelayed(this, DroneConfig.ANIMATION_DELAY_TIME);
            }
        }
    };
    private boolean isShowDisternColor = false;
    private ThreadPoolHelper.MyThread twinkleDisternRunnable = new ThreadPoolHelper.MyThread(getData().getAlias() + "_twinkleDisternRunnable") {
        @Override
        public void run() {
            if (MapController.INSTANCE.isMainPage()) {
                if (AppConfig.SHOW_TWINKLE) {
                    if (!isErase && (getCurrentDisternAreaStatus() == MonitorDevice.DEVICE_STATUS.FIND_DRONE ||
                            getCurrentDisternAreaStatus() == MonitorDevice.DEVICE_STATUS.FIND_AVIATION)
                            && !MapController.INSTANCE.isStop()) {
                        try {
                            if (isShowDisternColor) {
                                if (coverDisternPolygon != null) {
                                    isShowDisternColor = false;
                                    coverDisternPolygon.setVisible(false);
                                }
                            } else {
                                if (coverDisternPolygon != null) {
                                    isShowDisternColor = true;
                                    coverDisternPolygon.setVisible(true);
                                }
                            }
                            HandlerUtils.getTwinkleHanlder().removeCallbacks(this);
                            HandlerUtils.getTwinkleHanlder().postDelayed(this, isShowDisternColor ? 300 : 200);
                            return;
                        } catch (Exception e) {
                            XAppLogger.getInstance().writeError(e);
                        }
                    } else {
                        HandlerUtils.getTwinkleHanlder().removeCallbacks(this);
                        HandlerUtils.getTwinkleHanlder().postDelayed(this, MonitorConfig.ANIMATION_TWINKLE_DELAY_TIME);
                        return;
                    }
                }
                HandlerUtils.getTwinkleHanlder().removeCallbacks(this);
                HandlerUtils.getTwinkleHanlder().postDelayed(this, DroneConfig.ANIMATION_DELAY_TIME);
            }
        }
    };

    @Override
    protected synchronized void startTwinkle() {
        startTwinkleAttack();
        startTwinkleWarning();
        startTwinkleDistern();
    }

    private synchronized void startTwinkleAttack() {
        if (needShowAttackTwinkle()) {
            HandlerUtils.getTwinkleHanlder().removeCallbacks(twinkleAttackRunnable);
            HandlerUtils.getTwinkleHanlder().post(twinkleAttackRunnable);
        }
    }

    private synchronized void startTwinkleWarning() {
        if (needShowWarningTwinkle()) {
            HandlerUtils.getTwinkleHanlder().removeCallbacks(twinkleWarningRunnable);
            HandlerUtils.getTwinkleHanlder().post(twinkleWarningRunnable);
        }
    }

    private synchronized void startTwinkleDistern() {
        if (needShowDisternTwinkle()) {
            HandlerUtils.getTwinkleHanlder().removeCallbacks(twinkleDisternRunnable);
            HandlerUtils.getTwinkleHanlder().post(twinkleDisternRunnable);
        }
    }
    // ------------------ 动画相关 -------------------------------

    // ----------------------  绘图相关 -------------------------------
    @Override
    public void onMapStatusChange(float currentZoomLevel) {
        synchronized (monitorLock) {
            super.onMapStatusChange(currentZoomLevel);
            if (getData() == null) {
                return;
            }
            if (LocalMapConfig.SHOW_ANIMATION) {
                startAnimation();
            } else {
                stopAnimation();
            }

            if (markerDevice != null) {
                BitmapDescriptor markerIcon = AMapBitmapManager.getInstance().getDescriptorBitmap(getData().getType(),
                        getCurrentMonitorStatus(), getCurrentZoomLevel(), isSelected());
                if (markerIcon != null) {
                    markerDevice.setIcon(markerIcon);
                    //                if (isAngleChanged) {
//                    //计算设备的朝向中间角度
//                    float centerAngle = getData().getCenterAngle();
//                    markerDevice.setRotate(-centerAngle);
//                    XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "更新设备角度 设备id:"
//                            + getData().getMonitorId() + " | 角度:" + centerAngle);
//                }
                }
            }
            if (AppConfig.SHOW_RADIUS_TV) {
                // 半径文字还在只需要缩放大小
                if (overlayRadiusTvs.size() > 0) {
                    for (int i = 0; i < overlayRadiusTvs.size(); i++) {
                        Text text = (Text) overlayRadiusTvs.get(i);
                        if (text != null) {
                            text.setFontSize(ParametersManager.getIntervalTvScale(currentZoomLevel));
                        }
                    }
                } else {
                    // 半径文字被移除需要重新添加
                    updateRadiusTvs();
                }
            } else {
                removeRadiusTvs();
            }

            if (needShowRadiusTvs()) {
                if (needShowMonitorIdTv()) {
                    if (overlayNameTv != null) {
                        overlayNameTv.setFontSize(ParametersManager.getNameTvScale(currentZoomLevel));
                        if (positionsAttackArcLine.size() <= 0) {
                            overlayNameTv.setPosition(AMapPositionsUtils.transformAMapPosition(ComputeUtils.getNameTvPosition(getData().getLongitude(), getData().getLatitude(), currentZoomLevel)));
                        }
                    } else {
                        // 设备名称文字被移除需要重新添加
                        updateNameTvs();
                    }
                } else {
                    removeNameTv();
                }
            }
        }
    }

    /**
     * 更新扫描覆盖区
     */
    @Override
    protected synchronized void updateScanCover(boolean isStatusChanged, boolean isWorkRadiusChanged) {
        if (needShowScanLine()) {
            // 显示扫描线
            int scanSize = positionsScanPolygons.size();

            if (scanSize > 0) {
                if (isWorkRadiusChanged) {
                    removeScanCover();
                }

                if (coverScanPolygon == null || coverScanPolygonLine == null) {

                    removeScanCover();

                    currentScanIndex = 0;
                    List<LatLng> latLngs = AMapPositionsUtils.transformAMapPosition(positionsScanPolygons.get(currentScanIndex));

                    PolygonOptions ooPolygon = MaMapUtils.getCoverPolygonOptions(latLngs, ColorManager.getScanCoverColor(getCurrentMonitorStatus()));
                    coverScanPolygon = getMap().addPolygon(ooPolygon);

                    List<LatLng> lineSacnLatLngs = new ArrayList<>();
                    lineSacnLatLngs.add(latLngs.get(0));
                    lineSacnLatLngs.add(latLngs.get(2));
                    PolylineOptions ooPolyline = MaMapUtils.getScanPolylineOptions(lineSacnLatLngs, ColorManager.getScanLineColor(getCurrentMonitorStatus()));
                    coverScanPolygonLine = getMap().addPolyline(ooPolyline);

                    currentScanIndex = scanSize - 1;

                    XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "添加发射区扫描浮层 设备id:"
                            + getData().getAlias() + " | 类型:" + getData().getType() + " | 状态:" + getCurrentMonitorStatus());
                } else {

                    if (coverScanPolygon != null) {
                        coverScanPolygon.setFillColor(ColorManager.getScanCoverColor(getCurrentMonitorStatus()));
                    }
                    if (coverScanPolygonLine != null) {
                        coverScanPolygonLine.setColor(ColorManager.getScanLineColor(getCurrentMonitorStatus()));
                    }
                    XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "更新发射区扫描浮层 设备id:"
                            + getData().getAlias() + " | 类型:" + getData().getType() + " | 状态:" + getCurrentMonitorStatus());
                }
            }
        }
    }

    /**
     * 十秒倒计时结束时主动更新覆盖区
     */
    @Override
    protected void onUpdateAttackCover() {
        if (coverAttackPolygon != null) {
            int color = ColorManager.getDeviceAttackAreasColor(isShowAwaitCover, getCurrentMonitorStatus());
            coverAttackPolygon.setFillColor(color);
        }
    }

    /**
     * 更新发射区cover
     *
     * @param isAngleChanged
     * @param isPositionChanged
     */
    @Override
    protected synchronized void updateAttackCover(boolean isStatusChanged, boolean isAngleChanged, boolean isPositionChanged, boolean isWorkRadiusChanged) {

        if (needShowAttackCover()) {
            // 创建攻击区域多边形的覆盖层
            if (pointsAttackPolygon.size() > 0) {
                int color = ColorManager.getDeviceAttackAreasColor(isShowAwaitCover, getCurrentMonitorStatus());

                int radius = getData().workRadius;

                if (coverAttackPolygon == null) {

                    removeAttackCover();

                    PolygonOptions ooPolygon = MaMapUtils.getCoverPolygonOptions(AMapPositionsUtils.transformAMapPosition(pointsAttackPolygon), color);
                    coverAttackPolygon = getMap().addPolygon(ooPolygon);

                    updateScanCover();
                    XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "添加发射区浮层 设备id:"
                            + getData().getAlias() + " | 类型:" + getData().getType() + " | 状态:" + getCurrentMonitorStatus());
                } else {

                    if (isStatusChanged) {
                        updateScanCover(isStatusChanged, isWorkRadiusChanged);
                        coverAttackPolygon.setFillColor(color);
                    }

                    if (isAngleChanged || isPositionChanged || isWorkRadiusChanged) {
                        coverAttackPolygon.setPoints(AMapPositionsUtils.transformAMapPosition(pointsAttackPolygon));
                    }
                    coverAttackPolygon.setVisible(true);
                    XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "更新发射区浮层 设备id:"
                            + getData().getAlias() + " | 类型:" + getData().getType() + " | 状态:" + getCurrentMonitorStatus() + " | isStatusChanged:" + isStatusChanged);
                }
            }
        }
    }

    @Override
    protected synchronized void updateInvadeDrone(Drone drone) {
        super.updateInvadeDrone(drone);
        HandlerUtils.getUIHandler().post(new Runnable() {
            @Override
            public void run() {
                Vector<Vector<MyLatLng>> attackLines = attackLinePositions.get(drone.getItemId());
                if (attackLines != null) {
                    if (coverAttackLines.size() <= 0) {
                        for (Vector<MyLatLng> lineLatLng : attackLines) {
                            if (lineLatLng != null && lineLatLng.size() >= 2) {
                                PolylineOptions polylineOptions = MaMapUtils.getPolylineOptions(
                                         AMapPositionsUtils.transformAMapPosition(lineLatLng), ColorManager.getAttackLineColor(), false);
                                Polyline polyline = getMap().addPolyline(polylineOptions);
                                polyline.setVisible(false);
                                coverAttackLines.add(polyline);
                            }
                        }
                    } else {
                        for (int n = 0; n < attackLines.size(); n++) {
                            Vector<MyLatLng> lineLatLng = attackLines.get(n);
                            if (lineLatLng != null && lineLatLng.size() >= 2) {
                                coverAttackLines.get(n).setPoints(AMapPositionsUtils.transformAMapPosition(lineLatLng));
                            }
                        }
                    }
                    HandlerUtils.getTwinkleHanlder().removeCallbacks(attackRunnable);
                    HandlerUtils.getTwinkleHanlder().post(attackRunnable);
                }
            }
        });
    }

    /**
     * 更新预警区cover
     *
     * @param isAngleChanged
     * @param isPositionChanged
     */
    @Override
    protected void updateWarningCover(boolean isStatusChanged, boolean isAngleChanged, boolean isPositionChanged, boolean isWorkRadiusChanged) {

        if (needShowWarningArea()) {
            // 创建预警区域多边形的覆盖层
            if (positionsWarningPolygon.size() > 0) {

                int color = ColorManager.getDeviceWarningAreasColor(getCurrentWarningStatus());

                if (coverWarningPolygon == null) {

                    PolygonOptions ooPolygon = MaMapUtils.getCoverPolygonOptions(AMapPositionsUtils.transformAMapPosition(positionsWarningPolygon), color);

                    coverWarningPolygon = getMap().addPolygon(ooPolygon);
                    coverWarningPolygon.setVisible(LocalMapConfig.SHOW_AREA_WARNING);

                    XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "添加预警区浮层 设备id:"
                            + getData().getAlias() + " | 类型:" + getData().getType() + " | 状态:" + getCurrentWarningStatus());
                } else {

                    if (isStatusChanged) {
                        coverWarningPolygon.setFillColor(color);
                    }
                    if (isAngleChanged || isPositionChanged || isWorkRadiusChanged) {
                        coverWarningPolygon.setPoints(AMapPositionsUtils.transformAMapPosition(positionsWarningPolygon));
                    }
                    coverWarningPolygon.setVisible(LocalMapConfig.SHOW_AREA_WARNING);

                    XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "更新预警区浮层 设备id:"
                            + getData().getAlias() + " | 类型:" + getData().getType() + " | 状态:" + getCurrentWarningStatus());
                }
            }
        }
    }

    /**
     * 更新识别区cover
     *
     * @param isStatusChanged
     * @param isAngleChanged
     * @param isPositionChanged
     */
    @Override
    protected void updateDiscernCover(boolean isStatusChanged, boolean isAngleChanged, boolean isPositionChanged, boolean isWorkRadiusChanged) {
        if (needShowDisternArea()) {
            // 创建预警区域多边形的覆盖层
            if (positionsDisternPolygon.size() > 0) {

                int color = ColorManager.getDeviceDiscernAreasColor(getCurrentDisternAreaStatus());

                if (coverDisternPolygon == null) {

                    PolygonOptions ooPolygon = MaMapUtils.getCoverPolygonOptions(AMapPositionsUtils.transformAMapPosition(positionsDisternPolygon), color);

                    coverDisternPolygon = getMap().addPolygon(ooPolygon);
                    coverDisternPolygon.setVisible(LocalMapConfig.SHOW_AREA_DISTERN);
                    XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "添加识别区浮层 设备id:"
                            + getData().getAlias() + " | 类型:" + getData().getType() + " | 状态:" + getCurrentDisternAreaStatus());
                } else {

                    if (isStatusChanged) {
                        coverDisternPolygon.setFillColor(color);
                    }
                    if (isPositionChanged || isAngleChanged || isWorkRadiusChanged) {
                        coverDisternPolygon.setPoints(AMapPositionsUtils.transformAMapPosition(positionsDisternPolygon));
                    }
                    coverDisternPolygon.setVisible(LocalMapConfig.SHOW_AREA_DISTERN);

                    XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "更新识别区浮层 设备id:"
                            + getData().getAlias() + " | 类型:" + getData().getType() + " | 状态:" + getCurrentDisternAreaStatus());
                }
            }
        }
    }

    /**
     * 添加所有的线
     *
     * @param isAngleChanged
     * @param isPositionChanged
     * @param isWorkRadiusChanged
     */
    @Override
    protected synchronized void updateLines(boolean isAngleChanged, boolean isPositionChanged, boolean isWorkRadiusChanged) {
        if (needShowLine()) {
            int allArcLineSize = positionsAttackArcLine.size();
            // 判断已有对象是否和当前匹配,比如圆和弧线的区别
            boolean needRedraw = false;
            if (overlayLines.size() > 0) {
                if (isCircle()) {
                    if (!(overlayLines.get(0) instanceof Circle)) {
                        needRedraw = true;
                    }
                } else {
                    if (!(overlayLines.get(0) instanceof Polyline)) {
                        needRedraw = true;
                    }
                }
            }
            // 半径更新或没有绘制过或和绘制点集合数量不匹配
            if (needRedraw || isWorkRadiusChanged || overlayLines.size() <= 0 || overlayLines.size() != allArcLineSize) {

                removeLines();

                if (allArcLineSize > 0) {
                    for (int index = 0; index < allArcLineSize; index++) {

                        int radius = (index + 1) * LocalMapConfig.INTERVAL;
                        List<LatLng> points = AMapPositionsUtils.transformAMapPosition(positionsAttackArcLine.get(index));

                        if (isCircle()) {

                            CircleOptions circleLineOptions = MaMapUtils.getCircleLineOptions(getLatLng(), radius, ColorManager.getLineColor());
                            // 添加弧线对象
                            overlayLines.add(getMap().addCircle(circleLineOptions));
                        } else {
                            if (points.size() >= 3) {

                                ArcOptions arcLineOptions = MaMapUtils.getArcLineOptions(points, ColorManager.getLineColor());
                                // 添加弧线对象
                                overlayLines.add(getMap().addArc(arcLineOptions));
                            }
                        }
                    }

                    // 创建折线对象
                    if (!isCircle() && positionsBrokenLine.size() > 0) {
                        PolylineOptions brokenLineOverlayOptions = MaMapUtils.getBrokenPolylineOptions(
                                AMapPositionsUtils.transformAMapPosition(positionsBrokenLine), ColorManager.getLineColor());
                        overlayBrokenlines = getMap().addPolyline(brokenLineOverlayOptions);
                    }

                    XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "添加 线 设备名称:" + getData().getAlias() + " | 类型:" + getData().getType() + " | 状态:" + getCurrentMonitorStatus());
                }
            } else {
                if (isAngleChanged || isPositionChanged) {
                    for (int i = 0; i < overlayLines.size(); i++) {
                        if (isCircle()) {
                            Circle circle = (Circle) overlayLines.get(i);
                            if (circle != null) {
                                circle.setCenter(getLatLng());
                            }
                        } else {
                            Polyline line = (Polyline) overlayLines.get(i);
                            List<LatLng> latLngs = AMapPositionsUtils.transformAMapPosition(positionsAttackArcLine.get(i));
                            if (line != null && latLngs != null) {
                                line.setPoints(latLngs);
                            }
                        }
                    }
                    if (overlayBrokenlines != null) {
                        overlayBrokenlines.setPoints(AMapPositionsUtils.transformAMapPosition(positionsBrokenLine));
                    }
                    XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "更新 线 设备名称:" + getData().getAlias() + " | 类型:" + getData().getType() + " | 状态:" + getCurrentMonitorStatus());
                }
            }
        }
    }

    /**
     * 更新文字
     *
     * @param isAngleChanged
     * @param isPositionChanged
     * @param isWorkRadiusChanged
     */
    @Override
    protected synchronized void updateRadiusTvs(boolean isAngleChanged, boolean isPositionChanged, boolean isWorkRadiusChanged) {
        if (needShowRadiusTvs()) {

            int allArcLineSize = positionsAttackArcLine.size();
            if (isWorkRadiusChanged || overlayRadiusTvs.size() <= 0 || overlayRadiusTvs.size() != allArcLineSize) {

                removeRadiusTvs();

                int centerAngle = getData().getCenterAngle();
                int centerPointsIndex = 1;
                if (isCircle()) {
                    centerPointsIndex = 0;
                }

                // 添加弧线上半径文字
                for (int index = 1; index < allArcLineSize; index += 2) {

                    int radius = (index + 1) * LocalMapConfig.INTERVAL;
                    List<LatLng> points = AMapPositionsUtils.transformAMapPosition(positionsAttackArcLine.get(index));

                    if (AppConfig.SHOW_MONITOR_ID) {

                        if (index != (allArcLineSize - 1)) {

                            TextOptions radiusTextOptions = MaMapUtils.getIntervalTextOptions(String.valueOf(radius),
                                    points.get(centerPointsIndex), centerAngle);

                            overlayRadiusTvs.add(getMap().addText(radiusTextOptions));
                        }
                    } else {

                        TextOptions radiusTextOptions = MaMapUtils.getIntervalTextOptions(String.valueOf(radius),
                                points.get(centerPointsIndex), centerAngle);

                        overlayRadiusTvs.add(getMap().addText(radiusTextOptions));
                    }
                }

                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "添加半径文字  设备名称:" + getData().getAlias() + " | 类型:" + getData().getType() + " | 状态:" + getCurrentMonitorStatus());
                if (AppConfig.SHOW_WARNING_RADIUS_TV) {
                    // 添加警告弧线上文字
                    if (positionsWarningArcLine.size() > 0) {
                        int tvPositionIndex = 1;
                        if (isCircle()) {
                            tvPositionIndex = 0;
                        }
                        LatLng tvPosition = AMapPositionsUtils.transformAMapPosition(positionsWarningArcLine.get(tvPositionIndex));
                        if (tvPosition != null) {
                            TextOptions warningRadiusTextOptions =
                                    MaMapUtils.getIntervalTextOptions(String.valueOf(getData().warningRadius), tvPosition, centerAngle);
                            overlayWarningRadiusTvs = getMap().addText(warningRadiusTextOptions);
                            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "添加警告半径文字 设备名称:" + getData().getAlias() + " | 类型:" + getData().getType() + " | 状态:" + getCurrentMonitorStatus());
                        }
                    }
                }
            } else {
                if (isAngleChanged || isPositionChanged) {

                    int centerAngle = getData().getCenterAngle();
                    int centerPointsIndex = 1;
                    if (isCircle()) {
                        centerPointsIndex = 0;
                    }

                    for (int i = 0; i < overlayRadiusTvs.size(); i++) {
                        Text text = (Text) overlayRadiusTvs.get(i);
                        List<LatLng> latLngs = AMapPositionsUtils.transformAMapPosition(positionsAttackArcLine.get(i));
                        if (text != null && latLngs != null) {
                            text.setPosition(latLngs.get(centerPointsIndex));
                            text.setRotate(-centerAngle);
                        }
                    }
                    if (overlayWarningRadiusTvs != null) {
                        int tvPositionIndex = 1;
                        if (isCircle()) {
                            tvPositionIndex = 0;
                        }
                        LatLng tvPosition = AMapPositionsUtils.transformAMapPosition(positionsWarningArcLine.get(tvPositionIndex));
                        if (tvPosition != null) {
                            overlayWarningRadiusTvs.setPosition(tvPosition);
                        }
                    }
                    XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "更新半径文字 设备名称:" + getData().getAlias() + " | 类型:" + getData().getType() + " | 状态:" + getCurrentMonitorStatus());
                }
            }
        }
    }

    /**
     * 更新设备名称文字
     *
     * @param isAngleChanged
     * @param isPositionChanged
     * @param isWorkRadiusChanged
     */
    @Override
    protected synchronized void updateNameTvs(boolean isAngleChanged, boolean isPositionChanged, boolean isWorkRadiusChanged) {
        if (needShowMonitorIdTv()) {
            int allArcLineSize = positionsAttackArcLine.size();
            List<LatLng> points = AMapPositionsUtils.transformAMapPosition(positionsAttackArcLine.get(allArcLineSize - 1));
            int centerAngle = getData().getCenterAngle();
            int centerPointsIndex = 1;
            if (isCircle()) {
                centerPointsIndex = 0;
            }

            if (allArcLineSize > 0) {

                // 添加设备名称文字
                if (overlayNameTv == null) {

                    if (points != null) {

                        overlayNameTv = getMap().addText(MaMapUtils.getNameTextOptions(getData().getMonitorId(),
                                points.get(centerPointsIndex), centerAngle));
                        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "渲染 设备名称 设备名称:" + getData().getAlias() + " | 类型:" + getData().getType() + " | 状态:" + getCurrentMonitorStatus());
                    }
                } else {
                    if (isAngleChanged || isPositionChanged || isWorkRadiusChanged) {
                        if (points != null) {
                            overlayNameTv.setPosition(AMapPositionsUtils.transformAMapPosition(
                                    ComputeUtils.getNameTvPosition(getData().getLongitude(), getData().getLatitude(), getCurrentZoomLevel())));
                            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "更新 设备名称 设备名称:" + getData().getAlias() + " | 类型:" + getData().getType() + " | 状态:" + getCurrentMonitorStatus());
                        }
                    }
                }
            } else {
                // 添加设备名称文字
                if (overlayNameTv == null) {

                    if (points != null) {

                        TextOptions monitorNameTextOptions = MaMapUtils.getNameTextOptions(getData().getMonitorId(),
                                 AMapPositionsUtils.transformAMapPosition(ComputeUtils.getNameTvPosition(getData().getLongitude(), getData().getLatitude(), getCurrentZoomLevel())),
                                centerAngle);
                        overlayNameTv = getMap().addText(monitorNameTextOptions);
                        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "渲染 设备名称 设备名称:" + getData().getAlias() + " | 类型:" + getData().getType() + " | 状态:" + getCurrentMonitorStatus());
                    }
                } else {
                    if (isAngleChanged || isPositionChanged || isWorkRadiusChanged) {
                        if (points != null) {
                            overlayNameTv.setPosition(AMapPositionsUtils.transformAMapPosition(ComputeUtils.getNameTvPosition(getData().getLongitude(), getData().getLatitude(), getCurrentZoomLevel())));
                            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "更新 设备名称 设备名称:" + getData().getAlias() + " | 类型:" + getData().getType() + " | 状态:" + getCurrentMonitorStatus());
                        }
                    }
                }
            }
        }
    }
    // ----------------------  绘图相关 -------------------------------

    // -----------------  移除恢复绘图相关 -------------------------------

    /**
     * 将设备从地图上擦除
     */
    public void erase() {
        synchronized (monitorLock) {
            super.erase();
            twinkleAttackRunnable = null;
            twinkleWarningRunnable = null;
            twinkleDisternRunnable = null;
            scanRunnable = null;
            allPositions.clear();
        }
    }

    /**
     * 移除发射区cover
     */
    @Override
    public synchronized void removeScanCover() {

        if (needShowScanLine()) {
            if (coverScanPolygon != null) {
                coverScanPolygon.remove();
                coverScanPolygon = null;
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "移除扫描线后的浮层 设备id:"
                        + getData().getAlias() + " | 类型:" + getData().getType() + " | 状态:" + getCurrentMonitorStatus());
            }
            if (coverScanPolygonLine != null) {
                coverScanPolygonLine.remove();
                coverScanPolygonLine = null;
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "移除扫描线 设备id:"
                        + getData().getAlias() + " | 类型:" + getData().getType() + " | 状态:" + getCurrentMonitorStatus());
            }
        }
    }

    /**
     * 移除发射区cover
     */
    @Override
    public synchronized void removeAttackCover() {
        if (needShowAttackCover()) {
            if (coverAttackPolygon != null) {
                coverAttackPolygon.remove();
                coverAttackPolygon = null;
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "移除发射区浮层 设备id:"
                        + getData().getAlias() + " | 类型:" + getData().getType() + " | 状态:" + getCurrentMonitorStatus());
            }
            removeScanCover();
            findDroneTypeInAttack = FIND_DRONE_TYPE_DEFAULT;
        }
    }

    @Override
    protected void removeAttackLine() {
        super.removeAttackLine();
        HandlerUtils.getUIHandler().removeCallbacks(attackRunnable);
        if (coverAttackLines != null && coverAttackLines.size() > 0) {
            for (Polyline polyline : coverAttackLines) {
                polyline.remove();
            }
            coverAttackLines.clear();
        }
    }

    /**
     * 移除预警区cover
     */
    @Override
    public synchronized void removeWarningCover() {
        if (coverWarningPolygon != null) {

            coverWarningPolygon.remove();
            coverWarningPolygon = null;
            findDroneTypeInWarning = FIND_DRONE_TYPE_DEFAULT;

            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "移除预警区浮层 设备id:"
                    + getData().getAlias() + " | 类型:" + getData().getType() + " | 状态:" + getCurrentWarningStatus());
        }
    }

    /**
     * 移除识别区cover
     */
    @Override
    public synchronized void removeDisternCover() {
        if (coverDisternPolygon != null) {

            coverDisternPolygon.remove();
            coverDisternPolygon = null;
            findDroneTypeInDistern = FIND_DRONE_TYPE_DEFAULT;

            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "移除识别区浮层 设备id:"
                    + getData().getAlias() + " | 类型:" + getData().getType() + " | 状态:" + getCurrentDisternAreaStatus());
        }
    }

    /**
     * 移除所有线
     */
    @Override
    public synchronized void removeLines() {
        if (needShowLine()) {
            if (overlayLines.size() > 0) {
                for (int i = 0; i < overlayLines.size(); i++) {
                    if (isCircle()) {
                        ((Circle) overlayLines.get(i)).remove();
                    } else {
                        ((Polyline) overlayLines.get(i)).remove();
                    }
                }
                overlayLines.clear();
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "移除线 设备名称:" + getData().getAlias() + " | 类型:" + getData().getType() + " | 状态:" + getCurrentMonitorStatus());
            }
            if (overlayBrokenlines != null) {
                overlayBrokenlines.remove();
                overlayBrokenlines = null;
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "移除折线 设备名称:" + getData().getAlias() + " | 类型:" + getData().getType() + " | 状态:" + getCurrentMonitorStatus());
            }
        }
    }

    /**
     * 移除半径文字
     */
    @Override
    public synchronized void removeRadiusTvs() {
        if (needShowRadiusTvs()) {
            if (overlayRadiusTvs.size() > 0) {
                for (int i = 0; i < overlayRadiusTvs.size(); i++) {
                    overlayRadiusTvs.get(i).remove();
                }
                overlayRadiusTvs.clear();
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "移除半径文字 设备名称:" + getData().getAlias() + " | 类型:" + getData().getType() + " | 状态:" + getCurrentMonitorStatus());
            }
        }
    }

    /**
     * 移除设备名称文字
     */
    @Override
    public synchronized void removeNameTv() {
        if (needShowMonitorIdTv()) {
            if (overlayNameTv != null) {
                overlayNameTv.remove();
                overlayNameTv = null;
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "移除设备名称文字 设备名称:" + getData().getAlias() + " | 类型:" + getData().getType() + " | 状态:" + getCurrentMonitorStatus());
            }
        }
    }
    // -----------------  移除恢复绘图相关 -------------------------------
}
