package com.drone.monitor.bean;

import com.drone.monitor.bean.custom.MyObject;

/**
 * Created by jiajie on 2020-03-18.
 */
public class SaveOrUpdate extends MyObject {
    public String phoneNo;
    public String password;

    @Override
    public String toString() {
        return "SaveOrUpdate{" +
                "phoneNo='" + phoneNo + '\'' +
                ", password='" + password + '\'' +
                "} " + super.toString();
    }
}
