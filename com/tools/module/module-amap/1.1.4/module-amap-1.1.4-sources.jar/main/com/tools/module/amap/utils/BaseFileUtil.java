package com.tools.module.amap.utils;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.Image;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;

import com.tools.module.common.ContextStore;
import com.tools.module.common.utils.AppUtil;
import com.tools.module.common.utils.ByteArrayPool;
import com.tools.module.common.utils.HandlerUtils;
import com.tools.module.common.utils.TimeUtil;
import com.tools.module.common.utils.XAppLogger;
import com.tools.module.amap.BaseConstants;
import com.tools.module.amap.manager.UserCenter;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;

/**
 * Created by jiajie on 2017/11/25.
 */

public class BaseFileUtil {

    //针对非系统影音资源文件夹
    public static void insertIntoMediaStore1(boolean isVideo, File saveFile) {
        ContentResolver mContentResolver = ContextStore.getContext().getContentResolver();
        long createTime = System.currentTimeMillis();
        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.TITLE, saveFile.getName());
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, saveFile.getName());
        //值一样，但是还是用常量区分对待
        values.put(isVideo ? MediaStore.Video.VideoColumns.DATE_TAKEN
                : MediaStore.Images.ImageColumns.DATE_TAKEN, createTime);
        values.put(MediaStore.MediaColumns.DATE_MODIFIED, System.currentTimeMillis());
        values.put(MediaStore.MediaColumns.DATE_ADDED, System.currentTimeMillis());
        if (!isVideo) {
            values.put(MediaStore.Images.ImageColumns.ORIENTATION, 0);
        }
        values.put(MediaStore.MediaColumns.DATA, saveFile.getAbsolutePath());
        values.put(MediaStore.MediaColumns.SIZE, saveFile.length());
        values.put(MediaStore.MediaColumns.MIME_TYPE, isVideo ? getVideoMimeType(saveFile.getAbsolutePath()) : "image/jpeg");
        //插入
        mContentResolver.insert(isVideo
                ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                : MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
    }

    public static void insertIntoMediaStore(File file) {
        String path = file.getAbsolutePath();
        Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
        Uri contentUri = Uri.fromFile(file);
        mediaScanIntent.setData(contentUri);
        // 最后通知图库更新
        ContextStore.getContext().sendBroadcast(mediaScanIntent);

        if (Build.VERSION.SDK_INT >= 19) {

            MediaScannerConnection.scanFile(ContextStore.getContext(), new String[]{path}, null, null);
        }
    }

    // 获取video的mine_type,暂时只支持mp4,3gp
    private static String getVideoMimeType(String path) {
        String lowerPath = path.toLowerCase();
        if (lowerPath.endsWith("mp4") || lowerPath.endsWith("mpeg4")) {
            return "video/mp4";
        } else if (lowerPath.endsWith("3gp")) {
            return "video/3gp";
        }
        return "video/mp4";
    }

    public static String getFileSize(String path) {
        File f = new File(path);
        if (!f.exists()) {
            return "0 MB";
        } else {
            long size = f.length();
            return (size / 1024f) / 1024f + "MB";
        }
    }

    public static String getPaintImgName() {
        File file = new File(BaseConstants.PATH_SREEN_PAINT);
        if (!file.exists()) {
            file.mkdirs();
        }
        String number = String.valueOf((int) ((Math.random() * 9 + 1) * 100000));
        return BaseConstants.PATH_SREEN_PAINT + File.separator + ("paint" + "-" + UserCenter.INSTANCE.getPhoneNo() + "-" + TimeUtil.getFileTimeStr() + "-" + number + ".jpg");
    }

    public static String getRecordVideoPath(String phoneNo) {
        File file = new File(BaseConstants.PATH_RECORD_VIDEO);
        if (!file.exists()) {
            file.mkdirs();
        }
        String number = String.valueOf((int) ((Math.random() * 9 + 1) * 100000));
        return BaseConstants.PATH_RECORD_VIDEO + File.separator + (phoneNo + "-" + TimeUtil.getFileTimeStr() + "-" + number + ".mp4");
    }

    public static String getCompressVideoPath(String videoPath) {
        String name = getFileName(videoPath);
        if (TextUtils.isEmpty(name)) {
            return name;
        }
        int lastIndex = name.lastIndexOf(".");
        if (lastIndex < 0) {
            return name;
        }
        return BaseConstants.PATH_VIDEO_CACH + File.separator + name;
    }

    public static String getVideoId(String url) {
        int firstIndex = url.lastIndexOf(File.separator);
        int lastIndex = url.lastIndexOf("?");
        if (lastIndex < 0) {
            lastIndex = url.length();
        }
        return url.substring(firstIndex + 1, lastIndex);
    }

    public static String getOSSVideoCachePath(String url) {
        int firstIndex = url.lastIndexOf(File.separator);
        int lastIndex = url.lastIndexOf("?");
        if (lastIndex < 0) {
            return url;
        }
        return BaseConstants.PATH_VIDEO_CACH + File.separator + url.substring(firstIndex + 1, lastIndex);
    }

    public static String getFileName(String filePath) {
        int lastIndex = filePath.lastIndexOf(File.separator);
        if (lastIndex < 0) {
            return filePath;
        }
        return filePath.substring(lastIndex + 1);
    }

    public static String getFileRootDir(String filePath) {
        int lastIndex = filePath.lastIndexOf(File.separator);
        if (lastIndex < 0) {
            return filePath;
        }
        return filePath.substring(0, lastIndex + 1);
    }

    public static String getVideoCatchPath(String videoId) {
        File file = new File(BaseConstants.PATH_VIDEO_CACH);
        if (!file.exists()) {
            file.mkdirs();
        }
        return BaseConstants.PATH_VIDEO_CACH + File.separator + videoId;
    }

    /**
     * 从assets目录中复制文件内容
     *
     * @param context  Context 使用CopyFiles类的Activity
     * @param fromPath String  原文件路径
     * @param toPath   String  复制后路径
     */
    public static void copyAssets(final Context context, final String fromPath, final String toPath) {
        HandlerUtils.getThreadHanlder().post(new Runnable() {
            @Override
            public void run() {
                try {
                    InputStream is = context.getAssets().open(fromPath);
                    FileOutputStream fos = new FileOutputStream(new File(toPath));
                    byte[] buffer = new byte[1024];
                    int byteCount = 0;
                    while ((byteCount = is.read(buffer)) != -1) {//循环从输入流读取 buffer字节
                        fos.write(buffer, 0, byteCount);//将读取的输入流写入到输出流
                    }
                    fos.flush();//刷新缓冲区
                    is.close();
                    fos.close();
                    XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_OTHER, "开始拷贝sh文件");
                } catch (Exception e) {
                    XAppLogger.getInstance().writeError(e);
                }
            }
        });
    }

    public static String getFilesPath(Context context) {
        if (context == null) {
            return null;
        } else {
            File dir = null;
            File filesDir;
            String filesDirPath;
            if (Environment.getExternalStorageState().equals("mounted")) {
                filesDir = context.getExternalFilesDir((String) null);
                if (filesDir != null) {
                    filesDirPath = filesDir.getAbsolutePath();
                    if (!TextUtils.isEmpty(filesDirPath)) {
                        dir = new File(filesDirPath);
                    }
                }
            }

            if (dir == null) {
                filesDir = context.getFilesDir();
                if (filesDir != null) {
                    filesDirPath = filesDir.getAbsolutePath();
                    if (!TextUtils.isEmpty(filesDirPath)) {
                        dir = new File(filesDirPath);
                    }
                }
            }
            if (dir == null) {
                return null;
            } else {
                if (!dir.exists()) {
                    dir.mkdirs();
                    if (!dir.exists()) {
                        return null;
                    }
                }

                return dir.getAbsolutePath().toString();
            }
        }
    }

    /**
     * 读取json路径
     */
    public static String getCustomStyleFilePath(String customStyleFileName) {
        File customStyleFile = new File(BaseConstants.PATH_CONFIG + File.separator + customStyleFileName);
        if (customStyleFile.exists()) {
            if (customStyleFile.isFile()) {
                return customStyleFile.getAbsolutePath();
            } else {
                customStyleFile.delete();
            }
        }
        FileOutputStream outputStream = null;
        InputStream inputStream = null;
        String filePath = null;
        try {
            inputStream = ContextStore.getContext().getAssets().open("config" + File.separator + customStyleFileName);
            byte[] buffer = new byte[inputStream.available()];
            inputStream.read(buffer);
            File file = new File(BaseConstants.PATH_CONFIG);
            if (!file.exists()) {
                file.mkdirs();
            }
            customStyleFile = new File(file.getAbsolutePath() + "/" + customStyleFileName);
            if (customStyleFile.exists()) {
                customStyleFile.delete();
            }
            customStyleFile.createNewFile();

            filePath = customStyleFile.getAbsolutePath();

            outputStream = new FileOutputStream(customStyleFile);
            outputStream.write(buffer);
        } catch (IOException e) {
            XAppLogger.getInstance().writeError("Copy custom style file failed" + AppUtil.getExceptionString(e));
        } finally {
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
                if (outputStream != null) {
                    outputStream.close();
                }
            } catch (IOException e) {
                XAppLogger.getInstance().writeError("Close stream failed" + AppUtil.getExceptionString(e));
                return null;
            }
        }
        return filePath;
    }

    public static void saveToFile(Bitmap bitmap, File imgFile) {
        saveToFile(bitmap, imgFile, true);
    }

    public static void saveToFile(Bitmap bitmap, File imgFile, boolean isSaveToMedia) {
        FileOutputStream fos = null;
        try {
            if (bitmap != null) {
                fos = new FileOutputStream(imgFile);
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
            }
            if (isSaveToMedia) {
                // 其次把文件插入到系统图库
                BaseFileUtil.insertIntoMediaStore(imgFile);
            }
        } catch (Exception e) {
            XAppLogger.getInstance().writeError(e);
        } finally {
            if (null != fos) {
                try {
                    fos.close();
                } catch (IOException e) {
                    XAppLogger.getInstance().writeError(e);
                }
            }
        }
    }

    public static void saveToFile(Image image, File imgFile) {
        FileOutputStream fos = null;
        Bitmap bitmap = null;
        try {
            if (image != null) {
                int width = image.getWidth();
                int height = image.getHeight();
                final Image.Plane[] planes = image.getPlanes();
                final ByteBuffer buffer = planes[0].getBuffer();
                int pixelStride = planes[0].getPixelStride();
                int rowStride = planes[0].getRowStride();
                int rowPadding = rowStride - pixelStride * width;

                bitmap = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888);
                bitmap.copyPixelsFromBuffer(buffer);
                bitmap = Bitmap.createBitmap(bitmap, 0, 0, width, height);

                fos = new FileOutputStream(imgFile);
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);

                // 其次把文件插入到系统图库
                BaseFileUtil.insertIntoMediaStore(imgFile);
            }
        } catch (Exception e) {
            XAppLogger.getInstance().writeError(e);
        } finally {
            if (null != fos) {
                try {
                    fos.close();
                } catch (IOException e) {
                    XAppLogger.getInstance().writeError(e);
                }
            }
            if (null != bitmap) {
                bitmap.recycle();
            }
        }
    }

    /**
     * 拷贝文件
     *
     * @param fromFilePath
     * @param toFilePath
     * @param deleteExist
     * @return
     */
    public static boolean copyFile(String fromFilePath, String toFilePath, boolean deleteExist) {
        File toFile = new File(toFilePath);
        if (toFile.exists()) {
            if (deleteExist) {
                if (!toFile.delete()) {
                    return false;
                }
            } else {
                return true;
            }
        }

        File parentFolder = toFile.getParentFile();
        if (null != parentFolder && !parentFolder.exists()) {
            parentFolder.mkdirs();
        }

        try {
            File fromFile = new File(fromFilePath);
            if (!fromFile.exists()) {
                Log.e("IMAGE_LOADER",
                        "saveImageCacheTo failed, fromFile don't exist, fromFilePath:"
                                + fromFilePath);
                return false;
            }
            if (!fromFile.canRead()) {
                Log.e("IMAGE_LOADER",
                        "saveImageCacheTo failed, fromFile don't read, fromFilePath:"
                                + fromFilePath);
                return false;
            }

            java.io.FileInputStream fosfrom = new java.io.FileInputStream(fromFilePath);
            FileOutputStream fosto = new FileOutputStream(toFilePath);
            byte buff[] = ByteArrayPool.sDefaultPool.getBuf(1024);
            int c;
            while ((c = fosfrom.read(buff)) > 0) {
                fosto.write(buff, 0, c); // 将内容写到新文件当中
            }
            // 关闭数据流
            fosfrom.close();
            fosto.close();
            ByteArrayPool.sDefaultPool.returnBuf(buff);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
