package com.drone.monitor.bean;

import com.drone.monitor.bean.custom.MyArrayList;
import com.drone.monitor.bean.custom.MyObject;

import java.util.List;

import io.protostuff.Tag;

public class WebSocketBean<T> extends MyObject {

    @Tag(1)
    private int code = 0;

    @Tag(2)
    private String message;

    @Tag(3)
    private boolean list;

    @Tag(4)
    private T obj;

    @Tag(5)
    private List<? extends Object> listObj = new MyArrayList<>();

    @Tag(6)
    private String token;

    /**
     * drone 查询无人机
     * monitor 查询设备
     * order 发送指令
     * heartbeat 心跳指令
     */
    @Tag(7)
    private String operation;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    public T getObj() {
        return obj;
    }

    public void setObj(T obj) {
        this.obj = obj;
    }

    public List<? extends Object> getListObj() {
        return listObj;
    }

    public void setListObj(List<? extends Object> listObj) {
        this.listObj = listObj;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean getList() {
        return list;
    }

    public void setList(boolean list) {
        this.list = list;
    }

    public void buildErr(ERROR error) {
        code = error.getCode();
        message = error.getMsg();
    }

    public boolean isList() {
        return list;
    }

    @Override
    public String toStringConcise() {
        return "WebSocketBean{" +
                "code=" + code +
                ", message='" + message + '\'' +
                ", operation='" + operation + '\'' +
                ", list=" + list +
                ", obj=" +
                (obj == null ? obj :
                        (obj instanceof MyObject ? ((MyObject) obj).toStringConcise() :
                                obj.toString())) +
                ", listObj=" +
                (listObj == null ? listObj :
                        (listObj instanceof MyArrayList ? ((MyArrayList) listObj).toStringConcise() :
                                listObj.toString())) +
                ", token='" + token + '\'' +
                '}';
    }

    @Override
    public String toString() {
        return "WebSocketBean{" +
                "code=" + code +
                ", message='" + message + '\'' +
                ", operation='" + operation + '\'' +
                ", list=" + list +
                ", obj=" + obj +
                ", listObj=" + listObj +
                ", token='" + token + '\'' +
                '}';
    }

    /**
     * drone 查询无人机
     * monitor 查询设备
     * order 发送指令
     * heartbeat 心跳指令
     */
    public interface OPERATION_TYPE {
        String DRONE = "drone";
        String MONITOR = "monitor";
        String ORDER = "order";
        String HEARTBEAT = "heartbeat";
    }
}
