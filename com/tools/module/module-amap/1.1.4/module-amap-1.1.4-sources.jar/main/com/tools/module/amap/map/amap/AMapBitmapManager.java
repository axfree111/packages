package com.tools.module.amap.map.amap;

import android.graphics.Bitmap;
import android.view.View;

import com.tools.module.common.utils.ResourceUtil;
import com.tools.module.common.utils.XAppLogger;
import com.tools.module.amap.map.utils.BaseBitmapManager;
import com.tools.module.amap.map.utils.BitmapManger;
import com.tools.module.amap.manager.ParametersManager;
import com.amap.api.maps.model.BitmapDescriptor;
import com.amap.api.maps.model.BitmapDescriptorFactory;

public class AMapBitmapManager extends BaseBitmapManager<BitmapDescriptor> {

    private static AMapBitmapManager instance;

    private AMapBitmapManager() {
        init();
    }

    public static AMapBitmapManager getInstance() {
        if (instance == null) {
            synchronized (AMapBitmapManager.class) {
                if (instance == null) {
                    instance = new AMapBitmapManager();
                }
            }
        }
        return instance;
    }

    @Override
    public BitmapDescriptor getBitmapDescriptor(int resId, float currentZoomLevel) {
        if (resId > 0) {
            try {
                float scale = ParametersManager.getDroneMarkerScale(currentZoomLevel);
                return BitmapDescriptorFactory.fromBitmap(
                        BitmapManger.scaleBitmap(ResourceUtil.getBitmap(resId), scale));
            } catch (Exception e) {
                XAppLogger.getInstance().writeError(e);
            }
        }
        return null;
    }

    @Override
    public BitmapDescriptor getOriginalBitmapDescriptor(Bitmap bitmap, float currentZoomLevel) {
        if (bitmap != null) {
            try {
                return BitmapDescriptorFactory.fromBitmap(bitmap);
            } catch (Exception e) {
                XAppLogger.getInstance().writeError(e);
            }
        }
        return null;
    }

    @Override
    public BitmapDescriptor getBitmapDescriptor(View view, float currentZoomLevel, boolean isSelected) {
        if (view != null) {
            try {
                float scale = ParametersManager.getDroneMarkerScale(currentZoomLevel);
                if (isSelected) {
                    scale *= 2;
                }
                return BitmapDescriptorFactory.fromBitmap(
                        BitmapManger.scaleBitmap(getBitmapfromView(view), scale));
            } catch (Exception e) {
                XAppLogger.getInstance().writeError(e);
            }
        }
        return null;
    }

    @Override
    protected BitmapDescriptor getDroneBitmapDescriptor(Bitmap bitmap, float currentZoomLevel, boolean isSelected) {
        if (bitmap != null) {
            try {
                float scale = ParametersManager.getDroneMarkerScale(currentZoomLevel);
                if (isSelected) {
                    scale *= 2;
                }
                return BitmapDescriptorFactory.fromBitmap(
                        BitmapManger.scaleBitmap(bitmap, scale));
            } catch (Exception e) {
                XAppLogger.getInstance().writeError(e);
            }
        }
        return null;
    }

    @Override
    protected BitmapDescriptor getMonitorBitmapDescriptor(Bitmap bitmap, float currentZoomLevel, boolean isSelected) {
        if (bitmap != null) {
            try {
                float scale = ParametersManager.getDroneMarkerScale(currentZoomLevel);
                if (isSelected) {
                    scale *= 2;
                }
                return BitmapDescriptorFactory.fromBitmap(
                        BitmapManger.scaleBitmap(bitmap, scale));
            } catch (Exception e) {
                XAppLogger.getInstance().writeError(e);
            }
        }
        return null;
    }

    @Override
    protected BitmapDescriptor getBitmapDescriptor(Bitmap bitmap, float currentZoomLevel) {
        if (bitmap != null) {
            try {
                return BitmapDescriptorFactory.fromBitmap(
                        BitmapManger.scaleBitmap(bitmap,
                                ParametersManager.getMarkerScale(currentZoomLevel)));
            } catch (Exception e) {
                XAppLogger.getInstance().writeError(e);
            }
        }
        return null;
    }

    @Override
    protected BitmapDescriptor getVideoBitmapDescriptor(Bitmap bitmap, float currentZoomLevel, boolean isSelected) {
        if (bitmap != null) {
            try {
                float scale = ParametersManager.getDroneMarkerScale(currentZoomLevel);
                if (isSelected) {
                    scale *= 2;
                }
                return BitmapDescriptorFactory.fromBitmap(
                        BitmapManger.scaleBitmap(bitmap, scale));
            } catch (Exception e) {
                XAppLogger.getInstance().writeError(e);
            }
        }
        return null;
    }
}
