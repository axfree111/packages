package com.tools.module.amap.model.base;

import androidx.annotation.UiThread;

import com.drone.monitor.bean.Drone;
import com.drone.monitor.bean.WarningAreaInfo;
import com.drone.monitor.bean.custom.MyLatLng;
import com.tools.module.amap.R;
import com.tools.module.amap.manager.ColorManager;
import com.tools.module.amap.manager.WarningManager;
import com.tools.module.amap.map.LocalMapConfig;
import com.tools.module.amap.map.MapController;
import com.tools.module.amap.map.utils.PointsUtils;
import com.tools.module.amap.map.utils.SpatialRelationUtil;
import com.tools.module.amap.model.DroneRecordInvadeModel;
import com.tools.module.amap.observer.MapObserver;
import com.tools.module.amap.utils.ComputeUtils;
import com.tools.module.common.utils.ResourceUtil;
import com.tools.module.common.utils.HandlerUtils;
import com.tools.module.common.utils.XAppLogger;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Vector;

/**
 * Created by jiajie on 2020-01-20.
 */
public abstract class BaseDistrictFenceModel extends BaseModel {
    protected boolean isPolyon = false;
    private Vector<MyLatLng> districtFencePoints = new Vector<>();
    private Hashtable<String, BaseDroneModel> aviationInFenceDroneMap = new Hashtable<>();
    private Hashtable<String, BaseMonitorModel> inFenceMonitorMap = new Hashtable<>();

    protected WarningAreaInfo warningAreaInfo;
    protected MyLatLng circlePoint;
    /**
     * 扫描多边型点集合,反方向的集合
     */
    protected Vector<Vector<MyLatLng>> positionsScanPolygons = new Vector<>();
    protected volatile int currentScanIndex = 0;

    protected boolean haveDroneStatus = false;
    private int soundIdDefault = -1;
    private int soundIdDroneWarning = soundIdDefault;
    protected boolean isErase = false;
    protected boolean isCanEdit = true;
    protected boolean isEdit = false;
    protected int fenceCoverColor = ResourceUtil.getColor(R.color.fence_cover_color);
    protected int fenceFinishCoverColor = ResourceUtil.getColor(R.color.transparent);
    protected int scanCoverColor = ColorManager.getDistrictFenceLineColor();
    protected int scanLineColor = ColorManager.getDistrictFenceLineColor();
    protected int fenceLineColor = ColorManager.getDistrictFenceLineColor();
    protected int radiusLineColor = ResourceUtil.getColor(R.color.black);

    public interface MarkerId {
        int CENTER = 0;
        int CIRCLE = 1;
    }

    @Override
    public int getMarkerType() {
        return Drone.MARKER_TYPE.DISTRICT_FENCE;
    }

    @Override
    public int getObjType() {
        return 0;
    }

    public void setCanEdit(boolean isCanEdit) {
        this.isCanEdit = isCanEdit;
    }

    public boolean isCanEdit() {
        return isCanEdit;
    }

    public void setId(String id) {
        if (warningAreaInfo != null) {
            warningAreaInfo.id = id;
        }
    }

    public String getId() {
        if (warningAreaInfo == null) {
            return "";
        }
        return warningAreaInfo.id;
    }

    public WarningAreaInfo getWarningAreaInfo() {
        return warningAreaInfo;
    }

    public boolean isCircle() {
        if (warningAreaInfo == null) {
            return true;
        }
        return warningAreaInfo.type == 0;
    }


    public MyLatLng getCenterLatLng() {
        if (warningAreaInfo == null) {
            return null;
        }
        return warningAreaInfo.getCenterLatLng();
    }

    public MyLatLng getCirclePoint() {
        return circlePoint;
    }

    public void setFenceConfig(int fenceCoverColor, int fenceFinishCoverColor, int fenceLineColor, int scanCoverColor, int scanLineColor) {
        this.fenceCoverColor = fenceCoverColor;
        this.fenceFinishCoverColor = fenceFinishCoverColor;
        this.fenceLineColor = fenceLineColor;
        this.scanCoverColor = scanCoverColor;
        this.scanLineColor = scanLineColor;
    }

    public BaseDistrictFenceModel() {
        isErase = false;
        isEdit = true;
    }

    @UiThread
    public void showFence() {
        updateFenceCover();
        updateScanCover();
        updateFenceLine();
    }

    private void setRadius(double workRadius) {
        warningAreaInfo.radius = workRadius;
        MapObserver.onFenceRadiusChanged(getWorkRadiusStr());
    }

    private void calculateAllPoints() {
        int radius = (int) getWorkRadius();
        if (radius > 0) {
            MyLatLng centerLatLng = getCenterLatLng();
            districtFencePoints = PointsUtils.getArcLinePoints(centerLatLng, 0, 360, radius);
            positionsScanPolygons = PointsUtils.getMonitorScanArrayPoints(centerLatLng, radius);
        }
    }

    public String getWorkRadiusStr() {
        if (getWorkRadius() <= 1000) {
            return ResourceUtil.getContent(R.string.m_distance_label, getWorkRadius());
        } else {
            return ResourceUtil.getContent(R.string.km_distance_label, getWorkRadius() / 1000f);
        }
    }

    public double getWorkRadius() {
        if (warningAreaInfo == null) {
            return 0;
        }
        return warningAreaInfo.radius;
    }

    protected boolean pointsCanIsPolyon() {
        if (isCircle()) {
            if (getWorkRadius() > 0) {
                return true;
            }
        } else {
            if (getFenceLatLngs().size() >= LocalMapConfig.FENCE_MIN_POINTS) {
                return true;
            }
        }
        return false;
    }

    public boolean checkMonitorInFence(BaseMonitorModel monitorModel) {
        if (monitorModel == null || monitorModel.getData() == null) {
            return false;
        }
        if (SpatialRelationUtil.isPolygonContainsPoint(getFenceLatLngs(), monitorModel.getData().getMyLatLng())) {
            if (addMonitor(monitorModel)) {
                return true;
            }
        } else {
            deleteMonitor(monitorModel);
        }
        return false;
    }

    public boolean checkDroneInFence(MyLatLng latLng) {
        if (latLng == null) {
            return false;
        }
        if (SpatialRelationUtil.isPolygonContainsPoint(getFenceLatLngs(), latLng)) {
            return true;
        }
        return false;
    }

    public boolean checkDroneInFence(BaseDroneModel droneModel) {
        if (droneModel == null || droneModel.getData() == null) {
            return false;
        }
        if (SpatialRelationUtil.isPolygonContainsPoint(getFenceLatLngs(), droneModel.getData().getMyLatLng())) {
            if (addDrone(droneModel)) {
                return true;
            }
        } else {
            deleteDrone(droneModel);
        }
        return false;
    }

    private boolean deleteMonitor(BaseMonitorModel monitorModel) {
        if (isContainsDevice(monitorModel)) {
            inFenceMonitorMap.remove(monitorModel.getClassKey());
            return true;
        }
        return false;
    }

    private boolean addMonitor(BaseMonitorModel monitorModel) {
        if (!isContainsDevice(monitorModel)) {
            inFenceMonitorMap.put(monitorModel.getClassKey(), monitorModel);
            return true;
        }
        return false;
    }

    private boolean isContainsDevice(BaseMonitorModel monitorModel) {
        if (monitorModel == null) {
            return false;
        }
        return inFenceMonitorMap.containsKey(monitorModel.getClassKey());
    }

    public boolean deleteDrone(BaseDroneModel droneModel) {
        if (isContainsDrone(droneModel)) {
            droneModel.deleteInvadeResultModel(getClassKey());
            aviationInFenceDroneMap.remove(droneModel.getClassKey());
            locationCheckSound();
            return true;
        }
        return false;
    }

    private boolean addDrone(BaseDroneModel droneModel) {
        if (!isContainsDrone(droneModel)) {
            Drone drone = droneModel.getData();
            // 存储已BaseDroneModel为key的无人机记录
            aviationInFenceDroneMap.put(droneModel.getClassKey(), droneModel);
            DroneRecordInvadeModel recordModel = new DroneRecordInvadeModel();
            recordModel.setId(getClassKey());
            recordModel.setInvadeType(BaseMonitorModel.INVADE_AREA_TYPE.DISTRICT_FENCE_AREA);
            droneModel.checkMonitorResultModel(recordModel);
            // 遍历电子围栏中的设备，用来提示无人机进入了那个设备范围
            for (BaseMonitorModel monitorModel : inFenceMonitorMap.values()) {
                DroneRecordInvadeModel recordMonitorModel = new DroneRecordInvadeModel();
                recordMonitorModel.setId(monitorModel.getData().getMonitorId());
                recordMonitorModel.setDeviceLatlng(drone.getMyLatLng());
                droneModel.checkMonitorResultModel(recordMonitorModel);
            }
            locationCheckSound();
            return true;
        }
        return false;
    }

    private boolean isContainsDrone(BaseDroneModel droneModel) {
        if (droneModel == null) {
            return false;
        }
        return aviationInFenceDroneMap.containsKey(droneModel.getClassKey());
    }

    public void setWarningAreaInfo(WarningAreaInfo areaInfo) {
        if (areaInfo == null) {
            return;
        }
        if (warningAreaInfo == null) {
            warningAreaInfo = areaInfo;
            setRadius(warningAreaInfo.radius);
            this.circlePoint = ComputeUtils.eOffsetBearing(warningAreaInfo.getCenterLatLng(), warningAreaInfo.radius, 90);
            calculateAllPoints();
            updateMarkers();
            updateFenceCover();
            updateFenceLine();
        }
    }

    public boolean updateWarningAreaInfo(WarningAreaInfo areaInfo) {
        if (areaInfo == null) {
            return false;
        }
        if (warningAreaInfo == null) {
            warningAreaInfo = areaInfo;
            this.circlePoint = ComputeUtils.eOffsetBearing(warningAreaInfo.getCenterLatLng(), warningAreaInfo.radius, 90);
            updateUI();
            return true;
        }
        if (warningAreaInfo.radius != areaInfo.radius
                || warningAreaInfo.latitude != areaInfo.latitude
                || warningAreaInfo.longitude != areaInfo.longitude) {
            warningAreaInfo.copy(areaInfo);
            setRadius(warningAreaInfo.radius);
            updateUI();
            return true;
        } else {
            warningAreaInfo.copy(areaInfo);
        }
        return false;
    }

    public void updateUI() {
        // 更细cover
        HandlerUtils.getUIHandler().postDelayed(new Runnable() {
            @Override
            public void run() {
                calculateAllPoints();
                onEditFinish();
            }
        }, 100);
    }

    public void updateMarkerLatLng(int markerType, MyLatLng latLng) {
        if (markerType == MarkerId.CENTER) {
            warningAreaInfo.setCenterLatLng(latLng);
        } else {
            circlePoint = latLng;
        }
        setRadius(ComputeUtils.getDistance(getCenterLatLng(), circlePoint));
        HandlerUtils.getUIHandler().postDelayed(new Runnable() {
            @Override
            public void run() {
                calculateAllPoints();
                updateFenceCover();
                updateFenceLine();
            }
        }, 500);
    }

    public void updateFenceLatLng(int index, MyLatLng latLngs) {
        if (isCircle()) {
            return;
        }
        if (districtFencePoints != null && districtFencePoints.size() > index) {
            districtFencePoints.set(index, latLngs);
            if (isPolyon) {
                updateFenceCover();
            } else {
                updateFenceLine();
            }
        }
    }

    public List<MyLatLng> getFenceLatLngs() {
        List<MyLatLng> latLngs = new ArrayList<>();
        if (districtFencePoints != null) {
            latLngs.addAll(districtFencePoints);
        }
        return latLngs;
    }

    protected boolean isNeedMarker() {
        if (MapController.IS_EDIT_MAP) {
            return true;
        }
        return false;
    }

    public void clearSound() {
        soundIdDroneWarning = soundIdDefault;
    }

    public void checkSound() {
        if (aviationInFenceDroneMap.size() > 0) {
            playEarlyWarningDrone();
        }
    }

    private void locationCheckSound() {
        if (aviationInFenceDroneMap.size() > 0) {
            haveDroneStatus = true;
            playEarlyWarningDrone();
        } else {
            haveDroneStatus = false;
            stopEarlyWarningDrone();
        }
    }

    public void checkVibrator() {
        if (aviationInFenceDroneMap.size() > 0) {
            WarningManager.getInstance().startVibrator();
        }
    }

    private void playEarlyWarningDrone() {
        if (LocalMapConfig.USE_SPEAK) {
            WarningManager.getInstance().startFlushPlay(R.string.speech_drone_in_fence_tip, true, true);
            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "播放预警警告！！！");
        } else {
            if (soundIdDroneWarning == soundIdDefault) {
                soundIdDroneWarning = WarningManager.getInstance().findDroneStartPlay();
            }
            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "播放发现无人机警告！！！ | soundIdDroneEarlyWarning:%d", soundIdDroneWarning);
        }
    }

    private void stopEarlyWarningDrone() {
        if (!LocalMapConfig.USE_SPEAK) {
            if (soundIdDroneWarning != soundIdDefault) {
                WarningManager.getInstance().stopWarning(soundIdDroneWarning);
                WarningManager.getInstance().stopVibrator();
                soundIdDroneWarning = soundIdDefault;
            }
            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "播放发现无人机警告！！！ | soundIdDroneEarlyWarning:%d", soundIdDroneWarning);
        }
    }

    protected void clearMonitorResultModel() {
        for (BaseDroneModel droneModel : aviationInFenceDroneMap.values()) {
            droneModel.deleteInvadeResultModel(getClassKey());
            // 需要移除电子围栏中设备和无人机关系
            for (BaseMonitorModel monitorModel : inFenceMonitorMap.values()) {
                droneModel.deleteInvadeResultModel(monitorModel.getData().getMonitorId());
            }
        }
        aviationInFenceDroneMap.clear();
        inFenceMonitorMap.clear();
        stopEarlyWarningDrone();
    }

    public Hashtable<String, BaseDroneModel> getAviationInFenceDroneMap() {
        return aviationInFenceDroneMap;
    }

    public abstract void updateScanCover();

    protected abstract void removeScanCover();

    protected abstract void removeCover();

    public abstract void updateFenceLine();

    protected abstract void removeFeceLine();

    public abstract void updateMarkers();

    public abstract void removeMarkers();

    @UiThread
    public void onEditFinish() {
        isEdit = false;
        removeFeceLine();
        removeMarkers();
    }

    @UiThread
    public boolean updateFenceCover() {
        if (!isCircle()) {
            if (districtFencePoints.size() >= 3) {
                isPolyon = true;
                removeFeceLine();
                return true;
            }
        } else {
            return true;
        }
        return false;
    }

    public boolean isEditFinish() {
        return true;
    }

    /**
     * 首先判断点是否在区域内，不在区域内则添加点
     *
     * @param latLng
     * @return
     */
    @UiThread
    public boolean addMarker(MyLatLng latLng) {
        if (isPolyon) {
            return false;
        }
        boolean isAdd = true;
        if (districtFencePoints.size() > 0) {
            MyLatLng firstLatLng = districtFencePoints.get(districtFencePoints.size() - 1);
            if (ComputeUtils.getDistance(latLng.longitude, latLng.latitude,
                    firstLatLng.longitude, firstLatLng.latitude) > 30) {
                isAdd = true;
            } else {
                isAdd = false;
                updateFenceCover();
            }
        }
        if (isAdd) {
            districtFencePoints.add(latLng);
            WarningManager.getInstance().createFencePointStartPlay();
        }
        return isAdd;
    }

    @UiThread
    public void onStartEdit() {
        clearMonitorResultModel();
        this.circlePoint = ComputeUtils.eOffsetBearing(warningAreaInfo.getCenterLatLng(), warningAreaInfo.radius, 90);
        updateMarkers();
        updateFenceLine();
        removeScanCover();
    }

    @UiThread
    public void erase() {
        isErase = true;
        removeFeceLine();
        removeCover();
        removeScanCover();
        removeMarkers();
        districtFencePoints.clear();
        clearMonitorResultModel();
    }
}
