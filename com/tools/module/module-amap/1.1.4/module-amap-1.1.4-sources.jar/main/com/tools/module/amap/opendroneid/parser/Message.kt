package com.tools.module.amap.opendroneid.parser

class Message<T : DronePackData.Payload?>(
    val header: DronePackData.Header,
    val payload: T,
    val timestamp: Long,
    val msgCounter: Int) :
    Comparable<Message<T>> {

    override fun compareTo(o: Message<T>): Int {
        if (header.type == DronePackData.Type.AUTH && o.header.type == DronePackData.Type.AUTH) {
            val authThis = payload as DronePackData.Authentication
            val authO = o.payload as DronePackData.Authentication
            return (authThis.authDataPage - authO.authDataPage)
        } else {
            return header.type!!.compareTo(o.header.type!!)
        }
    }

    override fun toString(): String {
        return "Message {" +
                "header=" + header.toString() +
                ", payload=" + payload.toString() +
                ", timestamp=" + timestamp +
                ", msgCounter=" + msgCounter +
                '}'
    }
}