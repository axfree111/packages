package com.tools.module.amap.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.tools.module.amap.R;
import com.tools.module.amap.databinding.ViewHistoryNoteViewBinding;

public class HistoryNoteInfoView extends FrameLayout {

    public HistoryNoteInfoView(@NonNull Context context) {
        this(context, null);
    }

    public HistoryNoteInfoView(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public HistoryNoteInfoView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        this(context, attrs, defStyleAttr, 0);
    }

    public HistoryNoteInfoView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        initV(context, attrs);
    }

    private void initV(Context context, AttributeSet attrs) {
        viewBinding = ViewHistoryNoteViewBinding.inflate(LayoutInflater.from(context), this, true);
    }

    public void setData(String timeStr, String heightStr, String sppedStr) {
        viewBinding.historyNoteTv.setText(timeStr + "\n" + heightStr + " " + sppedStr);
    }

    private ViewHistoryNoteViewBinding viewBinding;
}