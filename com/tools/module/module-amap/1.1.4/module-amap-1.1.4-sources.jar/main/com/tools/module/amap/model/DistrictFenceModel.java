package com.tools.module.amap.model;

import com.drone.monitor.bean.custom.MyLatLng;

import java.io.Serializable;

/**
 * Created by jiajie on 2019-12-23.
 */
public class DistrictFenceModel implements Serializable {
    public String id;
    public int index;
    public int fenceMarkerType;
    public MyLatLng latLng;
}
