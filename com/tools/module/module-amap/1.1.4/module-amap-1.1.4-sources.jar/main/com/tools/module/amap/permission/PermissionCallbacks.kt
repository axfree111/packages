package com.tools.module.amap.permission

import com.tools.module.common.annotation.NotProguard

@NotProguard
interface PermissionCallbacks {
    fun onPermissionsGranted()

    fun onPermissionsDenied(perms: Array<String>?)
}
