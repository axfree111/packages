package com.tools.module.amap.model;

import java.io.Serializable;

public class ArcPointOffset implements Serializable {
    public double lat;
    public double lng;
}
