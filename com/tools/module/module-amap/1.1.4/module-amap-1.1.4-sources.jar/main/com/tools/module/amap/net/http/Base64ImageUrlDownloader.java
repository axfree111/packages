package com.tools.module.amap.net.http;

import android.text.TextUtils;

import com.tools.module.amap.net.StatusCode;
import com.tools.module.amap.net.http.request.IRequestHost;
import com.tools.module.amap.net.http.response.FileHttpResponseHandler;
import com.tools.module.common.utils.AppUtil;
import com.tools.module.common.utils.ByteArrayPool;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Webview中Base64图片下载
 */
public class Base64ImageUrlDownloader {

    /**
     * 是否支持
     *
     * data:image/gif;base64,base64编码的gif图片数据
     * data:image/png;base64,base64编码的png图片数据
     * data:image/jpeg;base64,base64编码的jpeg图片数据
     * data:image/x-icon;base64,base64编码的icon图片数据
     * @return
     */
    public static boolean isSupport(String url) {
        if (TextUtils.isEmpty(url)) {
            return false;
        }

        if (url.startsWith("data:image/gif;base64,") ||
            url.startsWith("data:image/png;base64,") ||
            url.startsWith("data:image/jpeg;base64,") ||
            url.startsWith("data:image/x-icon;base64,")) {
            return true;
        }

        return false;
    }

    /**
     * Base 64图片下载处理
     * @param url
     * @param savePath
     * @param responseHandler
     * @param requestHost
     */
    public static void handleBase64ImageUrlDownload(String url, String savePath, FileHttpResponseHandler responseHandler, IRequestHost requestHost) {
        String prefixStr = ";base64,";
        int index = url.indexOf(prefixStr);
        if (index > 0) {
            String base64ImageData = url.substring(index+prefixStr.length());

            FileOutputStream fos = null;
            byte[] buff = null;
            try {
                File downloadFile = new File(savePath);
                if (!downloadFile.exists()) {
                    downloadFile.createNewFile();
                }
                fos = new FileOutputStream(downloadFile);
                byte[] decodedString = android.util.Base64.decode(base64ImageData, android.util.Base64.DEFAULT);
                fos.write(decodedString);
                fos.flush();

                // 处理完成
                if (responseHandler != null) {
                    responseHandler.sendSuccessMessage(url, 200, downloadFile);
                }
            } catch (IOException ioe) {
                ioe.printStackTrace();
                if (responseHandler != null) {
                    responseHandler.sendFailureMessage(url, ioe, StatusCode.getIOExceptionStatusCode(ioe), null);
                }
            } catch (Exception e) {
                e.printStackTrace();
                if (responseHandler != null) {
                    responseHandler.sendFailureMessage(url, e, StatusCode.EXCEPTION, null);
                }
            } finally {
                ByteArrayPool.sDefaultPool.returnBuf(buff);
                AppUtil.closeQuietly(fos);

                if (responseHandler != null) {
                    responseHandler.sendFinishMessage();
                }
            }
        }

    }
}
