package com.drone.monitor.bean;

import com.drone.monitor.bean.custom.MyObject;

import java.util.Date;

//@CompoundIndexes(
//    {
//        @CompoundIndex(name = "phoneNo", unique = true)
//    }
//)
public class UserInfo extends MyObject {

    private String id;

    private String phoneNo;

    /**
     * 暂时不用
     */
    private String account;

    private String password;

    /**
     * 0 超级管理员
     * 1 管理员
     * 2 操作员
     */
    private int userLevel = -1;

    private String userName;

    private Date createTime;

    private Date updateTime;

    private String parentId;

    // TODO 需确定下以下几个字段
    private String openId;
    private String userDetail;
    private String roleId;
    private int mid;// 与ChannelsInfo中id相关，表示系统类型
    private String channelConfig;

    public int getMid() {
        return mid;
    }

    public void setMid(int mid) {
        this.mid = mid;
    }

    public String getChannelConfig() {
        return channelConfig;
    }

    public void setChannelConfig(String channelConfig) {
        this.channelConfig = channelConfig;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public int getUserLevel() {
        return userLevel;
    }

    public void setUserLevel(int userLevel) {
        this.userLevel = userLevel;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public String getUserDetail() {
        return userDetail;
    }

    public void setUserDetail(String userDetail) {
        this.userDetail = userDetail;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    @Override
    public String toString() {
        return "UserInfo{" +
                "id='" + id + '\'' +
                ", phoneNo='" + phoneNo + '\'' +
                ", account='" + account + '\'' +
                ", password='" + password + '\'' +
                ", userLevel=" + userLevel +
                ", userName='" + userName + '\'' +
                ", createTime=" + createTime +
                ", updateTime=" + updateTime +
                ", parentId='" + parentId + '\'' +
                ", openId='" + openId + '\'' +
                ", userDetail='" + userDetail + '\'' +
                ", roleId='" + roleId + '\'' +
                ", mid=" + mid +
                ", channelConfig='" + channelConfig + '\'' +
                "} " + super.toString();
    }


    /**
     * 0 超级管理员
     * 1 管理员
     * 2 操作员
     */
    public interface USER_LEVEL {
        int SUPER_USER = 0;
        int MANAGE_USER = 1;
        int OPERATOR_USER = 2;
    }
}
