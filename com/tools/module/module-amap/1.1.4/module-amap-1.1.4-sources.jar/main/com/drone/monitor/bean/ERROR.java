package com.drone.monitor.bean;

import android.text.TextUtils;

/**
 *
 */
public enum ERROR {

    SUSSES(0, "成功"),
    MESSAGE_SEND_FAILED(1, "短信验证码发送失败"),
    MESSAGE_CONFIRM_FAILED(2, "短信验证码已失效，请重新获取"),
    MESSAGE_REPEAT(3, "短信验证码发送频繁，请稍后再试"),
    ERR_PARAM_INVALID(-1, "参数非法"),
    USER_LEVEL_ERROR(-101, "用户注册等级错误，低等级用户无法操作上级用户"),
    USER_CANT_DELETE_ERROR(-105, "该用户下有下级用户，请先转移下级用户"),
    USER_NOTEXIST_ERROR(-103, "用户不存在"),
    INVALAID_PHONENO_ERROR(-105, "无效手机号"),
    USER_NEEDLOGIN_ERROR(-104, "需要登录"),
    USER_CANT_CHECK_ERROR(-106, "无权查看该用户"),
    CANT_UPDATE_MONITOR_ERROR(-201, "该设备不归属于当前用户，无法修改"),
    MONITOR_NEED_SIGN_ERROR(-202, "该设备需要先注册"),
    MONITOR_OFFLINE_ERROR(-301, "该设备已下线无法发送指令"),
    WEBSOCKET_CONNECT_ERROR(-601, "WEBSOCKET接口校验失败"),
    WEBSOCKET_SERI_ERROR(-602, "WEBSOCKET接口解析失败"),
    WEBSOCKET_SEND_ERROR(-603, "WEBSOCKET接口推送"),
    DB_OPERATION_ERROR(-701, "数据库操作失败"),
    USER_EXIST_ERROR(-102, "用户已注册，请勿重复注册");

    private int code;
    private String msg;
    private String extMsg;

    ERROR(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public String getExtMsg() {
        return extMsg;
    }

    public void setExtMsg(String extMsg) {
        this.extMsg = extMsg;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        if (TextUtils.isEmpty(extMsg))
            return msg + ":" + extMsg;
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public static ERROR getParamInvalid(String extMsg) {
        ERROR e = ERROR.ERR_PARAM_INVALID;
        e.setExtMsg(extMsg);
        return e;
    }
}
