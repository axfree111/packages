package com.tools.module.amap.net.http.response;

import android.text.TextUtils;

import androidx.annotation.CallSuper;

import com.google.gson.Gson;
import com.tools.module.amap.net.http.bean.HttpBaseResponseData;
import com.tools.module.common.utils.XAppLogger;
import com.tools.module.common.utils.HandlerUtils;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;


/**
 * <p>
 * 方便于网络解析和ui之间的回调
 */
public abstract class UIHttpResponse<T extends HttpBaseResponseData> extends StringHttpResponseHandler {

    private static final String TAG = UIHttpResponse.class.getSimpleName();

    private Type dataType;

    private boolean httpResult;

    public UIHttpResponse() {
        //this.dataType = type;
        Type superClass = getClass().getGenericSuperclass();
        if (superClass instanceof ParameterizedType) {
            Type[] typeArray = ((ParameterizedType) superClass).getActualTypeArguments();
            if (typeArray != null && typeArray.length > 0) {
                this.dataType = typeArray[0];
            }
        }
    }

    /**
     * 数据请求开始执行
     */
    protected void onUIStart() {
    }

    /**
     * 数据解析完成后通知ui线程进行处理
     *
     * @param parseData 解析后的结果, 需要判空
     */
    protected abstract void onUIUpdate(T parseData);

    /**
     * 在UI线程处理错误
     *
     * @return true: 业务层已处理这个错误，底层不需要再处理
     * false: 业务层没有处理，需要底层继续处理
     */
    protected boolean onUIFailure(int errorCode, String errorMessage, String responseContent) {
        return onUIFailure(errorCode, errorMessage);
    }

    protected boolean onUIFailure(int errorCode, String errorMessage) {
        return false;
    }

    /**
     * 请求结束, 成功或失败都会调用到这个函数
     */
    protected void onUIFinish(boolean success) {
        onUIFinish();
    }

    protected void onUIFinish() {
    }

    /**
     * 请求开始执行
     */
    @Override
    @Deprecated
    @CallSuper
    public final void onStart() {
        super.onStart();
        httpResult = false;
        HandlerUtils.getUIHandler().post(new Runnable() {
            @Override
            public void run() {
                onUIStart();
            }
        });
    }

    /**
     * 请求出错
     */
    @Override
    @Deprecated
    @CallSuper
    public void onFailure(Throwable error, int statusCode, final String content) {
        super.onFailure(error, statusCode, content);
        httpResult = false;
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_ERROR, content);
    }

    /**
     * 请求结束
     */
    @Override
    @Deprecated
    @CallSuper
    public final void onFinish() {
        HandlerUtils.getUIHandler().post(new Runnable() {
            @Override
            public void run() {
                onUIFinish(httpResult);
            }
        });
    }

    @Override
    @Deprecated
    @CallSuper
    public void onSuccess(int statusCode, String content) {
        Exception exception = null;
        T data = null;
        try {
            data = parseData(content);
            if (data == null && dataType != null) {
                // response为空或不能正确解析数据, 抛出异常触发onFailure阶段
                throw new RuntimeException("response is null or parse data failed");
            }
        } catch (Exception e) {
            e.printStackTrace();
            exception = e;
        }
        httpResult = true;
        final T dataCopy = data;
        HandlerUtils.getUIHandler().post(new Runnable() {
            @Override
            public void run() {
                onUIUpdate(dataCopy);
            }
        });
    }

    /**
     * 在非ui线程回调, 用于数据解析
     */
    protected T parseData(String response) {
        if (dataType == null) {
            return null;
        }
        if (TextUtils.isEmpty(response)) {
            return null;
        }
        T baseEntity = new Gson().fromJson(response, dataType);
        return baseEntity;
    }

}
