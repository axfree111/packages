package com.tools.module.amap.opendroneid.data

import com.tools.module.amap.R
import com.tools.module.amap.opendroneid.OpenDroneIdConstants
import com.tools.module.amap.opendroneid.parser.toPartString
import com.tools.module.common.utils.ResourceUtil
import java.nio.charset.StandardCharsets

class OperatorIdBizData : MessageBizData() {
    private var operatorIdType = 0
    private var operatorId: ByteArray?

    init {
        operatorId = ByteArray(0)
    }

    fun setOperatorIdType(operatorIdType: Int) {
        var operatorIdType = operatorIdType
        if (operatorIdType < 0) operatorIdType = 0
        if (operatorIdType > 255) operatorIdType = 255
        this.operatorIdType = operatorIdType
    }

    fun getOperatorIdType(): Int {
        return operatorIdType
    }

    fun setOperatorId(operatorId: ByteArray) {
        if (operatorId.size <= OpenDroneIdConstants.MAX_ID_BYTE_SIZE) this.operatorId = operatorId
    }

    fun getOperatorId(): ByteArray? {
        return operatorId
    }

    fun getOperationIdForAsciiString(): String {
        return operatorId?.toPartString(StandardCharsets.US_ASCII)
            ?: ResourceUtil.getContent(R.string.unknown)
    }

    fun getOperationIdForUtf8String(): String {
        return operatorId?.toPartString(StandardCharsets.UTF_8)
            ?: ResourceUtil.getContent(R.string.unknown)
    }

//    val operatorIdAsString: String
//        get() {
//            if (operatorId != null) {
//                for (c in operatorId!!) {
//                    if ((c <= 31 || c >= 127) && c.toInt() != 0) {
//                        return "Invalid String"
//                    }
//                }
//                return String(operatorId!!)
//            }
//            return ""
//        }
}
