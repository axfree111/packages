package com.tools.module.amap.model.base;

import android.text.TextUtils;

import com.drone.monitor.bean.Drone;
import com.drone.monitor.bean.VideoInfo;
import com.tools.module.amap.manager.WarningManager;
import com.tools.module.common.utils.XAppLogger;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by jiajie on 2020-02-17.
 */
public abstract class BaseVideoModel<T> extends BaseModel {

    private volatile Map<String, ClusterItem> mClusterItems = new ConcurrentHashMap<>();
    protected volatile Map<String, T> mMarkers = new ConcurrentHashMap<>();
    protected volatile Map<String, T> mNewMarkers = new ConcurrentHashMap<>();
    private volatile Map<String, VideoInfo> mVideos = new ConcurrentHashMap<>();
    private volatile Map<String, VideoInfo> mHideVideo = new ConcurrentHashMap<>();

    public BaseVideoModel() {

    }

    @Override
    public int getMarkerType() {
        return Drone.MARKER_TYPE.VIDEO;
    }

    @Override
    public int getObjType() {
        return 0;
    }

    // TODO 定义成泛型
    public ClusterItem removeClusterItem(String videoId) {
        return mClusterItems.remove(videoId);
    }

    public ClusterItem getClusterItem(String videoId) {
        return mClusterItems.get(videoId);
    }

    public Map<String, ClusterItem> getClusterItems() {
        return mClusterItems;
    }

    protected void addClusterItems(String videoId, ClusterItem clusterItem) {
        if (mClusterItems != null) {
            mClusterItems.put(videoId, clusterItem);
        }
    }

    protected void removeVideo(String videoId) {
        if (mVideos != null) {
            mVideos.remove(videoId);
        }
    }

    protected void addVideo(String videoId, VideoInfo videoInfo) {
        if (mVideos != null) {
            mVideos.put(videoId, videoInfo);
        }
    }

    public Map<String, VideoInfo> getVideos() {
        return mVideos;
    }

    public Map<String, VideoInfo> getHideVideos() {
        return mHideVideo;
    }

    public VideoInfo getVideoInfo(String videoId) {
        if (mVideos.containsKey(videoId)) {
            return mVideos.get(videoId);
        }
        return null;
    }

    public void addMarker(String videoId, T marker) {
        mMarkers.put(videoId, marker);
    }

    public void addNewMarker(String videoId, T marker) {
        mNewMarkers.put(videoId, marker);
    }

    public boolean isContainsNewMarker(String videoId) {
        return mNewMarkers.containsKey(videoId);
    }

    public void addMarker(VideoInfo video) {
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_VIDEO, "添加视频marker:" + video.videoId);
        if (!isContainsVideo(video)) {
            if (video.isNewVideo()) {
                WarningManager.getInstance().haveNewVideoStartPlay();
            }
        }
    }

    public abstract void updateMarker(VideoInfo video);

    public abstract void removeMarker(VideoInfo video);

    public abstract void removeMarker(String videoId);

    public abstract void eraseMarker(String videoId);

    public abstract void eraseMarker(VideoInfo video);

    public void removeAllMarker() {
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_VIDEO, "removeAllMarker()");
        Map<String, VideoInfo> copyVideos = new HashMap<>();
        copyVideos.putAll(mVideos);
        Iterator iterator = copyVideos.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, VideoInfo> entry = (Map.Entry) iterator.next();
            if (entry != null) {
                VideoInfo videoInfo = entry.getValue();
                if (videoInfo != null) {
                    eraseMarker(videoInfo);
                }
            }
        }
        Map<String, VideoInfo> copyHideVideos = new HashMap<>();
        copyVideos.putAll(mHideVideo);
        Iterator hideIterator = copyHideVideos.entrySet().iterator();
        while (hideIterator.hasNext()) {
            Map.Entry<String, VideoInfo> entry = (Map.Entry) hideIterator.next();
            if (entry != null) {
                VideoInfo videoInfo = entry.getValue();
                if (videoInfo != null) {
                    eraseMarker(videoInfo);
                }
            }
        }
        clear();
    }

    public void removeHideVideo(String videoId) {
        if (!TextUtils.isEmpty(videoId)) {
            mHideVideo.remove(videoId);
        }
    }

    public void hideMarker(VideoInfo video) {
        mHideVideo.put(video.videoId, video);
        removeMarker(video);
    }

    protected boolean isContainsVideo(VideoInfo video) {
        if (video != null && !TextUtils.isEmpty(video.videoId)) {
            if (mVideos.containsKey(video.videoId)) {
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_VIDEO, "检测已包含视频:" + video.videoId);
                return true;
            }
        }
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_VIDEO, "检测不包含视频:" + video.videoId);
        return false;
    }

    protected boolean isContainsVideo(String videoId) {
        if (!TextUtils.isEmpty(videoId)) {
            if (mVideos.containsKey(videoId)) {
                return true;
            }
        }
        return false;
    }

    protected boolean isHideVideo(VideoInfo video) {
        if (video != null && !TextUtils.isEmpty(video.videoId)) {
            if (mHideVideo.containsKey(video.videoId)) {
                return true;
            }
        }
        return false;
    }

    public void clear() {
        if (mMarkers != null) {
            mMarkers.clear();
        }
        if (mNewMarkers != null) {
            mNewMarkers.clear();
        }
        if (mVideos != null) {
            mVideos.clear();
        }
    }
}
