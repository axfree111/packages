package com.drone.monitor.bean;

import com.drone.monitor.bean.custom.MyObject;

public class WebConfigInfo extends MyObject {

    public String title;
    public String titleEn;
    public String logo;
    public int logoWidth;
    public int logoHeight;
    public String company;
    public String themeColor;
    public String pageTitle;

    @Override
    public String toString() {
        return "WebConfigInfo{" +
                "title='" + title + '\'' +
                ", titleEn='" + titleEn + '\'' +
                ", logo='" + logo + '\'' +
                ", logoWidth=" + logoWidth +
                ", logoHeight=" + logoHeight +
                ", company='" + company + '\'' +
                ", themeColor='" + themeColor + '\'' +
                ", pageTitle='" + pageTitle + '\'' +
                "} " + super.toString();
    }
}
