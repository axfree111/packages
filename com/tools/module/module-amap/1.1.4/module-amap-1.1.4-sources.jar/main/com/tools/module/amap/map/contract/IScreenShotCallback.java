package com.tools.module.amap.map.contract;

public interface IScreenShotCallback {
    void screenCapture(String filePath);
}
