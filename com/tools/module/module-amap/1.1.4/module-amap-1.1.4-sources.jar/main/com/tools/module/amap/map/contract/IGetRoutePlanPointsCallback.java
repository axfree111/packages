package com.tools.module.amap.map.contract;

import com.drone.monitor.bean.custom.MyLatLng;

import java.util.List;

/**
 * Created by jiajie on 2020-01-19.
 */
public interface IGetRoutePlanPointsCallback {
    void onSuccess(List<MyLatLng> latLngs);

    void onFailed();
}
