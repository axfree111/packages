package com.tools.module.amap;

import android.os.Environment;

import java.io.File;
import java.util.Random;

/**
 * Date: 2025/4/3
 * Desc:
 * <p>
 * author: jaje
 */
public class BaseConstants {

    public static File PATHROOT = Environment.getExternalStorageDirectory();
    private static String PATH_BASE = PATHROOT + File.separator + "1DR" + File.separator;
    public static String PATH_SREENSHOT = PATH_BASE + "Shot";
    public static String PATH_DRAW_SREENSHOT = PATH_BASE + "Draw";
    public static String DRAW_PRE = "app_tactics_%s_%s";
    public static String DRAW_PRE_NAME = "手机-战术-%s";
    public static String PATH_SREEN_RECORD = PATH_BASE + "Record";
    public static String PATH_SREEN_PAINT = PATH_BASE + "Paint";
    public static String PATH_CONFIG = PATH_BASE + "Config";
    public static String PATH_WATERMARK = PATH_CONFIG + File.separator + "watermark.png";
    public static String PATH_LOG = PATH_BASE + "Log";
    public static String PATH_APK = PATH_BASE + "Apk";
    public static String PATH_RECORD_VIDEO = PATH_BASE + "recordVideo";
    public static String PATH_VIDEO_CACH = PATH_BASE + "videoCache";
    public static String PATH_OSS_DIR = PATH_BASE + "oss";
    public static String PATH_OSS_WW_ZIP = "wangwang.zip";
    public static String PATH_OSS_WW = PATH_OSS_DIR + File.separator + PATH_OSS_WW_ZIP;
    public static String PATH_MAP_CACHE_DIR = PATH_BASE + File.separator + "mapCache";
    public static final String CHINE_ISO3_CODE = "CHN";

    public static String ID = "200PD";
    public static Random RANDOM = new Random();
}
