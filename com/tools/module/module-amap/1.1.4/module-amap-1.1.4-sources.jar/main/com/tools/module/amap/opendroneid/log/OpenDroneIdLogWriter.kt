package com.tools.module.amap.opendroneid.log

import android.bluetooth.le.ScanResult
import android.text.TextUtils
import com.tools.module.amap.opendroneid.parser.Constants
import com.tools.module.amap.opendroneid.parser.DronePackData
import com.tools.module.common.utils.XAppLogger
import java.io.BufferedWriter
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStreamWriter
import java.nio.charset.StandardCharsets
import java.util.concurrent.BlockingQueue
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue

class OpenDroneIdLogWriter(file: File) {
    private val writer = BufferedWriter(
        OutputStreamWriter(FileOutputStream(file), StandardCharsets.UTF_8)
    )
    private val logQueue: BlockingQueue<String> = LinkedBlockingQueue()
    private var loggingActive = false

    init {
        val exec = Executors.newSingleThreadExecutor()

        XAppLogger.getInstance().writeLog("${TAG} starting logging to $file")
        exec.submit {
            try {
                loggingActive = true
                var last = System.currentTimeMillis()

                // write header
                writer.write(TextUtils.join(",", LogEntry.HEADER))
                writer.write("," + DronePackData.BasicId.csvHeader())
                writer.write(DronePackData.BasicId.csvHeader())
                writer.write(DronePackData.Location.csvHeader())
                writer.write(DronePackData.DescriptionID.csvHeader())
                writer.write(DronePackData.SystemMsg.csvHeader())
                writer.write(DronePackData.OperatorID.csvHeader())
                for (i in 0 until Constants.MAX_AUTH_DATA_PAGES) writer.write(DronePackData.Authentication.csvHeader())
                writer.newLine()
                while (loggingActive) {
                    var log: String?
                    try {
                        log = logQueue.take()
                    } catch (e: InterruptedException) {
                        break
                    }
                    writer.write(log)
                    writer.newLine()
                    val time = System.currentTimeMillis()
                    if (time - last > 1000) {
                        writer.flush()
                        last = time
                    }
                }
            } catch (e: IOException) {
                XAppLogger.getInstance().writeLog("${TAG} error writing log", e)
            } finally {
                try {
                    writer.flush()
                    writer.close()
                } catch (e: IOException) {
                    e.printStackTrace()
                }
            }
        }
    }

    fun logBluetooth(
        msgVersion: Int, result: ScanResult,
        transportType: String?, csvLog: StringBuilder?
    ) {
        val entry = LogEntry()
        entry.session = session
        entry.timestamp = result.timestampNanos
        entry.transportType = transportType
        entry.macAddress = result.device.address
        entry.msgVersion = msgVersion
        entry.rssi = result.rssi
        if (result.scanRecord != null) entry.data = result.scanRecord!!.bytes
        entry.csvLog = csvLog
        logQueue.add(entry.toString())
    }

    fun logNaN(
        msgVersion: Int, timeNano: Long?, peerHash: Int, serviceSpecificInfo: ByteArray?,
        transportType: String?, csvLog: StringBuilder?
    ) {
        val entry = LogEntry()
        entry.session = session
        entry.timestamp = timeNano!!
        entry.transportType = transportType
        entry.macAddress = peerHash.toString()
        entry.msgVersion = msgVersion
        entry.rssi = 0
        if (serviceSpecificInfo != null) entry.data = serviceSpecificInfo
        entry.csvLog = csvLog
        logQueue.add(entry.toString())
    }

    fun logBeacon(
        msgVersion: Int, timeNano: Long?, scanResult: android.net.wifi.ScanResult,
        data: ByteArray?, transportType: String?, csvLog: StringBuilder?
    ) {
        val entry = LogEntry()
        entry.session = session
        entry.timestamp = timeNano!!
        entry.transportType = transportType
        entry.macAddress = scanResult.BSSID
        entry.msgVersion = msgVersion
        entry.rssi = scanResult.level
        if (data != null) entry.data = data
        entry.csvLog = csvLog
        logQueue.add(entry.toString())
    }

    fun close() {
        loggingActive = false
        try {
            writer.flush()
            writer.close()
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    companion object {
        private const val TAG = "LogWriter"
        private var session = 0
        fun bumpSession() {
            session++
        }
    }
}

