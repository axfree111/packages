package com.tools.module.amap.net.http.request;

import android.text.TextUtils;

import com.tools.module.amap.net.NetManager;
import com.tools.module.amap.net.StatusCode;
import com.tools.module.amap.net.http.HttpClient;
import com.tools.module.amap.net.http.OkHttpUtils;
import com.tools.module.amap.net.http.response.HttpResponseHandler;
import com.tools.module.amap.net.http.response.StringHttpResponseHandler;
import com.tools.module.common.utils.XAppLogger;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okio.Buffer;
import okio.BufferedSink;
import okio.Okio;
import okio.Source;

/**
 * Created by Changjiajie on 2018/4/4.
 */

public class OkHttpUrlRequest {

    private long startTime;

    public OkHttpUrlRequest() {
    }

    public Call request(HttpRequestWrapper requestWrapper) {
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "use okhttp to execute");

        HttpResponseHandler<?> responseHandler = requestWrapper.getResponseHandler();

        if (responseHandler != null) {
            responseHandler.sendStartMessage();
        }

        startTime = System.currentTimeMillis();

        String url = requestWrapper.getRealUrl();

        try {

            Request.Builder requestBuild = new Request.Builder();
            HttpRequestWrapper.HttpType httpType = requestWrapper.getType();
            switch (httpType) {
                case Get:
                    requestBuild.get();
                    break;
                case Post:
                    requestBuild.post(getBody(requestWrapper));
                    break;
                case Put:
                    requestBuild.put(getBody(requestWrapper));
                    break;
                case Delete:
                    requestBuild.delete();
                    break;
            }

            // 设置url
            requestBuild.url(url);

            // 添加头信息
            Map<String, String> headerPairs = requestWrapper.getHeadersMap();
            if (headerPairs != null && headerPairs.size() > 0) {
                Iterator<Map.Entry<String, String>> headersIter = headerPairs.entrySet().iterator();
                while (headersIter.hasNext()) {
                    Map.Entry<String, String> headerEntry = headersIter.next();
                    requestBuild.addHeader(headerEntry.getKey(), headerEntry.getValue());
                }
            }

            Call call = OkHttpUtils.okHttpClient.newCall(requestBuild.build());

            call.enqueue(getCallback(responseHandler));

            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, " Header:" + call.request().headers().toString());

            return call;

        } catch (Exception e) {
            e.printStackTrace();
            if (responseHandler != null) {
                responseHandler.sendFailureMessage(url, e, StatusCode.EXCEPTION, null);
                responseHandler.sendFinishMessage();
            }
        }

        return null;
    }

    /**
     * @param responseHandler
     * @return
     */
    private Callback getCallback(final HttpResponseHandler<?> responseHandler) {
        return new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                if (responseHandler != null) {
                    responseHandler.sendFailureMessage(
                            call.request().url().toString(), e, StatusCode.getIOExceptionStatusCode(e), null);
                    responseHandler.sendFinishMessage();
                    printTakeTime(null);
                }
            }

            @Override
            public void onResponse(Call call, Response response) {
                if (responseHandler != null) {

                    int statusCode = 0;
                    String url = call.request().url().toString();

                    if (response == null) {
                        responseHandler.sendFailureMessage(url, new Exception("response is null!"), StatusCode.EMPTY_RESPONSE, null);
                    } else {
                        statusCode = response.code();
                        if (response.body() == null) {
                            responseHandler.sendFailureMessage(url, new Exception("response body is null!"), statusCode, null);
                        } else {
                            if (responseHandler instanceof StringHttpResponseHandler) {
                                StringHttpResponseHandler stringResponseHandler = (StringHttpResponseHandler) responseHandler;
                                String responseBody = "";
                                try {
                                    responseBody = response.body().string();
                                    if (response.isSuccessful()) {
                                        if (!TextUtils.isEmpty(responseBody)) {
                                            // 解析Header数据
                                            HttpClient.readHeaders(response);
                                        }
                                        stringResponseHandler.sendSuccessMessage(url, statusCode, responseBody);
                                    } else {
                                        stringResponseHandler.sendFailureMessage(url, new Exception("response is not successful!"), statusCode, responseBody);
                                    }
                                } catch (IOException ioe) {
                                    if (statusCode == 0) {
                                        statusCode = StatusCode.getIOExceptionStatusCode(ioe);
                                    }
                                    stringResponseHandler.sendFailureMessage(url, ioe, statusCode, responseBody);
                                }
                            } else {
                                responseHandler.sendResponseMessage(url, response);
                            }
                        }
                    }

                    responseHandler.sendFinishMessage();
                }

                printTakeTime(response);
            }
        };
    }

    /**
     * 根据RequestParams参数，返回需要上传的body结构
     *
     * @return
     */
    private RequestBody getBody(HttpRequestWrapper requestWrapper) {

        RequestParams requestParameter = requestWrapper.getRequestParams();
        if (requestParameter == null) {
            return RequestBody.create(null, "");
        }

        if (requestParameter.jsonBody != null) {
            // 上传json
            return RequestBody.create(MediaType.parse("application/json; charset=utf-8"), requestParameter.jsonBody);

        } else if (requestParameter.formBody != null) {
            // 上传form数据
            FormBody.Builder builder = new FormBody.Builder();
            Iterator<Map.Entry<String, String>> entryIter = requestParameter.formBody.entrySet().iterator();
            while (entryIter.hasNext()) {
                Map.Entry<String, String> entry = entryIter.next();
                builder.add(entry.getKey(), entry.getValue());
            }
            return builder.build();

        } else if (requestParameter.bytesBody != null) {
            // 上传二进制数据
            return RequestBody.create(MediaType.parse("application/octet-stream"), requestParameter.bytesBody);

        } else if (!TextUtils.isEmpty(requestParameter.uploadFilePath)) {
            // 上传文件
            MultipartBody.Builder builder = new MultipartBody.Builder().setType(MultipartBody.FORM);
            // Add string params
            for (ConcurrentHashMap.Entry<String, String> entry : requestParameter.urlParams.entrySet()) {
                builder.addFormDataPart(entry.getKey(), entry.getValue());
            }

            File file = new File(requestParameter.uploadFilePath);
            RequestBody uploadFile = createUploadProgressRequestBody(MediaType.parse("image/jpeg"), file, requestWrapper.getResponseHandler());
            if (TextUtils.isEmpty(requestParameter.uploadParameterName)) {
                builder.addFormDataPart(file.getName(), file.getName(), uploadFile);
            } else {
                builder.addFormDataPart(requestParameter.uploadParameterName, file.getName(), uploadFile);
            }
            return builder.build();

        } else if (requestParameter.urlParams != null) {
            FormBody.Builder builder = new FormBody.Builder();
            Iterator<Map.Entry<String, String>> entryIter = requestParameter.urlParams.entrySet().iterator();
            while (entryIter.hasNext()) {
                Map.Entry<String, String> entry = entryIter.next();
                builder.add(entry.getKey(), entry.getValue());
            }
            return builder.build();

        }

        return RequestBody.create(null, "");
    }

    // 为了实现上传文件增加进度回调的功能
    // 否则可直接使用RequestBody fileBody = RequestBody.create(MediaType.parse("application/octet-stream"), file);
    private static RequestBody createUploadProgressRequestBody(final MediaType contentType, final File file, final HttpResponseHandler<?> responseHandler) {
        return new RequestBody() {
            @Override
            public MediaType contentType() {
                return contentType;
            }

            @Override
            public long contentLength() {
                return file.length();
            }

            @Override
            public void writeTo(BufferedSink sink) throws IOException {
                Source source;
                try {
                    long total = contentLength();
                    long readCount = 0;
                    int lastPercent = -1;
                    source = Okio.source(file);
                    //sink.writeAll(source);
                    Buffer buf = new Buffer();
                    for (long count; (count = source.read(buf, 2048)) != -1; ) {
                        sink.write(buf, count);
                        readCount += count;
                        if (responseHandler != null) {
                            int percent = (int) (((float) readCount * 100) / total);
                            // 防止相同的进度多次上报影响效率
                            if (percent != lastPercent) {
                                responseHandler.sendProgressMessage(percent, (int) total);
                                lastPercent = percent;
                            }
                        }

                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };
    }

    private void printTakeTime(Response response) {
        if (NetManager.isDebug()) {
            StringBuilder strBuilder = new StringBuilder("request take time:")
                    .append(System.currentTimeMillis() - startTime);
            if (null != response) {
                strBuilder.append(" / real take time:")
                        .append(response.receivedResponseAtMillis() - response.sentRequestAtMillis());
                Request request = response.request();
                if (null != request && null != request.url()) {
                    strBuilder.append(" [").append(response.request().url().toString()).append("]");
                }
            }
            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, strBuilder.toString());
        }
    }

}
