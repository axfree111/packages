package com.tools.module.amap.model.amap;

import com.amap.api.maps.AMap;
import com.drone.monitor.bean.MonitorDevice;
import com.tools.module.amap.map.MapController;
import com.tools.module.amap.map.amap.MaMapUtils;

/**
 * 子设备不绘制marker
 */
public class AMapMonitorModel extends AMapBaseMonitorModel {
    public AMapMonitorModel(MonitorDevice monitor) {
        super(monitor);
    }

    @Override
    protected AMap getMap() {
        return MaMapUtils.getInstance().getMap();
    }

    @Override
    protected float getCurrentZoomLevel() {
        return MapController.CURRENT_ZOOM_LEVEL;
    }

    @Override
    protected void updateMarker(boolean isStatusChanged, boolean isAngleChanged, boolean isPositionChanged) {

    }

    @Override
    protected void removeDeviceMarker() {

    }
}