package com.tools.module.amap.model;

import com.drone.monitor.bean.custom.MyObject;

/**
 * Created by jiajiecsf on 12/27/20.
 */
public class DeviceBitModel extends MyObject {
    public int resId;
    public int type;
}
