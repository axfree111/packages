package com.tools.module.amap.map.amap.clusterutil;

import com.tools.module.amap.model.base.ClusterItem;
import com.amap.api.maps.model.Marker;

import java.util.Map;

/**
 * Created by yiyi.qi on 16/10/10.
 */

public interface ClusterClickListener {
    /**
     * 点击聚合点的回调处理函数
     *
     * @param marker       点击的聚合点
     * @param clusterItems 聚合点所包含的元素
     */
    public boolean onClick(Marker marker, int markerType, Map<String, ClusterItem> clusterItems);

    public boolean onClick(Marker marker);
}
