package com.tools.module.amap.net.webSocket;

import com.drone.monitor.bean.WebSocketBean;

public interface WebSocketResponse {

    void onWebSocketOpen();

    void onWebSocketClose();

    void onReceiveMessage(WebSocketBean bean);

}
