package com.tools.module.amap.opendroneid.utils

import com.drone.monitor.bean.Drone
import com.drone.monitor.bean.MonitorDevice
import com.drone.monitor.bean.MonitorDevice.DEVICE_STATUS
import com.drone.monitor.bean.custom.MyLatLng
import com.tools.module.amap.opendroneid.data.AircraftObject
import java.util.Date

/**
 * Date: 2025/4/8
 * Desc:
 *
 * author: jaje
 */
object BizDataConverter {

    fun aircraftToDroneData(aircraftObject: AircraftObject) : Drone? {
        if (aircraftObject.getSerialNumberBaseBizDataValue() == null) {
            return null
        }
        return Drone().apply {
            val baseSerialNumberId = aircraftObject.getSerialNumberBaseBizDataValue()!!
            val uasId = baseSerialNumberId.getUasIdForAsciiString()
            itemId = uasId
            state = MonitorDevice.DEVICE_STATUS.POWER_ON
            type = Drone.DRONE_TYPE.DRONE_FROM_LOCAL
            showId = uasId
            nameString = uasId
            val location = aircraftObject.getLocationValue()
            yaw = location?.direction?.toInt() ?: 0
            height = location?.getHeight() ?: 0.0
            createTime = Date()
            if (location != null) {
                setLatLng(MyLatLng(location.getLatitude(), location.getLongitude()))
            } else {
                setLatLng(null)
            }
            tag = aircraftObject
        }
    }

    // TODO 处理monitor的点击
    fun aircraftToMonitorData(aircraftObject: AircraftObject) : MonitorDevice? {
        if (aircraftObject.getSerialNumberBaseBizDataValue() == null) {
            return null
        }
        return MonitorDevice().apply {
            aircraftObject.getSerialNumberBaseBizDataValue()?.apply {
                val uasId = getUasIdForAsciiString()
                monitorId = uasId
                status = DEVICE_STATUS.POWER_ON
                type = MonitorDevice.DEVICE_TYPE.SCAN_OPERATOR
                showId = uasId
                alias = uasId
            }
            // TODO 后期这块可添加操作的无人机位置信息
            aircraftObject.getLocationValue()?.apply {
            }
            aircraftObject.getSystemValue()?.apply {
                setLatLng(getOperatorLatitude(), getOperatorLongitude())
            }
            tag = aircraftObject
        }
    }

}