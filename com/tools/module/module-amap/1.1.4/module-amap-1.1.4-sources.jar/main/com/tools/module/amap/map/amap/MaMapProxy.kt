package com.tools.module.amap.map.amap

import android.os.Bundle
import com.amap.api.maps.model.LatLng
import com.drone.monitor.bean.Drone
import com.drone.monitor.bean.MonitorDevice
import com.drone.monitor.bean.VideoInfo
import com.drone.monitor.bean.custom.MyLatLng
import com.tools.module.amap.manager.UserCenter
import com.tools.module.amap.map.MapConstants
import com.tools.module.amap.map.contract.IGetDestinationInfoCallback
import com.tools.module.amap.map.contract.IMarkerInterceptorCallback
import com.tools.module.amap.map.proxy.IMapProxy
import com.tools.module.amap.model.MarkerDataModel
import com.tools.module.amap.model.amap.AMapDistrictFenceModel
import com.tools.module.amap.model.amap.AMapDroneModel
import com.tools.module.amap.model.amap.AMapMonitorCarrierModel
import com.tools.module.amap.model.amap.AMapSelectAreaModel
import com.tools.module.amap.model.amap.AMapVideoModel
import com.tools.module.amap.model.base.BaseDistrictFenceModel
import com.tools.module.amap.model.base.BaseDroneModel
import com.tools.module.amap.model.base.BaseMonitorModel
import com.tools.module.amap.model.base.BaseSelectAreaModel
import com.tools.module.amap.model.base.BaseVideoModel

/**
 * Date: 2025/4/1
 * Desc:
 *
 * author: jaje
 */
class MaMapProxy: IMapProxy {

    override fun createViewModel(): BaseVideoModel<*> {
        return AMapVideoModel()
    }

    override fun createMonitorModel(device: MonitorDevice): BaseMonitorModel {
        return AMapMonitorCarrierModel(device)
    }

    override fun createDroneModel(data: Drone): BaseDroneModel {
        return AMapDroneModel(data)
    }

    override fun createSelectAreaModel(): BaseSelectAreaModel {
        return AMapSelectAreaModel()
    }

    override fun createDistrictFenceModel(): BaseDistrictFenceModel {
        return AMapDistrictFenceModel()
    }

    override fun getAddressNameByLatlng(latLng: MyLatLng, callback: IGetDestinationInfoCallback) {
        MaMapUtils.getInstance().getAddressNameByLatlng(latLng, callback)
    }

    override fun onLongClickMapToEdit(): Boolean {
        val authority = UserCenter.authorityInfo
        return (authority == null || (authority != null && authority.canOperationFence))
    }

    override fun isShowTitleOverlay(): Boolean {
        // TODO 后期这块需要处理，权限判断
        //  MapConstants.isShowTitleOverlay() && UserCenter.isSuperUser
        return false
    }

    override fun convertWGS84LatLng(myLatLng: MyLatLng): MyLatLng {
        val aMapConverterLatLng = AMapPositionsUtils.converterWGS84LatLng(
            LatLng(myLatLng.latitude, myLatLng.longitude)
        )
        return MyLatLng(aMapConverterLatLng.latitude, aMapConverterLatLng.longitude)
    }

    override fun convertLatLng(monitor: MonitorDevice) {
        if (monitor.isWgs84LatLng()) {
            val aMapConverterLatLng =
                AMapPositionsUtils.converterWGS84LatLng(
                    AMapPositionsUtils.transformAMapPosition(
                        monitor.myLatLng
                    )
                )
            monitor.myLatLng = MyLatLng(aMapConverterLatLng.latitude, aMapConverterLatLng.longitude)
        }
        if (monitor.getTargetLatlng() != null) {
            // 接受到的是WGS-84
            val aTargetLatlngConverterLatLng =
                AMapPositionsUtils.converterWGS84LatLng(
                    AMapPositionsUtils.transformAMapPosition(
                        monitor.getTargetLatlng()
                    )
                )
            monitor.setTargetLatlng(MyLatLng(
                aTargetLatlngConverterLatLng.latitude,
                aTargetLatlngConverterLatLng.longitude
            ))
        }
    }

    override fun setNewVideoInfo(videoInfo: VideoInfo) {
        MaMapUtils.getInstance().setZoom(videoInfo.latitude, videoInfo.longitude)
    }

    override fun showTitleOverlay(show: Boolean) {
        if (show) {
            MaMapUtils.getInstance().showTitleOverlay()
        } else {
            MaMapUtils.getInstance().hideTitleOverlay()
        }
    }

    override fun droneInfoUpdate(drone: Drone) {
        MaMapUtils.getInstance().droneInfoUpdate(drone)
    }

    override fun hideWindowsInfo() {
        MaMapUtils.getInstance().hideWindowsInfo()
    }

    override fun getCurrentSelectedMKDataModel(): MarkerDataModel {
        return MaMapUtils.getInstance().currentSelectedMKDataModel
    }

    override fun monitorInfoUpdate(monitor: MonitorDevice) {
        MaMapUtils.getInstance().monitorInfoUpdate(monitor)
    }

    override fun onCreate() {
        MaMapUtils.getInstance().onStart()
    }

    override fun onResume() {
        MaMapUtils.getInstance().onResume()
    }

    override fun onPause() {
        MaMapUtils.getInstance().onPause()
    }

    override fun onStop() {
        MaMapUtils.getInstance().onStop()
    }

    override fun onDestroy() {
        MaMapUtils.getInstance().onDestroy()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        MaMapUtils.getInstance().onSaveInstanceState(outState)
    }

    override fun setZoom(latitude: Double, longitude: Double) {
        MaMapUtils.getInstance().setZoom(latitude, longitude)
    }

    override fun setZoom(latitude: Double, longitude: Double, zoom: Float) {
        MaMapUtils.getInstance().setZoom(latitude, longitude, zoom)
    }

    override fun setMarkerClickInterceptor(markerClickInterceptor: IMarkerInterceptorCallback) {
        MaMapUtils.getInstance().setMarkerClickInterceptor(markerClickInterceptor)
    }
}