package com.drone.monitor.bean;

import android.text.TextUtils;

import com.drone.monitor.bean.custom.MyObject;
import com.google.gson.reflect.TypeToken;
import com.tools.module.common.utils.GsonUtils;

public class RoleInfo extends MyObject {

    private String id;

    private String name;

    private int level;

    private String info;

    private String authority;

    private AuthorityInfo authorityInfoObj;

    private String parentId;

    private String areaCode;

    private int mid;
    private int rightId;

    public static class Info extends MyObject {
        public int[] rights;
        public String desc;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public Info getInfo() {
        if (TextUtils.isEmpty(info)) {
            return null;
        }
        return GsonUtils.getGson().fromJson(info, new TypeToken<Info>() {
        }.getType());
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public AuthorityInfo getAuthority() {
        if (!TextUtils.isEmpty(authority) && authorityInfoObj == null) {
            authorityInfoObj = GsonUtils.getGson().fromJson(authority, new TypeToken<AuthorityInfo>() {
            }.getType());
        }
        return authorityInfoObj;
    }

    public void setAuthority(String authority) {
        this.authority = authority;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getAreaCode() {
        return areaCode;
    }

    public void setAreaCode(String areaCode) {
        this.areaCode = areaCode;
    }

    public int getMid() {
        return mid;
    }

    public void setMid(int mid) {
        this.mid = mid;
    }

    public int getRightId() {
        return rightId;
    }

    public void setRightId(int rightId) {
        this.rightId = rightId;
    }

    @Override
    public String toString() {
        return "RoleInfo{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", level=" + level +
                ", info='" + info + '\'' +
                ", authority='" + authority + '\'' +
                ", parentId='" + parentId + '\'' +
                ", areaCode='" + areaCode + '\'' +
                ", mid=" + mid +
                ", rightId=" + rightId +
                "} " + super.toString();
    }
}
