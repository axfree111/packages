package com.tools.module.amap.manager;

import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Build;

import com.tools.module.amap.R;
import com.tools.module.amap.utils.PreferencesUtils;
import com.tools.module.common.ContextStore;
import com.tools.module.common.utils.XAppLogger;

import java.util.Vector;

/**
 * Created by jiajiecsf on 2020/12/1.
 */
public class SoundManager {

    // 警报声播放次数
    public static final int EXCEPTION_PLAY_COUNT = 6;//1分钟
    public static final int WARNING_PLAY_COUNT = 60;//两分钟
    public static final int HAVE_DRONE_PLAY_COUNT = 150;//十分钟
    private SoundPool soundPool;
    private Vector<Integer> streamIDList = new Vector<>();
    private int jammerWorkSoundId;
    private int haveDroneSoundId;
    private int createFencePointSoundId;
    private int createFenceFinishSoundId;
    private int haveNewVideoSoundId;
    private boolean isLoadSoundComplete = false;

    public SoundManager() {
        init();
    }

    private void init() {
        if (soundPool == null) {
            // 5.0 及 之后
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                soundPool = new SoundPool.Builder()
                        .setMaxStreams(10)
                        .build();
            } else {
                // 5.0 以前
                soundPool = new SoundPool(30, AudioManager.STREAM_MUSIC, 0);
            }
            jammerWorkSoundId = soundPool.load(ContextStore.getContext(), R.raw.jammer_work, 1);
            haveDroneSoundId = soundPool.load(ContextStore.getContext(), R.raw.hava_drone, 1);
            createFencePointSoundId = soundPool.load(ContextStore.getContext(), R.raw.create_fence_point, 1);
            createFenceFinishSoundId = soundPool.load(ContextStore.getContext(), R.raw.create_fence_finish, 1);
            haveNewVideoSoundId = soundPool.load(ContextStore.getContext(), R.raw.have_new_video, 1);
            soundPool.setOnLoadCompleteListener(new SoundPool.OnLoadCompleteListener() {
                @Override
                public void onLoadComplete(SoundPool soundPool, int sampleId, int status) {
                    isLoadSoundComplete = true;
                    XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "声音资源加载完成");
                }
            });
        }
    }

    public Vector<Integer> getStreamIDList() {
        return streamIDList;
    }

    private synchronized int startPlaySound(int soundId, boolean isLoop, boolean isCheckSwitch) {
        boolean isPlay = true;
        if (isCheckSwitch) {
            isPlay = PreferencesUtils.getSoundSwitch();
        }
        if (isLoadSoundComplete && soundPool != null && isPlay) {
            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "播放声音 | soundId:" + soundId);
            int streamID = playSound(soundId, isLoop);
            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "播放声音返回值 | streamID:" + streamID);
            if (isLoop) {
                if (!streamIDList.contains((Object) streamID)) {
                    streamIDList.add(streamID);
                }
            }
            return streamID;
        }
        return 0;
    }

    public synchronized int playSound(int soundId, boolean isLoop) {
        int loop = isLoop ? -1 : 0;
        if (isLoop) {
            if (soundId == jammerWorkSoundId) {
                loop = EXCEPTION_PLAY_COUNT;
            } else if (soundId == haveDroneSoundId) {
                loop = HAVE_DRONE_PLAY_COUNT;
            }
        }
        return soundPool.play(soundId, 1, 1, 1, loop, 1);
    }

    public synchronized int haveNewVideoStartPlay() {
        return startPlaySound(haveNewVideoSoundId, false, false);
    }

    public synchronized int createFencePointStartPlay() {
        return startPlaySound(createFencePointSoundId, false, false);
    }

    public synchronized int createFenceFinishStartPlay() {
        return startPlaySound(createFenceFinishSoundId, false, false);
    }

    public synchronized int findDroneWarningStartPlay() {
        return startPlaySound(haveDroneSoundId, true, true);
    }

    public synchronized int deviceExceptionStartPlay() {
        return startPlaySound(jammerWorkSoundId, true, true);
    }

    public synchronized void stopWarning(int streamID) {
        if (streamIDList.contains((Object) streamID)) {
            streamIDList.remove((Object) streamID);
        }
        if (soundPool != null) {
            soundPool.stop(streamID);
        }
    }

    public synchronized void stopAllSound() {
        if (soundPool != null) {
            for (int streamID : streamIDList) {
                soundPool.stop(streamID);
            }
            streamIDList.clear();
        }
    }
}
