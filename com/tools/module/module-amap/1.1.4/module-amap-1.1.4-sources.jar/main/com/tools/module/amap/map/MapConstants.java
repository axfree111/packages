package com.tools.module.amap.map;

import com.tools.module.amap.manager.UserCenter;

/**
 * Date: 2025/4/2
 * Desc:
 * <p>
 * author: jaje
 */
public class MapConstants {

    public volatile static float SHOW_TITLE_OVERLAY_LEVEL = 11.0f;

    public static boolean isShowTitleOverlay() {
        return (MapController.CURRENT_ZOOM_LEVEL < SHOW_TITLE_OVERLAY_LEVEL) ? true : false;
    }

    public static boolean needShowTitleOverlay() {
        return UserCenter.INSTANCE.isSuperUser() && isShowTitleOverlay() && LocalMapConfig.IS_SHOW_SHIP;
    }
}
