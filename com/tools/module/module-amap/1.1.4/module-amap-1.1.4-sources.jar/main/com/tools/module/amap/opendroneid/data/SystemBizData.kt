package com.tools.module.amap.opendroneid.data

import com.tools.module.amap.R
import com.tools.module.common.utils.ResourceUtil
import java.sql.Timestamp
import java.util.Locale

class SystemBizData : MessageBizData() {
    var operatorLocationType: OperatorLocationTypeEnum
    private var operatorClassificationType: OperatorClassificationTypeEnum
    private var operatorLatitude = 0.0
    private var operatorLongitude = 0.0
    var areaCount: Int = 0
    var areaRadius: Int = 0
    var areaCeiling: Double
    var areaFloor: Double
    var category: CategoryEnum

    /**
     * UA等级
     * 0：微型无人驾驶航空器
     * 1：轻型无人驾驶航空器
     * 2：小型无人驾驶航空器
     * 3：具备运行识别功能的其它无人驾驶航空器
     * 4~15：预留
     * 微轻小型无人
     */
    var uaClassValue: UAClassValueEnum
    var operatorAltitudeGeo: Double
    var systemTimestamp: Long = 0

    init {
        operatorLocationType = OperatorLocationTypeEnum.Invalid
        operatorClassificationType = OperatorClassificationTypeEnum.Undeclared
        areaCeiling = -1000.0 // -1000 is the Invalid value in the specification
        areaFloor = -1000.0 // -1000 is the Invalid value in the specification
        category = CategoryEnum.Undeclared
        uaClassValue = UAClassValueEnum.MICRO_UAV
        operatorAltitudeGeo = -1000.0 // -1000 is the Invalid value in the specification
    }

    // These apply both to operator Latitude/Longitude and to AltitudeGeo
    enum class OperatorLocationTypeEnum(val key: Int, val description: String) {
        TakeOff(0, ResourceUtil.getContent(R.string.take_off)),
        Dynamic(1, ResourceUtil.getContent(R.string.dynamic)),  // Live GNSS Location
        Fixed(2, ResourceUtil.getContent(R.string.fixed)),  // Fixed Location
        Invalid(3, ResourceUtil.getContent(R.string.invalid));

        companion object {
            fun keyOfType(key: Int): OperatorLocationTypeEnum {
                for (type in OperatorLocationTypeEnum.entries) {
                    if (type.key == key) {
                        return type
                    }
                }
                return OperatorLocationTypeEnum.Invalid
            }
        }
    }

    fun setOperatorLocationType(operatorLocationType: Int) {
        this.operatorLocationType = OperatorLocationTypeEnum.keyOfType(operatorLocationType)
    }

    /**
     * 无人驾驶航空器分类归属区域
     * 0：未定义
     * 1: EU
     * 2：中国
     * 3-7：预留
     */
    enum class OperatorClassificationTypeEnum(val key: Int, val description: String) {
        Undeclared(0, ResourceUtil.getContent(R.string.undeclared)),
        EU(1, ResourceUtil.getContent(R.string.eu)),
        China(2, ResourceUtil.getContent(R.string.china));

        companion object {
            fun keyOfType(key: Int): OperatorClassificationTypeEnum {
                for (type in OperatorClassificationTypeEnum.entries) {
                    if (type.key == key) {
                        return type
                    }
                }
                return OperatorClassificationTypeEnum.Undeclared
            }
        }
    }

    fun getOperatorClassificationType(): OperatorClassificationTypeEnum {
        return operatorClassificationType
    }

    fun setOperatorClassificationType(operatorClassificationType: Int) {
        this.operatorClassificationType = OperatorClassificationTypeEnum.keyOfType(operatorClassificationType)
    }

    fun setOperatorLatitude(operatorLatitude: Double) {
        var operatorLatitude = operatorLatitude
        if (operatorLatitude < -90 || operatorLatitude > 90) {
            operatorLatitude = 0.0
            // both equal to zero is defined in the specification as the Invalid value
            this.operatorLongitude = 0.0
        }
        this.operatorLatitude = operatorLatitude
    }

    fun getOperatorLatitude(): Double {
        return operatorLatitude
    }

    fun getOperatorLatitudeAsString(): String {
        if (operatorLatitude == 0.0 && operatorLongitude == 0.0) return ResourceUtil.getContent(R.string.unknown)
        return String.format(Locale.US, "%3.7f", operatorLatitude)
    }

    fun setOperatorLongitude(operatorLongitude: Double) {
        var operatorLongitude = operatorLongitude
        if (operatorLongitude < -180 || operatorLongitude > 180) {
            this.operatorLatitude = 0.0
            operatorLongitude =
                0.0 // both equal to zero is defined in the specification as the Invalid value
        }
        this.operatorLongitude = operatorLongitude
    }

    fun getOperatorLongitude(): Double {
        return operatorLongitude
    }

    fun getOperatorLongitudeAsString(): String {
        if (operatorLatitude == 0.0 && operatorLongitude == 0.0) return ResourceUtil.getContent(R.string.unknown)
        return String.format(Locale.US, "%3.7f", operatorLongitude)
    }

    val areaRadiusAsString: String
        get() = String.format(Locale.US, "%d m", areaRadius)

    private fun getAltitudeAsString(altitude: Double): String {
        if (altitude == -1000.0) return ResourceUtil.getContent(R.string.unknown)
        return String.format(Locale.US, "%3.1f m", altitude)
    }

    fun getAreaCeilingAsString(): String {
        return getAltitudeAsString(areaCeiling)
    }

    fun getAreaFloorAsString(): String {
        return getAltitudeAsString(areaFloor)
    }

    enum class CategoryEnum(val key: Int, val description: String) {
        Undeclared(0, ResourceUtil.getContent(R.string.undeclared)),
        EUOpen(1, ResourceUtil.getContent(R.string.eu_open)),
        EUSpecific(2, ResourceUtil.getContent(R.string.eu_specific)),
        EUCertified(3, ResourceUtil.getContent(R.string.eu_certified));

        companion object {
            fun keyOfType(key: Int): CategoryEnum {
                for (type in CategoryEnum.entries) {
                    if (type.key == key) {
                        return type
                    }
                }
                return CategoryEnum.Undeclared
            }
        }

    }

    fun setCategory(category: Int) {
        this.category = CategoryEnum.keyOfType(category)
    }

    enum class UAClassValueEnum(val key: Int, val description: String) {
        MICRO_UAV(0, ResourceUtil.getContent(R.string.micro_uav)),
        LIGHT_UAV(1, ResourceUtil.getContent(R.string.micro_uav)),
        SMALL_UAV(2, ResourceUtil.getContent(R.string.micro_uav)),
        IDENTIFIED_UAV(3, ResourceUtil.getContent(R.string.micro_uav)),
        HIGH_CLASS_UAV(15, ResourceUtil.getContent(R.string.high_class_uav)),
        Undeclared(16, ResourceUtil.getContent(R.string.undeclared));

        companion object {
            fun keyOfType(key: Int): UAClassValueEnum {
                for (type in UAClassValueEnum.entries) {
                    if (type.key == key) {
                        return type
                    }
                }
                return UAClassValueEnum.Undeclared
            }
        }
    }

    fun setUAClassValue(uaClassValue: Int) {
        this.uaClassValue = UAClassValueEnum.keyOfType(uaClassValue)
    }

    fun getOperatorAltitudeGeoAsString(): String {
        return getAltitudeAsString(operatorAltitudeGeo)
    }

    fun getSystemTimestampAsString(): String {
        if (systemTimestamp == 0L) return ResourceUtil.getContent(R.string.unknown)
        val time = Timestamp((1546300800L + systemTimestamp) * 1000)
        return time.toString()
    }
}