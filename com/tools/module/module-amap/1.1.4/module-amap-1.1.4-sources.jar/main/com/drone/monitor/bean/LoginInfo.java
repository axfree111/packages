package com.drone.monitor.bean;

import com.drone.monitor.bean.custom.MyObject;

import java.util.List;

/**
 * Created by jiajiecsf on 2/26/21.
 */
public class LoginInfo extends MyObject {

    public RoleInfo role;
    public UserInfo userinfo;
    public List<ChannelsInfo> channels;
}
