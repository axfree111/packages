package com.tools.module.amap.permission

import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.TextUtils
import android.text.style.ForegroundColorSpan
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.animation.AlphaAnimation
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.tools.module.amap.R
import com.tools.module.amap.utils.StatusBarUtil
import com.tools.module.amap.view.dialog.ConfirmDialog
import com.tools.module.common.utils.AppUtil
import com.tools.module.common.utils.ResourceUtil

/**
 * 检查权限时，如果上下文对象不是activity,需借助透明activity实现回调
 */
class PermissionActivity : AppCompatActivity() {
    private var mRequestPermissions: Array<String>? = null

    private var mPermissionDialog: ConfirmDialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        overridePendingTransition(0, 0)
        StatusBarUtil.setTranslucentStatus(this)
        StatusBarUtil.setStatusBarColor(this, 0x000000)
        if (intent != null) {
            val bundle = intent.extras
            if (bundle != null) {
                mRequestPermissions = bundle.getStringArray(REQUEST_PERMISSION)
                if (mRequestPermissions != null && mRequestPermissions!!.size > 0) {
                    ActivityCompat.requestPermissions(
                        this,
                        mRequestPermissions!!, REQUEST_PERMISSION_CODE
                    )
                    return
                }
            }
            finish()
        }
    }

    private fun doFinishForGranted() {
        Log.v(TAG, "blued permission Granted.")
        closePage()
        PermissionManager.permissionsGranted()
    }

    private fun doFinishForDenied() {
        Log.v(TAG, "blued permission Denied.")
        closePage()
        mRequestPermissions?.let { PermissionManager.permissionsDenied(*it) }
    }

    private fun closePage() {
        if (mPermissionDialog != null) {
            mPermissionDialog!!.dismiss()
        }
        overridePendingTransition(0, 0)
        finish()
    }


    //权限回调
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        Log.i(
            TAG,
            "onRequestPermissionsResult:$requestCode"
        )

        if (permissions.size == 0) {
            doFinishForGranted()
            return
        }
        val granted = ArrayList<String>()
        val denied = ArrayList<String>()
        val permissionStillNotGet = ArrayList<String>()
        for (i in permissions.indices) {
            val perm = permissions[i]
            if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                granted.add(perm)
                Log.v(
                    TAG,
                    "requestCode PERMISSION_GRANTED: $perm"
                )
            } else {
                denied.add(perm)
                Log.v(
                    TAG,
                    "equestCode PERMISSION_DENIED: $perm"
                )
            }
            if (!PermissionManager.hasPermissions(permissions[i])) {
                permissionStillNotGet.add(perm)
            }
        }

        if (!granted.isEmpty() && denied.isEmpty() && permissionStillNotGet.isEmpty()) {
            doFinishForGranted()
            return
        }

        if (!denied.isEmpty() || !permissionStillNotGet.isEmpty()) {
            val permissionRequest = ArrayList<String>()
            permissionRequest.addAll(denied)

            for (per in permissionStillNotGet) { //小米手机特别处理，二逼的小米
                var isAdd = true
                for (perDenied in denied) {
                    if (TextUtils.equals(per, perDenied)) {
                        isAdd = false
                    }
                }
                if (isAdd) {
                    permissionRequest.add(per)
                    Log.v(
                        TAG,
                        "blued permission permissionStillNotGet: $per"
                    )
                }
            }

            mRequestPermissions = permissionRequest.toTypedArray<String>()

            showSettingAlertDialog(permissionRequest)
        }
    }

    //权限说明
    private fun showSettingAlertDialog(perms: ArrayList<String>) {
        if (mPermissionDialog != null && mPermissionDialog!!.isShowing) {
            return
        }

        val keyword = PermissionManager.getReguestPermissionKeywords(this, perms)
        val appName = AppUtil.getAppName(this)
        val content = ResourceUtil.getContent(R.string.permission, appName, keyword)

        val inflater = LayoutInflater.from(this)
        val rootview = inflater.inflate(R.layout.dialog_permission, null)
        rootview.visibility = View.GONE

        val titleView = rootview.findViewById<View>(R.id.tv_title) as TextView
        titleView.setText(R.string.permission_title)

        val cancelView = rootview.findViewById<View>(R.id.tv_cancel) as TextView
        cancelView.setText(R.string.permission_cancel)
        cancelView.setOnClickListener { doFinishForDenied() }

        val continueView = rootview.findViewById<View>(R.id.tv_ok) as TextView
        continueView.setText(R.string.permission_setting)
        continueView.setOnClickListener {
            if (mPermissionDialog != null && mPermissionDialog!!.isShowing) {
                mPermissionDialog!!.dismiss()
            }
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            val uri = Uri.fromParts("package", packageName, null)
            intent.setData(uri)
            startActivityForResult(intent, SYSTEM_PERMISSION_SETTING)
        }

        val msgTv = rootview.findViewById<View>(R.id.tv_des) as TextView
        if (!TextUtils.isEmpty(content) && !TextUtils.isEmpty(keyword)) {
            val index = content.indexOf(keyword)
            if (index >= 0) {
                val style = SpannableStringBuilder(content)
                style.setSpan(
                    ForegroundColorSpan(Color.parseColor("#2593f4")), index, index + keyword.length,
                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                )
                msgTv.text = style
            } else {
                msgTv.text = content
            }
        } else {
            msgTv.text = content
        }

        mPermissionDialog = ConfirmDialog(this)
        mPermissionDialog!!.setCancelable(false)
        mPermissionDialog!!.setContentView(rootview)
        mPermissionDialog!!.setOnOperationListener { what ->
            if (what == ConfirmDialog.Operation.CANCEL) {
                doFinishForDenied()
            }
        }
        mPermissionDialog!!.show()

        rootview.visibility = View.VISIBLE
        val alphaAnimation = AlphaAnimation(0f, 1f)
        alphaAnimation.fillAfter = false
        alphaAnimation.duration = 300
        rootview.animation = alphaAnimation
        alphaAnimation.start()
    }

    public override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        Log.v(TAG, "requestCode:$requestCode")
        if (requestCode == SYSTEM_PERMISSION_SETTING) {
            mRequestPermissions?.let {
                if (PermissionManager.hasPermissions(*it)) {
                    doFinishForGranted()
                } else {
                    doFinishForDenied()
                }
            }
        }
        super.onActivityResult(requestCode, resultCode, data)
    }


    companion object {
        private const val TAG = "PermissionActivity"

        private const val SYSTEM_PERMISSION_SETTING = 2001
        private const val REQUEST_PERMISSION_CODE = 2002

        const val REQUEST_PERMISSION: String = "com.blued.android.framework.reqeust_permission_code"
    }
}
