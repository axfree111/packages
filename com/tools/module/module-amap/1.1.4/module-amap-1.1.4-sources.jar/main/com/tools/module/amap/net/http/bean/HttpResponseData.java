package com.tools.module.amap.net.http.bean;

import java.util.List;

public class HttpResponseData<T> extends HttpBaseResponseData {
    public List<T> data;

    @Override
    public String toString() {
        return "HttpResponseData{" +
                "code=" + code +
                ", message='" + message + '\'' +
                ", data=" + data +
                '}';
    }
}