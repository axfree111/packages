/*
    Android Asynchronous Http Client
    Copyright (c) 2011 James Smith <james@loopj.com>
    http://loopj.com

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

package com.tools.module.amap.net.http.response;

import android.os.Message;
import android.os.SystemClock;
import android.text.TextUtils;

import com.tools.module.amap.net.StatusCode;
import com.tools.module.amap.net.http.request.HttpRequestWrapper;
import com.tools.module.amap.net.http.request.IRequestHost;
import com.drone.monitor.bean.ERROR;
import com.tools.module.common.utils.AppUtil;
import com.tools.module.common.utils.HandlerUtils;
import com.tools.module.common.utils.XAppLogger;

import java.io.IOException;

import okhttp3.Response;
import okhttp3.ResponseBody;


public abstract class AbstractHttpResponseHandler<T> {
    private static final String TAG = "原始返回数据 ";
    protected static final int SUCCESS_MESSAGE = 0;
    protected static final int FAILURE_MESSAGE = 1;
    protected static final int START_MESSAGE = 2;
    protected static final int FINISH_MESSAGE = 3;
    protected static final int PROGRESS_MESSAGE = 4;
    protected static final int CANCEL_MESSAGE = 5;

    /**
     * 响应状态
     */
    private enum ResponseState {
        INIT,
        START,
        END,
        FINISHED
    }

    protected HttpRequestWrapper requestWrapper;
    private boolean uiCallback;
    private ResponseState state = ResponseState.INIT;
    private Object extraData;

    // 用于统计数据
    private long startTime = 0;

    /**
     * Creates a new AsyncHttpResponseHandler
     */
    public AbstractHttpResponseHandler() {
        this(false);
    }

    public void setData(Object extraData) {
        this.extraData = extraData;
    }

    public Object getData() {
        return this.extraData;
    }

    /**
     * Creates a new AsyncHttpResponseHandler
     */
    public AbstractHttpResponseHandler(boolean uiCallback) {
        this.uiCallback = uiCallback;
    }

    /**
     * Fired when the request is started, override to handle in your own code
     */
    public abstract void onStart();

    /**
     * Fired in all cases when the request is finished, after both success and failure, override to handle in your own code
     */
    public abstract void onFinish();

    /**
     * whether accept the content, if false, onCancel() will be called
     * after onStart(), and before onSuccess()
     *
     * @return
     */
    public boolean onAccept(int statusCode, long contentLength) {
        return true;
    }

    /**
     * 获取返回数据类型, 如string, file, binary
     *
     * @return
     */
    public String getResponseType() {
        return "";
    }

    /**
     * 获取返回值的长度
     *
     * @param content
     * @return
     */
    public long getResponseLength(T content) {
        return 0;
    }

    /**
     * Fired when a request returns successfully, override to handle in your own code
     *
     * @param statusCode the status code of the response
     * @param content    the body of the HTTP response from the server
     */
    public abstract void onSuccess(int statusCode, T content);

    /**
     * Fired when a request fails to complete, override to handle in your own code
     *
     * @param error   the underlying cause of the failure
     * @param content the response body, if any
     */
    public void onFailure(Throwable error, int statusCode, T content) {
        // By default, call the deprecated onFailure(Throwable) for compatibility
    }

    /**
     * progress interface
     *
     * @param percent
     * @param byteCount
     */
    public abstract void onProgress(int percent, int byteCount);

    /**
     * 取消执行
     *
     * @return
     */
    public abstract void onCancel();

    public HttpRequestWrapper getRequestWrapper() {
        return requestWrapper;
    }

    //
    // Pre-processing of messages (executes in background threadpool thread)
    //

    protected abstract T parseResponse(int statusCode, ResponseBody body) throws IOException;

    public void sendSuccessMessage(String url, int statusCode, T responseBody) {
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, TAG + "success, url:" + url + ", statusCode:" + statusCode + ", responseBody:" + responseBody);
        sendMessage(obtainMessage(SUCCESS_MESSAGE, new Object[]{url, Integer.valueOf(statusCode), responseBody}));
    }

    public void sendFailureMessage(String url, Throwable e, int statusCode, T responseBody) {
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, TAG + "fail, url:" + url + ", e:" + AppUtil.getExceptionString(e) + ", statusCode:" + statusCode + ", responseBody:" + responseBody);
        sendMessage(obtainMessage(FAILURE_MESSAGE, new Object[]{url, e, statusCode, responseBody}));
    }

    public void sendStartMessage() {
        sendMessage(obtainMessage(START_MESSAGE, null));
    }

    public void sendFinishMessage() {
        sendMessage(obtainMessage(FINISH_MESSAGE, null));
    }

    public void sendCancelMessage(String cancelReason) {
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, TAG + "cancel, reason:" + cancelReason);
        sendMessage(obtainMessage(CANCEL_MESSAGE, null));
    }

    public void sendProgressMessage(int percent, int byteCount) {
        sendMessage(obtainMessage(PROGRESS_MESSAGE, new Object[]{percent, byteCount}));
    }
    //
    // Pre-processing of messages (in original calling thread, typically the UI thread)
    //

    protected void handleStartMessage() {
        startTime = SystemClock.uptimeMillis();
        state = ResponseState.START;
        if (requestWrapper == null || requestWrapper.getRequestHost() == null || requestWrapper.getRequestHost().isActive()) {
            onStart();
        }
    }

    protected void handleProgressMessage(int percent, int byteCount) {
        if (requestWrapper == null || requestWrapper.getRequestHost() == null || requestWrapper.getRequestHost().isActive()) {
            onProgress(percent, byteCount);
        }
    }

    protected void handleSuccessMessage(String url, int statusCode, T responseBody) {
        state = ResponseState.END;
        if (requestWrapper == null || requestWrapper.getRequestHost() == null || requestWrapper.getRequestHost().isActive()) {
            onSuccess(statusCode, responseBody);
        }

    }

    protected void handleFailureMessage(String url, Throwable e, int statusCode, T responseBody) {
        state = ResponseState.END;
        if (requestWrapper == null || requestWrapper.getRequestHost() == null || requestWrapper.getRequestHost().isActive()) {
            onFailure(e, statusCode, responseBody);
        }
    }

    protected void handleCancelMessage() {
        state = ResponseState.END;
        if (requestWrapper == null || requestWrapper.getRequestHost() == null || requestWrapper.getRequestHost().isActive()) {
            onCancel();
        }
    }

    protected void handleFinishMessage() {
        if (state != ResponseState.END) {
            String url = "";
            if (requestWrapper != null) {
                url = requestWrapper.getRealUrl();
            }
            handleFailureMessage(url, null, 0, null);
        }
        state = ResponseState.FINISHED;
        if (requestWrapper == null || requestWrapper.getRequestHost() == null || requestWrapper.getRequestHost().isActive()) {
            onFinish();
        }
    }

    /**
     * 是否已取消
     *
     * @return
     */
    public boolean isCancelled() {
        if (Thread.currentThread().isInterrupted()) {
            return true;
        }
        if (requestWrapper != null) {
            IRequestHost requestHost = requestWrapper.getRequestHost();
            if (requestHost != null) {
                return !requestHost.isActive();
            }
        }
        return false;
    }

    // Methods which emulate android's Handler and Message methods
    protected void handleMessage(Message msg) {
        Object[] response;

        switch (msg.what) {
            case SUCCESS_MESSAGE:
                response = (Object[]) msg.obj;
                handleSuccessMessage((String) response[0], ((Integer) response[1]).intValue(), (T) response[2]);
                break;
            case FAILURE_MESSAGE:
                response = (Object[]) msg.obj;
                handleFailureMessage((String) response[0], (Throwable) response[1], ((Integer) response[2]).intValue(), (T) response[3]);
                break;
            case START_MESSAGE:
                handleStartMessage();
                break;
            case FINISH_MESSAGE:
                handleFinishMessage();
                break;
            case PROGRESS_MESSAGE:
                response = (Object[]) msg.obj;
                handleProgressMessage(((Integer) response[0]).intValue(), ((Integer) response[1]).intValue());
                break;
            case CANCEL_MESSAGE:
                handleCancelMessage();
                break;
            default:
                // unknown msg type
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_ERROR, TAG + "unknown msg:" + msg);
                handleCancelMessage();
                break;
        }
    }

    protected void sendMessage(final Message msg) {
        if (this.uiCallback) {
            HandlerUtils.getUIHandler().post(new Runnable() {
                @Override
                public void run() {
                    handleMessage(msg);
                }
            });
        } else {
            handleMessage(msg);
        }
    }

    protected Message obtainMessage(int responseMessage, Object response) {
        Message msg;
        if (this.uiCallback) {
            msg = HandlerUtils.getUIHandler().obtainMessage(responseMessage, response);
        } else {
            msg = Message.obtain();
            msg.what = responseMessage;
            msg.obj = response;
        }
        return msg;
    }

    // Interface to AsyncHttpRequest
    public void sendResponseMessage(String url, Response response) {
        if (response == null) {
            sendFailureMessage(url, new Exception("response is null!"), StatusCode.EMPTY_RESPONSE, null);
            return;
        }

        ResponseBody body = response.body();
        int statusCode = response.code();
        long entityLength = (body != null) ? body.contentLength() : 0;
        if (!onAccept(statusCode, entityLength)) {
            sendCancelMessage("response donot accept, statusCode:" + statusCode + ", entityLength:" + entityLength);
            return;
        }
        T responseBody = null;
        IOException e = null;
        try {
            responseBody = parseResponse(statusCode, body);
        } catch (IOException ex) {
            e = ex;
        }
        if (e != null) {
            if (statusCode == ERROR.SUSSES.getCode()) {
                statusCode = StatusCode.getIOExceptionStatusCode(e);
            }
            sendFailureMessage(url, e, statusCode, responseBody);
        } else {
            if (statusCode != ERROR.SUSSES.getCode()) {
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_ERROR, TAG + "status code is " + statusCode);
                Exception failException = TextUtils.isEmpty(response.message()) ? null : new Exception(response.message());
                sendFailureMessage(url, failException, statusCode, responseBody);
            } else {
                sendSuccessMessage(url, statusCode, responseBody);
            }
        }
    }
}
