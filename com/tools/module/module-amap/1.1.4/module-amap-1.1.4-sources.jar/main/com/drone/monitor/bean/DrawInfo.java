package com.drone.monitor.bean;

import android.text.TextUtils;

import com.drone.monitor.bean.custom.MyArrayList;
import com.drone.monitor.bean.custom.MyLatLng;
import com.drone.monitor.bean.custom.MyObject;
import com.google.gson.reflect.TypeToken;
import com.tools.module.common.utils.GsonUtils;

import java.util.Date;
import java.util.List;

public class DrawInfo extends MyObject {

    public int id;
    public Date gmtCreate;
    public Date gmtModified;
    public String boardUrl;
    public String ossName;
    public String boardDetail;
    public String state;
    public int mid;
    public String name;

    public BoardDetail getBoardDetail() {

        BoardDetail result = GsonUtils.getGson().fromJson(boardDetail, new TypeToken<BoardDetail>() {
        }.getType());
        return result;
    }

    public void setBoardDetail(String boardDetail) {
        this.boardDetail = boardDetail;
    }

    public void setBoardDetail(BoardDetail boardDetail) {
        this.boardDetail = GsonUtils.getGson().toJson(boardDetail);
    }

    public static class BoardDetail extends MyObject {
        // 地图状态，中心经纬度和当前zoom大小
        public MapConfig mapConfig;
        public List<DataConfig> dataConfig;

        public static class DataConfig extends MyObject {
            public String type;
            public ShapeOption shapeOptions;

            public static class ShapeOption extends MyObject {
                public int type;
                // 经纬度
                public double latitude;
                public double longitude;
                // 多边形路径
                public MyArrayList<Path> path;
                // 矩形的西南和东北经纬度
                public MyLatLng southWest;
                public MyLatLng northeEast;
                // 椭圆的半径，第一位大半径，第二位小半径
                public double[] radius;

                // 填充颜色
                private String fillColor;
                // 线的颜色
                private String lineColor;//Color.parseColor(“#6495ED”)

                // 手绘路径
                public List<MyLatLng> handWritePath;

                // 直线
                public List<MyLatLng> linePath;

                public String getFillColor() {
                    if (TextUtils.isEmpty(fillColor)) {
                        return fillColor = "#00000000";
                    }
                    return fillColor;
                }

                public void setFillColor(String fillColor) {
                    this.fillColor = fillColor;
                }

                public String getLineColor() {
                    if (TextUtils.isEmpty(lineColor)) {
                        return lineColor = "#000000";
                    }
                    return lineColor;
                }

                public void setLineColor(String lineColor) {
                    this.lineColor = lineColor;
                }

                public static class Path extends MyObject {
                    public double Q;
                    public double L;
                    public double lng;
                    public double lat;
                }
            }
        }

        public static class MapConfig extends MyObject {
            // 中心经纬度
            public MyLatLng center;
            // 当前zoom大小
            public float zoom;
        }

    }

    @Override
    public String toString() {
        return "DrawInfo{" +
                "id=" + id +
                ", gmtCreate=" + gmtCreate +
                ", gmtModified=" + gmtModified +
                ", boardUrl='" + boardUrl + '\'' +
                ", ossName='" + ossName + '\'' +
                ", boardDetail='" + boardDetail + '\'' +
                ", state='" + state + '\'' +
                ", mid=" + mid +
                ", name='" + name + '\'' +
                "} " + super.toString();
    }

}
