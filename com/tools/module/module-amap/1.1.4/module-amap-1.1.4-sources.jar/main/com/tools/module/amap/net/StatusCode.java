package com.tools.module.amap.net;

import java.io.EOFException;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.HttpRetryException;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.net.UnknownServiceException;
import java.util.HashMap;

import javax.net.ssl.SSLException;

public class StatusCode {

    /**
     * 普通错误
     */
    public static final int EMPTY_RESPONSE = -1001;
    public static final int EMPTY_URL      = -1002;

    /**
     * exception
     */
    public static final int EXCEPTION                = -2001;

    public static final int EXCEPTION_IO                = -2011;
    public static final int EXCEPTION_UNKNOWN_HOST      = -2012;
    public static final int EXCEPTION_UNKNOWN_SERVICE   = -2013;
    public static final int EXCEPTION_SOCKET            = -2014;
    public static final int EXCEPTION_HTTP_RETRY        = -2015;
    public static final int EXCEPTION_SSL               = -2016;
    public static final int EXCEPTION_INTERRUPTED_IO    = -2017;
    public static final int EXCEPTION_EOF               = -2018;

    public static final int ERROR_OOM = -2020;

    public static int getIOExceptionStatusCode(IOException ioe) {
        if (null != ioe) {
            if (ioe instanceof SocketException) {
                return EXCEPTION_SOCKET;
            } else if (ioe instanceof UnknownServiceException) {
                return EXCEPTION_UNKNOWN_SERVICE;
            } else if (ioe instanceof UnknownHostException) {
                return EXCEPTION_UNKNOWN_HOST;
            } else if (ioe instanceof HttpRetryException) {
                return EXCEPTION_HTTP_RETRY;
            } else if (ioe instanceof SSLException) {
                return EXCEPTION_SSL;
            } else if (ioe instanceof InterruptedIOException) {
                return EXCEPTION_INTERRUPTED_IO;
            } else if (ioe instanceof EOFException) {
                return EXCEPTION_EOF;
            }
        }
        return EXCEPTION_IO;
    }

    private static final HashMap<Integer, String> MESSAGE = new HashMap<Integer, String>();

    static {
        MESSAGE.put(0, "成功");
        MESSAGE.put(1, "短信验证码发送失败");
        MESSAGE.put(2, "短信验证码已失效，请重新获取");
        MESSAGE.put(3, "短信验证码发送频繁，请稍后再试");
        MESSAGE.put(-1, "参数非法");
        MESSAGE.put(-101, "用户注册等级错误，低等级用户无法操作上级用户");
        MESSAGE.put(-105, "该用户下有下级用户，请先转移下级用户");
        MESSAGE.put(-103, "用户不存在");
        MESSAGE.put(-105, "无效手机号");
        MESSAGE.put(-104, "需要登录");
        MESSAGE.put(-106, "无权查看该用户");
        MESSAGE.put(-201, "该设备不归属于当前用户，无法修改");
        MESSAGE.put(-202, "该设备需要先注册");
        MESSAGE.put(-301, "该设备已下线无法发送指令");
        MESSAGE.put(-601, "WEBSOCKET接口校验失败");
        MESSAGE.put(-602, "WEBSOCKET接口解析失败");
        MESSAGE.put(-603, "WEBSOCKET接口推送");
        MESSAGE.put(-701, "数据库操作失败");
        MESSAGE.put(-102, "用户已注册，请勿重复注册");
    }

    public static String getHttpFormatErrorMessage(int code, String message) {
        if (null == message) {
            message = "";
        }
        return new StringBuilder(message).append("(").append(code).append(")").toString();
    }

}
