package com.tools.module.amap.map.utils;

import com.drone.monitor.bean.custom.MyLatLng;

import java.util.List;

/**
 * Created by jiajie on 2020-01-13.
 */
public class SpatialRelationUtil {

    private SpatialRelationUtil() {
    }

    /**
     * 返回一个点是否在一个多边形区域边界或区域内
     *
     * @param mPoints 多边形坐标点列表
     * @param point   待判断点
     * @return true 多边形包含这个点,false 多边形未包含这个点。
     */
    public static boolean isPolygonContainsPoint(List<MyLatLng> mPoints, MyLatLng point) {
        long startTime = System.currentTimeMillis();
        if (mPoints != null && mPoints.size() != 0 && point != null) {
            int var2;
            for (var2 = 0; var2 < mPoints.size(); ++var2) {
                MyLatLng var1 = mPoints.get(var2);
                if (point.longitude == var1.longitude && point.latitude == var1.latitude) {
                    return true;
                }
            }
            var2 = 0;
            boolean var3 = false;
            MyLatLng var4 = null;
            MyLatLng var5 = null;
            double var6 = 0.0D;
            int var8 = mPoints.size();

            for (int var9 = 0; var9 < var8; ++var9) {
                var4 = mPoints.get(var9);
                var5 = mPoints.get((var9 + 1) % var8);
                if (var4.latitude != var5.latitude
                        && point.latitude >= Math.min(var4.latitude, var5.latitude)
                        && point.latitude < Math.max(var4.latitude, var5.latitude)) {
                    var6 = (point.latitude - var4.latitude) * (var5.longitude - var4.longitude) / (var5.latitude - var4.latitude) + var4.longitude;
                    if (var6 == point.longitude) {
                        return true;
                    }

                    if (var6 < point.longitude) {
                        ++var2;
                    }
                }
            }
            return var2 % 2 == 1;
        } else {
            return false;
        }
    }

    /**
     * 返回一个点是否在一个多边形边界上
     *
     * @param mPoints 多边形坐标点列表
     * @param point   待判断点
     * @return true 点在多边形边上,false 点不在多边形边上。
     */
    public static boolean isPointInPolygonBoundary(List<MyLatLng> mPoints, MyLatLng point) {
        for (int i = 0; i < mPoints.size(); i++) {
            MyLatLng p1 = mPoints.get(i);
            MyLatLng p2 = mPoints.get((i + 1) % mPoints.size());
            // 取多边形任意一个边,做点point的水平延长线,求解与当前边的交点个数

            // point 在p1p2 底部 --> 无交点
            if (point.latitude < Math.min(p1.latitude, p2.latitude))
                continue;
            // point 在p1p2 顶部 --> 无交点
            if (point.latitude > Math.max(p1.latitude, p2.latitude))
                continue;

            // p1p2是水平线段,要么没有交点,要么有无限个交点
            if (p1.latitude == p2.latitude) {
                double minX = Math.min(p1.longitude, p2.longitude);
                double maxX = Math.max(p1.longitude, p2.longitude);
                // point在水平线段p1p2上,直接return true
                if ((point.latitude == p1.latitude) && (point.longitude >= minX && point.longitude <= maxX)) {
                    return true;
                }
            } else { // 求解交点
                double x = (point.latitude - p1.latitude) * (p2.longitude - p1.longitude) / (p2.latitude - p1.latitude) + p1.longitude;
                if (x == point.longitude) // 当x=point.longitude时,说明point在p1p2线段上
                    return true;
            }
        }
        return false;
    }

}
