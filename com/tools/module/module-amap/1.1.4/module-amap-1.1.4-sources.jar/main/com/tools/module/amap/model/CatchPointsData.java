package com.tools.module.amap.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by jiajie on 2020-01-20.
 */
public class CatchPointsData implements Serializable {
    /**
     * 记录了半径从500到6000每隔5度角弧线上的点
     */
    public List<List<ArcPointOffset>> ARC_POINT_TABLE = new ArrayList<>();
}
