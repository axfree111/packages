package com.tools.module.amap.net.http.bean;

public class HttpResponseSingleData<T> extends HttpBaseResponseData {
    public T data;

    @Override
    public String toString() {
        return "HttpResponseData{" +
                "code=" + code +
                ", message='" + message + '\'' +
                ", data=" + data +
                '}';
    }
}