package com.tools.module.amap.opendroneid.parser

import java.nio.charset.StandardCharsets

/**
 * Date: 2025/4/5
 * Desc:
 *
 * author: jaje
 */
object DronePackData {
    private const val DELIM = Constants.DELIM

    private const val LAT_LONG_MULTIPLIER = 1e-7
    private const val SPEED_VERTICAL_MULTIPLIER = 0.5
    
    enum class Type(val id: Int) {
        BASIC_ID(0),
        LOCATION(1),
        AUTH(2),
        DESCRIPTION_ID(3),
        SYSTEM(4),
        OPERATOR_ID(5),
        MESSAGE_PACK(0xF);

        companion object {
            fun fromId(id: Int): Type? {
                return if (id == BASIC_ID.id) {
                    BASIC_ID
                } else if (id == LOCATION.id) {
                    LOCATION
                } else if (id == AUTH.id) {
                    AUTH
                } else if (id == DESCRIPTION_ID.id) {
                    DESCRIPTION_ID
                } else if (id == SYSTEM.id) {
                    SYSTEM
                } else if (id == OPERATOR_ID.id) {
                    OPERATOR_ID
                } else if (id == MESSAGE_PACK.id) {
                    MESSAGE_PACK
                } else {
                    null
                }
            }
        }
    }

    class Header {
        /**
         * openDroneId/droneId
         * 第0个字节
         */
        var type: Type? = null // (7-4)
        var version: Int = 0 // (3-0)

        override fun toString(): String {
            return "Header{" +
                    "type=" + type +
                    ", version=" + version +
                    '}'
        }
    }

    interface Payload {
        fun toCsvString(): String?
    }

    class BasicId : Payload {
        /**
         * openDroneId/droneId
         * 第1个字节
         */

        /**
         * 0：无
         * 1：设备序列号
         * 2：由 CAA 提供的 UAS 实名登记号
         * 3：UTM 任务 ID
         */
        var idType: Int = 0 // (7-4)

        /**
         * openDroneId/droneId
         * UA类型，无人机类型
         * 0：未知或未定义
         * 1：固定翼飞机
         * 2：直升飞机（或多旋翼飞机）
         * 3：自转旋翼机
         * 4：垂直起降固定翼飞机
         * 5：扑翼机
         * 6：滑翔机
         * 7：风筝
         * 8：自由气球
         * 9：系留气球
         * 10：飞艇
         * 11：自由落体/降落伞（无动力）
         * 12：火箭
         * 13：系留动力飞机
         * 14：地面障碍物
         * 15：其他
         *
         * UA 等级
         * 取值范围 0~15
         * 0：微型无人驾驶航空器
         * 1：轻型无人驾驶航空器
         * 2：小型无人驾驶航空器
         * 3：具备运行识别功能的其它无人驾驶航空器
         * 4~15：预留
         * 微
         */
        var uaType: Int = 0 // (3-0)

        /**
         * openDroneId 转string时用 UTF-8
         * DroneId 转String时用 ASCII
         */
        val uasId: ByteArray = ByteArray(Constants.MAX_ID_BYTE_SIZE)

        override fun toCsvString(): String? {
            return (idType.toString() + DELIM
                    + uaType + DELIM
                    + String(uasId) + DELIM)
        }

        override fun toString(): String {
            return "BasicId{" +
                    "idType=" + idType +
                    ", uaType=" + uaType +
                    ", uasId='" + uasId.contentToString() + '\'' +
                    '}'
        }

        companion object {
            fun csvHeader(): String {
                return ("idType" + DELIM
                        + "uaType" + DELIM
                        + "uasId" + DELIM)
            }
        }
    }

    class Location : Payload {
        // 运行状态
        /**
        * 0：未报告
        * 1：地面
        * 2：空中
        * 3：UA 为紧急状态
        * 4：运行识别功能失效（UA 为非紧急状态）
        * 5：运行识别功能失效（UA 为紧急状态）
        * 6~15：预留
        */
        var runStatus: Int = 0
        // 高度类型位 0：基于起飞地的高度  1：基于 AGL 高度
        var heightType: Int = 0
        // 航迹角 E/W 方向标志 0：<180 1：>=180
        var EWDirection: Int = 0
        // 速度乘数 0：x 0.25 1：x 0.75
        var speedMult: Int = 0
        // 航迹角
        var direction: Int = 0
            get() = calcDirection(field.toDouble(), EWDirection).toInt()
        // 地速
        var speedHori: Float = 0f
            get() = calcSpeed(field.toDouble(), speedMult).toFloat()
        // 垂直速度
        var speedVert: Float = 0f
            get() = (SPEED_VERTICAL_MULTIPLIER * field).toFloat()
        var droneLat: Double = 0.0
            get() = LAT_LONG_MULTIPLIER * field
        var droneLon: Double = 0.0
            get() = LAT_LONG_MULTIPLIER * field
        // 气压高度
        var altitudePressure: Float = 0f
            get() = calcAltitude(field)
        // 几何高度
        var altitudeGeodetic: Float = 0f
            get() = calcAltitude(field)
        // 距离地面高度
        var height: Float = 0f
            get() = calcAltitude(field)
        // 水平精度
        var horizontalAccuracy: Int = 0
        // 垂直精度
        var verticalAccuracy: Int = 0
        // 气压高度精度
        var baroAccuracy: Int = 0
        // 速度精度
        var speedAccuracy: Int = 0
        // 注意这儿的时间戳不能直接使用，需要转换
        var timestamp: Int = 0
        // 时间戳精度
        /**
         * 7-4 位：预留
         * 3-0 位：时间戳精度，0.1 秒的倍数，
         * 可表示的精度范围为 0.1 秒-1.5 秒，精
         * 度未知时置为 0
         */
        var timeAccuracy: Int = 0
            get() = (field * 0.1).toInt()

        // 业务计算距离本手机的距离
        var distance: Float = 0f

        override fun toCsvString(): String {
            return (runStatus.toString() + DELIM
                    + heightType + DELIM
                    + EWDirection + DELIM
                    + speedMult + DELIM
                    + direction + DELIM
                    + speedHori + DELIM
                    + speedVert + DELIM
                    + droneLat + DELIM
                    + droneLon + DELIM
                    + altitudePressure + DELIM
                    + altitudeGeodetic + DELIM
                    + height + DELIM
                    + horizontalAccuracy + DELIM
                    + verticalAccuracy + DELIM
                    + baroAccuracy + DELIM
                    + speedAccuracy + DELIM
                    + timestamp + DELIM
                    + timeAccuracy + DELIM
                    + distance + DELIM)
        }

        override fun toString(): String {
            return "Location{" +
                    "status=" + runStatus +
                    ", heightType=" + heightType +
                    ", EWDirection=" + EWDirection +
                    ", speedMult=" + speedMult +
                    ", direction=" + direction +
                    ", speedHori=" + speedHori +
                    ", speedVert=" + speedVert +
                    ", droneLat=" + droneLat +
                    ", droneLon=" + droneLon +
                    ", altitudePressure=" + altitudePressure +
                    ", altitudeGeodetic=" + altitudeGeodetic +
                    ", height=" + height +
                    ", horizontalAccuracy=" + horizontalAccuracy +
                    ", verticalAccuracy=" + verticalAccuracy +
                    ", baroAccuracy=" + baroAccuracy +
                    ", speedAccuracy=" + speedAccuracy +
                    ", timestamp=" + timestamp +
                    ", timeAccuracy=" + timeAccuracy +
                    ", distance=" + distance +
                    '}'
        }

        companion object {
            fun calcSpeed(value: Double, mult: Int): Double {
                return if (mult == 0) value * 0.25
                else value * 0.75 + (255 * 0.25)
            }

            fun calcDirection(value: Double, EW: Int): Double {
                return if (EW == 0) {
                    value
                } else {
                    value + 180
                }
            }

            fun calcAltitude(value: Float): Float {
                return value / 2 - 1000
            }

            fun csvHeader(): String {
                return ("status" + DELIM
                        + "heightType" + DELIM
                        + "EWDirection" + DELIM
                        + "speedMult" + DELIM
                        + "direction" + DELIM
                        + "speedHori" + DELIM
                        + "speedVert" + DELIM
                        + "droneLat" + DELIM
                        + "droneLon" + DELIM
                        + "altitudePressure" + DELIM
                        + "altitudeGeodetic" + DELIM
                        + "height" + DELIM
                        + "horizontalAccuracy" + DELIM
                        + "verticalAccuracy" + DELIM
                        + "baroAccuracy" + DELIM
                        + "speedAccuracy" + DELIM
                        + "timestamp" + DELIM
                        + "timeAccuracy" + DELIM
                        + "distance" + DELIM)
            }
        }
    }

    class Authentication : Payload {
        var authType: Int = 0
        var authDataPage: Int = 0
        var authLastPageIndex: Int = 0
        var authLength: Int = 0
        var authTimestamp: Long = 0
        val authData: ByteArray = ByteArray(Constants.MAX_AUTH_DATA)

        private fun authDataToString(): String {
            val sb = StringBuilder()
            for (authDatum in authData) {
                sb.append(String.format("%02X ", authDatum))
            }
            return sb.toString()
        }

        override fun toCsvString(): String? {
            return (authType.toString() + DELIM
                    + authDataPage + DELIM
                    + authLastPageIndex + DELIM
                    + authLength + DELIM
                    + authTimestamp + DELIM
                    + authDataToString() + DELIM)
        }

        override fun toString(): String {
            return "Authentication{" +
                    "authType=" + authType +
                    ", authDataPage=" + authDataPage +
                    ", authLastPageIndex=" + authLastPageIndex +
                    ", authLength=" + authLength +
                    ", authTimestamp=" + authTimestamp +
                    ", authData='" + authData.contentToString() + '\'' +
                    '}'
        }

        companion object {
            fun csvHeader(): String {
                return ("authType" + DELIM
                        + "authDataPage" + DELIM
                        + "authLastPageIndex" + DELIM
                        + "authLength" + DELIM
                        + "authTimestamp" + DELIM
                        + "authData" + DELIM)
            }
        }
    }

    class DescriptionID : Payload {
        var descriptionType: Int = 0
        val operationDescription: ByteArray = ByteArray(Constants.MAX_STRING_BYTE_SIZE)

        fun getDescriptionForUtf8Content(): String {
            return operationDescription.toPartString(StandardCharsets.UTF_8)
        }

        fun getDescriptionForAsciiContent(): String {
            return operationDescription.toPartString(StandardCharsets.US_ASCII)
        }

        override fun toCsvString(): String {
            return (descriptionType.toString() + DELIM
                    + String(operationDescription) + DELIM)
        }

        override fun toString(): String {
            return "DescriptionID{" +
                    "descriptionType=" + descriptionType +
                    ", operationDescription='" + operationDescription.contentToString() + '\'' +
                    '}'
        }

        companion object {
            fun csvHeader(): String {
                return ("descriptionType" + DELIM
                        + "operationDescription" + DELIM)
            }
        }
    }

    class SystemMsg : Payload {
        // 0: 起飞位置
        // 1: 动态位置
        // 2: 固定位置
        var operatorLocationType: Int = 0
        // 无人驾驶航空器等级分类归属
        // 区域及取值：
        // 0：未定义
        // 1: EU
        // 2：中国
        var operatorClassificationType: Int = 0
        var positionType: Int = 0
        var operatorLatitude: Double = 0.0
            get() = LAT_LONG_MULTIPLIER * field
        var operatorLongitude: Double = 0.0
            get() = LAT_LONG_MULTIPLIER * field
        var areaCount: Int = 0
        var areaRadius: Int = 0
            get() {
                return field * 10
            }
        var areaCeiling: Int = 0
            get() = calcAltitude(field.toDouble()).toInt()
        var areaFloor: Int = 0
            get() = calcAltitude(field.toDouble()).toInt()
        /**
         * UA 运行类别
         * 0：未定义
         * 1：开放类
         * 2：特许类
         * 3：审定类
         * 4~5：预留
         */
        var uaRunCategory: Int = 0
        /**
         * 0：微型无人驾驶航空器
         * 1：轻型无人驾驶航空器
         * 2：小型无人驾驶航空器
         * 3：具备运行识别功能的其它无人驾驶航空器
         * 4~15：预留
         * 微轻小型无人
         */
        var uaClassValue: Int = 0
        // 无人驾驶航空器操控员高度
        var operatorAltitudeGeo: Double = 0.0
            get() = calcAltitude(field)
        var systemTimestamp: Long = 0

        override fun toCsvString(): String {
            return (operatorLocationType.toString() + DELIM
                    + operatorClassificationType + DELIM
                    + positionType + DELIM
                    + operatorLatitude + DELIM
                    + operatorLongitude + DELIM
                    + areaCount + DELIM
                    + areaRadius + DELIM
                    + areaCeiling + DELIM
                    + areaFloor + DELIM
                    + uaRunCategory + DELIM
                    + uaClassValue + DELIM
                    + operatorAltitudeGeo + DELIM
                    + systemTimestamp + DELIM)
        }

        override fun toString(): String {
            return "PilotLocation{" +
                    "operatorLocationType=" + operatorLocationType +
                    ", classificationType=" + operatorClassificationType +
                    ", positionType=" + positionType +
                    ", operatorLatitude=" + operatorLatitude +
                    ", operatorLongitude=" + operatorLongitude +
                    ", areaCount=" + areaCount +
                    ", areaRadius=" + areaRadius +
                    ", areaCeiling=" + areaCeiling +
                    ", areaFloor=" + areaFloor +
                    ", category=" + uaRunCategory +
                    ", class=" + uaClassValue +
                    ", operatorAltitudeGeo=" + operatorAltitudeGeo +
                    ", systemTimestamp=" + systemTimestamp +
                    '}'
        }

        companion object {
            fun calcAltitude(value: Double): Double {
                return value / 2 - 1000
            }

            fun csvHeader(): String {
                return ("operatorLocationType" + DELIM
                        + "classificationType" + DELIM
                        + "operatorLatitude" + DELIM
                        + "operatorLongitude" + DELIM
                        + "areaCount" + DELIM
                        + "areaRadius" + DELIM
                        + "areaCeiling" + DELIM
                        + "areaFloor" + DELIM
                        + "category" + DELIM
                        + "classValue" + DELIM
                        + "operatorAltitudeGeo" + DELIM
                        + "systemTimestamp" + DELIM)
            }
        }
    }

    class OperatorID : Payload {
        var operatorIdType: Int = 0
        val operatorId: ByteArray = ByteArray(Constants.MAX_ID_BYTE_SIZE)

        override fun toCsvString(): String {
            return (operatorIdType.toString() + DELIM
                    + String(operatorId) + DELIM)
        }

        override fun toString(): String {
            return "OperatorID{" +
                    "operatorIdType=" + operatorIdType +
                    ", operatorId='" + operatorId.contentToString() + '\'' +
                    '}'
        }

        companion object {
            fun csvHeader(): String {
                return ("operatorIdType" + DELIM
                        + "operatorId" + DELIM)
            }
        }
    }

    class MessagePack : Payload {
        var messageSize: Int = 0
        var messagesLength: Int = 0
        val messages: ByteArray = ByteArray(Constants.MAX_MESSAGE_PACK_SIZE)

        override fun toString(): String {
            return "MessagePack{" +
                    "messageSize=" + messageSize +
                    ", messagesLength=" + messagesLength +
                    ", messages='" + messages.contentToString() + '\'' +
                    '}'
        }

        override fun toCsvString(): String? {
            return null
        }
    }

}