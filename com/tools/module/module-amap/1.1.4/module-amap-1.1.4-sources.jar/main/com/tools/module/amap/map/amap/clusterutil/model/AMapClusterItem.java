package com.tools.module.amap.map.amap.clusterutil.model;

import com.drone.monitor.bean.custom.MyLatLng;
import com.tools.module.amap.map.LocalMapConfig;
import com.tools.module.amap.model.base.ClusterItem;
import com.tools.module.common.annotation.NotProguard;

/**
 * Created by jiajie on 2020-03-07.
 */
@NotProguard
public class AMapClusterItem implements ClusterItem {

    private String id;
    private MyLatLng mLatLng;
    private Object object;
    private int markerType;
    private int type;
    private int status;
    private int rotateAngle;
    private boolean isCicle;
    private boolean needJumpAnimation;


    public AMapClusterItem(String id, MyLatLng latLng, int markerType, int type) {
        this.id = id;
        this.mLatLng = latLng;
        this.markerType = markerType;
        this.type = type;
    }

    public AMapClusterItem(String id, MyLatLng latLng, int markerType, int type, int status, boolean isCicle) {
        this.id = id;
        this.mLatLng = latLng;
        this.markerType = markerType;
        this.type = type;
        this.status = status;
        this.isCicle = isCicle;
    }

    public void setRotateAngle(int rotateAngle) {
        this.rotateAngle = rotateAngle;
    }

    public void setPosition(MyLatLng mLatLng) {
        this.mLatLng = mLatLng;
    }

    public void setMarkerType(int markerType) {
        this.markerType = markerType;
    }

    public void setType(int type) {
        this.type = type;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public void setCicle(boolean cicle) {
        isCicle = cicle;
    }

    public void setObject(Object object) {
        this.object = object;
    }

    public void setNeedJumpAnimation(boolean needJumpAnimation) {
        this.needJumpAnimation = needJumpAnimation;
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public MyLatLng getPosition() {
        // TODO Auto-generated method stub
        return mLatLng;
    }

    @Override
    public int zIndex() {
        return LocalMapConfig.ZINDEX_ICON;
    }

    @Override
    public int getMarkerType() {
        return markerType;
    }

    @Override
    public int getType() {
        return type;
    }

    @Override
    public int getStatus() {
        return status;
    }

    @Override
    public int getRotateAngle() {
        return rotateAngle;
    }

    @Override
    public boolean needJumpAnimation() {
        return needJumpAnimation;
    }

    @Override
    public boolean isCircle() {
        return isCicle;
    }

    @Override
    public Object getObject() {
        return object;
    }

    @Override
    public String toString() {
        return "AMapClusterItem{" +
                "id='" + id + '\'' +
                ", mLatLng=" + mLatLng +
                ", object=" + object +
                ", markerType=" + markerType +
                ", type=" + type +
                ", status=" + status +
                ", rotateAngle=" + rotateAngle +
                ", isCicle=" + isCicle +
                '}';
    }
}
