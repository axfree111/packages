package com.tools.module.amap.manager

import com.tools.module.amap.R
import com.tools.module.common.utils.ResourceUtil

/**
 * Date: 2025/4/1
 * Desc:
 *
 * author: jaje
 */
object ResourceManager {

    private val monitorIconResList: MutableList<Int> = ArrayList()

    fun getMonitorIconList(): List<Int> {
        return monitorIconResList
    }

    fun initMonitorIcon() {
        monitorIconResList.add(R.drawable.ic_disturb_car)
        monitorIconResList.add(R.drawable.ic_disturb_hand)
        monitorIconResList.add(R.drawable.ic_disturb_ship_on)
        monitorIconResList.add(R.drawable.ic_disturb_portable_hemi)
        monitorIconResList.add(R.drawable.ic_disturb_portable_omnibearing)
        monitorIconResList.add(R.drawable.ic_disturb_railway_protection)
        monitorIconResList.add(R.drawable.ic_detect_abs_b)
        monitorIconResList.add(R.drawable.ic_detect_yunshao)
        monitorIconResList.add(R.drawable.ic_detect_leida)
        monitorIconResList.add(R.drawable.ic_detect_weibo)
        monitorIconResList.add(R.drawable.ic_defense_gps)
        monitorIconResList.add(R.drawable.ic_weapon)
        monitorIconResList.add(R.drawable.ic_weapon_guangdian)
        monitorIconResList.add(R.drawable.command_center_primary)
        monitorIconResList.add(R.drawable.command_center_secondary)
        monitorIconResList.add(R.drawable.command_center_tertiary)
    }

    @kotlin.jvm.JvmField
    val DRONE_ANGLE_STRING: Array<String> = arrayOf(
        ResourceUtil.getContent(R.string.drone_angle_n),
        ResourceUtil.getContent(R.string.drone_angle_en),
        ResourceUtil.getContent(R.string.drone_angle_e),
        ResourceUtil.getContent(R.string.drone_angle_es),
        ResourceUtil.getContent(R.string.drone_angle_s),
        ResourceUtil.getContent(R.string.drone_angle_ws),
        ResourceUtil.getContent(R.string.drone_angle_w),
        ResourceUtil.getContent(R.string.drone_angle_wn)
    )

    @kotlin.jvm.JvmField
    val FREQUENCY_RANGE_INFO_TITLES: Array<String> = arrayOf(
        "   ",
        ResourceUtil.getContent(R.string.work_status),
        ResourceUtil.getContent(R.string.V),
        ResourceUtil.getContent(R.string.I),
        ResourceUtil.getContent(R.string.temperature),
        ResourceUtil.getContent(R.string.positive_power),
        ResourceUtil.getContent(R.string.reverse_power),
        ResourceUtil.getContent(R.string.swr)
    )

    @kotlin.jvm.JvmField
    val HISTORY_DATA_TITLES: Array<String> = arrayOf(
        ResourceUtil.getContent(R.string.history_data_title_id),
        ResourceUtil.getContent(R.string.history_data_title_type),
        ResourceUtil.getContent(R.string.history_data_title_info),
        ResourceUtil.getContent(R.string.title_operation)
    )
}