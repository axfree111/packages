package com.tools.module.amap.map.amap.clusterutil;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;
import android.util.LruCache;

import com.tools.module.amap.R;
import com.tools.module.amap.map.amap.AMapBitmapManager;
import com.tools.module.amap.map.amap.AMapPositionsUtils;
import com.tools.module.amap.manager.ParametersManager;
import com.tools.module.amap.map.utils.BitmapManger;
import com.tools.module.amap.map.amap.MaMapUtils;
import com.tools.module.amap.model.base.ClusterItem;
import com.amap.api.maps.AMap;
import com.amap.api.maps.model.BitmapDescriptor;
import com.amap.api.maps.model.BitmapDescriptorFactory;
import com.amap.api.maps.model.CameraPosition;
import com.amap.api.maps.model.Marker;
import com.amap.api.maps.model.MarkerOptions;
import com.amap.api.maps.model.animation.AlphaAnimation;
import com.drone.monitor.bean.custom.MyLatLng;
import com.tools.module.amap.map.MapController;
import com.tools.module.amap.utils.ComputeUtils;

import com.drone.monitor.bean.Drone;
import com.tools.module.amap.utils.PositionsUtils;
import com.tools.module.amap.view.ClusterMarkerView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;


/**
 * Created by yiyi.qi on 16/10/10.
 * 整体设计采用了两个线程,一个线程用于计算组织聚合数据,一个线程负责处理Marker相关操作
 */
public class ClusterOverlay implements AMap.OnMarkerClickListener {
    private AMap mAMap;
    private Context mContext;
    // 此key为无人机或者设备id
    private Map<String, ClusterItem> mClusterItemMap = new ConcurrentHashMap<>();
    private Map<String, List<Cluster>> mClusters = new ConcurrentHashMap<>();
    private int mClusterSize;
    private ClusterClickListener mClusterClickListener;
    private ClusterRender mClusterRender;
    private Map<String, Marker> mAddMarkers = new HashMap<>();
    private double mClusterDistance;
    private LruCache<String, BitmapDescriptor> mLruCache;
    private HandlerThread mSignClusterThread = new HandlerThread("calculateCluster");
    private Handler mSignClusterHandler;

    private AlphaAnimation mADDAnimation = new AlphaAnimation(0, 1);

    private float mPXInMeters;
    private boolean mIsCanceled = false;
    private boolean isCalculateClustering = false;

    /**
     * 构造函数,批量添加聚合元素时,调用此构造函数
     *
     * @param amap
     * @param clusterSize
     * @param context
     */
    public ClusterOverlay(AMap amap, int clusterSize, Context context) {
        //默认最多会缓存80张图片作为聚合显示元素图片,根据自己显示需求和app使用内存情况,可以修改数量
        mLruCache = new LruCache<String, BitmapDescriptor>(100) {
            protected void entryRemoved(boolean evicted, String key, BitmapDescriptor oldValue, BitmapDescriptor newValue) {
                oldValue.getBitmap().recycle();
            }
        };
        mContext = context;
        this.mAMap = amap;
        mClusterSize = clusterSize;
        mPXInMeters = mAMap.getScalePerPixel();
        mClusterDistance = mPXInMeters * mClusterSize;
        amap.setOnMarkerClickListener(this);
        initThreadHandler();
        assignClusters();
    }

    /**
     * 设置聚合点的点击事件
     *
     * @param clusterClickListener
     */
    public void setOnClusterClickListener(
            ClusterClickListener clusterClickListener) {
        mClusterClickListener = clusterClickListener;
    }

    public void removeClusterItem(ClusterItem item) {
        Message message = Message.obtain();
        message.what = SignClusterHandler.REMOVE_CALCULATE_SINGLE_CLUSTER;
        message.obj = item;
        mSignClusterHandler.sendMessage(message);
    }

    /**
     * 添加一个聚合点
     *
     * @param item
     */
    public void addClusterItem(ClusterItem item) {
        Message message = Message.obtain();
        message.what = SignClusterHandler.ADD_CALCULATE_SINGLE_CLUSTER;
        message.obj = item;
        mSignClusterHandler.sendMessage(message);
    }

    public void updateClusterItem(ClusterItem item) {
        if (mAMap == null) {
            return;
        }
        Message message = Message.obtain();
        message.what = SignClusterHandler.UPDATE_CALCULATE_SINGLE_CLUSTER;
        message.obj = item;
        mSignClusterHandler.sendMessage(message);
    }

    /**
     * 设置聚合元素的渲染样式，不设置则默认为气泡加数字形式进行渲染
     *
     * @param render
     */
    public void setClusterRenderer(ClusterRender render) {
        mClusterRender = render;
    }

    public void onEraseAll() {
        mIsCanceled = true;
        isCalculateClustering = true;
        removeAllMarker();
        mClusterItemMap.clear();
        mClusters.clear();
    }

    private void removeAllMarker() {
        Iterator<Map.Entry<String, Marker>> markerIterator = mAddMarkers.entrySet().iterator();
        while (markerIterator.hasNext()) {
            Map.Entry<String, Marker> entry = markerIterator.next();
            entry.getValue().remove();
//            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_DRONE, " removeAllMarker | " + Constants.TAG_TEST + entry.getKey() + "marker.remove()");
        }
        mAddMarkers.clear();
    }

    public void onDestroy() {
        mSignClusterHandler.removeCallbacksAndMessages(null);
        mSignClusterThread.quit();
        onEraseAll();
        mLruCache.evictAll();
    }

    //初始化Handler
    private void initThreadHandler() {
        mSignClusterThread.start();
        mSignClusterHandler = new SignClusterHandler(mSignClusterThread.getLooper());
    }

    public void onCameraChangeFinish(CameraPosition arg0) {
        mPXInMeters = mAMap.getScalePerPixel();
        mClusterDistance = mPXInMeters * mClusterSize;
        assignClusters();
    }

    //点击事件
    @Override
    public boolean onMarkerClick(Marker arg0) {
        if (mClusterClickListener == null) {
            return true;
        }
        Object object = arg0.getObject();
        if (object instanceof Cluster) {
            Cluster cluster = (Cluster) arg0.getObject();
            if (cluster != null) {
                return mClusterClickListener.onClick(arg0, cluster.getMarkerType(), cluster.getClusterItems());
            }
        } else {
            return mClusterClickListener.onClick(arg0);
        }
        return false;
    }

    /**
     * 将聚合元素添加至地图上
     */
    private void addClusterToMap(ConcurrentHashMap<String, List<Cluster>> clustersMap) {
        Iterator<Map.Entry<String, List<Cluster>>> iterator = clustersMap.entrySet().iterator();
        while (iterator.hasNext()) {
            if (mIsCanceled) {
                return;
            }
            Map.Entry<String, List<Cluster>> entry = iterator.next();
            List<Cluster> clusters = entry.getValue();
            if (clusters != null) {
                for (Cluster cluster : clusters) {
                    if (mIsCanceled) {
                        return;
                    }
                    addSingleClusterToMap(cluster);
                }
            }
        }
        isCalculateClustering = false;
    }

    /**
     * 将单个聚合元素添加至地图显示
     *
     * @param cluster
     */
    private void removeSingleClusterToMap(Cluster cluster) {
        if (cluster == null) {
            return;
        }
        Marker marker = cluster.getMarker();
        if (marker != null) {
//            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_DRONE, " removeSingleClusterToMap | " + Constants.TAG_TEST + cluster.getTemporaryId() + " remove()");
            marker.remove();
            mAddMarkers.remove(cluster.getTemporaryId());
        }
    }

    /**
     * 将单个聚合元素添加至地图显示
     *
     * @param cluster
     */
    private void addSingleClusterToMap(Cluster cluster) {
        if (cluster == null) {
            return;
        }
        if (!mAddMarkers.containsKey(cluster.getTemporaryId())) {
            MyLatLng latlng = cluster.getCenterLatLng();
            MarkerOptions markerOptions = new MarkerOptions();
            markerOptions.position(AMapPositionsUtils.transformAMapPosition(latlng));
            markerOptions.zIndex(cluster.zIndex());
            markerOptions.icon(getBitmapDes(cluster));
            Marker marker = mAMap.addMarker(markerOptions);
            if (cluster.getClusterCount() > 1) {
                marker.setObject(cluster);
            } else {
                marker.setObject(cluster.getObject());
            }
            cluster.setMarker(marker);
            mAddMarkers.put(cluster.getTemporaryId(), marker);
//            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_DRONE, "addSingleClusterToMap | " + Constants.TAG_TEST + cluster.getTemporaryId() + " marker.add()");
            if (marker != null) {
                if (cluster.getMarkerType() == Drone.MARKER_TYPE.VIDEO) {
                    if (cluster.needJumpAnimation()) {
                        MaMapUtils.getInstance().startJumpAnimation(marker);
                    } else {
                        MaMapUtils.getInstance().stopAnimation(marker);
                    }
                }
            }
        }
    }


    private void calculateClusters() {
        mIsCanceled = false;
        removeAllMarker();
        mClusters.clear();
        Iterator<Map.Entry<String, ClusterItem>> iterator = mClusterItemMap.entrySet().iterator();
        while (iterator.hasNext()) {
            if (mIsCanceled) {
                return;
            }
            Map.Entry<String, ClusterItem> entry = iterator.next();
            ClusterItem clusterItem = entry.getValue();
            // cluster聚合key
            String clusterKey = getClusterKey(clusterItem);
            if (clusterItem != null) {
                MyLatLng latlng = clusterItem.getPosition();
                if (MapController.getVisibleBounds().contains(latlng)) {
                    List<Cluster> currentClusters = mClusters.get(clusterKey);
                    if (currentClusters == null) {
                        currentClusters = new ArrayList<>();
                        mClusters.put(clusterKey, currentClusters);
                    }
                    Cluster cluster = getCluster(latlng, currentClusters);
                    if (cluster != null) {
                        cluster.addClusterItem(clusterItem);
                    } else {
                        cluster = new Cluster(clusterItem.getId(), latlng, clusterItem.getMarkerType(), clusterItem.getType(),
                                clusterItem.getStatus(), clusterItem.isCircle());
                        cluster.setObject(clusterItem.getObject());
                        cluster.addClusterItem(clusterItem);
                        currentClusters.add(cluster);
                    }
                }
            }
        }
        Message message = Message.obtain();
        message.what = SignClusterHandler.ADD_CLUSTER_LIST;
        message.obj = mClusters;
        if (mIsCanceled) {
            return;
        }
        mSignClusterHandler.sendMessage(message);
    }

    /**
     * 对点进行聚合
     */
    private void assignClusters() {
        mIsCanceled = true;
        isCalculateClustering = true;
        mSignClusterHandler.removeMessages(SignClusterHandler.CALCULATE_CLUSTER);
        mSignClusterHandler.sendEmptyMessageDelayed(SignClusterHandler.CALCULATE_CLUSTER, 300);
    }

    /**
     * 删除单个聚合
     *
     * @param clusterItem
     */
    private void removeCalculateSingleCluster(ClusterItem clusterItem) {
        MyLatLng latlng = clusterItem.getPosition();
        String clusterKey = getClusterKey(clusterItem);
        Cluster cluster = getCluster(latlng, mClusters.get(clusterKey));
        if (cluster != null) {
            Message message = Message.obtain();
            message.obj = cluster;
            if (cluster.removeClusterItem(clusterItem) >= 1) {
                // 说明聚合点还在
                message.what = SignClusterHandler.UPDATE_SINGLE_CLUSTER;
                mSignClusterHandler.removeMessages(SignClusterHandler.UPDATE_SINGLE_CLUSTER);
                mSignClusterHandler.sendMessageDelayed(message, 5);
            } else {
                // 移除聚合点
                message.what = SignClusterHandler.REMOVE_SINGLE_CLUSTER;
                mSignClusterHandler.removeMessages(SignClusterHandler.REMOVE_SINGLE_CLUSTER);
                mSignClusterHandler.sendMessageDelayed(message, 5);
            }
        }
    }

    /**
     * 在已有的聚合基础上，对单个聚合点进行位置更新
     *
     * @param clusterItem
     */
    private void updateCalculateSingleCluster(ClusterItem clusterItem) {
        if (isCalculateClustering) {
            return;
        }
        MyLatLng latlng = clusterItem.getPosition();
        if (latlng == null || !MapController.getVisibleBounds().contains(latlng)) {
            return;
        }
        String clusterKey = getClusterKey(clusterItem);
        List<Cluster> currentClusters = mClusters.get(clusterKey);
        if (currentClusters == null) {
            return;
        }
        Cluster cluster = getCluster(latlng, currentClusters);
        if (cluster != null) {
            cluster.updateClusterItem(clusterItem);
            Marker marker = mAddMarkers.get(clusterItem.getId());
            //XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_DRONE, Constants.TAG_TEST + " getMarker");
            if (marker != null) {
                if (cluster.getClusterCount() == 1) {
                    marker.setPosition(AMapPositionsUtils.transformAMapPosition(clusterItem.getPosition()));
                }
                if (clusterItem.getMarkerType() == Drone.MARKER_TYPE.VIDEO) {
                    if (clusterItem.needJumpAnimation()) {
                        MaMapUtils.getInstance().startJumpAnimation(marker);
                    } else {
                        MaMapUtils.getInstance().stopAnimation(marker);
                    }
                }
            }
        } else {
            // 说明当前位置移动到了聚合点之外，需要删除聚合点中的这个点
            for (Cluster cluster1 : currentClusters) {
                if (cluster1 != null) {
                    if (cluster1.isContainsClusterItem(clusterItem)) {
                        cluster1.removeClusterItem(clusterItem);
                        return;
                    }
                }
            }
        }
    }

    /**
     * 在已有的聚合基础上，对添加的单个元素进行聚合
     *
     * @param clusterItem
     */
    private void addCalculateSingleCluster(ClusterItem clusterItem) {
        MyLatLng latlng = clusterItem.getPosition();
        if (!PositionsUtils.inVisibleBounds(latlng)) {
            return;
        }
        String clusterKey = getClusterKey(clusterItem);
        List<Cluster> currentClusters = mClusters.get(clusterKey);
        if (currentClusters == null) {
            currentClusters = new ArrayList<>();
            mClusters.put(clusterKey, currentClusters);
        }
        Cluster cluster = getCluster(latlng, currentClusters);
        if (cluster != null) {
            cluster.addClusterItem(clusterItem);
            Message message = Message.obtain();
            message.what = SignClusterHandler.UPDATE_SINGLE_CLUSTER;

            message.obj = cluster;
            mSignClusterHandler.removeMessages(SignClusterHandler.UPDATE_SINGLE_CLUSTER);
            mSignClusterHandler.sendMessageDelayed(message, 5);
        } else {
            cluster = new Cluster(clusterItem.getId(), latlng, clusterItem.getMarkerType(), clusterItem.getType(),
                    clusterItem.getStatus(), clusterItem.isCircle());
            cluster.setObject(clusterItem.getObject());
            // 把创建的聚合类添加到聚合集合
            currentClusters.add(cluster);
            // 添加clusterItem到对应聚合中
            cluster.addClusterItem(clusterItem);
            Message message = Message.obtain();
            message.what = SignClusterHandler.ADD_SINGLE_CLUSTER;
            message.obj = cluster;
            mSignClusterHandler.sendMessage(message);
        }
    }

    /**
     * 根据一个点获取是否可以依附的聚合点，没有则返回null
     *
     * @param latLng
     * @return
     */
    private Cluster getCluster(MyLatLng latLng, List<Cluster> clusters) {
        if (clusters == null) {
            return null;
        }
        for (Cluster cluster : clusters) {
            if (isTogether(cluster.getCenterLatLng(), latLng)) {
                return cluster;
            }
        }
        return null;
    }

    private boolean isTogether(MyLatLng currentPoint, MyLatLng point) {
        double distance = ComputeUtils.getDistance(currentPoint, point);
        if (distance < mClusterDistance) {
            return true;
        }
        return false;
    }

    /**
     * 获取每个聚合点的绘制样式
     */
    private BitmapDescriptor getBitmapDes(Cluster cluster) {
        String lruCacheKey = getLruCacheKey(cluster);
        BitmapDescriptor bitmapDescriptor = mLruCache.get(lruCacheKey);
        if (bitmapDescriptor == null) {
            ClusterMarkerView markerView = new ClusterMarkerView(mContext);
            if (!TextUtils.isEmpty(lruCacheKey)) {
                if (cluster.getMarkerType() == Drone.MARKER_TYPE.VIDEO) {
                    markerView.setData(AMapBitmapManager.getInstance().getVideoMarkerResId(), cluster.getClusterCount());
                } else if (cluster.getMarkerType() == Drone.MARKER_TYPE.DRONE) {
                    markerView.setData(AMapBitmapManager.getInstance().getDroneResId(cluster.getType(), MapController.CURRENT_ZOOM_LEVEL), cluster.getClusterCount());
                }
                bitmapDescriptor = BitmapDescriptorFactory.fromView(markerView);
                if (bitmapDescriptor != null) {
                    mLruCache.put(lruCacheKey, bitmapDescriptor);
                }
            }
            if (bitmapDescriptor == null) {
                markerView.setData(R.drawable.defaultcluster, cluster.getClusterCount());
                bitmapDescriptor = BitmapDescriptorFactory.fromView(markerView);
            }
        }
        Bitmap bitmap = BitmapManger.scaleBitmap(bitmapDescriptor.getBitmap(),
                ParametersManager.getWeaponMarkerScale(MapController.CURRENT_ZOOM_LEVEL));
        bitmapDescriptor = BitmapDescriptorFactory.fromBitmap(bitmap);
        return bitmapDescriptor;
    }

    private String getLruCacheKey(Cluster cluster) {
        if (cluster != null) {
            return cluster.getMarkerType() + "_" + cluster.getType() + "_" + cluster.isCicle() + "_" + cluster.getClusterCount();
        }
        return "";
    }

    private String getClusterKey(Cluster cluster) {
        if (cluster != null) {
            return cluster.getMarkerType() + "_" + cluster.getType() + "_" + cluster.isCicle();
        }
        return "";
    }

    private String getClusterKey(ClusterItem clusterItem) {
        if (clusterItem != null) {
            return clusterItem.getMarkerType() + "_" + clusterItem.getType() + "_" + clusterItem.isCircle();
        }
        return "";
    }

    /**
     * 更新已加入地图聚合点的样式
     */
    private void updateCluster(Cluster cluster) {
        Marker marker = cluster.getMarker();
        marker.setIcon(getBitmapDes(cluster));
        //XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_DRONE, Constants.TAG_TEST + " updateCluster");
    }


//-----------------------辅助内部类用---------------------------------------------

    /**
     * 处理聚合点算法线程
     */
    class SignClusterHandler extends Handler {
        static final int CALCULATE_CLUSTER = 0;
        static final int ADD_CALCULATE_SINGLE_CLUSTER = 1;
        static final int REMOVE_CALCULATE_SINGLE_CLUSTER = 2;
        static final int UPDATE_CALCULATE_SINGLE_CLUSTER = 3;

        static final int ADD_CLUSTER_LIST = 5;

        static final int ADD_SINGLE_CLUSTER = 6;

        static final int UPDATE_SINGLE_CLUSTER = 7;

        static final int REMOVE_SINGLE_CLUSTER = 8;

        SignClusterHandler(Looper looper) {
            super(looper);
        }

        public void handleMessage(Message message) {
            switch (message.what) {
                case CALCULATE_CLUSTER:
                    calculateClusters();
                    break;
                case REMOVE_CALCULATE_SINGLE_CLUSTER:
                    ClusterItem removeItem = (ClusterItem) message.obj;
                    if (removeItem != null) {
                        if (mClusterItemMap.containsKey(removeItem.getId())) {
                            mClusterItemMap.remove(removeItem.getId());
                            removeCalculateSingleCluster(removeItem);
                        }
                    }
                    break;
                case ADD_CALCULATE_SINGLE_CLUSTER:
                    ClusterItem addItem = (ClusterItem) message.obj;
                    if (addItem != null) {
                        if (!mClusterItemMap.containsKey(addItem.getId())) {
                            mClusterItemMap.put(addItem.getId(), addItem);
                            addCalculateSingleCluster(addItem);
                        }
                    }
                    break;
                case UPDATE_CALCULATE_SINGLE_CLUSTER:
                    ClusterItem updateItem = (ClusterItem) message.obj;
                    if (updateItem != null) {
                        if (mClusterItemMap.containsKey(updateItem.getId())) {
                            mClusterItemMap.put(updateItem.getId(), updateItem);
                            updateCalculateSingleCluster(updateItem);
                        }
                    }
                    break;
                case ADD_CLUSTER_LIST:
                    ConcurrentHashMap<String, List<Cluster>> clustersMap = (ConcurrentHashMap<String, List<Cluster>>) message.obj;
                    addClusterToMap(clustersMap);
                    break;
                case ADD_SINGLE_CLUSTER:
                    Cluster cluster = (Cluster) message.obj;
                    addSingleClusterToMap(cluster);
                    break;
                case UPDATE_SINGLE_CLUSTER:
                    Cluster updateCluster = (Cluster) message.obj;
                    updateCluster(updateCluster);
                    break;
                case REMOVE_SINGLE_CLUSTER:
                    Cluster removeCluster = (Cluster) message.obj;
                    removeSingleClusterToMap(removeCluster);
                    break;
            }
        }
    }
}