package com.tools.module.amap.observer

import com.drone.monitor.bean.VideoInfo
import com.drone.monitor.bean.WarningAreaInfo
import com.tools.module.common.utils.HandlerUtils

/**
 * Date: 2025/4/3
 * Desc:
 *
 *
 * author: jaje
 */
object OperationObserver {

    private val mEditMapObservers = mutableListOf<IEditMapObserver>()

    @JvmStatic
    @Synchronized
    fun registerEditMapObserver(observer: IEditMapObserver?) {
        if (observer != null && !mEditMapObservers.contains(observer)) {
            mEditMapObservers.add(observer)
        }
    }
    @JvmStatic
    @Synchronized
    fun unRegisterEditMapObserver(observer: IEditMapObserver?) {
        if (observer != null) {
            mEditMapObservers.remove(observer)
        }
    }
    @JvmStatic
    fun notifyFinishCurrentEditFence(warningAreaInfo: WarningAreaInfo?, complete: (Boolean, WarningAreaInfo?) -> Unit) {
        HandlerUtils.getThreadHanlder().post {
            for (observer in mEditMapObservers) {
                observer.finishCurrentEditFence(warningAreaInfo, complete)
            }
        }
    }

    @JvmStatic
    fun notifyDeleteWarningArea(warningAreaInfo: WarningAreaInfo?, complete: (Boolean, WarningAreaInfo?) -> Unit) {
        HandlerUtils.getThreadHanlder().post {
            for (observer in mEditMapObservers) {
                observer.deleteWarningArea(warningAreaInfo, complete)
            }
        }
    }

    @JvmStatic
    fun notifyRemoveVideoInfo(video: VideoInfo?) {
        HandlerUtils.getThreadHanlder().post {
            for (observer in mEditMapObservers) {
                observer.removeVideoInfo(video)
            }
        }
    }

    @JvmStatic
    fun notifyHidVideoInfo(video: VideoInfo?) {
        HandlerUtils.getThreadHanlder().post {
            for (observer in mEditMapObservers) {
                observer.hidVideoInfo(video)
            }
        }
    }

    interface IEditMapObserver {
        fun finishCurrentEditFence(warningAreaInfo: WarningAreaInfo?, complete: (Boolean, WarningAreaInfo?) -> Unit)
        fun deleteWarningArea(warningAreaInfo: WarningAreaInfo?, complete: (Boolean, WarningAreaInfo?) -> Unit)
        fun removeVideoInfo(video: VideoInfo?)
        fun hidVideoInfo(video: VideoInfo?)
    }
}
