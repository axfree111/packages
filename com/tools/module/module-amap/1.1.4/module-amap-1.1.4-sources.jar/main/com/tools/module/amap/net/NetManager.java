package com.tools.module.amap.net;

import android.text.TextUtils;

import com.tools.module.common.base.AppConfig;
import com.tools.module.common.utils.GsonUtils;
import com.tools.module.common.utils.XAppLogger;
import com.tools.module.amap.map.utils.GpsUtils;
import com.drone.monitor.bean.custom.MyLatLng;
import com.tools.module.amap.map.MapController;
import com.tools.module.amap.net.http.HttpClient;
import com.tools.module.amap.net.http.OkHttpUtils;
import com.tools.module.amap.net.http.request.HttpRequestWrapper;
import com.tools.module.amap.net.http.response.HttpResponseHandler;
import com.tools.module.amap.net.webSocket.WebSocketClient;
import com.tools.module.amap.net.webSocket.WebSocketResponse;
import com.tools.module.amap.utils.ComputeUtils;
import com.tools.module.amap.utils.EncryptTool;
import com.tools.module.amap.map.LocalMapConfig;

import com.drone.monitor.bean.ChannelsInfo;
import com.drone.monitor.bean.DrawInfo;
import com.drone.monitor.bean.MonitorDevice;
import com.drone.monitor.bean.MonitorOrderDO;
import com.drone.monitor.bean.Order;
import com.drone.monitor.bean.SaveOrUpdate;
import com.drone.monitor.bean.VideoInfo;
import com.drone.monitor.bean.WarningAreaBaseInfo;

import okhttp3.OkHttpClient;

public class NetManager {

    private static final String TAG = NetManager.class.getSimpleName();

    private static String session;
    private static String token;
    private static boolean isDebug = false;

    public static void initOkHttp(String baseHost) {
        OkHttpUtils.init();
        initHost(baseHost);
    }

    public static void setDebug(boolean debug) {
        isDebug = debug;
    }

    public static boolean isDebug() {
        return isDebug;
    }

    public static OkHttpClient getOkHttpClient() {
        return OkHttpUtils.okHttpClient;
    }

    public static String getSession() {
        return session;
    }

    public static void setSession(String session) {
        NetManager.session = session;
    }


    public static String getToken() {
        return token;
    }

    public static void setToken(String token) {
        NetManager.token = token;
    }

    private static String HOST = "drone-monitor.cn";

//    112.126.101.172（公安部系统：域名drone-monitor.cn）
//    123.56.133.177（首赫销售系统shsell.drone-monitor.cn）

    private static final int PORT = 7001;

    private static String WEB_SOCKET_HOST = "ws://" + HOST;

    private static String HTTP_HOST = "http://" + HOST;

    private static String HTTPS_HOST = "https://" + HOST;

    public static void initHost(String baseHost) {
        HOST = baseHost;
        WEB_SOCKET_HOST = "ws://" + HOST;
        HTTP_HOST = "http://" + HOST;
        HTTPS_HOST = "https://" + HOST;
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "初始化Host,HOST:" + HOST);
    }

    public interface REQUST_URL {

        // 获取系统列表
        String GET_ALL_CHANNELS = HTTP_HOST + "/api/sign/get/allchannel";
        // 获取验证码
        String GET_CODE = HTTP_HOST + "/api/sign/getMsg?phoneNo=%s";
        // 验证码登录
        String CODE_LOGIN = HTTP_HOST + "/api/sign/signin?phoneNo=%s&confirmNo=%s";
        // 密码登录
        String PASSWORD_LOGIN = HTTP_HOST + "/api/sign/signin?phoneNo=%s&password=%s";
        // 重置密码
        String SET_PASSWORD = HTTP_HOST + "/api/user/saveOrUpdate";
        // 获取用户信息
        String GET_USER_INFO = HTTP_HOST + "/api/user/get_detail?phoneNo=%s";
        // 查询所有无人机信息
        String GET_DRONE = HTTP_HOST + "/api/drone/get";
        // 查询所有船舶数据
        String GET_SHIP = HTTP_HOST + "/api/drone/get/ship/byparam?minLng=%.4f&maxLng=%.4f&minLat=%.4f&maxLat=%.4f";
        // 获取民航数据
        String GET_PLANE = HTTP_HOST + "/api/drone/get/plane/byparam?minLng=%.4f&maxLng=%.4f&minLat=%.4f&maxLat=%.4f";
        // 获取民航详细数据
        String GET_PLANE_DETAIL = HTTP_HOST + "/api/drone/get/plane/detail?itemId=%s";
        // 查询无人机历史数据
        String SEARCH_ID_DRONE_HISTORY = HTTP_HOST + "/api/drone/get/byparam?id=%s&beginDate=%s&endDate=%s&pageNumber=%d&pageSize=%d";
        // 查询无人机历史数据
        String SEARCH_DRONE_HISTORY = HTTP_HOST + "/api/drone/get/id/byparam?beginDate=%s&endDate=%s";
        // 查询船舶的历史数据
        String SEARCH_SHIP_HISTORY = HTTP_HOST + "/api/drone/get/ship/point?id=%s&beginDate=%s&endDate=%s";
        // 获取所有设备信息
        String GET_ALL_MONITOR = HTTP_HOST + "/api/monitor/getAll";
        // 保存视频
        String SAVE_VIDEO = HTTP_HOST + "/api/wx/saveVideo?videoId=%s&longitude=%f&latitude=%f&phoneNo=%s";
        // 拉取视频
        String GET_VIDEO = HTTP_HOST + "/api/user/get/video?pageNumber=%d&pageSize=%d";
        // 删除视频
        String DELETE_VIDEO = HTTP_HOST + "/api/user/delete/video?videoids=%s";
        // 获取所有电子围栏
        String GET_WARNING_AREAS = HTTP_HOST + "/api/cleararea/get";
        // 增删改电子围栏
        String SAVE_WARNING_AREA = HTTP_HOST + "/api/cleararea/save";
        // 打击信息存储
        String SET_ATTACK = HTTP_HOST + "/api/monitor/setAttack";
        // 设置目的地
        String SET_DESTINATION = HTTP_HOST + "/api/monitor/setAttack";
        // TODO 预警区自动发射上报触发后台发射指令
        String AUTO_SEND_ORDER = HTTP_HOST + "/api/cleararea/autoSend";

        // 角色信息
        String GET_ROLE = HTTP_HOST + "/api/role/getRole?id=%s";
        // 获取权限
        String GET_RIGHT = HTTP_HOST + "/api/right/get?id=%s";

        // 获取战术画板
        String GET_DRAW = HTTP_HOST + "/api/draw/get?id=%s";
        // 上传战术画板
        String SAVE_ROLE = HTTP_HOST + "/api/draw/save";
        // 删除战术画板
        String DELETE_ROLE = HTTP_HOST + "/api/draw/delete?id=%s";

        // 切换系统
        String CHANGE_CHANNEL = HTTP_HOST + "/api/user/change_channel?id=%s";

        // 发送指令
        String SEND_ORDER = HTTP_HOST + "/api/order/save";

        // websocket 请求地址
        String WEB_SOCKET_URL = WEB_SOCKET_HOST + "/websocket/server/%s";

        String AMAP_SHARE_URL = "https://uri.amap.com/marker?position=%f,%f&coordinate=gaode&callnative=1";

        String GOOGLE_ROUTES_URL = "https://maps.googleapis.com/maps/api/directions/json?origin=%s&destination=%s&language=en-us&key=%s";

        // 查询所有船舶瓦片
        String GET_SHIP_TITLE_URL = HTTP_HOST + "/api/sign/get/ship/image?type=2&x=%d&y=%d&z=%d";
//    String GET_SHIP_TITLE_URL = "http://api.shipxy.com/apicall/GetShipRasterImage?k=8edbb11442564c3fb96180b7cba4156b&type=2&x=%d&y=%d&z=%d";

    }

    /**
     * origin、destination格式是"纬度,经度"拼接或者地名
     */
    public static void getGoogleRoutes(String url, HttpResponseHandler response) {
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "获取google路线 url : " + url);
        executeHttp(HttpClient.get(url, response));
    }

    /**
     * 更新打击目标
     *
     * @param taskId
     * @param monitorId
     * @param droneId
     * @param response
     */
    public static void updateAttackTarget(long taskId, String monitorId, String droneId, HttpResponseHandler response) {
        MonitorOrderDO setAttackInfo = new MonitorOrderDO();
        setAttackInfo.setId(taskId);
        setAttackInfo.setMonitorId(monitorId);
        setAttackInfo.setInfo(droneId);
        setAttackInfo.setState(MonitorDevice.ATTACK_STATE.CREATE);
        String bodyStr = GsonUtils.getGson().toJson(setAttackInfo);
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "setAttack %s: ", bodyStr);
        executeHttp(HttpClient.post(REQUST_URL.SET_ATTACK, response).setJsonBody(bodyStr));
    }

    /**
     * 取消打击目标任务
     *
     * @param monitorId
     * @param droneId
     * @param response
     */
    public static void cancelAttackTarget(long taskId, String monitorId, String droneId, HttpResponseHandler response) {
        MonitorOrderDO setAttackInfo = new MonitorOrderDO();
        setAttackInfo.setId(taskId);
        setAttackInfo.setMonitorId(monitorId);
        setAttackInfo.setInfo(droneId);
        setAttackInfo.setState(MonitorDevice.ATTACK_STATE.CANCEL);
        String bodyStr = GsonUtils.getGson().toJson(setAttackInfo);
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "setAttack %s: ", bodyStr);
        executeHttp(HttpClient.post(REQUST_URL.SET_ATTACK, response).setJsonBody(bodyStr));
    }

    /**
     * 更新目的地
     *
     * @param taskId
     * @param monitorId
     * @param latitude
     * @param longitude
     * @param response
     */
    public static void createDestination(long taskId, String monitorId, double latitude, double longitude, HttpResponseHandler response) {
        MonitorOrderDO setAttackInfo = new MonitorOrderDO();
        setAttackInfo.setId(taskId);
        setAttackInfo.setMonitorId(monitorId);
        setAttackInfo.setLatitude(latitude);
        setAttackInfo.setLongitude(longitude);
        setAttackInfo.setState(MonitorDevice.ATTACK_STATE.CREATE);
        String bodyStr = GsonUtils.getGson().toJson(setAttackInfo);
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "updateDestination %s: ", bodyStr);
        executeHttp(HttpClient.post(REQUST_URL.SET_DESTINATION, response).setJsonBody(bodyStr));
    }

    /**
     * 取消目的地任务
     *
     * @param monitorId
     * @param latitude
     * @param longitude
     * @param response
     */
    public static void cancelDestination(long taskId, String monitorId, double latitude, double longitude, HttpResponseHandler response) {
        MonitorOrderDO setAttackInfo = new MonitorOrderDO();
        setAttackInfo.setId(taskId);
        setAttackInfo.setMonitorId(monitorId);
        setAttackInfo.setLatitude(latitude);
        setAttackInfo.setLongitude(longitude);
        setAttackInfo.setState(MonitorDevice.ATTACK_STATE.CANCEL);
        String bodyStr = GsonUtils.getGson().toJson(setAttackInfo);
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "cancelDestination %s: ", bodyStr);
        executeHttp(HttpClient.post(REQUST_URL.SET_DESTINATION, response).setJsonBody(bodyStr));
    }

    /**
     * 达到目的地
     *
     * @param monitorId
     * @param latitude
     * @param longitude
     * @param response
     */
    public static void arriveDestination(long taskId, String monitorId, double latitude, double longitude, HttpResponseHandler response) {
        MonitorOrderDO setAttackInfo = new MonitorOrderDO();
        setAttackInfo.setId(taskId);
        setAttackInfo.setMonitorId(monitorId);
        setAttackInfo.setLatitude(latitude);
        setAttackInfo.setLongitude(longitude);
        setAttackInfo.setState(MonitorDevice.ATTACK_STATE.FINISH);
        String bodyStr = GsonUtils.getGson().toJson(setAttackInfo);
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "setAttack %s: ", bodyStr);
        executeHttp(HttpClient.post(REQUST_URL.SET_ATTACK, response).setJsonBody(bodyStr));
    }

    /**
     * @param response
     */
    public static void getAllChannels(HttpResponseHandler response) {
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "getAllChannels url : " + REQUST_URL.GET_ALL_CHANNELS);
        executeHttp(HttpClient.get(REQUST_URL.GET_ALL_CHANNELS, response));
    }

    /**
     * @param phoneNo
     * @param response
     */
    public static void getCode(String phoneNo, HttpResponseHandler response) {
        String url = String.format(REQUST_URL.GET_CODE, phoneNo);
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "getCode url : " + url);
        executeHttp(HttpClient.get(url, response));
    }

    /**
     * @param phoneNo
     * @param code
     * @param response
     */
    public static void onCodeLogin(String phoneNo, String code, HttpResponseHandler response) {
        String url = String.format(REQUST_URL.CODE_LOGIN, phoneNo, code);
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "登录 login url : " + url);
        executeHttp(HttpClient.get(url, response));
    }

    /**
     * @param phoneNo
     * @param psw
     * @param response
     */
    public static void onPswLogin(String phoneNo, String psw, HttpResponseHandler response) {
        String encoderPsw = EncryptTool.encoderBySHA1AndBase64(EncryptTool.encoderBySHA1AndBase64(psw));
        String url = String.format(REQUST_URL.PASSWORD_LOGIN, phoneNo, encoderPsw);
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "密码登录 login url : " + url);
        executeHttp(HttpClient.get(url, response));
    }

    /**
     * @param phoneNo
     * @param code
     * @param response
     */
    public static void onFindPswVerify(String phoneNo, String code, HttpResponseHandler response) {
        String url = String.format(REQUST_URL.CODE_LOGIN, phoneNo, code);
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "找回密码 login url : " + url);
        executeHttp(HttpClient.get(url, response));
    }

    /**
     * @param phoneNo
     * @param psw
     * @param response
     */
    public static void onSetPsw(String phoneNo, String psw, HttpResponseHandler response) {
        SaveOrUpdate body = new SaveOrUpdate();
        body.phoneNo = phoneNo;
        body.password = EncryptTool.encoderBySHA1AndBase64(EncryptTool.encoderBySHA1AndBase64(psw));
        String bodyStr = GsonUtils.getGson().toJson(body);
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "设置密码 setPsw url: %s | body: %s", REQUST_URL.SET_PASSWORD, bodyStr);
        executeHttp(HttpClient.post(REQUST_URL.SET_PASSWORD, response).setJsonBody(bodyStr));
    }

    /**
     * @param phoneNo
     * @param response
     */
    public static void getUserInfo(String phoneNo, HttpResponseHandler response) {
        String url = String.format(REQUST_URL.GET_USER_INFO, phoneNo);
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "获取用户信息 getUserInfo url : " + url);
        executeHttp(HttpClient.get(url, response));
    }

    /**
     * 获取角色数据
     *
     * @param response
     */
    public static void getRoleInfo(String roleId, HttpResponseHandler response) {
        String url = String.format(REQUST_URL.GET_ROLE, roleId);
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "获取角色信息 getRoleInfo url : " + url);
        HttpClient.execute(HttpClient.get(url, response));
    }

    /**
     * 获取权限数据
     *
     * @param response
     */
    public static void getRightInfo(int rightId, HttpResponseHandler response) {
        String url = String.format(REQUST_URL.GET_RIGHT, rightId);
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "获取权限信息 getRightInfo url : " + url);
        HttpClient.execute(HttpClient.get(url, response));
    }

    /**
     * @param response
     */
    public static void getAllMonitor(HttpResponseHandler response) {
        String url = REQUST_URL.GET_ALL_MONITOR;
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "获取所有设备数据 getAllMonitor url : " + url);
        executeHttp(HttpClient.get(url, response));
    }

    /**
     * @param response
     */
    public static void getAllDrone(HttpResponseHandler response) {
        String url = REQUST_URL.GET_DRONE;
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "获取无人机数据 getAllDrone url : " + url);
        HttpClient.execute(HttpClient.get(url, response));
    }

    /**
     * @param response
     */
    public static void getCurrentViewAllPlane(HttpResponseHandler response) {
        MyLatLng southwest = ComputeUtils.gcj_To_Wgp84(MapController.getVisibleBounds().southwest);
        MyLatLng northeast = ComputeUtils.gcj_To_Wgp84(MapController.getVisibleBounds().northeast);
        if (southwest != null && northeast != null) {
            double minLng = southwest.longitude;
            double maxLng = northeast.longitude;
            double minLat = southwest.latitude;
            double maxLat = northeast.latitude;
            searchAreaAllPlane(minLng, maxLng, minLat, maxLat, response);
        }
    }

    public static void searchAreaAllPlane(double minLng, double maxLng, double minLat, double maxLat, HttpResponseHandler response) {
        String url = String.format(REQUST_URL.GET_PLANE, minLng, maxLng, minLat, maxLat);
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "获取民航数据 searchAreaAllPlane url : " + url);
        HttpClient.execute(HttpClient.get(url, response));
    }


    /**
     * 获取航班详细数据
     *
     * @param response
     */
    public static void getPlaneDetail(String itemId, HttpResponseHandler response) {
        if (!TextUtils.isEmpty(itemId)) {
            String url = String.format(REQUST_URL.GET_PLANE_DETAIL, itemId);
            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "获取航班详细数据 getPlaneDetail url : " + url);
            HttpClient.execute(HttpClient.get(url, response));
        }
    }

    /**
     * @param response
     */
    public static void getAllShip(HttpResponseHandler response) {
        MyLatLng southwest = ComputeUtils.gcj_To_Wgp84(MapController.getVisibleBounds().southwest);
        MyLatLng northeast = ComputeUtils.gcj_To_Wgp84(MapController.getVisibleBounds().northeast);
        if (southwest != null && northeast != null) {
            double minLng = southwest.longitude;
            double maxLng = northeast.longitude;
            double minLat = southwest.latitude;
            double maxLat = northeast.latitude;
            String url = String.format(REQUST_URL.GET_SHIP, minLng, maxLng, minLat, maxLat);
            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "获取船舶数据 getAllShip url : " + url);
            HttpClient.execute(HttpClient.get(url, response));
        }
    }

    /**
     * @param response
     */
    public static void searchFromTimeAndAreaDrone(HttpResponseHandler response, String startTime, String endTime, double minLng, double maxLng, double minLat, double maxLat, double maxHeight) {
        String url = String.format(REQUST_URL.SEARCH_DRONE_HISTORY, startTime, endTime, maxHeight);
        if (maxLng != 0 && maxLat != 0) {
            double[] minLatLngs;
            double[] maxLatLngs;
            if (AppConfig.mapType == LocalMapConfig.MAP_TYPE.GOOGLE_MAP) {
                minLatLngs = new double[]{minLat, minLng};
                maxLatLngs = new double[]{maxLat, maxLng};
            } else {
                // 坐标转换把火星坐标转换成GPS84
                minLatLngs = GpsUtils.gcj02_To_Gps84(minLat, minLng);
                maxLatLngs = GpsUtils.gcj02_To_Gps84(maxLat, maxLng);
            }
            url += String.format("&minLng=%.4f&maxLng=%.4f&minLat=%.4f&maxLat=%.4f", minLatLngs[1], maxLatLngs[1], minLatLngs[0], maxLatLngs[0]);
        }
        if (maxHeight != 0) {
            url += String.format("&maxHeight=%.2f", maxHeight);
        }
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "搜索区域和时间无人机历史数据 searchFromIdDrone url : " + url);
        HttpClient.execute(HttpClient.get(url, response), 40 * 1000);
    }

    /**
     * @param response
     */
    public static void searchFromIdAndTimeDrone(HttpResponseHandler response, String itemId, String startTime, String endTime, int pageNumber, int pageSize) {
        String url = String.format(REQUST_URL.SEARCH_ID_DRONE_HISTORY, itemId, startTime, endTime, pageNumber, pageSize);
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "搜索某个无人机历史数据 searchFromIdDrone url : " + url);
        HttpClient.execute(HttpClient.get(url, response));
    }

    /**
     * @param response
     */
    public static void searchFromIdAndTimeShip(HttpResponseHandler response, String itemId, String startTime, String endTime) {
        String url = String.format(REQUST_URL.SEARCH_SHIP_HISTORY, itemId, startTime, endTime);
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "搜索某个船舶的历史数据 searchFromIdAndTimeShip url : " + url);
        HttpClient.execute(HttpClient.get(url, response));
    }

    /**
     * @param response
     */
    public static void saveVideo(VideoInfo videoInfo, String phoneNo, HttpResponseHandler response) {
        String url = String.format(REQUST_URL.SAVE_VIDEO, videoInfo.videoId,
                videoInfo.longitude, videoInfo.latitude, phoneNo);
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "保存视频 saveVideo url : " + url);
        HttpClient.execute(HttpClient.get(url, response));
    }

    /**
     * @param response
     */
    public static void deleteVideo(VideoInfo videoInfo, HttpResponseHandler response) {
        String url = String.format(REQUST_URL.DELETE_VIDEO, videoInfo.videoId);
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "删除视频 deleteVideo url : " + url);
        HttpClient.execute(HttpClient.get(url, response));
    }

    /**
     * @param response
     */
    public static void deleteWarningArea(WarningAreaBaseInfo areaBaseInfo, HttpResponseHandler response) {
        if (areaBaseInfo == null) {
            return;
        }
        WarningAreaBaseInfo body = new WarningAreaBaseInfo();
        body.copy(areaBaseInfo);
        body.state = WarningAreaBaseInfo.WARNING_AREA_STATUS_TYPE.DELETE;
        // 上传时转成wgp84
        ComputeUtils.gcj_To_Wgp84(body);
        String bodyStr = GsonUtils.getGson().toJson(body);
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "删除预警区 deleteWarningAreas  body: %s", bodyStr);
        executeHttp(HttpClient.post(REQUST_URL.SAVE_WARNING_AREA, response).setJsonBody(bodyStr));

    }

    /**
     * @param response
     */
    public static void uploadWarningArea(WarningAreaBaseInfo areaBaseInfo, HttpResponseHandler response) {
        if (areaBaseInfo == null) {
            return;
        }
        WarningAreaBaseInfo body = new WarningAreaBaseInfo();
        body.copy(areaBaseInfo);
        if (LocalMapConfig.IS_NOFLY_ZONE_SHOW_DRONE) {
            body.state = WarningAreaBaseInfo.WARNING_AREA_STATUS_TYPE.SHOW_DRONE;
        } else {
            body.state = WarningAreaBaseInfo.WARNING_AREA_STATUS_TYPE.HIDE_DRONE;
        }
        // 上传时转成wgp84
        ComputeUtils.gcj_To_Wgp84(body);
        String bodyStr = GsonUtils.getGson().toJson(body);
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "新增预警区 addWarningAreas  body: %s", bodyStr);
        executeHttp(HttpClient.post(REQUST_URL.SAVE_WARNING_AREA, response).setJsonBody(bodyStr));
    }

    /**
     * @param response
     */
    public static void getWarningAreas(HttpResponseHandler response) {
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "获取所有预警区 getWarningAreas url");
        HttpClient.execute(HttpClient.get(REQUST_URL.GET_WARNING_AREAS, response));
    }

    /**
     * 获取所有预警区数据
     *
     * @param response
     */
    public static void getVideos(int pageNumber, int videoPageSize, HttpResponseHandler response) {
        String url = String.format(REQUST_URL.GET_VIDEO, pageNumber, videoPageSize);
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "获取视频 getVideos url : " + url);
        HttpClient.execute(HttpClient.get(url, response));
    }

    /**
     * 获取战术画板数据
     *
     * @param response
     */
    public static void getDraw(HttpResponseHandler response) {
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "获取战术画板 getDraws url : " + REQUST_URL.GET_DRAW);
        HttpClient.execute(HttpClient.get(REQUST_URL.GET_DRAW, response));
    }

    /**
     * @param response
     */
    public static void uploadDraw(DrawInfo drawInfo, HttpResponseHandler response) {
        if (drawInfo == null) {
            return;
        }
        String bodyStr = GsonUtils.getGson().toJson(drawInfo);
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "新增战术图 uploadDraw  body: %s", bodyStr);
        executeHttp(HttpClient.post(REQUST_URL.SAVE_ROLE, response).setJsonBody(bodyStr));
    }

    /**
     * @param response
     */
    public static void deleteDraw(DrawInfo drawInfo, HttpResponseHandler response) {
        if (drawInfo == null) {
            return;
        }
        String url = String.format(REQUST_URL.DELETE_ROLE, drawInfo.id);
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "新增战术图 deleteDraw  url: %s", url);
        executeHttp(HttpClient.get(url, response));
    }

    /**
     * 切换系统
     *
     * @param data
     * @param response
     */
    public static void changeChannel(ChannelsInfo data, HttpResponseHandler response) {
        if (data == null) {
            return;
        }
        String url = String.format(REQUST_URL.CHANGE_CHANNEL, data.getId());
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "切换系统 changeChannel  url: %s", url);
        executeHttp(HttpClient.get(url, response));
    }

    /**
     * 发送指令
     *
     * @param response
     */
    public static void sendOrder(Order order, HttpResponseHandler response) {
        if (order == null) {
            return;
        }
        String bodyStr = GsonUtils.getGson().toJson(order);
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_HTTP, "发送指令 sendOrder  body: %s", bodyStr);
        executeHttp(HttpClient.post(REQUST_URL.SEND_ORDER, response).setJsonBody(bodyStr));
    }

    /**
     * @param phoneNo
     */
    public static void webSocketConnect(String phoneNo, WebSocketResponse wsResponse) {
        String url = String.format(REQUST_URL.WEB_SOCKET_URL, phoneNo);
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_SOCKET, "链接 webSocketConnect url : " + url);
        WebSocketClient.getInstance().connect(url, wsResponse);
    }

    /**
     * 异步执行
     *
     * @param requestWeapper
     */
    protected static void executeHttp(HttpRequestWrapper requestWeapper) {
        if (requestWeapper != null) {
            HttpClient.execute(requestWeapper);
        }
    }

    /**
     * 取消异步请求
     *
     * @param response
     */
    public static void cancelHttpRequest(HttpResponseHandler response) {
        HttpClient.cancelRequests(response);
    }

}
