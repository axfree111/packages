package com.tools.module.amap.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * （后裔）图片压缩工具
 */

public class ImgeUtil implements Handler.Callback {

    private static final String TAG = "Houyi";

    private static final int MSG_COMPRESS_SUCCESS = 0;
    private static final int MSG_COMPRESS_START = 1;
    private static final int MSG_COMPRESS_ERROR = 2;

    //压缩质量
    public final static int PHOTO_QUALITY = 90;
    //wifi环境下图片长宽
    public static final int QUALITY_WIFI = 1620;
    //如果是长图情况下的长宽
    public static final int BIG_PIC = 4096;
    ////非wifi环境下图片长宽
    //public static final int QUALITY_NOT_WIFI = 1080;
    public static final int LONG_IMAGE_SCALE = 3; // 长图判断比例

    //图片原始路径
    private String mOriginalPath;
    private String mNewPath;
    private OnCompressListener onCompressListener;

    private Handler mHandler;

    private ImgeUtil(Builder builder) {
        this.mOriginalPath = builder.originalPath;
        this.mNewPath = builder.newPath;
        this.onCompressListener = builder.onCompressListener;
        mHandler = new Handler(Looper.getMainLooper(), this);
    }

    public static Builder with() {
        return new Builder();
    }

    @Override
    public boolean handleMessage(Message msg) {

        if (onCompressListener == null) return false;

        switch (msg.what) {
            case MSG_COMPRESS_START:
                onCompressListener.onStart();
                break;
            case MSG_COMPRESS_SUCCESS:
                onCompressListener.onSuccess((String) msg.obj);
                break;
            case MSG_COMPRESS_ERROR:
                onCompressListener.onError((Throwable) msg.obj);
                break;
        }
        return false;
    }

    /**
     * 异步开启压缩
     */
    private void launch() {
        if (TextUtils.isEmpty(mOriginalPath) && onCompressListener != null) {
            onCompressListener.onError(new RuntimeException("image originalPath cannot be null"));
        }

        new Thread(new Runnable() {
            @Override
            public void run() {

                mHandler.sendMessage(mHandler.obtainMessage(MSG_COMPRESS_START));
                if (pictureProcessing(mOriginalPath, mNewPath)) {
                    mHandler.sendMessage(mHandler.obtainMessage(MSG_COMPRESS_SUCCESS, !TextUtils.isEmpty(mNewPath) ? mNewPath : mOriginalPath));
                } else {
                    mHandler.sendMessage(mHandler.obtainMessage(MSG_COMPRESS_ERROR, new RuntimeException("Image processing exception, please try again later.")));
                }

            }
        }).start();
    }

    /**
     * 同步开启压缩
     *
     * @return 是否压缩失败
     */
    private boolean get() {
        return pictureProcessing(mOriginalPath, mNewPath);
    }


    /**
     * 压缩图片
     *
     * @param originalPath 图片原始路径
     * @param newPath      压缩后的新路径
     * @return
     */
    private boolean pictureProcessing(String originalPath, String newPath) {

        //1，压缩图片（宽高和质量）
        Bitmap bitmap = imageCompression(originalPath);
        if (bitmap == null) {
            return false;
        }

        //2，旋转图片
        int degree = readPictureDegree(originalPath);
        Bitmap newBit = rotaingImageView(degree, bitmap);
        if (newBit == null) {
            newBit = bitmap;
        } else if (newBit != bitmap && bitmap != null && !bitmap.isRecycled()) {
            bitmap.recycle();
            bitmap = null;
        }
        bitmap = null;

        //3，保存图片
        boolean isSuccess = compressBmpToFile(newBit, !TextUtils.isEmpty(newPath) ? newPath : originalPath, PHOTO_QUALITY);
        if (newBit != null && !newBit.isRecycled()) {
            newBit.recycle();
            newBit = null;
        }

        return isSuccess;
    }

    private Bitmap imageCompression(String filePath) {
        Log.v(TAG, "imageCompression");

        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(filePath, opts);
        int outWidth = opts.outWidth;
        int outHeight = opts.outHeight;

        Log.v(TAG, "imageCompression outWidth：" + outWidth + " | outHeight：" + outHeight);
        int maxQuality = QUALITY_WIFI;
        if (outWidth > 0 && outHeight > 0) {
            if ((Math.max(outWidth, outHeight) / Math.min(outWidth, outHeight)) >= LONG_IMAGE_SCALE) {
                maxQuality = BIG_PIC;
            }
        }

        int widthRatio = opts.outWidth / maxQuality;
        int heightRatio = opts.outHeight / maxQuality;
        int totalRatio = (opts.outWidth * opts.outHeight) / (maxQuality * maxQuality);
        opts.inSampleSize = Math.max(widthRatio, heightRatio);
        opts.inSampleSize = Math.min(totalRatio, opts.inSampleSize);
        opts.inSampleSize = Math.max(1, opts.inSampleSize);

        opts.inJustDecodeBounds = false;

        FileInputStream fileInputStream = null;
        try {
            fileInputStream = new FileInputStream(new File(filePath));

            Bitmap bmp = null;
            int retryCount = 0;
            // 最多重试3次
            while (retryCount < 2) {
                try {
                    bmp = BitmapFactory.decodeFileDescriptor(fileInputStream.getFD(), null, opts);
                    break;
                } catch (OutOfMemoryError e) {
                    e.printStackTrace();
                    // 缩小图片分辨率再重试一次
                    opts.inSampleSize *= 2;
                    Log.v(TAG, "oom, opts.inSampleSize:" + opts.inSampleSize);
                    retryCount++;
                }
            }

            if (bmp == null) {
                return null;
            }

            if (outWidth <= maxQuality || outHeight <= maxQuality) { //防止二次图片宽高压缩
                return bmp;
            }

            return scaleImg(bmp, maxQuality);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (fileInputStream != null) {
                try {
                    fileInputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }

    public static Bitmap scalBitmap(Bitmap bmp, int scaleSize) {
        int outWidth = bmp.getWidth() / scaleSize;
        int outHeight = bmp.getHeight() / scaleSize;
        return bmp.createScaledBitmap(bmp, outWidth, outHeight, false);
    }

    public static Bitmap scaleImg(Bitmap img, float quality) {

        Log.v(TAG, "scaleImg");
        if (img == null) {
            return null;
        }
        float sHeight = 0;
        float sWidth = 0;
        Bitmap result = img;
        if (img.getWidth() >= img.getHeight() && img.getWidth() > quality) {
            sWidth = quality;
            sHeight = (quality * img.getHeight()) / img.getWidth();
            result = Bitmap.createScaledBitmap(img, (int) sWidth,
                    (int) sHeight, true);
            if (null != img && !img.isRecycled() && !img.equals(result)) {
                img.recycle();
            }
        } else if (img.getHeight() > img.getWidth()
                && img.getHeight() > quality) {
            sHeight = quality;
            sWidth = (quality * img.getWidth()) / img.getHeight();
            result = Bitmap.createScaledBitmap(img, (int) sWidth,
                    (int) sHeight, true);
            if (null != img && !img.isRecycled() && !img.equals(result)) {
                img.recycle();
            }
        }
        return result;
    }

    /**
     * 读取图片属性：旋转的角度
     *
     * @param path 图片绝对路径
     * @return degree旋转的角度
     */
    private static int readPictureDegree(String path) {
        int degree = 0;
        try {
            ExifInterface exifInterface = new ExifInterface(path);
            int orientation = exifInterface.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            switch (orientation) {
                case ExifInterface.ORIENTATION_ROTATE_90:
                    degree = 90;
                    break;
                case ExifInterface.ORIENTATION_ROTATE_180:
                    degree = 180;
                    break;
                case ExifInterface.ORIENTATION_ROTATE_270:
                    degree = 270;
                    break;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return degree;
    }

    /*
     * 旋转图片
     * @param angle
     * @param bitmap
     * @return Bitmap
     */
    private static Bitmap rotaingImageView(int angle, Bitmap bitmap) {

        Log.v(TAG, "rotaingImageView bitmap = " + bitmap);
        if (bitmap == null) return null;
        //旋转图片 动作
        Matrix matrix = new Matrix();
        matrix.postRotate(angle);
        // 创建新的图片
        Bitmap resizedBitmap = Bitmap.createBitmap(bitmap, 0, 0,
                bitmap.getWidth(), bitmap.getHeight(), matrix, true);
        return resizedBitmap;
    }

    /**
     * 保存图片
     *
     * @param bmp
     * @param filePath
     * @param scaleSize
     */
    public static boolean compressBmpToFile(Bitmap bmp, String filePath, int scaleSize) {

        Log.v(TAG, "compressBmpToFile bmp = " + bmp);
        boolean isCompressSuccess = false;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try {
            int quality = 100 / scaleSize;
            bmp = scalBitmap(bmp, scaleSize);
            isCompressSuccess = bmp.compress(Bitmap.CompressFormat.JPEG, quality,
                    baos);
            Log.v(TAG, "compressBmpToFile isCompressSuccess = " + isCompressSuccess);
            FileOutputStream fos = new FileOutputStream(filePath);
            fos.write(baos.toByteArray());
            Log.v(TAG, "compressBmpToFile baos.size() = " + baos.size());
            fos.flush();
            fos.close();
        } catch (Exception e) {
            Log.v(TAG, "compressBmpToFile e = " + e.toString());
        }
        return isCompressSuccess;
    }

    public static class Builder {
        private Context context;
        private String originalPath;
        private String newPath;
        private OnCompressListener onCompressListener;

        private ImgeUtil build() {
            return new ImgeUtil(this);
        }

        /**
         * 路径格式为：sd卡根目录+文件夹目录+文件名称+文件后缀
         * --/storage/emulated/0/test/720_1080.jpg
         *
         * @param originalPath 图片原始路径
         * @return
         */
        public Builder load(String originalPath) {
            this.originalPath = originalPath;
            return this;
        }

        /**
         * 如果图片原始路径与压缩后路径一致的话，只需传入原始路径即可
         * 路径格式为：sd卡根目录+文件夹目录+文件名称+文件后缀
         * --/storage/emulated/0/test/720_1080.jpg
         *
         * @param originalPath 图片原始路径
         * @param newPath      图片压缩后路径
         * @return
         */
        public Builder load(String originalPath, String newPath) {
            this.originalPath = originalPath;
            this.newPath = newPath;
            return this;
        }

        public Builder setCompressListener(OnCompressListener listener) {
            this.onCompressListener = listener;
            return this;
        }

        public void launch() {
            build().launch();
        }

        public boolean get() {
            return build().get();
        }
    }


    public interface OnCompressListener {

        void onStart();

        void onSuccess(String path);

        void onError(Throwable e);
    }

}

