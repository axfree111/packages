package com.drone.monitor.bean.custom;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * Created by jiajie on 2019-09-24.
 */
public class MyArrayList<E extends MyObject> extends ArrayList {

    public MyArrayList() {
        super();
    }

    public MyArrayList(int size) {
        super(size);
    }

    public String toStringConcise() {
        Iterator<E> it = iterator();
        if (!it.hasNext())
            return "[]";

        StringBuilder sb = new StringBuilder();
        sb.append('[');
        for (; ; ) {
            E e = it.next();
            sb.append(e instanceof java.util.Collection ? "(this Collection)" : e.toStringConcise());
            if (!it.hasNext())
                return sb.append(']').toString();
            sb.append(',').append(' ');
        }
    }
}
