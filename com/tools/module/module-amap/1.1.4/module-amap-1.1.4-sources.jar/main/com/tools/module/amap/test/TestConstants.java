package com.tools.module.amap.test;


import com.tools.module.common.annotation.NotProguard;

/**
 * Created by jiajie on 2020-01-14.
 */
@NotProguard
public class TestConstants {
    // 测试开关 控制是否是超级用户、是否用测试数据
    public static boolean ISTEST = true;
    public static boolean ISTEST_MAP = true;
    // 帧率测试数据
    public static final boolean TEST_FPS_DATA = false;
    public static final boolean TEST_HIDE_SHIP = false;
    public static final boolean TEST_HIDE_AIRCRAFT = false;
    // 无人机数据数据
    public static boolean TEST_DRONE = true;
    // 船舶数据
    public static final boolean TEST_SHIP = true;
    // 民航数据
    public static final boolean TEST_PLANE = true;
    // 测试无人机数量
    public static final int TEST_DRONE_NUM = 100;
    // 测试船舶数据量
    public static final int TEST_SHIP_NUM = 100;
    // 测试无人机失效更新
    public static final boolean TEST_DRONE_LOSE = true;
    // 测试更新无人机状态
    public static final boolean TEST_DRONE_STATUS_ON_OFF = true;
    // 测试更新无人机数据
    public static final boolean TEST_UPDATE_DRONE = true;
    // 更新无人机间隔时间
    public static final int TEST_UPDATE_DRONE_TIME = 5000;
    // 测试无人机入侵设备开关
    public static final boolean TEST_DRONE_RANDOM_INTRUDE = false;
    // 设备测试数据
    public static boolean TEST_MONITOR = true;
    // 测试设备数量
    public static final int TEST_MONITOR_NUM = 20;
    // 视频测试数据
    public static boolean TEST_VIDEO = false;
    // 测试视频数量
    public static final int TEST_VIDEO_NUM = 0;
    // 测试更新设备数据
    public static final boolean TEST_UPDATE_MONITOR = false;
    public static final boolean TEST_UPDATE_MONITOR_POSITION = false;
    // 测试更新频段状态
    public static final boolean TEST_UPDATE_FPS_STATUS = false;
    // 更新设备间隔时间
    public static final int TEST_UPDATE_MONITOR_TIME = 1000;
    // 测试移动设备
    public static final boolean TEST_MOVE_MONITOR = true;
    // 更新移动间隔时间
    public static final int TEST_UPDATE_MOVE_MONITOR_TIME = 5000;
    public static final String TEST_MONITOR_NAME = "test_device_";
    public static final String TEST_DRONE_NAME = "test_drone_";
    public static final String TEST_SHIP_NAME = "test_ship_";
    public static final String TEST_VIDEO_NAME = "test_video_";

    public static void resetTestParams() {
        ISTEST = false;
        ISTEST_MAP = false;
        TEST_DRONE = false;
        TEST_MONITOR = false;
    }

    public static void setSettingParams() {
        if (ISTEST) {
            TEST_DRONE = true;
            TEST_MONITOR = true;
        }
    }
}
