package com.tools.module.amap.model.base;

import com.drone.monitor.bean.custom.MyObject;

/**
 * Created by jiajiecsf on 12/27/20.
 */
public class BaseShapeModel extends MyObject {

    protected int shapeType = 0;
    public int markerType = 0;

    public int getShapeType() {
        return shapeType;
    }

    public void setShapeType(int shapeType) {
        this.shapeType = shapeType;
    }
}
