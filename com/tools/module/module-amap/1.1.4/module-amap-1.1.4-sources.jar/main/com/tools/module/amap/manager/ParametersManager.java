package com.tools.module.amap.manager;

import com.tools.module.amap.map.LocalMapConfig;
import com.tools.module.amap.map.MapController;

/**
 * Created by jiajie on 2019-12-13.
 */
public class ParametersManager {

    // 半径字体大小
    public static final int TV_SIZE_RADIUS = 15;
    // 名称字体大小
    public static final int TV_SIZE_NAME = 22;

    // 二分查找的递归实现
    public static int bsearch(float[] a, float val) {
        return bsearchInternally(a, 0, a.length, val);
    }

    public static int bsearchInternally(float[] a, int low, int high, float value) {
        if (low > high) return -1;

        int mid = low + ((high - low) >> 1);
        if (a[mid] == value) {
            return mid;
        } else if (a[mid] < value) {
            if (value - a[mid] < 0.25f) {
                return mid;
            } else {
                if (a[mid + 1] - value > 0 && a[mid + 1] - value <= 0.25f) {
                    return mid + 1;
                }
                return bsearchInternally(a, mid + 1, high, value);
            }
        } else {
            if (a[mid] - value <= 0.25f) {
                return mid;
            } else {
                if (value - a[mid - 1] > 0 && value - a[mid - 1] < 0.25f) {
                    return mid - 1;
                }
                return bsearchInternally(a, low, mid - 1, value);
            }
        }
    }

    // 二分查找的递归实现
    public static int bsearchNearby(float[] a, float val) {
        return bsearchInternallyNearby(a, 0, a.length, val);
    }

    public static int bsearchInternallyNearby(float[] a, int low, int high, float value) {
        if (low > high) return -1;

        int mid = low + ((high - low) >> 1);
        if (a[mid] == value) {
            return mid;
        } else if (a[mid] < value) {
            if (value - a[mid] < 0.5f) {
                return mid;
            } else {
                if (a[mid + 1] - value > 0 && a[mid + 1] - value <= 0.5f) {
                    return mid + 1;
                }
                return bsearchInternallyNearby(a, mid + 1, high, value);
            }
        } else {
            if (a[mid] - value <= 0.5f) {
                return mid;
            } else {
                if (value - a[mid - 1] > 0 && value - a[mid - 1] < 0.5f) {
                    return mid - 1;
                }
                return bsearchInternallyNearby(a, low, mid - 1, value);
            }
        }
    }

    public static int getNameTvScale(float currentZoomLevel) {
        float scale = currentZoomLevel / MapController.LEVELS_ZOOM_DEFAULT;
        if (scale > 1) {
            scale = 1;
        }
        return (int) (TV_SIZE_NAME * scale);
    }

    public static int getIntervalTvScale(float currentZoomLevel) {
        float scale = currentZoomLevel / MapController.LEVELS_ZOOM_DEFAULT;
        if (scale > 1) {
            scale = 1;
        }
        return (int) (TV_SIZE_RADIUS * scale);
    }

    public static float getDroneMarkerScale(float currentZoomLevel) {
        float scale;
        if (currentZoomLevel >= LocalMapConfig.LEVEL_MARKER_MAX) {
            scale = LocalMapConfig.MARKER_ICON_SCALE_MULTIPLIER;
        } else if (currentZoomLevel <= LocalMapConfig.LEVEL_MARKER_MIN) {
            scale = LocalMapConfig.LEVEL_MARKER_MIN / LocalMapConfig.LEVEL_MARKER_MAX * LocalMapConfig.MARKER_ICON_SCALE_MULTIPLIER;
        } else {
            scale = currentZoomLevel / LocalMapConfig.LEVEL_MARKER_MAX * LocalMapConfig.MARKER_ICON_SCALE_MULTIPLIER;
        }
        return scale;
    }

    public static float getWeaponMarkerScale(float currentZoomLevel) {
        float scale;
        if (currentZoomLevel >= LocalMapConfig.LEVEL_MARKER_MAX) {
            scale = LocalMapConfig.MARKER_ICON_SCALE_MULTIPLIER;
        } else if (currentZoomLevel <= LocalMapConfig.LEVEL_MARKER_MIN) {
            scale = LocalMapConfig.LEVEL_MARKER_MIN / LocalMapConfig.LEVEL_MARKER_MAX * LocalMapConfig.MARKER_ICON_SCALE_MULTIPLIER;
        } else {
            scale = currentZoomLevel / LocalMapConfig.LEVEL_MARKER_MAX * LocalMapConfig.MARKER_ICON_SCALE_MULTIPLIER;
        }
        return scale;
    }

    public static float getMarkerScale(float currentZoomLevel) {
        float scale;
        if (currentZoomLevel >= LocalMapConfig.LEVEL_MARKER_MAX) {
            scale = LocalMapConfig.MARKER_ICON_SCALE_MULTIPLIER;
        } else if (currentZoomLevel <= LocalMapConfig.LEVEL_MARKER_MIN) {
            scale = LocalMapConfig.LEVEL_MARKER_MIN / LocalMapConfig.LEVEL_MARKER_MAX * LocalMapConfig.MARKER_ICON_SCALE_MULTIPLIER;
        } else {
            scale = currentZoomLevel / LocalMapConfig.LEVEL_MARKER_MAX * LocalMapConfig.MARKER_ICON_SCALE_MULTIPLIER;
        }
        return scale;
    }
}
