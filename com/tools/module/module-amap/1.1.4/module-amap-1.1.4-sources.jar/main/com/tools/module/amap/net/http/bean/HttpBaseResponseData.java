package com.tools.module.amap.net.http.bean;

import com.drone.monitor.bean.custom.MyObject;

/**
 * Created by jiajiecsf on 2/14/21.
 */
public class HttpBaseResponseData extends MyObject {
    public int code;
    public String message;
    public int pageNumber;
    public int pageSize;
    public int pageCount;
    public int total;
}
