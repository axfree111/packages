package com.tools.module.amap.model.base;

import com.drone.monitor.bean.custom.MyLatLng;
import com.drone.monitor.bean.Drone;

import java.util.List;

/**
 * Created by jiajie on 2020-03-22.
 */
public abstract class BaseSelectAreaModel extends BaseModel {

    @Override
    public int getMarkerType() {
        return Drone.MARKER_TYPE.SELECT_AREA;
    }

    @Override
    public int getObjType() {
        return 0;
    }

    public abstract void addMarker();

    public abstract void removeAreaAndMarker();

    public abstract void updateCover();

    public abstract List<MyLatLng> getMinAndMaxLatLng();
}
