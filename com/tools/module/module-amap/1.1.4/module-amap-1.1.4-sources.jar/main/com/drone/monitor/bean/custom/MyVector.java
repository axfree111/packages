package com.drone.monitor.bean.custom;

import java.util.Vector;

/**
 * Created by jiajie on 2019-09-24.
 */
public class MyVector<E extends MyObject> extends Vector {
    public String toStringConcise() {
        return super.toString();
    }
}
