package com.tools.module.amap.net.http.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;

import com.tools.module.common.ContextStore;

public class HttpPreferences {

    private static final String PREF_NAME = "http";

    private static final String PREF_KEY_MOBILES = "mobiles";

    public static SharedPreferences httpPref;

    public static SharedPreferences getHttpPref() {
        if (httpPref == null) {
            httpPref = ContextStore.getContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        }
        return httpPref;
    }

    public static void saveMobile(String phoneNo) {
        String mobiles = getMobileStr();
        getHttpPref().edit().putString(PREF_KEY_MOBILES, mobiles + "#" + phoneNo).commit();
    }

    public static String[] getMobiles() {
        String mobiles = getMobileStr();
        if (TextUtils.isEmpty(mobiles)) {
            return null;
        } else {
            return mobiles.split("#");
        }
    }

    private static String getMobileStr() {
        return getHttpPref().getString(PREF_KEY_MOBILES, "");
    }

}
