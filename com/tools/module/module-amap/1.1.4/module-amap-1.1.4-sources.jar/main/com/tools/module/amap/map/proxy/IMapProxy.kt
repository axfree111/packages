package com.tools.module.amap.map.proxy

import android.os.Bundle
import com.drone.monitor.bean.Drone
import com.drone.monitor.bean.MonitorDevice
import com.drone.monitor.bean.VideoInfo
import com.drone.monitor.bean.custom.MyLatLng
import com.tools.module.amap.map.contract.IGetDestinationInfoCallback
import com.tools.module.amap.map.contract.IMarkerInterceptorCallback
import com.tools.module.amap.model.MarkerDataModel
import com.tools.module.amap.model.base.BaseDistrictFenceModel
import com.tools.module.amap.model.base.BaseDroneModel
import com.tools.module.amap.model.base.BaseMonitorModel
import com.tools.module.amap.model.base.BaseSelectAreaModel
import com.tools.module.amap.model.base.BaseVideoModel

/**
 * Date: 2025/3/31
 * Desc:
 *
 * author: jaje
 */
interface IMapProxy {

    fun createViewModel(): BaseVideoModel<*>

    fun createMonitorModel(device: MonitorDevice): BaseMonitorModel

    fun createDroneModel(data: Drone): BaseDroneModel

    fun createSelectAreaModel(): BaseSelectAreaModel

    fun createDistrictFenceModel(): BaseDistrictFenceModel

    fun getAddressNameByLatlng(latLng: MyLatLng, callback: IGetDestinationInfoCallback)

    fun onLongClickMapToEdit(): Boolean

    fun isShowTitleOverlay(): Boolean

    fun convertWGS84LatLng(myLatLng: MyLatLng): MyLatLng

    fun convertLatLng(monitor: MonitorDevice)

    fun setNewVideoInfo(videoInfo: VideoInfo)

    fun showTitleOverlay(show: Boolean)

    fun droneInfoUpdate(drone: Drone)

    fun hideWindowsInfo()

    fun getCurrentSelectedMKDataModel(): MarkerDataModel

    fun monitorInfoUpdate(monitor: MonitorDevice)

    fun onCreate()

    fun onResume()

    fun onPause()

    fun onStop()

    fun onDestroy()

    fun onSaveInstanceState(outState: Bundle)

    fun setZoom(latitude: Double, longitude: Double)

    fun setZoom(latitude: Double, longitude: Double, zoom: Float)

    fun setMarkerClickInterceptor(markerClickInterceptor: IMarkerInterceptorCallback)
}