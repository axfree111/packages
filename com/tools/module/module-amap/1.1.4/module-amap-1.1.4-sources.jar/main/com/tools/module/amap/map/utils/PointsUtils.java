package com.tools.module.amap.map.utils;

import com.drone.monitor.bean.MonitorDevice;
import com.drone.monitor.bean.custom.MyLatLng;
import com.tools.module.amap.map.LocalMapConfig;
import com.tools.module.amap.model.DroneConfig;
import com.tools.module.amap.utils.ComputeUtils;
import com.tools.module.common.utils.XAppLogger;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Vector;

public class PointsUtils {

    /**
     * 获取所有的点
     *
     * @param monitorDevice
     * @return
     */
    public static Vector<Vector<MyLatLng>> getMonitorAllPositions(MonitorDevice monitorDevice) {
        int startAngle = monitorDevice.direct % 360;
        int endAngle = startAngle + monitorDevice.directAngle;
        int centerAngle = monitorDevice.getCenterAngle();
        int workRadius = monitorDevice.workRadius;
        int warningRadius = monitorDevice.warningRadius;
        int discernRadius = monitorDevice.discernRadius;
        boolean isCircle = monitorDevice.directAngle == 360;

        Vector<Vector<MyLatLng>> allPositions = new Vector<>();

        if (workRadius <= 0) {
            return allPositions;
        }

        MyLatLng latLng = new MyLatLng(monitorDevice.getLatitude(), monitorDevice.getLongitude());

        // 预警区域 最外围的弧线点
        Vector<MyLatLng> warningAreaAllPoints = new Vector<>();
        if (warningRadius > workRadius) {
            Vector<MyLatLng> warningAreaPosAllPoints = getArcLinePoints(latLng, startAngle, endAngle, warningRadius);
            // 进行倒序处理
            Collections.reverse(warningAreaPosAllPoints);
            warningAreaAllPoints.addAll(warningAreaPosAllPoints);
        }

        // 识别区域 最外围的弧线点
        Vector<MyLatLng> disternAreaAllPoints = new Vector<>();
        if (discernRadius > workRadius) {
            Vector<MyLatLng> disternAreaPosAllPoints = getArcLinePoints(latLng, startAngle, endAngle, discernRadius);
            disternAreaAllPoints.addAll(disternAreaPosAllPoints);
        }

        // 攻击区域 最外围的弧线点
        Vector<MyLatLng> workArcAllPoints = new Vector<>();
        workArcAllPoints.addAll(getArcLinePoints(latLng, startAngle, endAngle, workRadius));


        //----------------------------------------------------------------------------
        // 第一个点集合 发射区域最外围的点 用来判断是否飞机入侵
        Vector<MyLatLng> workPeripheryAllPoints = new Vector<>();
        if (!isCircle) {
            // 添加中心点
            workPeripheryAllPoints.add(latLng);
        }
        workPeripheryAllPoints.addAll(workArcAllPoints);
        allPositions.add(workPeripheryAllPoints);
        //----------------------------------------------------------------------------

        //----------------------------------------------------------------------------
        // 第二个点集合 预警区域最外围的点 用来判断是否飞机入侵
        Vector<MyLatLng> warningPeripheryAllPoints = new Vector<>();
        if (warningAreaAllPoints.size() > 0) {
            warningPeripheryAllPoints.addAll(workArcAllPoints);
            warningPeripheryAllPoints.addAll(warningAreaAllPoints);
        }
        allPositions.add(warningPeripheryAllPoints);
        //----------------------------------------------------------------------------

        //----------------------------------------------------------------------------
        // 第三个点集合 识别区域最外围的点 用来判断是否飞机入侵
        Vector<MyLatLng> disternPeripheryAllPoints = new Vector<>();
        if (warningAreaAllPoints.size() > 0) {
            if (discernRadius <= warningRadius) {
                disternPeripheryAllPoints.addAll(workArcAllPoints);
                disternPeripheryAllPoints.addAll(disternAreaAllPoints);
            } else {
                if (warningAreaAllPoints.size() > 0) {
                    disternPeripheryAllPoints.addAll(warningAreaAllPoints);
                    disternPeripheryAllPoints.addAll(disternAreaAllPoints);
                }
            }
        }
        allPositions.add(disternPeripheryAllPoints);
        //----------------------------------------------------------------------------

        //----------------------------------------------------------------------------
        // 第四个点集合 折线点
        // TODO 如果默认显示预警区才显示预警区两边的线
//        int brokenRadius = workRadius;
//        if (warningRadius > workRadius) {
//            brokenRadius = warningRadius;
//        }
        Vector<MyLatLng> brokenLinePoints = new Vector<>();
        brokenLinePoints.add(ComputeUtils.eOffsetBearing(latLng, workRadius, startAngle));
        brokenLinePoints.add(latLng);
        brokenLinePoints.add(ComputeUtils.eOffsetBearing(latLng, workRadius, endAngle));
        allPositions.add(brokenLinePoints);

        //----------------------------------------------------------------------------
        // 第五个集合添加预警区弧线上的点
        Vector<MyLatLng> warninglinePoints = new Vector<>();
        if (warningRadius > workRadius) {
            if (isCircle) {
                //得到中间点
                warninglinePoints.add(ComputeUtils.eOffsetBearing(latLng, warningRadius, centerAngle));
            } else {
                //得到起点
                warninglinePoints.add(ComputeUtils.eOffsetBearing(latLng, warningRadius, startAngle));
                //得到中间点
                warninglinePoints.add(ComputeUtils.eOffsetBearing(latLng, warningRadius, centerAngle));
                //得到终点
                warninglinePoints.add(ComputeUtils.eOffsetBearing(latLng, warningRadius, endAngle));
            }
        }
        allPositions.add(warninglinePoints);
        //----------------------------------------------------------------------------

        //----------------------------------------------------------------------------
        // 第六个集合添加识别区弧线上的点
        Vector<MyLatLng> disternlinePoints = new Vector<>();
        if (discernRadius > workRadius) {
            if (isCircle) {
                //得到中间点
                disternlinePoints.add(ComputeUtils.eOffsetBearing(latLng, discernRadius, centerAngle));
            } else {
                //得到起点
                disternlinePoints.add(ComputeUtils.eOffsetBearing(latLng, discernRadius, startAngle));
                //得到中间点
                disternlinePoints.add(ComputeUtils.eOffsetBearing(latLng, discernRadius, centerAngle));
                //得到终点
                disternlinePoints.add(ComputeUtils.eOffsetBearing(latLng, discernRadius, endAngle));
            }
        }
        allPositions.add(disternlinePoints);
        //----------------------------------------------------------------------------

        //----------------------------------------------------------------------------
        // 第七个点集合 间隔线上的点 用来画弧线
        if (workRadius > 0) {
            if (workRadius >= LocalMapConfig.INTERVAL) {
                //计算每隔500米的弧线上的点
//                if (AppConfig.mapType == Constants.MAP_TYPE.GOOGLE_MAP) {
//                    for (int m = Constants.INTERVAL; m <= workRadius; m += Constants.INTERVAL) {
//                        allPositions.add(getArcLinePoints(latLng, startAngle, endAngle, m));
//                    }
//                } else {
                    for (int m = LocalMapConfig.INTERVAL; m <= workRadius; m += LocalMapConfig.INTERVAL) {

                        Vector<MyLatLng> linePoints = new Vector<>();
                        if (isCircle) {
                            //得到中间点
                            linePoints.add(ComputeUtils.eOffsetBearing(latLng, m, centerAngle));
                        } else {
                            //得到起点
                            linePoints.add(ComputeUtils.eOffsetBearing(latLng, m, startAngle));
                            //得到中间点
                            linePoints.add(ComputeUtils.eOffsetBearing(latLng, m, centerAngle));
                            //得到终点
                            linePoints.add(ComputeUtils.eOffsetBearing(latLng, m, endAngle));
                        }
                        allPositions.add(linePoints);
                    }
//                }
            } else {
//                if (AppConfig.mapType == Constants.MAP_TYPE.GOOGLE_MAP) {
//                    allPositions.add(getArcLinePoints(latLng, startAngle, endAngle, workRadius));
//                } else {
                    Vector<MyLatLng> linePoints = new Vector<>();
                    if (isCircle) {
                        //得到中间点
                        linePoints.add(ComputeUtils.eOffsetBearing(latLng, workRadius, centerAngle));
                    } else {
                        //得到起点
                        linePoints.add(ComputeUtils.eOffsetBearing(latLng, workRadius, startAngle));
                        //得到中间点
                        linePoints.add(ComputeUtils.eOffsetBearing(latLng, workRadius, centerAngle));
                        //得到终点
                        linePoints.add(ComputeUtils.eOffsetBearing(latLng, workRadius, endAngle));
                    }
                    allPositions.add(linePoints);
//                }
            }
        }
        //----------------------------------------------------------------------------
        return allPositions;
    }

    /**
     * 获取入侵路径连线的点集合
     *
     * @param moveLatlng
     * @param centerLatlng
     * @return
     */
    public static Vector<MyLatLng> getInvadRouteArrayPoints(MyLatLng moveLatlng, MyLatLng centerLatlng) {
        Vector<MyLatLng> latLngs = new Vector<>();
        if (moveLatlng == null || centerLatlng == null) {
            return latLngs;
        }
        if (moveLatlng.latitude == centerLatlng.latitude && moveLatlng.longitude == centerLatlng.longitude) {
            return latLngs;
        }
        float angle = ComputeUtils.calulateXYAnagle(moveLatlng, centerLatlng);
        MyLatLng startLatlng = ComputeUtils.eOffsetBearing(moveLatlng, DroneConfig.AROUND_DRONE_CIRCLE_LINE_RADIUS, angle);
        double distance = ComputeUtils.getDistance(startLatlng, centerLatlng);
        int pointNum = 10;
        if (distance < 10) {
            pointNum = 1;
        }
        double pointDistance = distance / pointNum;
        for (int i = 1; i <= pointNum; i++) {
            latLngs.add(ComputeUtils.eOffsetBearing(startLatlng, i * pointDistance, angle));
        }
        return latLngs;
    }

    /**
     * 获取设备攻击线集合
     *
     * @param centerLatlng
     * @param startAngle
     * @param endAngle
     * @param radius
     * @return
     */
    public static Vector<Vector<MyLatLng>> getMonitorAttackLineArrayPoints(MyLatLng centerLatlng,
                                                                           int startAngle, int endAngle, int radius) {
        Vector<Vector<MyLatLng>> allPositions = new Vector<>();
        if (centerLatlng == null || radius <= 0) {
            return allPositions;
        }
        int lineNum = (int) (radius * 1.0f / 3000 * 5);
        for (int i = 1; i <= lineNum; i++) {
            // 反正弦计算不规则半径值
            Vector<MyLatLng> linePoints = getArcLinePoints(centerLatlng,
                    startAngle, endAngle, (int) (radius * (Math.asin(i * 1.0f / lineNum) * 2 / Math.PI)));
            allPositions.add(linePoints);
        }
        return allPositions;
    }

    public static Vector<Vector<MyLatLng>> getMonitorScanArrayPoints(MonitorDevice monitorDevice) {
        int startAngle = monitorDevice.direct % 360;
        int endAngle = startAngle + monitorDevice.directAngle;
        int centerAngle = monitorDevice.getCenterAngle();
        int workRadius = monitorDevice.workRadius;

        Vector<Vector<MyLatLng>> allPositions = new Vector<>();

        if (workRadius <= 0) {
            return allPositions;
        }

        MyLatLng latLng = new MyLatLng(monitorDevice.getLatitude(), monitorDevice.getLongitude());

        return getMonitorScanArrayPoints(latLng, workRadius, startAngle, endAngle);
    }

    public static Vector<Vector<MyLatLng>> getMonitorScanArrayPoints(MyLatLng latLng, int workRadius) {
        return getMonitorScanArrayPoints(latLng, workRadius, 0, 360);
    }

    public static Vector<Vector<MyLatLng>> getMonitorScanArrayPoints(MyLatLng latLng, int workRadius, int startAngle, int endAngle) {
        Vector<Vector<MyLatLng>> allPositions = new Vector<>();

        if (workRadius <= 0) {
            return allPositions;
        }
        // 半径最外围的弧线点
        Vector<MyLatLng> workArcAllPoints = getArcLinePoints(latLng, startAngle, endAngle, workRadius);

        int size = workArcAllPoints.size();
        // 获取到反方向的多边形集合
        for (int i = size - 1; i > 0; i--) {
            Vector<MyLatLng> scanPoints = new Vector<>();
            scanPoints.add(latLng);
            scanPoints.add(workArcAllPoints.get(i - 1));
            scanPoints.add(workArcAllPoints.get(i));
            allPositions.add(scanPoints);
        }
        return allPositions;
    }

    public static Vector<MyLatLng> getArcLinePoints(MyLatLng latLng, int startAngle, int endAngle,
                                                    int workRadius) {
        Vector<MyLatLng> warningPolygonPoints = new Vector<>();

        //计算出不被5整除的第一个和最后一个点的角度
        float startOffsetAngle = startAngle + (LocalMapConfig.MIN_ANGLE - startAngle % LocalMapConfig.MIN_ANGLE);
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_OTHER, " startOffsetAngle:" + startOffsetAngle);
        //计算第一个点
        warningPolygonPoints.add(ComputeUtils.eOffsetBearing(latLng, workRadius, startAngle));

        //计算中间能被5整除的所有点
        for (float j = startOffsetAngle; j < endAngle; j += LocalMapConfig.MIN_ANGLE) {
            warningPolygonPoints.add(ComputeUtils.eOffsetBearing(latLng, workRadius, j));
            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_OTHER, " 角度:" + j);
        }

        //计算最后一个点
        warningPolygonPoints.add(ComputeUtils.eOffsetBearing(latLng, workRadius, endAngle));
        return warningPolygonPoints;
    }

    /**
     * 获取创建电子围栏初始化时顶点坐标
     *
     * @param centerLatLng
     * @param radius
     * @param pointNum
     * @return
     */
    public static Vector<MyLatLng> getDistrictFencePoints(MyLatLng centerLatLng, int radius, int pointNum) {
        if (centerLatLng == null) {
            centerLatLng = new MyLatLng(LocalMapConfig.CURRENT_VIEW_LATITUDE, LocalMapConfig.CURRENT_VIEW_LONGITUDE);
        }
        List<Float> angles = getAngles(pointNum);
        Vector<MyLatLng> fenceAllPoints = new Vector<>();
        if (radius <= 0 || pointNum <= 0) {
            return fenceAllPoints;
        }
        for (float angle : angles) {
            fenceAllPoints.add(ComputeUtils.eOffsetBearing(centerLatLng, radius, angle));
        }
        return fenceAllPoints;
    }

    private static List<Float> getAngles(int pointNum) {
        List<Float> angles = new ArrayList<>();
        float incrementAngle = 360f / pointNum;
        for (int i = 0; i < pointNum; i++) {
            angles.add(i * incrementAngle);
        }
        return angles;
    }
}
