package com.tools.module.amap.map.utils;

import com.drone.monitor.bean.Drone;
import com.tools.module.amap.model.DroneConfig;
import com.tools.module.amap.model.RoutePointModel;
import com.tools.module.amap.utils.ComputeUtils;

import java.util.List;

/**
 * Created by jiajiecsf on 2020/11/24.
 */
public class RoutePointUtils {
    public static boolean checkPoint(List<Drone> singleDroneHistoryData, Drone currentD, Drone timeNexD,
                                     RoutePointModel validLastTimePoint, List<RoutePointModel> validPoints,
                                     boolean isLastPoint) {
        // currentD > timeNexD
        long spaceTime = 0;
        if (timeNexD != null) {
            // 用数组后边的减去数组前边的
            spaceTime = currentD.createTime.getTime() - timeNexD.createTime.getTime();
        }
        // 对比和最近数据的时间间隔,如果大于两分钟说明关机重启了,作为新的起点
        if (spaceTime >= DroneConfig.DRONE_MAX_TIME_IS_OFF) {
            if (validLastTimePoint != null) {
                // 上一个点为中间点时走以下逻辑
                if (validLastTimePoint.pointType == RoutePointModel.PointType.CENTER_POINT) {
                    // 计算上一个点和这个点的时间差
                    spaceTime = validLastTimePoint.time.getTime() - currentD.createTime.getTime();
                    if (spaceTime <= DroneConfig.DRONE_SHOW_INTERVAL_TIME && validPoints.size() > 0) {
                        // 时间小于间隔则删除上一个点
                        validPoints.remove(validPoints.size() - 1);
                        singleDroneHistoryData.remove(singleDroneHistoryData.size() - 1);
                    }
                }
            }
            RoutePointModel endPointModel = new RoutePointModel();
            endPointModel.copyDrone(currentD);
            // 此点为结束结点
            endPointModel.pointType = RoutePointModel.PointType.END_POINT;
            validPoints.add(endPointModel);
            singleDroneHistoryData.add(currentD);

            RoutePointModel startPointModel = new RoutePointModel();
            startPointModel.copyDrone(timeNexD);
            // 此点为结束结点
            startPointModel.pointType = RoutePointModel.PointType.START_POINT;
            validPoints.add(startPointModel);
            singleDroneHistoryData.add(timeNexD);
            return true;
        } else {
            if (validLastTimePoint == null) {
                RoutePointModel startPointModel = new RoutePointModel();
                startPointModel.copyDrone(currentD);
                startPointModel.pointType = RoutePointModel.PointType.END_POINT;
                startPointModel.isLabelEndPoint = true;
                validPoints.add(startPointModel);
                singleDroneHistoryData.add(currentD);
            } else {
                // 存储的最后一点和当前点时间比较，validMaxTimePoint为记录的最大时间
                spaceTime = validLastTimePoint.time.getTime() - currentD.createTime.getTime();
                // 如果是中间结点则判断连个结点位是否大于10米或大于大于两分钟,如果满足两个条件则表示为一个结点
                if (spaceTime >= DroneConfig.DRONE_SHOW_INTERVAL_TIME &&
                        ComputeUtils.getDistance(validLastTimePoint.point, currentD.getMyLatLng()) > 10) {
                    RoutePointModel centerPointModel = new RoutePointModel();
                    centerPointModel.copyDrone(currentD);
                    // 当前点作为中间结点
                    centerPointModel.pointType = RoutePointModel.PointType.CENTER_POINT;
                    validPoints.add(centerPointModel);
                    singleDroneHistoryData.add(currentD);
                } else {
                    if (isLastPoint) {
                        RoutePointModel endPointModel = new RoutePointModel();
                        endPointModel.copyDrone(currentD);
                        endPointModel.pointType = RoutePointModel.PointType.START_POINT;
                        endPointModel.isLabelEndPoint = true;
                        validPoints.add(endPointModel);
                        singleDroneHistoryData.add(currentD);
                    }
                }
            }
        }
        return false;
    }


    public static boolean checkPoint(RoutePointModel currentPointModel, RoutePointModel timeMinPointModel
            , RoutePointModel validLastTimePoint, List<RoutePointModel> validPoints, boolean isLastPoint) {
        long spaceTime = 0;
        if (timeMinPointModel != null) {
            // 用数组前边的减去数组后边的
            spaceTime = currentPointModel.time.getTime() - timeMinPointModel.time.getTime();
        }
        // 对比和最近数据的时间间隔,如果大于两分钟说明关机重启了,作为新的起点
        if (spaceTime >= DroneConfig.DRONE_MAX_TIME_IS_OFF) {
            if (validLastTimePoint != null) {
                // 上一个点为中间点时走以下逻辑
                if (validLastTimePoint.pointType == RoutePointModel.PointType.CENTER_POINT) {
                    // 计算上一个点和这个点的时间差
                    spaceTime = validLastTimePoint.time.getTime() - currentPointModel.time.getTime();
                    if (spaceTime <= DroneConfig.DRONE_SHOW_INTERVAL_TIME && validPoints.size() > 0) {
                        // 时间小于间隔则删除上一个点
                        validPoints.remove(validPoints.size() - 1);
                    }
                }
            }
            RoutePointModel endPointModel = new RoutePointModel();
            endPointModel.copy(currentPointModel);
            // 此点为终点
            endPointModel.pointType = RoutePointModel.PointType.END_POINT;
            validPoints.add(endPointModel);

            RoutePointModel startPointModel = new RoutePointModel();
            endPointModel.copy(timeMinPointModel);
            // 此点为起始结点
            endPointModel.pointType = RoutePointModel.PointType.START_POINT;
            validPoints.add(startPointModel);
            return true;
        } else {
            if (validLastTimePoint == null) {
                RoutePointModel startPointModel = new RoutePointModel();
                startPointModel.copy(currentPointModel);
                startPointModel.pointType = RoutePointModel.PointType.END_POINT;
                startPointModel.isLabelEndPoint = true;
                validPoints.add(startPointModel);
            } else {
                // 存储的最后一点和当前点时间比较，由于向后添加因此记录的最小时间比没遍历的时间大
                spaceTime = validLastTimePoint.time.getTime() - currentPointModel.time.getTime();
                // 如果是中间结点则判断连个结点位是否大于10米或大于大于两分钟,如果满足两个条件则表示为一个结点
                if (spaceTime >= DroneConfig.DRONE_SHOW_INTERVAL_TIME &&
                        ComputeUtils.getDistance(validLastTimePoint.point, currentPointModel.point) > 10) {
                    RoutePointModel centerPointModel = new RoutePointModel();
                    centerPointModel.copy(currentPointModel);
                    // 当前点作为中间结点
                    centerPointModel.pointType = RoutePointModel.PointType.CENTER_POINT;
                    validPoints.add(centerPointModel);
                } else {
                    if (isLastPoint) {
                        RoutePointModel endPointModel = new RoutePointModel();
                        endPointModel.copy(currentPointModel);
                        endPointModel.pointType = RoutePointModel.PointType.START_POINT;
                        endPointModel.isLabelEndPoint = true;
                        validPoints.add(endPointModel);
                    }
                }
            }
        }
        return false;
    }
}
