package com.tools.module.amap.manager;

import androidx.annotation.NonNull;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Created by jiajie on 2019/7/12.
 */

public class ThreadPoolHelper {

    private static final String THREAD_NAME = "thread_";
    private static final int COREPOOLSIZE = 8;

    public void stopThread(MyThread thread) {
        if (thread != null) {
            if (!thread.isFinish()) {
                thread.stopRunning();
                thread.interrupt();
            }
        }
    }

    private ThreadPoolHelper() {
    }

    private static ThreadPoolHelper instance;

    public static ThreadPoolHelper getInstance() {
        if (instance == null) {
            synchronized (ThreadPoolHelper.class) {
                if (instance == null) {
                    instance = new ThreadPoolHelper();
                }
            }
        }
        return instance;
    }

    private class ThreadFactory implements java.util.concurrent.ThreadFactory {

        public ThreadFactory() {
            counter = 1;
        }

        @Override
        public Thread newThread(@NonNull Runnable r) {
            MyThread thread = new MyThread(r, THREAD_NAME + counter);
            counter++;
            return thread;
        }
    }

    public static int counter = 1;

    public static class MyThread extends Thread {
        protected boolean running = true;
        protected boolean finish = false;

        public void stopRunning() {
            running = false;
            finish = true;
        }

        public boolean isFinish() {
            return finish;
        }

        public MyThread() {
            super(THREAD_NAME + counter);
            counter++;
            running = true;
            finish = false;
        }

        public MyThread(String name) {
            super(name);
            running = true;
            finish = false;
        }

        public MyThread(Runnable runnable) {
            super(runnable);
            running = true;
            finish = false;
        }

        public MyThread(Runnable runnable, String name) {
            super(runnable, name);
            running = true;
            finish = false;
        }

        @Override
        public void run() {
            if (running) {
                finish = false;
                super.run();
                finish = true;
                counter--;
            }
        }
    }

    private ThreadPoolExecutor threadPool =
            new ThreadPoolExecutor(COREPOOLSIZE / 2, COREPOOLSIZE, 10L, TimeUnit.SECONDS,
                    new LinkedBlockingQueue<Runnable>(), new ThreadFactory(), new ThreadPoolExecutor.DiscardPolicy());

    public void execute(Runnable command) {
        threadPool.execute(command);
    }
}
