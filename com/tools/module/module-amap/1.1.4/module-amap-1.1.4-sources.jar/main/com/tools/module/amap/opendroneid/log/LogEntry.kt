package com.tools.module.amap.opendroneid.log

class LogEntry {
    var session: Int = 0
    var timestamp: Long = 0
    var transportType: String? = null
    var macAddress: String? = null
    var msgVersion: Int = 0
    var rssi: Int = 0
    var data: ByteArray? = null
    var csvLog: StringBuilder? = null

    override fun toString(): String {
        return (session.toString() + DELIM
                + timestamp + DELIM
                + transportType + DELIM
                + macAddress + DELIM
                + msgVersion + DELIM
                + rssi + DELIM
                + data?.let { toHexString(it, it.size) } + DELIM
                + csvLog)
    }

    companion object {
        val HEADER: Array<String> = arrayOf(
            "session",
            "timestamp (nanos)",
            "transportType",
            "macAddress",
            "msgVersion",
            "rssi",
            "payload"
        )

        const val DELIM: String = ","

        fun fromString(line: String): LogEntry? {
            val fields = line.split("\\s*[,]\\s*".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
            if (fields.size < 6) {
                return null
            }

            try {
                val entry = LogEntry()
                entry.session = fields[0].toInt()
                entry.timestamp = fields[1].toLong()
                entry.transportType = fields[2]
                entry.macAddress = fields[3]
                entry.msgVersion = fields[4].toInt()
                entry.rssi = fields[5].toInt()
                entry.data = parseHexString(fields[6])
                return entry
            } catch (e: Exception) {
                e.printStackTrace()
            }
            return null
        }

        fun toHexString(bytes: ByteArray, len: Int): String {
            return bytes.take(len).joinToString("") { "%02X".format(it.toInt() and 0xFF) }
        }

        private fun parseHexString(hexString: String): ByteArray {
            val byteStrings = hexString.split("\\s+".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
            val bytes = ByteArray(byteStrings.size)
            for (i in byteStrings.indices) {
                bytes[i] = byteStrings[i].toInt(16).toByte()
            }
            return bytes
        }
    }
}
