package com.tools.module.amap.map.amap.overlay;

import com.drone.monitor.bean.custom.MyLatLng;
import com.tools.module.amap.model.RoutePointModel;
import com.tools.module.common.utils.HandlerUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * 路线绘制类
 */
public class HistoryRouteOverlay extends RouteOverlay {

    private List<RoutePointModel> mHistoryModels = new ArrayList<>();
    private boolean isFirst = true;

    /**
     * 通过此构造函数创建步行路线图层。
     *
     * @since V2.1.0
     */
    public HistoryRouteOverlay(int markerType, int objType) {
        super(markerType, objType);
    }

    public void insertDatas(List<RoutePointModel> historyModels) {
        HandlerUtils.getUIHandler().post(new Runnable() {
            @Override
            public void run() {
                if (mHistoryModels == null || historyModels.size() < 2) {
                    return;
                }
                mHistoryModels = historyModels;
                RoutePointModel startModel = mHistoryModels.get(0);
                if (startModel != null) {
                    startPoint = startModel.point;
                }
                RoutePointModel endModel = mHistoryModels.get(mHistoryModels.size() - 1);
                if (endModel != null) {
                    endPoint = endModel.point;
                }
                removeFromMap();
                addToMap();
            }
        });
    }

    /**
     * 添加步行路线到地图中。
     *
     * @since V2.1.0
     */
    private void addToMap() {
        try {
            RoutePointModel prePointModel = null;
            for (int i = 0; i < mHistoryModels.size(); i++) {
                RoutePointModel pointModel = mHistoryModels.get(i);
                if (prePointModel == null) {
                    prePointModel = pointModel;
                } else {
                    addRoutToMap(prePointModel, pointModel, i);
                    prePointModel = pointModel;
                }
            }
            if (isFirst) {
                isFirst = false;
                zoomToSpan();
            }
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }

    /**
     * @return
     */
    private MyLatLng getLastWalkPoint() {
        if (mHistoryModels != null && mHistoryModels.size() > 0) {
            return mHistoryModels.get(mHistoryModels.size() - 1).point;
        }
        return null;
    }

    /**
     * @return
     */
    private MyLatLng getFirstRoutePoint() {
        if (mHistoryModels != null && mHistoryModels.size() > 0) {
            return mHistoryModels.get(0).point;
        }
        return null;
    }

    public void addRoutePolyLine(RoutePointModel firstPoint, RoutePointModel twoPoint) {
        if (mHistoryModels.size() > 0) {
            addRoutToMap(firstPoint, twoPoint, mHistoryModels.size() - 1);
        }
    }
}
