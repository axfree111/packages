package com.tools.module.amap.utils;

/**
 *
 */

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import io.protostuff.LinkedBuffer;
import io.protostuff.ProtostuffIOUtil;
import io.protostuff.Schema;
import io.protostuff.runtime.RuntimeSchema;


public class ProtostuffSerializerUtils {


    private static Map<Class<?>, Schema<?>> CACHED_SCHEMA = new ConcurrentHashMap<Class<?>, Schema<?>>();

    /**
     * 如果一个类没有参数为空的构造方法，那么直接调用newInstance()方法来得到一个实例对象的时候会抛异常。
     * 像私有构造方法，带参数的构造等不能通过class.newInstance()实例化。 Objenesis不用构造方法来实例化对象， 优于 Java 反射。
     */
    private static <T> Schema<T> getSchema(Class<T> clazz) {
        @SuppressWarnings("unchecked")
        Schema<T> schema = (Schema<T>) CACHED_SCHEMA.get(clazz);
        if (schema == null) {
            schema = RuntimeSchema.getSchema(clazz);
            if (schema != null) {
                CACHED_SCHEMA.put(clazz, schema);
            }
        }
        return schema;
    }

    public static <T> byte[] marshall(T obj) {
        if (obj == null) {
            return null;
        }

        @SuppressWarnings("unchecked")
        Class<T> clazz = (Class<T>) obj.getClass();
        LinkedBuffer buffer = LinkedBuffer.allocate(LinkedBuffer.DEFAULT_BUFFER_SIZE);
        try {
            Schema<T> schema = getSchema(clazz);
            return ProtostuffIOUtil.toByteArray(obj, schema, buffer);
        } catch (Exception e) {
            throw new IllegalStateException(e.getMessage(), e);
        } finally {
            buffer.clear();
        }
    }

    public static <T> T unmarshall(byte[] bytes, Class<T> clazz) {
        if (bytes == null || bytes.length == 0) {
            return null;
        }
        try {
            T obj = clazz.newInstance();
            Schema<T> schema = getSchema(clazz);
            ProtostuffIOUtil.mergeFrom(bytes, obj, schema);
            return obj;
        } catch (Exception e) {
            throw new IllegalStateException(e.getMessage(), e);
        }
    }

    public static <T> byte[] marshallList(List<T> objList) {
        if (objList == null) {
            return null;
        }else if(objList.isEmpty()) {
            return new byte[0];
        }
        @SuppressWarnings("unchecked")
        Schema<T> schema = (Schema<T>) getSchema(objList.get(0).getClass());
        LinkedBuffer buffer = LinkedBuffer.allocate(1024);
        byte[] protostuff = null;
        ByteArrayOutputStream bos = null;
        try {
            bos = new ByteArrayOutputStream();
            ProtostuffIOUtil.writeListTo(bos, objList, schema, buffer);
            protostuff = bos.toByteArray();
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage(), e);
        } finally {
            buffer.clear();
            try {
                if (bos != null) {
                    bos.close();
                }
            } catch (IOException ignore) {

            }
        }

        return protostuff;
    }

    public static <T> List<T> unmarshallList(byte[] bytes, Class<T> targetClass) {
        if (bytes == null) {
            return null;
        }else if(bytes.length == 0) {
            return Collections.emptyList();
        }

        Schema<T> schema = getSchema(targetClass);
        List<T> result = null;
        InputStream input = null;
        try {
            input = new ByteArrayInputStream(bytes);
            result = ProtostuffIOUtil.parseListFrom(input, schema);
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage(), e);
        } finally {
            if(null != input) {
                try {
                    input.close();
                } catch (IOException ignore) {

                }
            }
        }
        return result;
    }

}
