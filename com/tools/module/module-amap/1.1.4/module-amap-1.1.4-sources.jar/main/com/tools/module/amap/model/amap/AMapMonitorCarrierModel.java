package com.tools.module.amap.model.amap;

import com.amap.api.maps.AMap;
import com.drone.monitor.bean.MonitorDevice;
import com.tools.module.amap.map.amap.MaMapUtils;

public class AMapMonitorCarrierModel extends AMapBaseMonitorCarrierModel {

    public AMapMonitorCarrierModel(MonitorDevice monitor) {
        super(monitor);
    }

    @Override
    protected boolean markerIsDraggable() {
        return false;
    }

    @Override
    protected AMap getMap() {
        return MaMapUtils.getInstance().getMap();
    }
}
