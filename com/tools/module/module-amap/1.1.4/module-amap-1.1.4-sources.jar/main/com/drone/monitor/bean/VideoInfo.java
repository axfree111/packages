package com.drone.monitor.bean;

import android.text.TextUtils;

import com.drone.monitor.bean.custom.MyHasRouteObject;
import com.drone.monitor.bean.custom.MyLatLng;
import com.tools.module.common.utils.TimeUtil;
import com.tools.module.common.utils.XAppLogger;
import com.tools.module.amap.map.LocalMapConfig;
import com.tools.module.amap.utils.BaseFileUtil;

/**
 * {"code":0,"message":"成功","data":
 * [{"createTime":"2020-02-26 14:13:39","latitude":"0.000000","videoId":"18612189240-20200226141206129-185458.49805688715.mp4","userName":"超管四","phoneNo":"18612189240","url":"http://droneinfo.oss-cn-beijing.aliyuncs.com/18612189240-20200226141206129-185458.49805688715.mp4?Expires=1582702277&OSSAccessKeyId=LTAIdEr6GYt8TQOR&Signature=6OIxuwZ9Yhb48jkghITe5Xkc86Y%3D","longitude":"0.000000"}],
 * "pageNumber":null,"pageSize":null,"count":null}
 */
public class VideoInfo extends MyHasRouteObject {

    public String videoId;

    public String url;

    public boolean isLocation = false;
    /**
     * 经度
     */
    public double longitude;

    /**
     * 维度
     */
    public double latitude;

    public String userName;
    public String phoneNo;
    public String createTime;

    public String videoLocalPath;
    public int videoWidth;
    public int videoHeight;

    public String uploadVideoPath;
    private double process;
    public int processType = ProcessType.COMPRESS;
    public boolean isLook = false;

    public VideoInfo() {
        process = 0;
    }

    public boolean setProcess(double process) {
        if (process > this.process) {
            this.process = process;
            return true;
        }
        return false;
    }

    public double getProcess() {
        return this.process;
    }

    public String getCompressSize() {
        return videoWidth / 2 + "x" + videoHeight / 2;
    }

    public String getVideoObjectKey() {
        if (TextUtils.isEmpty(videoId)) {
            videoId = BaseFileUtil.getFileName(uploadVideoPath);
        }
        return videoId;
    }

    public interface ProcessType {
        int COMPRESS = 0;
        int UPLOAD = 1;
    }

    public void setLatLng(double latitude, double longitude) {
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public void setMyLatLng(MyLatLng latLng) {
        latitude = latLng.latitude;
        longitude = latLng.longitude;
    }

    public MyLatLng getMyLatLng() {
        return new MyLatLng(latitude, longitude);
    }

    public boolean isNewVideo() {
        if (!isLook) {
            long currentTime = System.currentTimeMillis();
            if (currentTime - TimeUtil.getTimeLong(createTime) <= LocalMapConfig.NEW_VIDEO_TIME) {
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_VIDEO, "检测属于新视频:" + videoId);
                return true;
            }
        }
        return false;
    }

    @Override
    public String toStringConcise() {
        return "VideoInfo{" +
                "videoId='" + videoId + '\'' +
                ", url='" + url + '\'' +
                ", longitude=" + longitude +
                ", latitude=" + latitude +
                ", userName='" + userName + '\'' +
                ", phoneNo='" + phoneNo + '\'' +
                "} ";
    }

    @Override
    public String toString() {
        return "VideoInfo{" +
                "videoId='" + videoId + '\'' +
                ", url='" + url + '\'' +
                ", longitude=" + longitude +
                ", latitude=" + latitude +
                ", userName='" + userName + '\'' +
                ", phoneNo='" + phoneNo + '\'' +
                ", createTime='" + createTime + '\'' +
                ", videoLocalPath='" + videoLocalPath + '\'' +
                ", videoWidth=" + videoWidth +
                ", videoHeight=" + videoHeight +
                ", uploadVideoPath='" + uploadVideoPath + '\'' +
                ", process=" + process +
                ", processType=" + processType +
                "} " + super.toString();
    }

    public void copy(VideoInfo data) {
        this.videoId = data.videoId;
        this.url = data.url;
        this.isLocation = data.isLocation;
        this.latitude = data.latitude;
        this.longitude = data.longitude;
        this.userName = data.userName;
        this.phoneNo = data.phoneNo;
        this.createTime = data.createTime;
        this.videoLocalPath = data.videoLocalPath;
        this.videoWidth = data.videoWidth;
        this.videoHeight = data.videoHeight;
        this.uploadVideoPath = data.uploadVideoPath;
        this.process = data.process;
        this.processType = data.processType;
        this.isLook = data.isLook;
    }
}
