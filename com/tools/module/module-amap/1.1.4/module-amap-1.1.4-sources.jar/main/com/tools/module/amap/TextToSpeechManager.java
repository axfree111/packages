package com.tools.module.amap;

import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import com.tools.module.common.utils.ResourceUtil;
import com.tools.module.common.utils.HandlerUtils;
import com.tools.module.amap.map.LocalMapConfig;
import com.tools.module.common.ContextStore;
import com.tools.module.common.utils.XAppLogger;

import java.util.List;
import java.util.Locale;

/**
 * Created by jiajiecsf on 2020/12/1.
 */
public class TextToSpeechManager {

    private TextToSpeech mTts = null;

    public TextToSpeechManager() {
        init();
    }

    private void init() {
        HandlerUtils.getThreadHanlder().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mTts == null) {
                    mTts = new TextToSpeech(ContextStore.getContext(), new TextToSpeech.OnInitListener() {
                        @Override
                        public void onInit(int status) {
                            //初始化成功的话，设置语音
                            if (status == TextToSpeech.SUCCESS) {
                                LocalMapConfig.USE_SPEAK = true;
                                List<TextToSpeech.EngineInfo> engineInfos = mTts.getEngines();
                                String label = "";
                                if (engineInfos != null && engineInfos.size() > 0) {
                                    TextToSpeech.EngineInfo engineInfo = engineInfos.get(0);
                                    if (engineInfo != null) {
                                        label = engineInfo.label;
                                    }
                                }
                                mTts.setPitch(1.0f);
                                mTts.setSpeechRate(1.0f);
                                mTts.setLanguage(Locale.CHINESE);
                                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_OTHER, "TTS初始化成功！使用的是：" + label);
                            } else {
                                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_OTHER, "TTS初始化失败！status:" + status);
                                LocalMapConfig.USE_SPEAK = false;
                            }
                        }
                    });
                }
            }
        }, 1000);
    }

    /**
     * TextToSpeech.QUEUE_FLUSH
     *
     * @param content
     * @param queueMode
     * @param listener
     */
    public void startPlay(String content, int queueMode, UtteranceProgressListener listener) {
        if (mTts != null) {
            mTts.setOnUtteranceProgressListener(listener);
            mTts.speak(content, queueMode, null, null);
        }
    }

    public void stop() {
        if (mTts != null) {
            mTts.stop();
        }
    }

    public boolean isSpeaking() {
        if (mTts != null) {
            return mTts.isSpeaking();
        }
        return false;
    }

    public void startPlay(int contentId, int queueMode, UtteranceProgressListener listener) {
        startPlay(ResourceUtil.getContent(contentId), queueMode, listener);
    }

    public void startAddPlay(int contentId, UtteranceProgressListener listener) {
        startPlay(contentId, TextToSpeech.QUEUE_ADD, listener);
    }

    public void startAddPlay(int contentId) {
        startAddPlay(contentId, null);
    }

    public void startFlushPlay(String content, UtteranceProgressListener listener) {
        startPlay(content, TextToSpeech.QUEUE_FLUSH, listener);
    }

    public void startFlushPlay(int contentId, UtteranceProgressListener listener) {
        startPlay(contentId, TextToSpeech.QUEUE_FLUSH, listener);
    }

    public void startFlushPlay(int contentId) {
        startAddPlay(contentId, null);
    }
}
