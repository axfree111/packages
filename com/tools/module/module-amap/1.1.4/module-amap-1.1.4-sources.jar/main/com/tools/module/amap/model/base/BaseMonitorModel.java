package com.tools.module.amap.model.base;

import android.text.TextUtils;

import androidx.annotation.UiThread;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;

import com.tools.module.amap.R;
import com.tools.module.amap.manager.SoundManager;
import com.tools.module.amap.manager.WarningManager;
import com.tools.module.amap.map.MapController;
import com.tools.module.amap.map.utils.PointsUtils;
import com.tools.module.amap.map.utils.SpatialRelationUtil;
import com.tools.module.amap.observer.DataObserver;
import com.tools.module.amap.observer.MapObserver;
import com.tools.module.amap.test.TestConstants;
import com.tools.module.amap.utils.ComputeUtils;
import com.tools.module.common.base.AppConfig;
import com.tools.module.amap.model.DroneRecordInvadeModel;
import com.tools.module.amap.model.MarkerDataModel;
import com.tools.module.amap.model.MonitorConfig;
import com.drone.monitor.bean.custom.MyLatLng;
import com.drone.monitor.bean.Drone;
import com.tools.module.amap.map.LocalMapConfig;
import com.drone.monitor.bean.MonitorDevice;
import com.tools.module.common.utils.ResourceUtil;
import com.tools.module.common.utils.HandlerUtils;
import com.tools.module.common.utils.XAppLogger;
import com.tools.module.amap.utils.PositionsUtils;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.Vector;

public abstract class BaseMonitorModel extends BaseModel<MonitorDevice> {

    /**
     * 当前设备状态
     */
    private volatile int currentMonitorStatus = MonitorDevice.DEVICE_STATUS.POWER_ON;

    /**
     * 记录上一个状态，用来恢复
     */
    private int prevMonitorWorkStatus = currentMonitorStatus;

    /**
     * 当前预警区域状态
     */
    private int currentWarningStatus = MonitorDevice.DEVICE_STATUS.POWER_ON;

    /**
     * 记录上一个预警状态，用来恢复
     */
    private int prevWarningStatus = currentWarningStatus;

    /**
     * 当前识别区状态
     */
    private int currentDisternAreaStatus = MonitorDevice.DEVICE_STATUS.POWER_ON;

    /**
     * 记录上一个识别区状态，用来恢复
     */
    private int prevDisternStatus = currentDisternAreaStatus;

    private static final int soundIdDefault = 0;
    /**
     * 发射区无人机警告声ID
     */
    private int soundIdDroneWarning = soundIdDefault;

    /**
     * 预警区无人机警告声ID
     */
    private int soundIdDroneEarlyWarning = soundIdDefault;

    /**
     * 设备异常警告声ID
     */
    private int soundIdExceptionWarning = soundIdDefault;


    /**
     * 攻击范围区域最外围点的经纬度
     */
    protected Vector<MyLatLng> pointsAttackPolygon = new Vector<>();

    /**
     * 预警范围区域外围点的经纬度
     */
    protected Vector<MyLatLng> positionsWarningPolygon = new Vector<>();

    /**
     * 识别范围区域外围点的经纬度
     */
    protected Vector<MyLatLng> positionsDisternPolygon = new Vector<>();

    /**
     * 折线点集合
     */
    protected Vector<MyLatLng> positionsBrokenLine = new Vector<>();

    /**
     * 预警区弧线点集合
     */
    protected Vector<MyLatLng> positionsWarningArcLine = new Vector<>();

    /**
     * 识别区弧线点集合
     */
    protected Vector<MyLatLng> positionsDisternArcLine = new Vector<>();

    /**
     * 发射区弧线点集合
     */
    protected Vector<Vector<MyLatLng>> positionsAttackArcLine = new Vector<>();

    /**
     * 扫描多边型点集合,反方向的集合
     */
    protected Vector<Vector<MyLatLng>> positionsScanPolygons = new Vector<>();
    protected volatile int currentScanIndex = 0;
    /**
     * 设备的所有点的经纬度
     */
    protected Vector<Vector<MyLatLng>> allPositions = new Vector<>();

    /**
     * 入侵无人机时设备发射线经纬度集合
     */
    protected Hashtable<String, Vector<Vector<MyLatLng>>> attackLinePositions = new Hashtable<>();
    protected volatile int currentAttackIndex = 0;

    protected final static int FIND_DRONE_TYPE_DEFAULT = 0;
    /**
     * 存放当前在设备发射区域内的无人机Id
     */
    private Hashtable<String, Drone> droneInAttackMap = new Hashtable<>();
    protected int findDroneTypeInAttack;
    private Hashtable<String, Drone> aircraftInAttackMap = new Hashtable<>();

    /**
     * 存放当前在设备预警区域内的无人机Id
     */
    private Hashtable<String, Drone> droneInWarningAreaMap = new Hashtable<>();
    protected int findDroneTypeInWarning;
    private Hashtable<String, Drone> aviationInWarningMap = new Hashtable<>();

    /**
     * 存放当前在设备预警区域内的无人机Id
     */
    private Hashtable<String, Drone> droneinDisternAreaMap = new Hashtable<>();
    protected int findDroneTypeInDistern;
    private Hashtable<String, Drone> aviationInDisternAreaMap = new Hashtable<>();

    /**
     * 子设备Model
     */
    protected volatile HashMap<String, BaseMonitorModel> childMonitorModels = new HashMap<>();
    /**
     * 是否是全向角
     */
    protected volatile boolean isCircle = false;

    protected volatile boolean isErase = false;

    // 是否显示待机区域
    protected volatile boolean isShowAwaitCover = true;

    // 标注是否正在上报数据
    protected boolean isPushFinishDestinationRecord = false;

    public BaseMonitorModel(MonitorDevice monitor) {
        setMonitorDevice(monitor);
        mkModel.type = Drone.MARKER_TYPE.MONITOR;
        currentMonitorStatus = monitor.status;
        calculateAllPoints();
    }


    /**
     * 计算所有点的信息
     */
    private void calculateAllPoints() {
        if (getData().getMonitorId().equals("Controlcenter-beijing")) {
            int i = 0;
        }
        if (needShowAttackCover()) {
            // 获取所有点的信息
            allPositions = PointsUtils.getMonitorAllPositions(getData());
            positionsScanPolygons = PointsUtils.getMonitorScanArrayPoints(getData());
            if (allPositions.size() > 0) {
                pointsAttackPolygon = allPositions.get(MonitorConfig.POINTS_INDEX_ATTACK_POLYGON);
                positionsWarningPolygon = allPositions.get(MonitorConfig.POINTS_INDEX_WARNING_POLYGON);
                positionsDisternPolygon = allPositions.get(MonitorConfig.POINTS_INDEX_DISTERN_POLYGON);
                positionsBrokenLine = allPositions.get(MonitorConfig.POINTS_INDEX_BROKEN_LINE);
                positionsWarningArcLine = allPositions.get(MonitorConfig.POINTS_INDEX_WARING_ARC_LINE);
                positionsDisternArcLine = allPositions.get(MonitorConfig.POINTS_INDEX_DISTERN_ARC_LINE);
                positionsAttackArcLine.clear();
                // 获取出来发射区弧线的所有点集合
                for (int index = MonitorConfig.POINTS_INDEX_DISTERN_ARC_LINE + 1; index < allPositions.size(); index++) {
                    positionsAttackArcLine.add(allPositions.get(index));
                }
            }
        }
    }

    /**
     * 计算设备攻击动画线
     *
     * @param drone
     */
    protected void calculateAttackLinePoints(Drone drone) {
        MyLatLng latLng = drone.getMyLatLng();
        double angle = ComputeUtils.getAngle1(getData().getLongitude(), getData().getLatitude()
                , latLng.longitude, latLng.latitude);
        int minAngle = getData().direct % 360;
        int maxAngle = minAngle + getData().directAngle;
        maxAngle = maxAngle % 360;
        int startAngle;
        int endAngle;
        if ((0 < angle && angle < 90) || (180 < angle && angle < 270)) {
            startAngle = (int) (angle - 32);
            endAngle = (int) (angle + 16);
        } else {
            startAngle = (int) (angle - 16);
            endAngle = (int) (angle + 32);
        }
        if (minAngle > maxAngle) {
            endAngle = Math.min(maxAngle, endAngle);
        } else {
            startAngle = Math.max(minAngle, startAngle);
            endAngle = Math.min(maxAngle, endAngle);
        }
        attackLinePositions.put(drone.getItemId(), PointsUtils.getMonitorAttackLineArrayPoints(getData().getMyLatLng(),
                startAngle, endAngle, getData().workRadius));
    }

    public String getMonitorId() {
        if (getData() != null) {
            return getData().getMonitorId();
        }
        return null;
    }

    public MonitorDevice getData() {
        return (MonitorDevice) super.getData();
    }

    public synchronized MarkerDataModel getMarkerDataModel() {
        mkModel.data = getData();
        return mkModel;
    }

    public MyLatLng getMyLatLng() {
        if (getData() == null) {
            return null;
        }
        return getData().getMyLatLng();
    }

    @Override
    public int getMarkerType() {
        return Drone.MARKER_TYPE.MONITOR;
    }

    @Override
    public int getObjType() {
        return getData().getType();
    }

    public int getCurrentMonitorStatus() {
        return currentMonitorStatus;
    }

    public int getPrevMonitorWorkStatus() {
        return prevMonitorWorkStatus;
    }

    public int getCurrentWarningStatus() {
        return currentWarningStatus;
    }

    public int getCurrentDisternAreaStatus() {
        return currentDisternAreaStatus;
    }

    public abstract void setVisible(boolean visible);

    protected abstract void updateAttackTargetLine(String targetDroneId, MyLatLng latLng);

    protected abstract void removeAttackTargetLine();

    protected abstract void updateDestinationRouteLine(MyLatLng latLng);

    protected abstract void removeDestinationRouteLine();

    protected abstract void onUpdateAttackCover();

    protected void setMonitorDevice(MonitorDevice monitor) {
        data = monitor;
        if (getData().directAngle == 360) {
            isCircle = true;
        } else {
            isCircle = false;
        }
        if (TestConstants.ISTEST) {
            getData().warningRadius = getData().workRadius + MonitorConfig.WARNING_DISTANCE;
            getData().discernRadius = getData().workRadius + MonitorConfig.DISTERN_DISTANCE;
        }
    }

    protected void clearDroneRecordInvadeModelData(DroneRecordInvadeModel model) {
        if (model != null) {
            model.setId("");
            model.setAlias("");
            model.setInvadeType(INVADE_AREA_TYPE.NO);
            model.setDeviceLatlng(null);
        }
    }

    protected void setDroneRecordInvadeModel(DroneRecordInvadeModel model, int invadeType) {
        model.setInvadeType(invadeType);
        model.setId(getData().getMonitorId());
        model.setAlias(getData().getAlias());
        model.setDeviceLatlng(getData().getMyLatLng());
    }
    // ------------------ 点击相关 -------------------------------

    /**
     * 用于点击事件状态
     * 设备的信息没有变化，只是状态发生了改变
     */
    public boolean clickMonitor() {
        boolean isUpdate = false;
        int newMonitorStatus = MonitorDevice.DEVICE_STATUS.SELECTED;

        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "点击了设备:"
                + getData().getMonitorId() + " | 当前状态:" + currentMonitorStatus
                + " | 新状态:" + newMonitorStatus);

        checkSound(newMonitorStatus, currentWarningStatus, currentDisternAreaStatus);

        // 位置，角度没变化，但状态变了，只更新上面的浮层
        if (newMonitorStatus != currentMonitorStatus) {
            // 改变当前状态为下一个状态
            setNextMonitorStatus(newMonitorStatus);
            // 但有可能状态没有变化，如果变成下一个状态，则更新cover
            if (newMonitorStatus == currentMonitorStatus) {
                updateAttackCover(true);
                isUpdate = true;
            }
        }

        return isUpdate;
    }

    // ------------------ 点击相关 -------------------------------


    // ----------------------  绘图相关 -------------------------------

    protected abstract void startScanAnimation();

    protected abstract void startTwinkle();

    protected synchronized void startAnimation() {
        updateScanCover();
    }

    protected synchronized void stopAnimation() {
        removeScanCover();
    }

    protected boolean isTimingHideAttackCover() {
        return true;
    }

    /**
     * 用于初始化，不进行任何状态的判断，直接添加
     */
    public void updateMonitor() {
        updateAttackCover();
        updateWarningCover();
        updateDiscernCover();
        updateLines();
        updateRadiusTvs();
        updateNameTvs();
        updateDestinationRouteLine(true);
        startScanAnimation();
        if (isTimingHideAttackCover()) {
            if (!SHOW_AWAIT_COVER) {
                HandlerUtils.getUIHandler().removeCallbacks(updateAttackCoverRunnalbe);
                HandlerUtils.getUIHandler().postDelayed(updateAttackCoverRunnalbe, 10000);
            }
        }
    }

    private void onTimerSetShowAwaitCover(int nextMonitorStatus) {
        if (SHOW_AWAIT_COVER) {
            return;
        }
        // 表示开机前设备属于关机或异常状态，此时进行覆盖区倒计时处理
        if (prevMonitorWorkStatus != MonitorDevice.DEVICE_STATUS.POWER_ON) {
            if (nextMonitorStatus == MonitorDevice.DEVICE_STATUS.POWER_ON) {
                isShowAwaitCover = true;
                if (isTimingHideAttackCover()) {
                    HandlerUtils.getUIHandler().removeCallbacks(updateAttackCoverRunnalbe);
                    HandlerUtils.getUIHandler().postDelayed(updateAttackCoverRunnalbe, 10000);
                }
                return;
            }
        }
    }

    // 是否显示待机区域
    public static final boolean SHOW_AWAIT_COVER = true;
    private Runnable updateAttackCoverRunnalbe = new Runnable() {
        @Override
        public void run() {
            isShowAwaitCover = SHOW_AWAIT_COVER;
            onUpdateAttackCover();
        }
    };

    /**
     * 更新设备的状态值
     *
     * @param newMonitor
     */
    public boolean updateMonitor(MonitorDevice newMonitor) {

        boolean isUpdate = false;

        if (newMonitor != null) {

            boolean isChanged = false;
            boolean isAngleChanged = false;
            boolean isWorkRadiusChanged = false;
            boolean isStatusChanged = false;
            boolean isPositionChanged = false;
            boolean isDestinationLatlngChanged = false;
            boolean isTargetDroneChanged = false;

            if (newMonitor.isRecognizable()) {

                // 类型信息一定不能变化，不然需要退出app重新进入才能更新
                isAngleChanged = isAngleChanged(newMonitor.direct, newMonitor.directAngle);
                isWorkRadiusChanged = isWorkRadiusChanged(newMonitor);
                isStatusChanged = isDeviceStatusChanged(newMonitor);
                // 所有设备都需要比较距离
                isPositionChanged = isPositionChanged(new MyLatLng(newMonitor.getLatitude(), newMonitor.getLongitude()));
                // 设备的目的地是否变化
                isDestinationLatlngChanged = isDestinationLatlngChanged(newMonitor.getTargetLatlng());
                // 攻击无人机是否改变
                isTargetDroneChanged = isTargetDroneChanged(newMonitor.getTargetDroneId());

                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "检测设备更新 设备id:" + newMonitor.getMonitorId()
                        + " | 角度变化:" + isAngleChanged
                        + " | 位置变化:" + isPositionChanged
                        + " | 状态变化:" + isStatusChanged
                        + " | 半径变化:" + isWorkRadiusChanged);
                // 位置或角度或状态有变化，重新计算所有点后更新
                if (isAngleChanged || isWorkRadiusChanged || isPositionChanged
                        || isStatusChanged || isDestinationLatlngChanged || isTargetDroneChanged) {
                    isChanged = true;
                }
            }

            if (isChanged) {

                int newMonitorStatus = newMonitor.status;

                checkSound(newMonitorStatus, currentWarningStatus, currentDisternAreaStatus);

                if (isStatusChanged) {
                    onTimerSetShowAwaitCover(newMonitorStatus);
                }

                setNextMonitorStatus(newMonitorStatus);

                setMonitorDevice(newMonitor);

                calculateAllPoints();

                updateMarker(isStatusChanged, isAngleChanged, isPositionChanged);
                updateAttackCover(isStatusChanged, isAngleChanged, isPositionChanged, isWorkRadiusChanged);
                updateWarningCover(isStatusChanged, isAngleChanged, isPositionChanged, isWorkRadiusChanged);
                updateDiscernCover(isStatusChanged, isAngleChanged, isPositionChanged, isWorkRadiusChanged);
                updateDestinationRouteLine(isDestinationLatlngChanged);

                if (isStatusChanged || isWorkRadiusChanged) {
                    updateScanCover(isStatusChanged, isWorkRadiusChanged);
                    startScanAnimation();
                }

                updateLines(isAngleChanged, isPositionChanged, isWorkRadiusChanged);
                updateRadiusTvs(isAngleChanged, isPositionChanged, isWorkRadiusChanged);
                updateNameTvs(isAngleChanged, isPositionChanged, isWorkRadiusChanged);

                startTwinkle();

                isUpdate = true;

            } else {

                getData().updateShowInfo(newMonitor);
            }
            // 设备更新时主动查询无人机经纬度进行更新连接线
            updateAttackTaskLine(isTargetDroneChanged);
        }
        return isUpdate;
    }

    protected synchronized void updateDestinationRouteLine(boolean isChanged) {
        updateDestinationRouteLine(false, isChanged);
    }

    /**
     * 更新到达目的地的连线
     */
    protected synchronized void updateDestinationRouteLine(boolean isFirst, boolean isChanged) {
        if (getData().isCanExecuteTaskMonitor()) {
            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "检测目的地路线 设备id:"
                    + getData().getAlias() + " | 设备经纬度：" + (getData().getTargetLatlng() == null ? "null" : getData().getTargetLatlng().toString()));
            if (getData().getTargetLatlng() != null) {
                if (getData().getTargetState() == MonitorDevice.ATTACK_STATE.CREATE) {
                    // 判断是否是给当前设备布置的任务，通过距离判断
                    double taskToSelfDistance = ComputeUtils.getDistance(getData().getMyLatLng(), new MyLatLng(LocalMapConfig.LATITUDE, LocalMapConfig.LONGITUDE));
                    if (taskToSelfDistance <= 20) {
                        // 表明是给自己布置的任务,则进行语音播报
                        if (isChanged) {
                            // 进行经纬度查询地址名称进行语音播报
                            MapObserver.notifyArriveDestination(getData().getTargetLatlng(), isFirst);
                        }
                    }
                    double distance = ComputeUtils.getDistance(getData().getMyLatLng(), getData().getTargetLatlng());
                    if (distance > 50) {
                        updateDestinationRouteLine(getData().getTargetLatlng());
                    } else {
                        if (!isPushFinishDestinationRecord) {
                            // 语音提示到达目的地
                            WarningManager.getInstance().startFlushPlay(R.string.speech_monitor_arrive_destination_tip);
                            isPushFinishDestinationRecord = true;
                            MapObserver.notifyPushArriveDestination(getData().getTaskId(), getData().getMonitorId(), getData().getTargetLatlng().latitude,
                                    getData().getTargetLatlng().longitude, new Function1<Boolean, Unit>() {
                                        @Override
                                        public Unit invoke(Boolean aBoolean) {
                                            HandlerUtils.getUIHandler().postDelayed(new Runnable() {
                                                @Override
                                                public void run() {
                                                    isPushFinishDestinationRecord = false;
                                                }
                                            }, 5000);
                                            return null;
                                        }
                                    });
                        }
                    }
                } else {
                    isPushFinishDestinationRecord = false;
                    removeDestinationRouteLine();
                }
            } else {
                isPushFinishDestinationRecord = false;
                removeDestinationRouteLine();
            }
        }
    }

    /**
     * 更新攻击任务线
     */
    protected synchronized void updateAttackTaskLine(boolean isTargetDroneChanged) {
        if (getData().isCanExecuteTaskMonitor()) {
            if (!TextUtils.isEmpty(getData().getTargetDroneId())) {
                if (getData().getTargetState() == MonitorDevice.ATTACK_STATE.CREATE) {
                    BaseDroneModel droneModel = MapController.getDroneModel(getData().getTargetDroneId());
                    if (droneModel != null && droneModel.getData() != null) {
                        updateAttackTargetLine(droneModel.getData().getItemId(), droneModel.getData().getMyLatLng());
                    } else {
                        removeAttackTargetLine();
                    }
                } else {
                    removeAttackTargetLine();
                }
            } else {
                removeAttackTargetLine();
            }
        }
    }

    protected synchronized void updateScanCover() {
        updateScanCover(false, false);
    }

    /**
     * 更新扫描覆盖区
     */
    protected abstract void updateScanCover(boolean isStatusChanged, boolean isWorkRadiusChanged);

    /**
     * 更新marker图标
     *
     * @param isStatusChanged
     * @param isAngleChanged
     * @param isPositionChanged
     */
    protected abstract void updateMarker(boolean isStatusChanged, boolean isAngleChanged, boolean isPositionChanged);

    /**
     * 更新发射区cover
     *
     * @return
     */
    protected synchronized void updateAttackCover() {
        updateMarker(false, false, false);
        updateAttackCover(false, false, false, false);
        startTwinkle();
    }

    /**
     * 更新发射区cover
     *
     * @return
     */
    protected synchronized void updateAttackCover(boolean isStatusChanged) {
        updateMarker(isStatusChanged, false, false);
        updateAttackCover(isStatusChanged, false, false, false);
        startTwinkle();
    }

    /**
     * 更新发射区cover
     *
     * @param isAngleChanged
     * @param isPositionChanged
     */
    protected abstract void updateAttackCover(boolean isStatusChanged, boolean isAngleChanged, boolean isPositionChanged, boolean isWorkRadiusChanged);

    /**
     * 更新预警区cover
     */
    protected void updateWarningCover() {
        updateWarningCover(false, false, false, false);
        startTwinkle();
    }

    /**
     * 更新预警区cover
     */
    protected void updateWarningCover(boolean isStatusChanged) {
        updateWarningCover(isStatusChanged, false, false, false);
        startTwinkle();
    }

    /**
     * 更新预警区cover
     *
     * @param isAngleChanged
     * @param isPositionChanged
     */
    protected abstract void updateWarningCover(boolean isStatusChanged, boolean isAngleChanged, boolean isPositionChanged, boolean isWorkRadiusChanged);

    /**
     * 更新识别区cover
     */
    protected void updateDiscernCover() {
        updateDiscernCover(false, false, false, false);
    }

    /**
     * 更新识别区cover
     */
    protected void updateDiscernCover(boolean isStatusChanged) {
        updateDiscernCover(isStatusChanged, false, false, false);
        startTwinkle();
    }

    /**
     * 更新识别区cover
     *
     * @param isStatusChanged
     * @param isAngleChanged
     * @param isPositionChanged
     */
    protected abstract void updateDiscernCover(boolean isStatusChanged, boolean isAngleChanged, boolean isPositionChanged, boolean isWorkRadiusChanged);

    /**
     * 添加所有的线
     */
    protected synchronized void updateLines() {
        updateLines(false, false, false);
    }

    /**
     * 添加所有的线
     *
     * @param isAngleChanged
     * @param isPositionChanged
     * @param isWorkRadiusChanged
     */
    protected abstract void updateLines(boolean isAngleChanged, boolean isPositionChanged, boolean isWorkRadiusChanged);

    protected synchronized void updateRadiusTvs() {
        updateRadiusTvs(false, false, false);
    }

    /**
     * 更新文字
     *
     * @param isAngleChanged
     * @param isPositionChanged
     * @param isWorkRadiusChanged
     */
    protected abstract void updateRadiusTvs(boolean isAngleChanged, boolean isPositionChanged, boolean isWorkRadiusChanged);

    protected synchronized void updateNameTvs() {
        updateNameTvs(false, false, false);
    }

    /**
     * 更新设备名称文字
     *
     * @param isAngleChanged
     * @param isPositionChanged
     * @param isWorkRadiusChanged
     */
    protected abstract void updateNameTvs(boolean isAngleChanged, boolean isPositionChanged, boolean isWorkRadiusChanged);

    /**
     * 更新设备攻击时的攻击动画线
     *
     * @param drone
     */
    protected synchronized void updateInvadeDrone(Drone drone) {
        if (MonitorConfig.SHOW_INVADEDRONE_ANIMATION) {
            calculateAttackLinePoints(drone);
        }
    }
    // ----------------------  绘图相关 -------------------------------


    // ------------------ 发现无人机相关 -------------------------------

    /**
     * 无人机入侵状态更新
     * 设备的信息没有变化，只是状态发生了改变
     */
    public synchronized boolean findDrone(int invadeType) {
        if (invadeType == INVADE_AREA_TYPE.NO) {
            return false;
        }

        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "设备更新状态无人机 设备id:"
                + getData().getMonitorId() + " | 区域类型:" + invadeType);

        boolean isUpdate = false;
        switch (invadeType) {
            case INVADE_AREA_TYPE.MONITOR_ATTACK:
                isUpdate = findDroneAttackArea();
                break;
            case INVADE_AREA_TYPE.MONITOR_WARNING:
                isUpdate = findDroneWarningArea();
                break;
            case INVADE_AREA_TYPE.MONITOR_DISCERN_AREA:
                isUpdate = findDroneDisternArea();
                break;
        }
        return isUpdate;
    }


    private boolean findDroneAttackArea() {
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "发射区发现无人机 当前状态:" + currentMonitorStatus
                + " | 设备id:" + getData().getMonitorId());
        boolean isUpdate = false;
        checkSound(findDroneTypeInAttack, currentWarningStatus, currentDisternAreaStatus);
        // 只更新上面的浮层
        if (findDroneTypeInAttack != currentMonitorStatus) {
            setNextMonitorStatus(findDroneTypeInAttack);
            // TODO 自动发送指令
//            if (DataManager.getInstance().getAuthorityInfo() != null && DataManager.getInstance().getAuthorityInfo().isAutoMode()) {
//                DataManager.getInstance().sendOrder(true);
//            }
            updateAttackCover(true);
            isUpdate = true;
        }
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "发射区发现无人机处理完成 | 是否更新:" + isUpdate + " | 设备id:" + getData().getMonitorId());
        return isUpdate;
    }

    private boolean findDroneWarningArea() {
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "预警区发现无人机 设备id:"
                + getData().getMonitorId() + " | 当前状态:" + currentWarningStatus
        );
        boolean isUpdate = false;
        checkSound(currentMonitorStatus, findDroneTypeInWarning, currentDisternAreaStatus);
        if (findDroneTypeInWarning != currentWarningStatus) {
            setNextWarningStatus(findDroneTypeInWarning);
            updateWarningCover(true);
            isUpdate = true;
        }
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "预警区发现无人机流程处理完成   | 是否更新:" + isUpdate);
        return isUpdate;
    }

    private boolean findDroneDisternArea() {
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "识别区发现无人机 设备id:"
                + getData().getMonitorId() + " | 当前状态:" + currentDisternAreaStatus);
        boolean isUpdate = false;
        checkSound(currentMonitorStatus, currentWarningStatus, findDroneTypeInDistern);
        if (findDroneTypeInDistern != currentDisternAreaStatus) {
            setNextDisternStatus(findDroneTypeInDistern);
            currentDisternAreaStatus = findDroneTypeInDistern;
            updateDiscernCover(true);
            isUpdate = true;
        }
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "识别区发现无人机流程处理完成   | 是否更新:" + isUpdate);
        return isUpdate;
    }

    // ------------------ 发现无人机相关 -------------------------------


    // --------------------------- 操作数据相关 -----------------------------------

    public BaseMonitorModel getMonitorModel(String deviceId) {
        if (TextUtils.isEmpty(deviceId)) {
            return null;
        }
        if (getMonitorId().equals(deviceId)) {
            return this;
        }
        return childMonitorModels.get(deviceId);
    }

    public DroneRecordInvadeModel isPointInDeviceArea(Drone drone) {
        DroneRecordInvadeModel checkResultModel = new DroneRecordInvadeModel();
        clearDroneRecordInvadeModelData(checkResultModel);
        MyLatLng position = drone.getMyLatLng();
        //如果是检测设备或者手持设备直接返回NO
        if (getData() == null) {
            return checkResultModel;
        }
        if (!getData().isCheckDroneType()) {
            return checkResultModel;
        }
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "设备%s 属于检测类型", getData().getMonitorId());

        boolean inDisternArea = false;
        if (positionsDisternPolygon.size() > 0) {
            if (SpatialRelationUtil.isPolygonContainsPoint(positionsDisternPolygon, position)) {
                inDisternArea = true;
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "设备%s 在识别区", getData().getMonitorId());
                setDroneRecordInvadeModel(checkResultModel, INVADE_AREA_TYPE.MONITOR_DISCERN_AREA);
            }
        }

        if (!inDisternArea) {

            boolean inWarningArea = false;
            if (positionsWarningPolygon.size() > 0) {
                if (SpatialRelationUtil.isPolygonContainsPoint(positionsWarningPolygon, position)) {
                    inWarningArea = true;
                    XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "设备%s 在预警区", getData().getMonitorId());
                    setDroneRecordInvadeModel(checkResultModel, INVADE_AREA_TYPE.MONITOR_WARNING);
                }
            }
            if (!inWarningArea && SpatialRelationUtil.isPolygonContainsPoint(pointsAttackPolygon, position)) {
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "设备%s 在发射区", getData().getMonitorId());
                setDroneRecordInvadeModel(checkResultModel, INVADE_AREA_TYPE.MONITOR_ATTACK);
            }
        }
        return checkResultModel;
    }

    /**
     * 提供给负载体判断使用
     *
     * @param latitude
     * @param longitude
     * @return
     */
    public String getPointInAttackAreaDeviceId(double latitude, double longitude) {
        if (getData() != null && getData().isCanRemoteOperationMonitor()) {
            if (childMonitorModels != null && childMonitorModels.size() > 0) {
                boolean inAttackArea;
                for (Map.Entry<String, BaseMonitorModel> entry : childMonitorModels.entrySet()) {
                    BaseMonitorModel childDevice = entry.getValue();
                    if (childDevice != null) {
                        inAttackArea = childDevice.isPointInAttackArea(latitude, longitude);
                        if (inAttackArea) {
                            return childDevice.getMonitorId();
                        }
                    }
                }
            }
            if (isPointInAttackArea(latitude, longitude)) {
                return getMonitorId();
            }
        }
        return null;
    }

    public boolean isPointInAttackArea(double latitude, double longitude) {
        if (getData() != null && getData().isCanRemoteOperationMonitor()) {
            if (SpatialRelationUtil.isPolygonContainsPoint(pointsAttackPolygon, new MyLatLng(latitude, longitude))) {
                return true;
            }
        }
        return false;
    }

    @UiThread
    public synchronized void addDrone(Drone drone, int invadeType) {
        int invadeType1 = INVADE_AREA_TYPE.NO;
        int invadeType2 = INVADE_AREA_TYPE.NO;
        Hashtable<String, Drone> temporaryMap = null;
        switch (invadeType) {
            case INVADE_AREA_TYPE.MONITOR_ATTACK:
                invadeType1 = INVADE_AREA_TYPE.MONITOR_WARNING;
                invadeType2 = INVADE_AREA_TYPE.MONITOR_DISCERN_AREA;
                if (drone.isCheckTargetObject()) {
                    temporaryMap = droneInAttackMap;
                } else {
                    temporaryMap = aircraftInAttackMap;
                }
                break;
            case INVADE_AREA_TYPE.MONITOR_WARNING:
                invadeType1 = INVADE_AREA_TYPE.MONITOR_ATTACK;
                invadeType2 = INVADE_AREA_TYPE.MONITOR_DISCERN_AREA;
                if (drone.isCheckTargetObject()) {
                    temporaryMap = droneInWarningAreaMap;
                } else {
                    temporaryMap = aviationInWarningMap;
                }
                break;
            case INVADE_AREA_TYPE.MONITOR_DISCERN_AREA:
                invadeType1 = INVADE_AREA_TYPE.MONITOR_ATTACK;
                invadeType2 = INVADE_AREA_TYPE.MONITOR_WARNING;
                if (drone.isCheckTargetObject()) {
                    temporaryMap = droneinDisternAreaMap;
                } else {
                    temporaryMap = aviationInDisternAreaMap;
                }
                break;
        }
        if (invadeType1 != INVADE_AREA_TYPE.NO && invadeType2 != INVADE_AREA_TYPE.NO) {
            deleteDrone(drone, invadeType1);
            deleteDrone(drone, invadeType2);
        }
        if (temporaryMap != null) {
            if (!temporaryMap.containsKey(drone.getItemId())) {
                temporaryMap.put(drone.getItemId(), drone);
                if (drone.isCheckTargetObject()) {
                    switch (invadeType) {
                        case INVADE_AREA_TYPE.MONITOR_ATTACK:
                            if (findDroneTypeInAttack != MonitorDevice.DEVICE_STATUS.FIND_DRONE) {
                                findDroneTypeInAttack = MonitorDevice.DEVICE_STATUS.FIND_DRONE;
                            }
                            break;
                        case INVADE_AREA_TYPE.MONITOR_WARNING:
                            if (findDroneTypeInWarning != MonitorDevice.DEVICE_STATUS.FIND_DRONE) {
                                findDroneTypeInWarning = MonitorDevice.DEVICE_STATUS.FIND_DRONE;
                            }
                            break;
                        case INVADE_AREA_TYPE.MONITOR_DISCERN_AREA:
                            if (findDroneTypeInDistern != MonitorDevice.DEVICE_STATUS.FIND_DRONE) {
                                findDroneTypeInDistern = MonitorDevice.DEVICE_STATUS.FIND_DRONE;
                            }
                            break;
                    }
                    findDrone(invadeType);
                    // 只有进入攻击区才显示攻击线动画
                    if (invadeType == INVADE_AREA_TYPE.MONITOR_ATTACK) {
                        if (MonitorConfig.SHOW_INVADEDRONE_ANIMATION) {
                            updateInvadeDrone(drone);
                        }
                    }
                    XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "设备%s 区域:%d 添加无人机id:%s 状态:%d 还剩无人机:%d",
                            getData().getMonitorId(), invadeType, drone.toStringConcise(), findDroneTypeInAttack, droneInAttackMap.size());
                }
            } else {
                Drone oldDrone = temporaryMap.get(drone.getItemId());
                if (ComputeUtils.isPositionChanged(oldDrone.getLongitude(), oldDrone.getLatitude()
                        , drone.getLongitude(), drone.getLatitude())) {
                    temporaryMap.put(drone.getItemId(), drone);
                    // 只有进入攻击区才显示攻击线动画
                    if (invadeType == INVADE_AREA_TYPE.MONITOR_ATTACK) {
                        if (MonitorConfig.SHOW_INVADEDRONE_ANIMATION) {
                            updateInvadeDrone(drone);
                        }
                    }
                }
            }
        }
    }

    public void deleteDrone(Drone drone) {
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "deleteDrone()");
        deleteDrone(drone, INVADE_AREA_TYPE.MONITOR_ATTACK);
        deleteDrone(drone, INVADE_AREA_TYPE.MONITOR_WARNING);
        deleteDrone(drone, INVADE_AREA_TYPE.MONITOR_DISCERN_AREA);
    }

    public void deleteDrone(Drone drone, int invadeType) {
        Hashtable<String, Drone> temporaryMap = null;
        switch (invadeType) {
            case INVADE_AREA_TYPE.MONITOR_ATTACK:
                if (drone.isCheckTargetObject()) {
                    temporaryMap = droneInAttackMap;
                } else {
                    temporaryMap = aircraftInAttackMap;
                }
                break;
            case INVADE_AREA_TYPE.MONITOR_WARNING:
                if (drone.isCheckTargetObject()) {
                    temporaryMap = droneInWarningAreaMap;
                } else {
                    temporaryMap = aviationInWarningMap;
                }
                break;
            case INVADE_AREA_TYPE.MONITOR_DISCERN_AREA:
                if (drone.isCheckTargetObject()) {
                    temporaryMap = droneinDisternAreaMap;
                } else {
                    temporaryMap = aviationInDisternAreaMap;
                }
                break;
        }

        if (temporaryMap != null) {
            if (temporaryMap.containsKey(drone.getItemId())) {
                temporaryMap.remove(drone.getItemId());
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "设备%s 区域:%d 删除无人机id:%s 还剩无人机:%d",
                        getData().getMonitorId(), invadeType, drone.toStringConcise(), droneInAttackMap.size());
                // 只有无人机才处理
                if (drone.isCheckTargetObject()) {
                    if (temporaryMap.size() <= 0) {
                        switch (invadeType) {
                            case INVADE_AREA_TYPE.MONITOR_ATTACK:
                                findDroneTypeInAttack = FIND_DRONE_TYPE_DEFAULT;
                                break;
                            case INVADE_AREA_TYPE.MONITOR_WARNING:
                                findDroneTypeInWarning = FIND_DRONE_TYPE_DEFAULT;
                                break;
                            case INVADE_AREA_TYPE.MONITOR_DISCERN_AREA:
                                findDroneTypeInDistern = FIND_DRONE_TYPE_DEFAULT;
                                break;
                        }
                        recoverArea(invadeType);
                        HandlerUtils.getUIHandler().post(new Runnable() {
                            @Override
                            public void run() {
                                removeAttackLine();
                            }
                        });
                    }
                }
            }
        }
    }

    public boolean isContainsDrone(int invadeType, String droneId) {
        switch (invadeType) {
            case INVADE_AREA_TYPE.MONITOR_ATTACK:
                return droneInAttackMap.containsKey(droneId);
            case INVADE_AREA_TYPE.MONITOR_WARNING:
                return droneInWarningAreaMap.containsKey(droneId);
            case INVADE_AREA_TYPE.MONITOR_DISCERN_AREA:
                return droneinDisternAreaMap.containsKey(droneId);
        }
        return false;
    }

    // --------------------------- 操作数据相关 -----------------------------------


    // -----------------  移除恢复绘图相关 -------------------------------

    /**
     * 恢复到前一个状态，只改变覆盖层，不会改变点的位置
     */
    protected void recoverArea() {
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "recoverArea() 1");
        recoverAttackArea();
        recoverWarningArea();
        recoverDiscernArea();
    }

    /**
     * 恢复到前一个状态，只改变覆盖层，不会改变点的位置
     *
     * @param invadeType
     */
    public void recoverArea(int invadeType) {
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "recoverArea：invadeType：" + invadeType);
        switch (invadeType) {
            case INVADE_AREA_TYPE.MONITOR_ATTACK:
                recoverAttackArea();
                break;
            case INVADE_AREA_TYPE.MONITOR_WARNING:
                recoverWarningArea();
                break;
            case INVADE_AREA_TYPE.MONITOR_DISCERN_AREA:
                recoverDiscernArea();
                break;
        }
    }

    public void recoverAttackArea() {
        int nextMonitorStatus;
        if (droneInAttackMap.size() > 0) {
            nextMonitorStatus = findDroneTypeInAttack;
        } else {
            nextMonitorStatus = prevMonitorWorkStatus;
        }
        if (nextMonitorStatus != currentMonitorStatus) {
            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "设备%s 发射区恢复到上一个状态:%d", getData().getMonitorId(), nextMonitorStatus);
            checkSound(nextMonitorStatus, currentWarningStatus, currentDisternAreaStatus);
            currentMonitorStatus = nextMonitorStatus;
            updateAttackCover(true);
        }
    }

    protected void recoverWarningArea() {
        int nextWarningStatus;
        if (!droneInWarningAreaMap.isEmpty()) {
            nextWarningStatus = findDroneTypeInWarning;
        } else {
            nextWarningStatus = prevWarningStatus;
        }
        if (nextWarningStatus != currentWarningStatus) {
            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR,
                    "设备%s 预警区恢复到上一个状态:%s", getData().getMonitorId(), nextWarningStatus);
            checkSound(currentMonitorStatus, nextWarningStatus, currentDisternAreaStatus);
            setNextWarningStatus(nextWarningStatus);
            updateWarningCover(true);
        }
    }

    protected void recoverDiscernArea() {
        int nextDiscernAreaStatus;
        if (!droneinDisternAreaMap.isEmpty()) {
            nextDiscernAreaStatus = findDroneTypeInDistern;
        } else {
            nextDiscernAreaStatus = prevDisternStatus;
        }
        if (nextDiscernAreaStatus != currentDisternAreaStatus) {
            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR,
                    "设备%s 识别区恢复到上一个状态:%s", getData().getMonitorId(), nextDiscernAreaStatus);
            checkSound(currentMonitorStatus, currentWarningStatus, nextDiscernAreaStatus);
            setNextDisternStatus(nextDiscernAreaStatus);
            updateDiscernCover(true);
        }
    }

    /**
     * 将设备从地图上擦除
     */
    public void erase() {
        HandlerUtils.getUIHandler().post(new Runnable() {
            @Override
            public void run() {
                isErase = true;
                droneInAttackMap.clear();
                droneInWarningAreaMap.clear();
                droneinDisternAreaMap.clear();
                pauseAttackDroneWarning();
                // 移除路线
                removeDestinationRouteLine();
                // 移除攻击目标线
                removeAttackTargetLine();
                removeAttackCover();
                removeWarningCover();
                removeDisternCover();
                removeLines();
                removeRadiusTvs();
                removeNameTv();
                removeDeviceMarker();
                removeAttackLine();
            }
        });
    }

    /**
     * 移除发射区cover
     */
    protected abstract void removeScanCover();

    /**
     * 移除发射区cover
     */
    protected abstract void removeAttackCover();

    /**
     * 移除发射线动画
     */
    protected synchronized void removeAttackLine() {
        currentAttackIndex = 0;
        attackLinePositions.clear();
    }

    /**
     * 移除图标
     */
    protected abstract void removeDeviceMarker();

    /**
     * 移除预警区cover
     */
    protected abstract void removeWarningCover();

    /**
     * 移除识别区cover
     */
    protected abstract void removeDisternCover();

    /**
     * 移除所有线
     */
    protected abstract void removeLines();

    /**
     * 移除半径文字
     */
    protected abstract void removeRadiusTvs();

    /**
     * 移除半径文字
     */
    protected abstract void removeNameTv();
    // -----------------  移除恢复绘图相关 -------------------------------


    // ----------------------  状态判断和设置相关 -------------------------------

    protected boolean isCircle() {
        return isCircle;
    }

    protected boolean needShowDisternTwinkle() {
        if (needShowDisternArea()) {
            return AppConfig.SHOW_TWINKLE_DISTERN;
        }
        return false;
    }

    protected boolean needShowDisternArea() {
        boolean needShowDisternArea = false;
        if (AppConfig.SHOW_AREA_DISTERN && getData().isRecognizable()) {
            if (getData().isCanRemoteOperationMonitor()) {
                needShowDisternArea = true;
            }
        }
        return needShowDisternArea;
    }

    protected boolean needShowWarningTwinkle() {
        if (needShowWarningArea()) {
            return AppConfig.SHOW_TWINKLE_WARNING;
        }
        return false;
    }

    protected boolean needShowWarningArea() {
        boolean needShowDisternArea = false;
        if (AppConfig.SHOW_AREA_WARNING && getData().isRecognizable()) {
            if (getData().isCanRemoteOperationMonitor()) {
                needShowDisternArea = true;
            }
        }
        return needShowDisternArea;
    }

    protected boolean needShowScanLine() {
        boolean isShowScan = false;
        if (AppConfig.SHOW_SCAN) {
            isShowScan = needShowAttackCover();
        }
        return isShowScan;
    }

    protected boolean needShowLine() {
        boolean needShowLine = false;
        if (AppConfig.SHOW_RADIUS_LINE) {
            needShowLine = needShowAttackCover();
        }
        return needShowLine;
    }

    protected boolean needShowRadiusTvs() {
        boolean needShowRadiusTv = false;
        if (AppConfig.SHOW_RADIUS_TV) {
            needShowRadiusTv = needShowAttackCover();
        }
        return needShowRadiusTv;
    }

    protected boolean needShowMonitorIdTv() {
        boolean needShowMonitorIdTv = false;
        if (AppConfig.SHOW_MONITOR_ID) {
            needShowMonitorIdTv = needShowAttackCover();
        }
        return needShowMonitorIdTv;
    }

    protected boolean needShowAttackTwinkle() {
        if (needShowAttackCover()) {
            return AppConfig.SHOW_TWINKLE_ATTACK;
        }
        return false;
    }

    protected boolean needShowAttackCover() {
        boolean needShowCover = false;
        if (getData().isRecognizable()) {
            needShowCover = getData().isCanRemoteOperationMonitor();
        }
        return needShowCover;
    }

    protected boolean needMarker() {
        boolean needMarker = false;
        switch (getData().getType()) {
            // 车载设备手持设备掉线就会消失
            case MonitorDevice.DEVICE_TYPE.DISTURB_HAND_06S01:
                if (AppConfig.SHOW_OFFLINE_CAR_MONITOR) {
                    needMarker = true;
                } else {
                    if (getData().status != MonitorDevice.DEVICE_STATUS.POWER_OFF) {
                        needMarker = true;
                    }
                }
                break;
            default: {
                if (AppConfig.SHOW_OFFLINE_CAR_MONITOR) {
                    needMarker = true;
                } else {
                    if (getData().status != MonitorDevice.DEVICE_STATUS.POWER_OFF) {
                        needMarker = true;
                    }
                }
            }
        }
        return needMarker;
    }

    protected void setNextDisternStatus(int nextDisternStatus) {
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR,
                "更新识别区状态:" + nextDisternStatus +
                        " | 当前状态:" + currentDisternAreaStatus +
                        " | 上个状态:" + prevDisternStatus +
                        " | 设备:" + getData().getMonitorId());
        prevDisternStatus = currentDisternAreaStatus;
        currentDisternAreaStatus = nextDisternStatus;
    }

    protected void setNextWarningStatus(int nextWarningStatus) {
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR,
                "更新预警区状态:" + nextWarningStatus +
                        " | 当前状态:" + currentWarningStatus +
                        " | 上个状态:" + prevWarningStatus +
                        " | 设备:" + getData().getMonitorId());
        prevWarningStatus = currentWarningStatus;
        currentWarningStatus = nextWarningStatus;
    }

    /**
     * 设置当前状态
     * prevMonitorWorkStatus 前一个状态，用来在选择，无人机入侵等之后恢复设备状态
     * currentMonitorStatus 当前状态，用来记录选中，无人机入侵等覆盖状态
     * nextMonitorStatus 设备新的状态
     *
     * @param nextMonitorStatus
     */
    protected void setNextMonitorStatus(int nextMonitorStatus) {
        switch (currentMonitorStatus) {
            case MonitorDevice.DEVICE_STATUS.SELECTED:
                // 当前状态为选中,如果下一个状态不等于上一个状态
                if (nextMonitorStatus != prevMonitorWorkStatus) {
                    // 新状态和前一个状态比，有变化，则通知外部状态变了，关闭当前的操作框
                    XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR,
                            "更新设备状态:" + nextMonitorStatus +
                                    " | 当前状态:" + currentMonitorStatus +
                                    " | 上个状态:" + prevMonitorWorkStatus +
                                    " | 设备:" + getData().getMonitorId());
                    currentMonitorStatus = nextMonitorStatus;
                    // 通知外部状态变了，关闭当前的操作框
                    DataObserver.getInstance().clearSelectMonitor();
                }
                break;
            case MonitorDevice.DEVICE_STATUS.FIND_DRONE:
            case MonitorDevice.DEVICE_STATUS.FIND_AVIATION:
                // 当前状态为发现无人机，下一个状态为选中则直接改变当前状态为选中，但不改变前一个状态
                if (nextMonitorStatus == MonitorDevice.DEVICE_STATUS.SELECTED) {
                    XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR,
                            "更新设备状态:" + nextMonitorStatus +
                                    " | 当前状态:" + currentMonitorStatus +
                                    " | 上个状态:" + prevMonitorWorkStatus +
                                    " | 设备:" + getData().getMonitorId());
                    currentMonitorStatus = nextMonitorStatus;
                }
                break;
            case MonitorDevice.DEVICE_STATUS.POWER_ON:
            case MonitorDevice.DEVICE_STATUS.POWER_OFF:
            case MonitorDevice.DEVICE_STATUS.WORK:
            case MonitorDevice.DEVICE_STATUS.EXCEPTION:
            case MonitorDevice.DEVICE_STATUS.MAINTAIN:
            default:
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR,
                        "更新设备状态:" + nextMonitorStatus +
                                " | 当前状态:" + currentMonitorStatus +
                                " | 上个状态:" + prevMonitorWorkStatus +
                                " | 设备:" + getData().getMonitorId());
                //记录上一个状态和当前状态
                prevMonitorWorkStatus = currentMonitorStatus;
                currentMonitorStatus = nextMonitorStatus;
                break;
        }
    }

    protected boolean isDeviceStatusChanged(MonitorDevice newMonitor) {
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "判断状态更新 设备:%s 当前状态:" + newMonitor.status
                + " | 本地数据的设备状态:" + getData().status, getData().getMonitorId());
        if (newMonitor.status != getData().status) {
            return true;
        }
        return false;
    }

    /**
     * 工作半径
     *
     * @param newMonitor
     * @return
     */
    protected boolean isWorkRadiusChanged(MonitorDevice newMonitor) {
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "判断工作半径更新 设备:%s 工作半径:" + newMonitor.workRadius
                + " | 本地数据的工作半径:" + getData().workRadius, getData().getMonitorId());
        if (getData().workRadius != newMonitor.workRadius) {
            return true;
        }
        return false;
    }

    /**
     * 目标位置是否改变
     *
     * @param newDestinationLatLng
     * @return
     */
    public boolean isDestinationLatlngChanged(MyLatLng newDestinationLatLng) {
        if (newDestinationLatLng != null) {
            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "目的地变更检测 设备:%s 经纬度:" + newDestinationLatLng.toString()
                    + " | 本地数据经纬度:" + (getData().getTargetLatlng() == null ? "" : getData().getTargetLatlng().toString()), getData().getMonitorId());
            if (getData().getTargetLatlng() == null) {
                return true;
            }
            if (newDestinationLatLng.latitude != getData().getTargetLatlng().latitude
                    || newDestinationLatLng.longitude != getData().getTargetLatlng().longitude) {
                return true;
            }
        } else {
            if (getData().getTargetLatlng() != null) {
                return true;
            }
        }
        return false;
    }

    /**
     * 攻击无人机的id是否改变
     *
     * @param droneId
     * @return
     */
    public boolean isTargetDroneChanged(String droneId) {
        if (TextUtils.isEmpty(getData().getTargetDroneId())) {
            if (!TextUtils.isEmpty(droneId)) {
                return true;
            }
        } else {
            if (!getData().getTargetDroneId().equals(droneId)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 大于3米才算是移动
     *
     * @param newMonitorLatLng
     * @return
     */
    public boolean isPositionChanged(MyLatLng newMonitorLatLng) {
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "判断经纬度更新 设备:%s 经纬度: latitude:" + newMonitorLatLng.latitude
                + " | longitude:" + newMonitorLatLng.longitude
                + " | 本地数据经纬度: latitude:" + getData().getLatitude()
                + " | longitude:" + getData().getLongitude(), getData().getMonitorId());
        return ComputeUtils.isPositionChanged(getData().getLongitude(), getData().getLatitude(), newMonitorLatLng.longitude, newMonitorLatLng.latitude);
    }

    /**
     * 是否角度有变化
     *
     * @param direct
     * @param directAngle
     * @return
     */
    private boolean isAngleChanged(int direct, int directAngle) {
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "判断角度更新 设备:%s 角度: direct:" + direct
                + " | directAngle:" + directAngle
                + " | 本地数据角度: direct:" + getData().direct
                + " | directAngle:" + getData().directAngle, getData().getMonitorId());
        if (getData().directAngle != directAngle ||
                (getData().direct != direct && Math.abs(getData().direct - direct) > MonitorConfig.PREVENT_SHAKE_ANGLE)) {
            return true;
        }
        return false;
    }

    protected boolean inVisibleBounds() {
        return PositionsUtils.inVisibleBounds(getData().getMyLatLng());
    }
    // ----------------------  状态判断和设置相关 -------------------------------


    // ---------------- 声音相关 --------------------------------

    public void clearSound() {
        currentMonitorStatus = soundIdDefault;
        prevMonitorWorkStatus = soundIdDefault;
        currentWarningStatus = soundIdDefault;
        prevWarningStatus = soundIdDefault;
        currentDisternAreaStatus = soundIdDefault;
        prevDisternStatus = soundIdDefault;
    }

    public void checkSound() {
        checkSound(currentMonitorStatus, currentWarningStatus, currentDisternAreaStatus);
    }

    public boolean checkVibrator() {
        if (aircraftInAttackMap.size() > 0 || aviationInWarningMap.size() > 0 || aviationInDisternAreaMap.size() > 0) {
            WarningManager.getInstance().startVibrator();
            return true;
        } else {
            WarningManager.getInstance().stopVibrator();
        }
        return false;
    }

    private void checkSound(int monitorStatus, int warningStatus, int disternAreaStatus) {
        boolean playExceptionSound = false;
        boolean playDroneSound = false;
        switch (monitorStatus) {
            case MonitorDevice.DEVICE_STATUS.POWER_OFF:
                // 上一个状态是开机变成关机再报警
                if (currentMonitorStatus == MonitorDevice.DEVICE_STATUS.POWER_ON) {
                    // TODO 先去掉设备掉线报警,避免手持设备长时间不动出去待机状态报警
                    if (LocalMapConfig.USE_SPEAK) {
                        playExceptionSound = true;
                    }
                }
                break;
            case MonitorDevice.DEVICE_STATUS.EXCEPTION:
                // TODO 先去掉设备异常时报警处理，改成文字提示
                if (LocalMapConfig.USE_SPEAK) {
                    playExceptionSound = true;
                }
                break;
            default:
                if (droneInAttackMap.size() > 0) {
                    playDroneSound = true;
                } else {
                    playDroneSound = false;
                }
                playExceptionSound = false;
                break;
        }
        if (currentMonitorStatus != monitorStatus) {
            if (playExceptionSound) {
                playExceptionWarning(monitorStatus);
            } else {
                if (playDroneSound) {
                    playAttackDroneWarning();
                } else {
                    pauseAttackDroneWarning();
                }
                pauseExceptionWarning();
            }
        }
    }

    private Runnable delayResetAttackDroneSoundId = new Runnable() {
        @Override
        public void run() {
            if (soundIdDroneWarning != soundIdDefault) {
                soundIdDroneWarning = soundIdDefault;
                WarningManager.getInstance().stopVibrator();
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "倒计时恢复发现无人机警报！！！");
            }
        }
    };

    private void playAttackDroneWarning() {
        if (LocalMapConfig.USE_SPEAK) {
            WarningManager.getInstance().startFlushPlay(R.string.speech_find_drone_in_monitor_tip, true, true);
            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "播放发现无人机警报！！！");
        } else {
            if (soundIdDroneWarning == soundIdDefault) {
                soundIdDroneWarning = WarningManager.getInstance().findDroneStartPlay();
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "播放发现无人机警报！！！ | soundIdDroneWarning:%d", soundIdDroneWarning);
                HandlerUtils.getThreadHanlder().postDelayed(delayResetAttackDroneSoundId, SoundManager.HAVE_DRONE_PLAY_COUNT * 4 * 1000);
            }
        }
    }

    private void pauseAttackDroneWarning() {
        if (!LocalMapConfig.USE_SPEAK) {
            if (soundIdDroneWarning != soundIdDefault) {
                WarningManager.getInstance().stopWarning(soundIdDroneWarning);
                WarningManager.getInstance().stopVibrator();
                soundIdDroneWarning = soundIdDefault;
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "暂停发现无人机警报！！！ | soundIdDroneWarning:%d", soundIdDroneWarning);
                HandlerUtils.getThreadHanlder().removeCallbacks(delayResetAttackDroneSoundId);
            }
        }
    }

    private Runnable delayResetExceptionSoundId = new Runnable() {
        @Override
        public void run() {
            if (soundIdExceptionWarning != soundIdDefault) {
                soundIdExceptionWarning = soundIdDefault;
                WarningManager.getInstance().stopVibrator();
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "倒计时异常警报！！！");
            }
        }
    };

    private void playExceptionWarning(int monitorStatus) {
        if (LocalMapConfig.USE_SPEAK) {
            String content = null;
            if (monitorStatus == MonitorDevice.DEVICE_STATUS.EXCEPTION) {
                content = ResourceUtil.getContent(R.string.speech_monitor_exception_tip, getData().getAlias());
            } else if (monitorStatus == MonitorDevice.DEVICE_STATUS.POWER_OFF) {
                content = ResourceUtil.getContent(R.string.speech_monitor_offline_tip, getData().getAlias());
            }
            if (!TextUtils.isEmpty(content)) {
                WarningManager.getInstance().startFlushPlay(content, true, true);
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "播放异常警报！！！");
            }
        } else {
            if (AppConfig.MONITOR_EXCEPTION_WARNING) {
                if (soundIdExceptionWarning == soundIdDefault) {
                    soundIdExceptionWarning = WarningManager.getInstance().deviceExceptionStartPlay();
                    XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "播放异常警报！！！ | soundIdExceptionWarning:%d", soundIdExceptionWarning);
                    HandlerUtils.getThreadHanlder().postDelayed(delayResetExceptionSoundId, SoundManager.EXCEPTION_PLAY_COUNT * 10 * 1000);
                }
            }
        }
    }

    private void pauseExceptionWarning() {
        if (!LocalMapConfig.USE_SPEAK) {
            if (AppConfig.MONITOR_EXCEPTION_WARNING) {
                if (soundIdExceptionWarning != soundIdDefault) {
                    WarningManager.getInstance().stopWarning(soundIdExceptionWarning);
                    WarningManager.getInstance().stopVibrator();
                    soundIdExceptionWarning = soundIdDefault;
                    XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_MONITOR, "暂停异常警报！！！");
                    HandlerUtils.getThreadHanlder().removeCallbacks(delayResetExceptionSoundId);
                }
            }
        }
    }

    public interface INVADE_AREA_TYPE {
        int NO = 0;
        int MONITOR_ATTACK = 1;
        int MONITOR_WARNING = 2;
        int MONITOR_DISCERN_AREA = 3;
        int DISTRICT_FENCE_AREA = 4;
    }
}
