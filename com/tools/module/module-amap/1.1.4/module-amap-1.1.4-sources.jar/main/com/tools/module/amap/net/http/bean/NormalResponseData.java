package com.tools.module.amap.net.http.bean;


import com.tools.module.common.annotation.NotProguard;

@NotProguard
public class NormalResponseData<T> extends HttpBaseResponseData {
    public T data;

    @Override
    public String toString() {
        return "NormalResponseData{" +
                "code=" + code +
                ", message='" + message + '\'' +
                ", data=" + data +
                '}';
    }
}