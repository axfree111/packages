package com.drone.monitor.bean

import android.text.TextUtils
import com.drone.monitor.bean.custom.MyLatLng
import com.tools.module.amap.R
import com.tools.module.amap.manager.ResourceManager
import com.tools.module.common.utils.ResourceUtil
import io.protostuff.Tag
import java.util.Date

class Drone : BaseData() {
    /**
     * 经度
     */
    @Tag(1)
    var longitude = 0.0
        set(value) {
            field = value
            setShowLongitude(value)
        }
    /**
     * 维度
     */
    @Tag(2)
    var latitude = 0.0
        set(value) {
            field = value
            setShowLatitude(value)
        }


    /**
     * 高度
     */
    @JvmField
    @Tag(3)
    var height: Double = 0.0

    @Tag(4)
    var itemId: String = ""
        set(value) {
            field = value
            setShowId(value)
            setShowName(value)
        }

    @JvmField
    @Tag(5)
    var createTime: Date = Date()

    /**
     * type = 1 公安系统下发信息
     * type = 2 大疆设备监测数据
     * type = 3 航空识别信息，此类型需要区别显示
     */
    @Tag(6)
    var type = 0
        set(value) {
            field = value
            setMarkerType(getMarkerType())
        }

    @JvmField
    @Tag(7)
    var yaw: Int = 0

    /**
     * 0 - 无人机消失
     * 1 - 无人机正常
     * 2 - 无人机
     */
    @JvmField
    @Tag(8)
    var state: Int = 0

    /**
     * 扩展信息 比如 速度  航班号 航空识别码等
     */
    @Tag(9)
    var ext: String? = null

    var nameString: String? = null

    fun setLatLng(latLng: MyLatLng?) {
        if (latLng != null) {
            longitude = latLng.longitude
            latitude = latLng.latitude
        }
    }

    fun setLatLng(latitude: Double, longitude: Double) {
        this.longitude = longitude
        this.latitude = latitude
    }

    val myLatLng: MyLatLng
        get() = MyLatLng(latitude, longitude)

    val isRecognizable: Boolean
        get() {
            if (type >= DRONE_TYPE.MIN
                && type <= DRONE_TYPE.MAX
            ) {
                return true
            }
            return false
        }

    val isNeedCalculateAngle: Boolean
        get() = when (type) {
            DRONE_TYPE.AIRCRAFT_FIGHTER,
            DRONE_TYPE.AIRCRAFT_ZHISHENGJI,
            DRONE_TYPE.AIRCRAFT_TONGHANG,
            DRONE_TYPE.AIRCRAFT_OTHER_DIKONGYOUREN -> true

            else -> {
                false
            }
        }

    val isNeedShowOrientation: Boolean
        get() {
            return when (type) {
                DRONE_TYPE.AIRCRAFT_AVIATION,
                DRONE_TYPE.AIRCRAFT_FIGHTER,
                DRONE_TYPE.AIRCRAFT_ZHISHENGJI,
                DRONE_TYPE.AIRCRAFT_TONGHANG,
                DRONE_TYPE.AIRCRAFT_OTHER_DIKONGYOUREN,
                DRONE_TYPE.SHIP_DISTURB_OWNER,
                DRONE_TYPE.SHIP_DISTURB_ENFORCE,
                DRONE_TYPE.SHIP_DISTURB_TROOPS,
                DRONE_TYPE.SHIP_OFFICIAL,
                DRONE_TYPE.SHIP_CONTAINER,
                DRONE_TYPE.SHIP_PASSENGER,
                DRONE_TYPE.SHIP_BULK,
                DRONE_TYPE.SHIP_TUG,
                DRONE_TYPE.SHIP_CRUISE,
                DRONE_TYPE.SHIP_OTHER -> true

                else -> {
                    false
                }
            }
        }

    val isShowClusterObject: Boolean
        get() = false
    //        switch (type) {
//            case DRONE_TYPE.DRONE_FROM_DJ:
//            case DRONE_TYPE.DRONE_FROM_OTHER2:
//            case DRONE_TYPE.DRONE_FROM_CAA:
//            case DRONE_TYPE.DRONE_FROME_QIYE:
//            case DRONE_TYPE.DRONE_FROM_OTHER3:
//            case DRONE_TYPE.DRONE_FROM_TROOPSRADAR:
//            case DRONE_TYPE.DRONE_FROM_OTHER4:
//            case DRONE_TYPE.DRONE_POLICE:
//            case DRONE_TYPE.DRONE_FROM_OTHER5:
//            case DRONE_TYPE.DRONE_FROM_WUXIANDIAN:
//            case DRONE_TYPE.DRONE_FROM_OTHER6:
//            case DRONE_TYPE.DRONE_FROM_OTHER7:
//            case DRONE_TYPE.DRONE_FROM_OTHER1:
//            case DRONE_TYPE.DRONE_FROM_YUNSHAO:
//                return true;
//            default: {
//                return false;
//            }
//        }

    val isCheckTargetObject: Boolean
        /**
         * 是否属于危险设备
         *
         * @return
         */
        get() {
            return when (type) {
                DRONE_TYPE.DRONE_FROM_DJ,
                DRONE_TYPE.DRONE_FROM_OTHER2,
                DRONE_TYPE.DRONE_FROM_CAA,
                DRONE_TYPE.DRONE_FROME_QIYE,
                DRONE_TYPE.DRONE_FROM_OTHER3,
                DRONE_TYPE.DRONE_FROM_TROOPSRADAR,
                DRONE_TYPE.DRONE_FROM_OTHER4,
                DRONE_TYPE.DRONE_POLICE,
                DRONE_TYPE.DRONE_FROM_OTHER5,
                DRONE_TYPE.DRONE_FROM_WUXIANDIAN,
                DRONE_TYPE.DRONE_FROM_OTHER6,
                DRONE_TYPE.DRONE_FROM_OTHER7,
                DRONE_TYPE.DRONE_FROM_OTHER1,
                DRONE_TYPE.DRONE_FROM_YUNSHAO,
                DRONE_TYPE.DRONE_FROM_LOCAL ->
                    //            case DRONE_TYPE.SHIP_DISTURB_OWNER:
                    //            case DRONE_TYPE.SHIP_DISTURB_ENFORCE:
                    //            case DRONE_TYPE.SHIP_OFFICIAL:
                    //            case DRONE_TYPE.SHIP_CONTAINER:
                    //            case DRONE_TYPE.SHIP_PASSENGER:
                    //            case DRONE_TYPE.SHIP_BULK:
                    //            case DRONE_TYPE.SHIP_TUG:
                    //            case DRONE_TYPE.SHIP_CRUISE:
                    //            case DRONE_TYPE.SHIP_OTHER:
                    true

                else -> {
                    false
                }
            }
        }

    val isShowRouteObject: Boolean
        get() {
            return when (type) {
                DRONE_TYPE.DRONE_FROM_DJ, DRONE_TYPE.DRONE_FROM_OTHER2, DRONE_TYPE.DRONE_FROM_CAA, DRONE_TYPE.DRONE_FROME_QIYE, DRONE_TYPE.DRONE_FROM_OTHER3, DRONE_TYPE.DRONE_FROM_TROOPSRADAR, DRONE_TYPE.DRONE_FROM_OTHER4, DRONE_TYPE.DRONE_POLICE, DRONE_TYPE.DRONE_FROM_OTHER5, DRONE_TYPE.DRONE_FROM_WUXIANDIAN, DRONE_TYPE.DRONE_FROM_OTHER6, DRONE_TYPE.DRONE_FROM_OTHER7, DRONE_TYPE.DRONE_FROM_OTHER1, DRONE_TYPE.DRONE_FROM_YUNSHAO, DRONE_TYPE.SHIP_DISTURB_OWNER, DRONE_TYPE.SHIP_DISTURB_ENFORCE, DRONE_TYPE.SHIP_DISTURB_TROOPS, DRONE_TYPE.SHIP_OFFICIAL, DRONE_TYPE.SHIP_CONTAINER, DRONE_TYPE.SHIP_PASSENGER, DRONE_TYPE.SHIP_BULK, DRONE_TYPE.SHIP_TUG, DRONE_TYPE.SHIP_CRUISE, DRONE_TYPE.SHIP_OTHER, DRONE_TYPE.DRONE_FROM_LOCAL -> true
                else -> {
                    false
                }
            }
        }

    override fun getMarkerType(): Int {
        return getMarkerType(type)
    }

    override fun toStringConcise(): String {
        return "Drone{" +
                "itemId='" + itemId + '\'' +
                ", type=" + type +
                ", yaw=" + yaw +
                ", state=" + state +
                '}'
    }

    override fun toString(): String {
        return "Drone{" +
                "itemId='" + itemId + '\'' +
                ", longitude=" + longitude +
                ", latitude=" + latitude +
                ", type=" + type +
                ", height=" + height +
                ", yaw=" + yaw +
                ", createTime=" + createTime +
                ", state=" + state +
                ", ext='" + ext + '\'' +
                '}'
    }

    /**
     * @param newDrone
     */
    fun updateOtherInfo(newDrone: Drone?) {
        this.createTime = this.createTime
        this.ext = this.ext
    }

    fun getShowNameString(): String? {
        if (!TextUtils.isEmpty(nameString)) {
            return nameString
        }
        var contentStr = itemId
        if (TextUtils.isEmpty(itemId)) {
            contentStr = ResourceUtil.getContent(R.string.no_name)
        }
        return ResourceUtil.getContent(R.string.drone_name_label, contentStr)
    }

    val heightAndAngleString: String
        get() {
            var yaw = yaw
            if (yaw < 0) {
                yaw = (yaw % 360) + 360
            }
            val remainder = yaw % 45
            val index = yaw / 45
            return ResourceUtil.getContent(
                R.string.drone_height_and_angle_label,
                height,
                ResourceManager.DRONE_ANGLE_STRING[index % 8],
                remainder
            )
        }

    val latLngString: String
        get() = ResourceUtil.getContent(
            R.string.drone_latlng_label,
            longitude,
            latitude
        )

    fun copy(drone: Drone) {
        itemId = drone.itemId
        type = drone.type
        state = drone.state
        height = drone.height
        setLatLng(drone.myLatLng)
        createTime = drone.createTime
        yaw = drone.yaw
        ext = drone.ext
        super.copy(drone)
    }

    fun updateBaseData() {
        setShowId(itemId)
        setShowName(itemId)
        setShowLatitude(latitude)
        setShowLongitude(longitude)
        setShowExt(ext)
        setMarkerType(getMarkerType())
    }

    interface DRONE_TYPE {
        companion object {
            const val DRONE_FROM_DJ: Int = 1 //大疆设备监测数据
            const val DRONE_FROM_OTHER2: Int = 2 //没定义类型
            const val DRONE_FROM_CAA: Int = 5 //民航侦测无人机
            const val DRONE_FROME_QIYE: Int = 6 //厂家企业无人机信息
            const val DRONE_FROM_OTHER3: Int = 7 //没定义类型
            const val DRONE_NONGYEZHIBAO: Int = 8 //农业植保机
            const val DRONE_FROM_TROOPSRADAR: Int = 9 //部队雷达信息
            const val DRONE_FROM_OTHER4: Int = 10 //没定义类型
            const val DRONE_POLICE: Int = 11 //军用无人机
            const val DRONE_FROM_OTHER5: Int = 12 //没定义类型
            const val DRONE_FROM_WUXIANDIAN: Int = 13 //无线电信息
            const val DRONE_FROM_OTHER6: Int = 14 //没定义类型
            const val DRONE_FROM_OTHER7: Int = 15 //没定义类型

            const val DRONE_FROM_LOCAL: Int = 16 //没定义类型

            const val DRONE_FROM_OTHER1: Int = 23 //没定义类型
            const val DRONE_FROM_YUNSHAO: Int = 24 //云哨信息

            const val AIRCRAFT_AVIATION: Int = 3 //航空识别信息，此类型需要区别显示
            const val AIRCRAFT_FIGHTER: Int = 4 //战斗机
            const val AIRCRAFT_ZHISHENGJI: Int = 25 //直升机
            const val AIRCRAFT_TONGHANG: Int = 26 //通航
            const val AIRCRAFT_OTHER_DIKONGYOUREN: Int = 27 //其他低空有人飞机

            // 自身设备船舶
            const val SHIP_DISTURB_OWNER: Int = 28 //民用船舶
            const val SHIP_DISTURB_ENFORCE: Int = 29 //执法船舶
            const val SHIP_DISTURB_TROOPS: Int = 30 //军用船舶

            // 船舶类型
            const val SHIP_OFFICIAL: Int = 40 //公务船
            const val SHIP_CONTAINER: Int = 41 //集装船
            const val SHIP_PASSENGER: Int = 42 //客船
            const val SHIP_BULK: Int = 43 //散货舶
            const val SHIP_TUG: Int = 44 //拖船
            const val SHIP_CRUISE: Int = 45 //邮轮
            const val SHIP_OTHER: Int = 46 //其他

            const val MIN: Int = 1
            const val MAX: Int = 46
        }
    }

    interface MARKER_TYPE {
        companion object {
            const val DRONE: Int = 1
            const val SHIP: Int = 2
            const val AIRCRAFT: Int = 3
            const val VIDEO: Int = 4
            const val MONITOR: Int = 5
            const val SELECT_AREA: Int = 6
            const val DISTRICT_FENCE: Int = 7
        }
    }

    companion object {
        @JvmStatic
        fun getMarkerType(value: Int): Int {
            when (value) {
                DRONE_TYPE.DRONE_FROM_DJ, DRONE_TYPE.DRONE_FROM_OTHER2, DRONE_TYPE.DRONE_FROM_CAA, DRONE_TYPE.DRONE_FROME_QIYE, DRONE_TYPE.DRONE_FROM_OTHER3, DRONE_TYPE.DRONE_FROM_TROOPSRADAR, DRONE_TYPE.DRONE_FROM_OTHER4, DRONE_TYPE.DRONE_POLICE, DRONE_TYPE.DRONE_FROM_OTHER5, DRONE_TYPE.DRONE_FROM_WUXIANDIAN, DRONE_TYPE.DRONE_FROM_OTHER6, DRONE_TYPE.DRONE_FROM_OTHER7, DRONE_TYPE.DRONE_FROM_OTHER1, DRONE_TYPE.DRONE_FROM_YUNSHAO, DRONE_TYPE.DRONE_FROM_LOCAL -> return MARKER_TYPE.DRONE
                DRONE_TYPE.SHIP_DISTURB_OWNER, DRONE_TYPE.SHIP_DISTURB_ENFORCE, DRONE_TYPE.SHIP_DISTURB_TROOPS, DRONE_TYPE.SHIP_OFFICIAL, DRONE_TYPE.SHIP_CONTAINER, DRONE_TYPE.SHIP_PASSENGER, DRONE_TYPE.SHIP_BULK, DRONE_TYPE.SHIP_TUG, DRONE_TYPE.SHIP_CRUISE, DRONE_TYPE.SHIP_OTHER -> return MARKER_TYPE.SHIP
                DRONE_TYPE.AIRCRAFT_AVIATION, DRONE_TYPE.AIRCRAFT_FIGHTER, DRONE_TYPE.AIRCRAFT_ZHISHENGJI, DRONE_TYPE.AIRCRAFT_TONGHANG, DRONE_TYPE.AIRCRAFT_OTHER_DIKONGYOUREN -> return MARKER_TYPE.AIRCRAFT
            }
            return 0
        }
    }
}
