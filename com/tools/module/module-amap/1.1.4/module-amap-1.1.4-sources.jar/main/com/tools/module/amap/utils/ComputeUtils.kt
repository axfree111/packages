package com.tools.module.amap.utils

import com.drone.monitor.bean.custom.MyLatLng
import com.tools.module.amap.map.LocalMapConfig
import com.drone.monitor.bean.WarningAreaBaseInfo
import com.tools.module.amap.map.utils.Gps
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Date: 2025/4/1
 * Desc:
 *
 * author: jaje
 */
object ComputeUtils {
    private var pi: Double = 3.1415926535897932384626
    private var a: Double = 6378245.0
    private var ee: Double = 0.00669342162296594323
    private const val EARTH_RADIUS: Double = 6378137.0
    // 防位置抖动临界值
    private const val PREVENT_SHAKE_DISTANCE: Double = 5.0

    fun test() {
        // 北斗芯片获取的经纬度为WGS84地理坐标 31.426896,119.496145
        val gps = Gps(31.426896, 119.496145)
        println("gps :$gps")
        val gcj = gps84_To_Gcj02(gps.wgLat, gps.wgLon)
        println("gcj :$gcj")
        val star = gcj02_To_Wgp84(gcj.wgLat, gcj.wgLon)
        println("star:$star")
        val bd = gcj02_To_Bd09(gcj.wgLat, gcj.wgLon)
        println("bd  :$bd")
        val gcj2 = bd09_To_Gcj02(bd.wgLat, bd.wgLon)
        println("gcj :$gcj2")
    }

    //使用数学的方法计算需要画扇形的圆弧上的点坐标
    @JvmStatic
    fun eOffsetBearing(point: MyLatLng, dist: Double, bearing: Float): MyLatLng {
        //计算1经度与原点的距离
        var bearing = bearing
        val latConv: Double = calculateDistance(
            point.longitude,
            point.latitude,
            point.longitude,
            point.latitude + 0.1
        ) * 10.0
        //计算1纬度与原点的距离
        val lngConv: Double = calculateDistance(
            point.longitude,
            point.latitude,
            point.longitude + 0.1,
            point.latitude
        ) * 10.0
        if (bearing < 0) {
            bearing = (bearing % 360) + 360
        }
        //算余5度
        val remainder = bearing % LocalMapConfig.MIN_ANGLE
        val distRemainder = dist % LocalMapConfig.INTERVAL
        val radiiIndex = (dist / LocalMapConfig.INTERVAL).toInt()
        if (distRemainder == 0.0 && radiiIndex >= 1) {
            //%72计算超过360的度数
            val bearIndex = (bearing / LocalMapConfig.MIN_ANGLE).toInt() % 72
            if (remainder == 0f && ComputeDataProvider.ARC_POINT_TABLE != null) {
                if (ComputeDataProvider.ARC_POINT_TABLE.size >= radiiIndex) {
                    val arcPointOffsets = ComputeDataProvider.ARC_POINT_TABLE[radiiIndex - 1]
                    if (arcPointOffsets != null && arcPointOffsets.size > bearIndex) {
                        val pointOffset = arcPointOffsets[bearIndex]
                        val lat = point.latitude + pointOffset.lat / latConv
                        val lng = point.longitude + pointOffset.lng / lngConv
                        return MyLatLng(lat, lng)
                    }
                }
            } else {
                //需要画一个点补充5度夹角中间的一个点
            }
        } else {
            //需要画不是整除500的弧线的点
        }
        //正弦计算待获取的点的纬度与原点纬度差
        val lat: Double =
            point.latitude + getArcPointLatOffset(dist, bearing) / latConv
        //余弦计算待获取的点的经度与原点经度差
        val lng: Double =
            point.longitude + getArcPointlngOffset(dist, bearing) / lngConv
        return MyLatLng(lat, lng)
    }

    @JvmStatic
    fun getDistance(latLng1: MyLatLng, latLng2: MyLatLng): Double {
        return getDistance(latLng1.longitude, latLng1.latitude, latLng2.longitude, latLng2.latitude)
    }

    /**
     * 返回单位是米
     *
     * @param longitude1
     * @param latitude1
     * @param longitude2
     * @param latitude2
     * @return
     */
    @JvmStatic
    fun getDistance(
        longitude1: Double, latitude1: Double,
        longitude2: Double, latitude2: Double
    ): Double {
        val Lat1 = rad(latitude1)
        val Lat2 = rad(latitude2)
        val a = Lat1 - Lat2
        val b = rad(longitude1) - rad(longitude2)
        var s = 2 * asin(sqrt(sin(a / 2).pow(2.0) + cos(Lat1) * cos(Lat2) * sin(b / 2).pow(2.0)))
        s = s * EARTH_RADIUS
        s = (Math.round(s * 10000) / 10000).toDouble()
        return s
    }

    private fun rad(d: Double): Double {
        return d * Math.PI / 180.0
    }

    @JvmStatic
    fun calulateXYAnagle(latLng1: MyLatLng, latLng2: MyLatLng): Float {
        return calulateXYAnagle(
            latLng1.longitude,
            latLng1.latitude,
            latLng2.longitude,
            latLng2.latitude
        )
    }

    /**
     * 根据两点计算方向角度
     *
     * @param longitude1
     * @param latitude1
     * @param longitude2
     * @param latitude2
     * @return
     */
    @JvmStatic
    fun calulateXYAnagle(
        longitude1: Double, latitude1: Double, longitude2: Double,
        latitude2: Double
    ): Float {
        val tan = (atan(
            abs((latitude2 - latitude1) / (longitude2 - longitude1))
        ) * 180 / Math.PI).toFloat()
        return if (longitude2 > longitude1 && latitude2 > latitude1)  // 第一象限
        {
            -tan
        } else if (longitude2 > longitude1 && latitude2 < latitude1)  // 第二象限
        {
            tan
        } else if (longitude2 < longitude1 && latitude2 > latitude1)  // 第三象限
        {
            tan - 180
        } else {
            180 - tan
        }
    }

    @JvmStatic
    fun getAngle(startPoint: MyLatLng, endPoint: MyLatLng): Int {
        return getAngle(
            startPoint.latitude,
            startPoint.longitude,
            endPoint.latitude,
            endPoint.longitude
        )
    }

    @JvmStatic
    fun getAngle(startLatitude: Double, startLongitude: Double,
        endLatitude: Double, endLongitude: Double): Int {
        if (startLatitude == 0.0 || startLongitude == 0.0 || endLatitude == 0.0 || endLongitude == 0.0) {
            return -1
        }
        if (startLatitude == endLatitude && startLongitude == endLongitude) {
            return -1
        }
        val longitude1 = startLongitude
        val longitude2 = endLongitude
        val latitude1 = Math.toRadians(startLatitude)
        val latitude2 = Math.toRadians(endLatitude)
        val longDiff = Math.toRadians(longitude2 - longitude1)
        val y = sin(longDiff) * cos(latitude2)
        val x = cos(latitude1) * sin(latitude2) - sin(latitude1) * cos(latitude2) * cos(longDiff)
        return ((Math.toDegrees(atan2(y, x)) + 360) % 360).toInt()
    }

    @JvmStatic
    fun getLatLngs(southWest: MyLatLng?, northeEast: MyLatLng?): List<MyLatLng> {
        if (southWest == null || northeEast == null) {
            return ArrayList(0)
        }
        val latLngs: MutableList<MyLatLng> = ArrayList(4)
        val ll1 = MyLatLng(
            northeEast.latitude,
            northeEast.longitude
        )
        val ll2 = MyLatLng(
            northeEast.latitude,
            southWest.longitude
        )
        val ll3 = MyLatLng(
            southWest.latitude,
            southWest.longitude
        )
        val ll4 = MyLatLng(
            southWest.latitude,
            northeEast.longitude
        )
        latLngs.add(ll1)
        latLngs.add(ll2)
        latLngs.add(ll3)
        latLngs.add(ll4)
        latLngs.add(ll1)
        return latLngs
    }


    /**
     * @param lat_a 纬度1
     * @param lng_a 经度1
     * @param lat_b 纬度2
     * @param lng_b 经度2
     * @return
     */
    @JvmStatic
    fun getAngle1(lat_a: Double, lng_a: Double, lat_b: Double, lng_b: Double): Double {
        if (lng_a == lng_b || lat_a == lat_b) {
            return if (lng_a == lng_b) {
                /** 经度相同 */
                if (lat_b >= lat_a) {
                    0.0
                } else {
                    180.0
                }
            } else {
                /** 纬度相同 */
                if (lng_b >= lng_a) {
                    90.0
                } else {
                    270.0
                }
            }
        }

        var tmpValue = sin(lat_a) * sin(lat_b) + cos(lat_a) * cos(lat_b) * cos(lng_b - lng_a)
        tmpValue = sqrt(1 - tmpValue * tmpValue)
        tmpValue = cos(lat_b) * sin(lng_b - lng_a) / tmpValue
        val resultAngle = abs(asin(tmpValue) * 180 / Math.PI)

        return if (lng_b > lng_a) {
            if (lat_b >= lat_a) {
                /** 第一象限 */
                90 - resultAngle
            } else {
                /** 第二象限 */
                270 + resultAngle
            }
        } else {
            /** 第四象限 */
            if (lat_b >= lat_a) {
                90 + resultAngle
            } else {
                /** 第三象限 */
                270 - resultAngle
            }
        }
    }

    /**
     * 计算名称在图标的位置
     *
     * @param longitude
     * @param latitude
     * @param currentZoomLevel
     * @return
     */
    @JvmStatic
    fun getNameTvPosition(
        longitude: Double, latitude: Double,
        currentZoomLevel: Float
    ): MyLatLng {
        val currentDistance = LocalMapConfig.CURRENT_PX_IN_METERS * 5
        return eOffsetBearing(
            MyLatLng(latitude, longitude),
            currentDistance.toDouble(),
            LocalMapConfig.DEVICE_NAME_SHOW_ANGLE.toFloat()
        )
    }

    @JvmStatic
    fun isPositionChanged(
        longitude1: Double, latitude1: Double,
        longitude2: Double, latitude2: Double
    ): Boolean {
        if (longitude1 != longitude2 || latitude1 != latitude2) {
            val distance =
                calculateDistance(longitude1, latitude1, longitude2, latitude2).toDouble()
            if (distance >= PREVENT_SHAKE_DISTANCE) {
                return true
            }
        }
        return false
    }

    /**
     * 获取两点间距离
     *
     * @param longitude1
     * @param latitude1
     * @param longitude2
     * @param latitude2
     * @return
     */
    @JvmStatic
    fun calculateDistance(
        longitude1: Double, latitude1: Double,
        longitude2: Double, latitude2: Double
    ): Int {
        var x1 = longitude1
        var y1 = latitude1
        var x2 = longitude2
        var y2 = latitude2
        val NF_pi = 0.01745329251994329 // 弧度 PI/180
        x1 *= NF_pi
        y1 *= NF_pi
        x2 *= NF_pi
        y2 *= NF_pi
        val sinx1 = sin(x1)
        val siny1 = sin(y1)
        val cosx1 = cos(x1)
        val cosy1 = cos(y1)
        val sinx2 = sin(x2)
        val siny2 = sin(y2)
        val cosx2 = cos(x2)
        val cosy2 = cos(y2)
        val v1 = DoubleArray(3)
        v1[0] = cosy1 * cosx1 - cosy2 * cosx2
        v1[1] = cosy1 * sinx1 - cosy2 * sinx2
        v1[2] = siny1 - siny2
        val dist = sqrt(v1[0] * v1[0] + v1[1] * v1[1] + v1[2] * v1[2])

        return (asin(dist / 2) * 12742001.5798544).toInt()
    }

    @JvmStatic
    fun getArcPointLatOffset(radii: Double, angle: Float): Double {
        return radii * cos(angle * Math.PI / 180)
    }

    @JvmStatic
    fun getArcPointlngOffset(radii: Double, angle: Float): Double {
        return radii * sin(angle * Math.PI / 180)
    }

    @JvmStatic
    fun getCenterPoint(startPoint: MyLatLng?, endPoint: MyLatLng?): MyLatLng? {
        if (startPoint == null || endPoint == null) {
            return null
        }
        val centerLatitude = startPoint.latitude + (endPoint.latitude - startPoint.latitude) / 2
        val centerLongitude = startPoint.longitude + (endPoint.longitude - startPoint.longitude) / 2
        return MyLatLng(
            centerLatitude,
            centerLongitude
        )
    }

    /**
     * 18      * 84 to 火星坐标系 (GCJ-02) World Geodetic System ==> Mars Geodetic System
     * 19      *
     * 20      * @param lat
     * 21      * @param lon
     * 22      * @return
     * 23
     */
    @JvmStatic
    fun gps84_To_Gcj02(lat: Double, lon: Double): Gps {
        if (outOfChina(lat, lon)) {
            return Gps(lat, lon)
        }
        var dLat = transformLat(lon - 105.0, lat - 35.0)
        var dLon = transformLon(lon - 105.0, lat - 35.0)
        val radLat = lat / 180.0 * pi
        var magic = sin(radLat)
        magic = 1 - ee * magic * magic
        val sqrtMagic = sqrt(magic)
        dLat =
            (dLat * 180.0) / ((a * (1 - ee)) / (magic * sqrtMagic) * pi)
        dLon = (dLon * 180.0) / (a / sqrtMagic * cos(radLat) * pi)
        val mgLat = lat + dLat
        val mgLon = lon + dLon
        return Gps(mgLat, mgLon)
    }

    /**
     * 42      * * 火星坐标系 (GCJ-02) to 84 * * @param lon * @param lat * @return
     * 43      *
     */
    @JvmStatic
    fun gcj02_To_Wgp84(lat: Double, lon: Double): Gps {
        val gps = transform(lat, lon)
        val lontitude = lon * 2 - gps.wgLon
        val latitude = lat * 2 - gps.wgLat
        return Gps(latitude, lontitude)
    }

    /**
     * 52      * 火星坐标系 (GCJ-02) 与百度坐标系 (BD-09) 的转换算法 将 GCJ-02 坐标转换成 BD-09 坐标
     * 53      *
     * 54      * @param gg_lat
     * 55      * @param gg_lon
     * 56
     */
    @JvmStatic
    fun gcj02_To_Bd09(gg_lat: Double, gg_lon: Double): Gps {
        val x = gg_lon
        val y = gg_lat
        val z = sqrt(x * x + y * y) + 0.00002 * sin(y * pi)
        val theta = atan2(y, x) + 0.000003 * cos(x * pi)
        val bd_lon = z * cos(theta) + 0.0065
        val bd_lat = z * sin(theta) + 0.006
        return Gps(bd_lat, bd_lon)
    }

    /**
     * 67      * * 火星坐标系 (GCJ-02) 与百度坐标系 (BD-09) 的转换算法 * * 将 BD-09 坐标转换成GCJ-02 坐标 * * @param
     * 68      * bd_lat * @param bd_lon * @return
     * 69
     */
    @JvmStatic
    fun bd09_To_Gcj02(bd_lat: Double, bd_lon: Double): Gps {
        val x = bd_lon - 0.0065
        val y = bd_lat - 0.006
        val z = sqrt(x * x + y * y) - 0.00002 * sin(y * pi)
        val theta = atan2(y, x) - 0.000003 * cos(x * pi)
        val gg_lon = z * cos(theta)
        val gg_lat = z * sin(theta)
        return Gps(gg_lat, gg_lon)
    }

    /**
     * 80      * (BD-09)-->84
     * 81      * @param bd_lat
     * 82      * @param bd_lon
     * 83      * @return
     * 84
     */
    @JvmStatic
    fun bd09_To_Gps84(bd_lat: Double, bd_lon: Double): Gps {
        val gcj02 = bd09_To_Gcj02(bd_lat, bd_lon)
        val map84 = gcj02_To_Wgp84(
            gcj02.wgLat,
            gcj02.wgLon
        )
        return map84
    }

    @JvmStatic
    fun gcj_To_Wgp84(latLng: List<MyLatLng?>?): List<MyLatLng>? {
        if (latLng == null || latLng.size <= 0) {
            return null
        }
        val wgp84LatLngs: MutableList<MyLatLng> = java.util.ArrayList(latLng.size)
        for (ll in latLng) {
            if (ll != null) {
                val gps84: Gps = gcj02_To_Wgp84(ll.latitude, ll.longitude)
                val wgp84LatLng = MyLatLng(
                    gps84.wgLat,
                    gps84.wgLon
                )
                wgp84LatLngs.add(wgp84LatLng)
            }
        }
        return wgp84LatLngs
    }

    @JvmStatic
    fun gcj_To_Wgp84(body: WarningAreaBaseInfo?) {
        if (body != null) {
            val gps84: Gps = gcj02_To_Wgp84(body.latitude, body.longitude)
            body.setCenterLatLng(gps84.wgLat, gps84.wgLon)
        }
    }

    @JvmStatic
    fun gcj_To_Wgp84(latLng: MyLatLng?): MyLatLng? {
        var wgp84LatLng: MyLatLng? = null
        if (latLng != null) {
            val gps84 = gcj02_To_Wgp84(latLng.latitude, latLng.longitude)
            wgp84LatLng =
                MyLatLng(gps84.wgLat, gps84.wgLon)
        }
        return wgp84LatLng
    }

    @JvmStatic
    fun outOfChina(lat: Double, lon: Double): Boolean {
        if (lon < 72.004 || lon > 137.8347) return true
        if (lat < 0.8293 || lat > 55.8271) return true
        return false
    }

    @JvmStatic
    fun transform(lat: Double, lon: Double): Gps {
        if (outOfChina(lat, lon)) {
            return Gps(lat, lon)
        }
        var dLat = transformLat(lon - 105.0, lat - 35.0)
        var dLon = transformLon(lon - 105.0, lat - 35.0)
        val radLat = lat / 180.0 * pi
        var magic = sin(radLat)
        magic = 1 - ee * magic * magic
        val sqrtMagic = sqrt(magic)
        dLat =
            (dLat * 180.0) / ((a * (1 - ee)) / (magic * sqrtMagic) * pi)
        dLon = (dLon * 180.0) / (a / sqrtMagic * cos(radLat) * pi)
        val mgLat = lat + dLat
        val mgLon = lon + dLon
        return Gps(mgLat, mgLon)
    }

    @JvmStatic
    fun transformLat(x: Double, y: Double): Double {
        var ret = (-100.0 + 2.0 * x + 3.0 * y + 0.2 * y * y + 0.1 * x * y + 0.2 * sqrt(abs(x)))
        ret += (20.0 * sin(6.0 * x * pi) + 20.0 * sin(2.0 * x * pi)) * 2.0 / 3.0
        ret += (20.0 * sin(y * pi) + 40.0 * sin(y / 3.0 * pi)) * 2.0 / 3.0
        ret += (160.0 * sin(y / 12.0 * pi) + 320 * sin(y * pi / 30.0)) * 2.0 / 3.0
        return ret
    }

    @JvmStatic
    fun transformLon(x: Double, y: Double): Double {
        var ret = 300.0 + x + 2.0 * y + 0.1 * x * x + 0.1 * x * y + (0.1
                * sqrt(abs(x)))
        ret += (20.0 * sin(6.0 * x * pi) + 20.0 * sin(2.0 * x * pi)) * 2.0 / 3.0
        ret += (20.0 * sin(x * pi) + 40.0 * sin(x / 3.0 * pi)) * 2.0 / 3.0
        ret += (150.0 * sin(x / 12.0 * pi) + 300.0 * sin(
            x / 30.0
                    * pi
        )) * 2.0 / 3.0
        return ret
    }
}