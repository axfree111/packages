package com.tools.module.amap.model.amap;

import com.amap.api.maps.model.Circle;
import com.amap.api.maps.model.Polygon;
import com.amap.api.maps.model.Polyline;
import com.amap.api.maps.model.Text;
import com.tools.module.amap.model.base.BaseMonitorModel;
import com.tools.module.amap.model.base.BaseShapeModel;

/**
 * Created by jiajiecsf on 12/27/20.
 */
public class AMapShapeModel extends BaseShapeModel {

    // 手绘线
    private Polyline handWritePolyline;
    // 直线
    private Polyline linePolyline;
    // 空心圆
    private Circle hollowCircle;
    // 实心圆
    private Circle fillCircle;
    // 空心矩形
    private Polyline hollowRectPolyline;
    // 实心矩形
    private Polygon fillRectPolygon;
    // 文字
    private Text tv;
    // 图片
    private BaseMonitorModel baseMonitorModel;

    public Polyline getHandWritePolyline() {
        return handWritePolyline;
    }

    public void setHandWritePolyline(Polyline handWritePolyline) {
        this.handWritePolyline = handWritePolyline;
    }

    public Polyline getLinePolyline() {
        return linePolyline;
    }

    public void setLinePolyline(Polyline linePolyline) {
        this.linePolyline = linePolyline;
    }

    public Circle getHollowCircle() {
        return hollowCircle;
    }

    public void setHollowCircle(Circle hollowCircle) {
        this.hollowCircle = hollowCircle;
    }

    public Circle getFillCircle() {
        return fillCircle;
    }

    public void setFillCircle(Circle fillCircle) {
        this.fillCircle = fillCircle;
    }

    public Polyline getHollowRectPolyline() {
        return hollowRectPolyline;
    }

    public void setHollowRectPolyline(Polyline hollowRectPolyline) {
        this.hollowRectPolyline = hollowRectPolyline;
    }

    public Polygon getFillRectPolygon() {
        return fillRectPolygon;
    }

    public void setFillRectPolygon(Polygon fillRectPolygon) {
        this.fillRectPolygon = fillRectPolygon;
    }

    public Text getTv() {
        return tv;
    }

    public void setTv(Text tv) {
        this.tv = tv;
    }

    public BaseMonitorModel getBaseMonitorModel() {
        return baseMonitorModel;
    }

    public void setBaseMonitorModel(BaseMonitorModel baseMonitorModel) {
        this.baseMonitorModel = baseMonitorModel;
    }
}
