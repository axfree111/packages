package com.tools.module.amap.model;

/**
 * Date: 2025/4/2
 * Desc:
 * <p>
 * author: jaje
 */
public class DroneConfig {
    // 是否显示无人机进入预警区时的波纹提示线
    public static final boolean SHOW_DRONE_WEARING_LINE = true;
    // 是否显示无人机入侵时和设备的连线
    public static final boolean SHOW_DRONE_TO_MONITOE_ROUTE_LINE = false;
    public static final int AROUND_DRONE_CIRCLE_LINE_WIDTH = 7;
    public static final int AROUND_DRONE_CIRCLE_LINE_RADIUS = 50;
    // 是否显示无人机上的距离标注
    public static final boolean SHOW_DRONE_DISTENCE_TV = false;
    // 动画延迟发送
    public static final int ANIMATION_DELAY_TIME = 3 * 1000;
    // 无人机最大间隔时长,表示关过机
    public static final int DRONE_MAX_TIME_IS_OFF = 130 * 1000;
    // 无人机显示间隔时间
    public static final int DRONE_SHOW_INTERVAL_TIME = 2 * 60 * 1000;
    // 无人机警告线宽度
    public static float DONRE_WARING_LINE_WIDTH = 7f;
}
