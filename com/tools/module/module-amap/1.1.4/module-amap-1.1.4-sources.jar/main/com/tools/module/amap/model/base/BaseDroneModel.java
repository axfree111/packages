package com.tools.module.amap.model.base;

import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;

import androidx.annotation.UiThread;

import com.drone.monitor.bean.MonitorDevice;
import com.tools.module.common.utils.MathUtils;
import com.tools.module.amap.BaseConstants;
import com.tools.module.amap.R;
import com.tools.module.amap.manager.ColorManager;
import com.tools.module.amap.manager.UserCenter;
import com.tools.module.amap.map.MapConstants;
import com.tools.module.amap.map.MapController;
import com.tools.module.amap.map.utils.PointsUtils;
import com.tools.module.amap.model.DroneConfig;
import com.tools.module.amap.model.DroneRecordInvadeModel;
import com.tools.module.amap.model.MarkerDataModel;
import com.drone.monitor.bean.custom.MyLatLng;
import com.tools.module.amap.model.RoutePointModel;
import com.tools.module.amap.observer.DataObserver;
import com.drone.monitor.bean.BaseRouteHistoryData;
import com.drone.monitor.bean.Drone;
import com.tools.module.amap.map.LocalMapConfig;
import com.tools.module.common.utils.ResourceUtil;
import com.tools.module.common.utils.HandlerUtils;
import com.tools.module.common.utils.XAppLogger;
import com.tools.module.amap.utils.ComputeUtils;
import com.tools.module.amap.utils.PositionsUtils;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Vector;

/**
 * Created by jiajie on 2019-07-20.
 */
public abstract class BaseDroneModel extends BaseModel {

    // TODO 需要解决无人机重复显示问题
    public int markerType;
    protected static final int warningRadius = 5;
    private MarkerDataModel.DroneExtraModel extraModel = new MarkerDataModel.DroneExtraModel();

    /**
     * 入侵无人机时和设备的连接线经纬度集合
     */
    protected Hashtable<String, Vector<MyLatLng>> attackRouteLinePositions = new Hashtable<>();
    protected volatile Hashtable<String, Integer> mToMonitorLineIndexMap = new Hashtable<>();
    /**
     * 存放当前无人机影响的监控设备
     */
    private Hashtable<String, DroneRecordInvadeModel> invadeMap = new Hashtable();

    protected static int warningColor = ColorManager.getDroneWarningAreasColor();


    public BaseDroneModel(Drone drone) {

        setDroneData(drone);

        markerType = getData().getMarkerType();
        mkModel.type = markerType;
    }

    public boolean isMarkerAnchor() {
        switch (getMarkerType()) {
            case Drone.MARKER_TYPE.AIRCRAFT:
            case Drone.MARKER_TYPE.SHIP:
                return true;
        }
        return false;
    }

    @Override
    public synchronized Drone getData() {
        return (Drone) super.getData();
    }

    protected abstract void updateDroneMarker();

    protected abstract void addMarker();

    protected abstract void removeMarker();

    public abstract void startAnimation();

    public abstract void showMarkerWindow();

    public abstract void hideMarkerWindow();

    public abstract void showDistanceInfo();

    public abstract void hideDistanceInfo();

    public abstract void onWarningTwinkle();

    public abstract void onCancelWaringTwinkle();

    /**
     * 计算无人机到设备的连线的点集合
     */
    protected void calculateAttackRoutePoints(DroneRecordInvadeModel resultModel) {
        attackRouteLinePositions.put(getData().getItemId(), PointsUtils.getInvadRouteArrayPoints(getData().getMyLatLng(), resultModel.getDeviceLatlng()));
    }

    protected synchronized void updateDroneToMonitorRouteLine(DroneRecordInvadeModel resultModel) {
        calculateAttackRoutePoints(resultModel);
    }

    @Override
    public int getMarkerType() {
        if (getData() != null) {
            return getData().getMarkerType();
        }
        return 0;
    }

    @Override
    public int getObjType() {
        return getData().getType();
    }

    public boolean isShowRoute() {
        return extraModel.isShowTrack;
    }

    public void setShowRoute(boolean showRoute) {
        HandlerUtils.getUIHandler().post(new Runnable() {
            @Override
            public void run() {
                extraModel.isShowTrack = showRoute;
                if (!showRoute) {
                    removeRoute();
                }
            }
        });
    }

    /**
     * TODO 抽离问题
     * TODO 主要是为了接受数据，把数据导入到当前Model
     */
    public void setRoutePointsData(BaseRouteHistoryData historyData) {
        if (historyData != null && historyData.points != null
                && !historyData.points.isEmpty()) {
            if (extraModel.isShowTrack) {
                getData().setHistoryPoints(historyData.points);
                updateRoute();
            }
        } else {
            extraModel.isShowTrack = false;
        }
    }

    public void setRoutePointsData(Drone routeDrone) {
        if (routeDrone != null && routeDrone.getHistoryPoints() != null
                && !routeDrone.getHistoryPoints().isEmpty()) {
            if (extraModel.isShowTrack) {
                getData().setHistoryPoints(routeDrone.getHistoryPoints());
                updateRoute();
            }
        } else {
            extraModel.isShowTrack = false;
        }
    }


    public List<RoutePointModel> getRouteLatLngs() {
        return getData().getHistoryPoints();
    }

    /**
     * 擦除无人机
     */
    public void erase() {
        HandlerUtils.getUIHandler().post(new Runnable() {
            @Override
            public void run() {
                if (getData().getType() == Drone.DRONE_TYPE.AIRCRAFT_AVIATION) {
                    if (getData() != null) {
                        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_DRONE, XAppLogger.TAG_TEST + "xxx" + "erase: --- mDroneId=" + getData().getItemId() + " | " + getData().toString());
                    }
                }
                clearInvadeResultModel();
                onCancelWaringTwinkle();
                removeRoute();
                // 删除无人机标识
                removeMarker();
            }
        });
    }

    private void setDroneData(Drone drone) {

        if (getData() == null) {

            data = drone;
        } else {
            // 民航和战斗机预算飞行方向,位置有变化再做计算
            if (isPositionChanged(drone.getLatitude(), drone.getLongitude())) {
                if (extraModel.isShowTrack) {
                    RoutePointModel pointModel = new RoutePointModel();
                    pointModel.height = drone.height;
                    pointModel.point = new MyLatLng(drone.getLatitude(), drone.getLongitude());
                    RoutePointModel prePointModel = getData().addBackSingleHistoryPoint(pointModel, false);
                    if (prePointModel != null) {
                        // TODO 此处处理单个路径点的添加
                        addRoute(prePointModel, pointModel);
                    }
                    drone.setHistoryPoints(getData().getHistoryPoints());
                }
                if (drone.isNeedCalculateAngle()) {
                    int angle = ComputeUtils.getAngle(getData().getMyLatLng(), drone.getMyLatLng());
                    if (angle == -1) {
                        drone.yaw = getData().yaw;
                    } else {
                        drone.yaw = angle;
                    }
                }
            }
            data = drone;
        }
    }

    protected boolean showDrone() {
        switch (getData().getMarkerType()) {
            case Drone.MARKER_TYPE.DRONE:
                if (!LocalMapConfig.IS_NOFLY_ZONE_SHOW_DRONE
                        && MapController.inDistrictFence(getData().getMyLatLng())) {
                    return false;
                } else {
                    return true;
                }
            case Drone.MARKER_TYPE.AIRCRAFT:
                return LocalMapConfig.IS_SHOW_AIRCRAFT;
            case Drone.MARKER_TYPE.SHIP:
                return LocalMapConfig.IS_SHOW_SHIP;
        }
        return true;
    }

    /**
     * 初始化用
     */
    public synchronized void updateDrone() {
        HandlerUtils.getUIHandler().post(new Runnable() {
            @Override
            public void run() {
                if (showDrone()) {
                    updateDroneMarker();
                    if (invadeMap.size() > 0 || extraModel.isShowTrack) {
                        updateRoute();
                    }
                    checkDistanceInfo(getInvadeResultModels());
                }
            }
        });
    }

    /**
     * 更新用
     *
     * @param newDrone
     */
    @UiThread
    public synchronized boolean updateDrone(Drone newDrone) {
        boolean update = false;

        if (newDrone != null && newDrone.isRecognizable()) {

            if (isChanged(newDrone)) {

                setDroneData(newDrone);

                checkDistanceInfo(getInvadeResultModels());

                update = true;

                if (showDrone()) {

                    if (getData().getType() == Drone.DRONE_TYPE.AIRCRAFT_AVIATION) {
                        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_DRONE, XAppLogger.TAG_TEST + "更新无人机: Id:" + getData().getItemId() + " | 信息:" + getData().toString());
                    }
                    updateDroneMarker();
                    if (extraModel.isShowTrack) {
                        updateRoute();
                    }
                }
            } else {

                getData().updateOtherInfo(newDrone);
            }
        }
        return update;
    }

    protected boolean isShowAnimation() {
        boolean isShow = false;
        if (getData().isCheckTargetObject()) {
            if (getData().height > 10) {
                if (BaseConstants.RANDOM.nextBoolean()) {
                    isShow = true;
                }
            }
        }
        return isShow;
    }

    public synchronized MarkerDataModel getMarkerDataModel() {
        mkModel.data = getData();
        mkModel.extra = extraModel;
        return mkModel;
    }

    protected boolean inVisibleBounds() {
        return PositionsUtils.inVisibleBounds(getData().getMyLatLng());
    }

    protected boolean isShowMarker() {
        switch (getData().getMarkerType()) {
            case Drone.MARKER_TYPE.SHIP:
                if (UserCenter.INSTANCE.isSuperUser()) {
                    if (!MapConstants.isShowTitleOverlay() && inVisibleBounds() && LocalMapConfig.IS_SHOW_SHIP) {
                        return true;
                    }
                } else {
                    if (inVisibleBounds() && LocalMapConfig.IS_SHOW_SHIP) {
                        return true;
                    }
                }
                break;
            case Drone.MARKER_TYPE.AIRCRAFT:
                if (inVisibleBounds()) {
                    return true;
                }
                break;
            case Drone.MARKER_TYPE.DRONE:
                return true;
        }
        return false;
    }

    private boolean isChanged(Drone newDrone) {
        boolean isHeightChanged = isHeightChanged(newDrone.height);
        boolean isPositionChanged = isPositionChanged(newDrone.getLatitude(), newDrone.getLongitude());
        boolean isAngleChanged = isAngleChanged(newDrone.yaw);
        boolean isStateChanged = isStateChanged(newDrone.state);
        if (isHeightChanged || isPositionChanged || isAngleChanged || isStateChanged) {
            return true;
        }
        return false;
    }

    private boolean isStateChanged(int state) {
        if (state != MonitorDevice.DEVICE_STATUS.POWER_ON) {
            return true;
        }
        return false;
    }

    private boolean isHeightChanged(double height) {
        if (getData().height != height && Math.abs(getData().height - height) > 0.3) {
            return true;
        }
        return false;
    }

    /**
     * 大于2米才算是移动
     *
     * @param latitude
     * @param longitude
     * @return
     */
    private boolean isPositionChanged(double latitude, double longitude) {
        if (getData().getLatitude() != latitude || getData().getLongitude() != longitude) {
            double distance = ComputeUtils.getDistance(getData().getLatitude(), getData().getLongitude(),
                    latitude, longitude);
            if (distance >= 2.0D) {
                return true;
            }
        }
        return false;
    }

    /**
     * 是否角度有变化
     *
     * @param yaw
     * @return
     */
    private boolean isAngleChanged(int yaw) {
        if (getData().yaw != yaw) {
            return true;
        } else {
            return false;
        }
    }

    protected int getCircleRadius(int index) {
        return (int) (LocalMapConfig.CURRENT_PX_IN_METERS * 90 * MathUtils.getArcsin(index, warningRadius));
    }

    protected int getCircleWidthRadius(int index) {
        return (int) (DroneConfig.DONRE_WARING_LINE_WIDTH * MathUtils.getArcsin(index, warningRadius));
    }

    public synchronized void checkMonitorResultModel(DroneRecordInvadeModel resultModel) {
        if (isCheckAreaAndAlarm()) {
            String localSaveKey = resultModel.getId();
            // 在DataManager中的唯一key
            String invadeDistanceKey = getInvadeDistanceKey(resultModel);
            SpannableStringBuilder value = getDistanceSpannableStr(resultModel);
            // 显示设备到无人机的连接线
            if (DroneConfig.SHOW_DRONE_TO_MONITOE_ROUTE_LINE) {
                updateDroneToMonitorRouteLine(resultModel);
            }
            if (!invadeMap.containsKey(localSaveKey)) {
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_DRONE, "无人机中添加设备：" + resultModel.toString());
                invadeMap.put(localSaveKey, resultModel);
                // TODO 显示弹窗会遮挡操作设备
//            showMarkerWindow();
                onWarningTwinkle();
                if (!TextUtils.isEmpty(value)) {
                    DataObserver.getInstance().onAddShow(invadeDistanceKey, value);
                }
            } else {
                // 更新数据
                invadeMap.put(localSaveKey, resultModel);
                if (!TextUtils.isEmpty(value)) {
                    DataObserver.getInstance().onUpdate(invadeDistanceKey, value);
                }
            }
            if (DroneConfig.SHOW_DRONE_DISTENCE_TV) {
                showDistanceInfo();
            }
        }
    }

    private void checkDistanceInfo(List<DroneRecordInvadeModel> recordModels) {
        for (DroneRecordInvadeModel recordModel : recordModels) {
            checkMonitorResultModel(recordModel);
        }
    }

    private String getMonitorDistanceKey(String key) {
        return key + "_" + getData().getItemId();
    }

    /**
     * 此key需要是唯一标识，无人机modelKey 或者 设备id_无人机id
     *
     * @param resultModel
     * @return
     */
    private String getInvadeDistanceKey(DroneRecordInvadeModel resultModel) {
        if (resultModel.getInvadeType() != BaseMonitorModel.INVADE_AREA_TYPE.DISTRICT_FENCE_AREA) {
            return getMonitorDistanceKey(resultModel.getId());
        }
        return getClassKey();
    }

    private synchronized void deleteMonitorResultModel(DroneRecordInvadeModel resultModel) {
        deleteInvadeResultModel(resultModel.getId());
    }

    public synchronized void deleteInvadeResultModel(String key) {
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_DRONE, "无人机中移除入侵key：" + key);
        if (invadeMap.containsKey(key)) {
            DroneRecordInvadeModel recordMonitorModel = invadeMap.remove(key);
            // 获取到DataManager中存储的唯一key
            String keyStr = getInvadeDistanceKey(recordMonitorModel);
            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_DRONE, "通知去除无人机距离信息：" + keyStr);
            DataObserver.getInstance().onDeleteShow(keyStr);
            if (invadeMap.size() <= 0) {
                HandlerUtils.getUIHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        onCancelWaringTwinkle();
//                hideMarkerWindow();
//                hideDistanceInfo();
                    }
                });
            }
        }
    }

    protected void clearInvadeResultModel() {
        for (DroneRecordInvadeModel recordModel : getInvadeResultModels()) {
            String key = getInvadeDistanceKey(recordModel);
            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_DRONE, "通知去除无人机入侵距离信息：" + key);
            DataObserver.getInstance().onDeleteShow(key);
            BaseMonitorModel monitorModel = MapController.getMonitorModel(recordModel.getId());
            if (monitorModel != null) {
                monitorModel.deleteDrone(getData());
            }
        }
    }

    public synchronized List<DroneRecordInvadeModel> getInvadeResultModels() {
        List<DroneRecordInvadeModel> copyMonitorIds = new ArrayList<>();
        copyMonitorIds.addAll(invadeMap.values());
        return copyMonitorIds;
    }

    public boolean isCheckAreaAndAlarm() {
        if (getData().isCheckTargetObject()) {
            return true;
        }
        return false;
    }

    public List<SpannableStringBuilder> getDistanceInfos() {
        List<SpannableStringBuilder> strs = new ArrayList<>();
        for (DroneRecordInvadeModel recordMM : invadeMap.values()) {
            SpannableStringBuilder content = getDistanceSpannableStr(recordMM);
            if (content != null) {
                strs.add(content);
            }
        }
        return strs;
    }

    private SpannableStringBuilder getDistanceSpannableStr(DroneRecordInvadeModel recordMM) {
        if (recordMM.getInvadeType() != BaseMonitorModel.INVADE_AREA_TYPE.DISTRICT_FENCE_AREA) {
            MyLatLng myLatlng = recordMM.getDeviceLatlng();
            if (myLatlng != null) {
//                String showMonitor = recordMM.getId();
//                if (showMonitor.length() > 9) {
//                    showMonitor = recordMM.getId().substring(0, 3) + "..." + recordMM.getId().substring(0, 3);
//                }
                String contentStr;
                if (recordMM.getInvadeType() != BaseMonitorModel.INVADE_AREA_TYPE.MONITOR_ATTACK) {
                    double distance = ComputeUtils.getDistance(getData().getLongitude(), getData().getLatitude(),
                            myLatlng.longitude, myLatlng.latitude);
                    distance /= 1000;
                    contentStr = ResourceUtil.getContent(R.string.drone_to_monitor_km_distance_label,
                            getData().getItemId(), recordMM.getAlias(), distance);
                } else {
                    int distance = (int) ComputeUtils.getDistance(getData().getLongitude(), getData().getLatitude(),
                            myLatlng.longitude, myLatlng.latitude);
                    contentStr = ResourceUtil.getContent(R.string.drone_to_monitor_m_distance_label,
                            getData().getItemId(), recordMM.getAlias(), distance);
                }
                SpannableStringBuilder content = new SpannableStringBuilder(contentStr);
                int nameStartIndex = contentStr.indexOf("#", 0);
                int nameEndIndex = contentStr.lastIndexOf("#");
                content.setSpan(new ForegroundColorSpan(ResourceUtil.getColor(R.color.login_main_tv_color)), nameStartIndex, nameEndIndex,
                        Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                int distanceStartIndex = contentStr.indexOf("^", 0);
                int distanceEndIndex = contentStr.lastIndexOf("^");
                content.setSpan(new ForegroundColorSpan(ResourceUtil.getColor(R.color.login_main_tv_color)), distanceStartIndex, distanceEndIndex,
                        Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                content.delete(nameStartIndex, nameStartIndex + 1);
                content.delete(nameEndIndex - 1, nameEndIndex);
                contentStr = contentStr.replaceAll("#", "");
                int startIndex = contentStr.indexOf("^", 0);
                int endIndex = contentStr.lastIndexOf("^");
                content.delete(startIndex, startIndex + 1);
                content.delete(endIndex - 1, endIndex);
                return content;
            }
        } else {
            String contentStr = ResourceUtil.getContent(R.string.drone_invade_label, getData().getItemId());
            SpannableStringBuilder content = new SpannableStringBuilder(contentStr);
            int nameStartIndex = contentStr.indexOf("#", 0);
            int nameEndIndex = contentStr.lastIndexOf("#");
            content.setSpan(new ForegroundColorSpan(ResourceUtil.getColor(R.color.login_main_tv_color)), nameStartIndex, nameEndIndex,
                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            content.delete(nameStartIndex, nameStartIndex + 1);
            content.delete(nameEndIndex - 1, nameEndIndex);
            return content;
        }
        return null;
    }

    public boolean isNeedCalculateAngle() {
        return getData().isNeedCalculateAngle();
    }

    public boolean isNeedShowOrientation() {
        return getData().isNeedShowOrientation();
    }

    public boolean isShowClusterObject() {
        return getData().isShowClusterObject();
    }

    /**
     * 检测报警的类型
     *
     * @return
     */
    public boolean isCheckTargetObject() {
        return getData().isCheckTargetObject();
    }

    public boolean isShowRouteObject() {
        return getData().isShowRouteObject();
    }

    @Override
    public String toString() {
        return "{" +
                "mDrone=" + getData().toStringConcise() +
                ", invadeMap=" + invadeMap +
                '}';
    }
}
