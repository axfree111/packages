package com.drone.monitor.bean.custom;

import java.io.Serializable;

/**
 * 自定义一个toString,打印简洁log
 * Created by jiajie on 2019-09-24.
 */
public class MyObject extends Object implements Serializable {

    public String toStringConcise() {
        return toString();
    }
}
