package com.tools.module.amap.permission

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.core.content.PermissionChecker
import com.tools.module.amap.R
import com.tools.module.amap.permission.PermissionActivity
import com.tools.module.amap.temp.FloatDialog
import com.tools.module.common.ContextStore
import com.tools.module.common.utils.AppUtil

/**
 * 需要target version >= 23编译，才能生效。
 *
 *
 * 以下是危险权限，不检查就直接调用与权限相关的功能，就会crash.一般权限不用特别检查
 * 每个权限组只需申请一个权限即可
 *
 *
 * 权限组	          权限
 *
 *
 * CALENDAR       READ_CALENDAR
 * WRITE_CALENDAR
 *
 *
 * CAMERA         CAMERA
 *
 *
 * CONTACTS       READ_CONTACTS
 * WRITE_CONTACTS
 * GET_ACCOUNTS
 *
 *
 * LOCATION       ACCESS_FINE_LOCATION
 * ACCESS_COARSE_LOCATION
 *
 *
 * MICROPHONE     RECORD_AUDIO
 *
 *
 * PHONE          READ_PHONE_STATE
 * CALL_PHONE
 * READ_CALL_LOG
 * WRITE_CALL_LOG
 * ADD_VOICEMAIL
 * USE_SIP
 * PROCESS_OUTGOING_CALLS
 *
 *
 * SENSORS        BODY_SENSORS
 *
 *
 * SMS            SEND_SMS
 * RECEIVE_SMS
 * READ_SMS
 * RECEIVE_WAP_PUSH
 * RECEIVE_MMS
 *
 *
 * STORAGE        READ_EXTERNAL_STORAGE
 * WRITE_EXTERNAL_STORAGE
 */
object PermissionManager {
    private const val TAG = "PermissionManager"

    @JvmField
    var ALL_PIS: Array<String> = arrayOf(
        Manifest.permission.WRITE_EXTERNAL_STORAGE,
        Manifest.permission.READ_EXTERNAL_STORAGE,
        Manifest.permission.READ_PHONE_STATE,
        Manifest.permission.CAMERA,
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_COARSE_LOCATION
    )

    private val PIS_STRING = arrayOf(
        R.string.permission_storage,
        R.string.permission_storage,
        R.string.permission_phone,
        R.string.permission_camera,
        R.string.permission_mic,
        R.string.permission_location,
        R.string.permission_location
    )


    private var mPermissionCallBack: PermissionCallbacks? = null
    private val permissionKeywords = HashMap<String, Int>()

    /**
     * 检查权限是否都授权了
     */
    @JvmStatic
    fun hasPermissions(vararg perms: String): Boolean {
        // Always return true for SDK < M, let the system deal with the permissions
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return true
        }

        for (perm in perms) {
            var hasPerm = (ContextCompat.checkSelfPermission(ContextStore.getContext(), perm) ==
                    PackageManager.PERMISSION_GRANTED)

            if (hasPerm && isXiaomiPhone) { //小米手机特别处理，二逼的小米
                hasPerm = (PermissionChecker.checkPermission(
                    ContextStore.getContext(), perm,
                    Process.myPid(), Process.myUid(),
                    ContextStore.getContext().packageName
                )
                        == PermissionChecker.PERMISSION_GRANTED)
            }
            Log.i(TAG, "$perm: $hasPerm")
            if (!hasPerm) {
                return false
            }
        }

        return true
    }

    /**
     * 查找
     *
     * @param perms
     * @return
     */
    @JvmStatic
    private fun getRequestPermissions(vararg perms: String): Array<String> {
        val requestPermissionList = ArrayList<String>()
        for (perm in perms) {
            var hasPerm = (ContextCompat.checkSelfPermission(ContextStore.getContext(), perm) ==
                    PackageManager.PERMISSION_GRANTED)

            if (hasPerm && isXiaomiPhone) { //小米手机特别处理，二逼的小米
                hasPerm = (PermissionChecker.checkPermission(
                    ContextStore.getContext(), perm,
                    Process.myPid(), Process.myUid(),
                    ContextStore.getContext().packageName
                )
                        == PermissionChecker.PERMISSION_GRANTED)
            }
            if (!hasPerm) {
                requestPermissionList.add(perm)
            }
        }
        return requestPermissionList.toTypedArray<String>()
    }

    /**
     * 请求权限
     *
     * @param perms 权限列表
     */
    @JvmStatic
    fun checkAndRequestPermissions(callback: PermissionCallbacks?, vararg perms: String) {
        val requestPermissions = getRequestPermissions(*perms)
        if (requestPermissions.isEmpty()) {
            callback?.onPermissionsGranted()
            return
        }

        if (callback != null) {
            mPermissionCallBack = callback
        }

        //借助完全透明activity实现回调
        val bundle = Bundle()
        bundle.putStringArray(PermissionActivity.REQUEST_PERMISSION, requestPermissions)
        val intent = Intent(ContextStore.getContext(), PermissionActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        intent.putExtras(bundle)
        ContextStore.getContext().startActivity(intent)
    }

    /**
     * 获取
     *
     * @param permissions
     * @return
     */
    @JvmStatic
    internal fun getReguestPermissionKeywords(
        context: Context,
        permissions: ArrayList<String>?
    ): String {
        if (null == permissions || permissions.size == 0) {
            return ""
        }

        val stringIdList = ArrayList<Int>()
        for (perm in permissions) {
            val stringId = permissionKeywords[perm]
            if (null != stringId && !stringIdList.contains(stringId)) {
                stringIdList.add(stringId)
            }
        }

        val keywords = StringBuilder(" ")
        for (stringId in stringIdList) {
            keywords.append(context.getString(stringId)).append(" ")
        }
        return keywords.toString()
    }

    private val isXiaomiPhone: Boolean
        //是不是小米手机
        get() = if ("xiaomi".equals(Build.MANUFACTURER, ignoreCase = true)) {
            true
        } else {
            false
        }

    @JvmStatic
    internal fun permissionsGranted() {
        if (mPermissionCallBack != null) {
            Log.v(TAG, "blued permission setting Granted:")
            mPermissionCallBack!!.onPermissionsGranted()
            mPermissionCallBack = null
        }
    }

    @JvmStatic
    internal fun permissionsDenied(vararg perms: String) {
        if (mPermissionCallBack != null) {
            Log.v(
                TAG,
                "blued permission setting Denied and cancel, requestCode:$perms"
            )
            mPermissionCallBack!!.onPermissionsDenied(getRequestPermissions(*perms))
            mPermissionCallBack = null
        }
    }

    /**
     * 检测悬浮框权限
     */
    @JvmStatic
    fun checkOverlayPermission(activity: Activity) {
        if (Build.VERSION.SDK_INT >= 23) {
            if (!Settings.canDrawOverlays(ContextStore.getContext())) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + ContextStore.getContext().packageManager)
                )
                if (AppUtil.canHandleIntent(intent)) {
                    val dialog = FloatDialog(activity)
                    dialog.show()
                }
            }
        }
    }

    @JvmStatic
    fun initPermissionKeywords() {
        permissionKeywords.clear()
        for (i in ALL_PIS.indices) {
            permissionKeywords[ALL_PIS[i]] =
                PIS_STRING[i]
        }
    }
}
