package com.drone.monitor.bean;

import java.util.Date;

public class WarningAreaInfo extends WarningAreaBaseInfo {

    public Date gmtCreate;

    public Date gmtModified;

    public double maxLongitude;//最大经度
    public double minLongitude;
    public double maxLatitude;
    public double minLatitude;

    public void copy(WarningAreaInfo areaInfo) {
        super.copy(areaInfo);
        this.gmtCreate = areaInfo.gmtCreate;
        this.gmtModified = areaInfo.gmtModified;
        this.maxLatitude = areaInfo.maxLatitude;
        this.minLatitude = areaInfo.minLatitude;
        this.maxLongitude = areaInfo.maxLongitude;
        this.minLongitude = areaInfo.minLongitude;
    }

    @Override
    public String toStringConcise() {
        return "WarningAreaInfo{" +
                "id='" + id + '\'' +
                ", gmtCreate=" + gmtCreate +
                ", gmtModified=" + gmtModified +
                ", maxLongitude=" + maxLongitude +
                ", minLongitude=" + minLongitude +
                ", maxLatitude=" + maxLatitude +
                ", minLatitude=" + minLatitude +
                ", longitude=" + longitude +
                ", latitude=" + latitude +
                ", type=" + type +
                ", radius=" + radius +
                ", state=" + state +
                "} ";
    }

    @Override
    public String toString() {
        return "WarningAreaInfo{" +
                "id='" + id + '\'' +
                ", gmtCreate=" + gmtCreate +
                ", gmtModified=" + gmtModified +
                ", maxLongitude=" + maxLongitude +
                ", minLongitude=" + minLongitude +
                ", maxLatitude=" + maxLatitude +
                ", minLatitude=" + minLatitude +
                ", longitude=" + longitude +
                ", latitude=" + latitude +
                ", type=" + type +
                ", radius=" + radius +
                ", state=" + state +
                "} ";
    }
}
