package com.drone.monitor.bean

import android.text.TextUtils
import com.drone.monitor.bean.custom.MyLatLng
import com.tools.module.amap.R
import com.tools.module.common.utils.ResourceUtil
import io.protostuff.Tag
import java.util.Date
import kotlin.math.max

class MonitorDevice : BaseData() {
    @Tag(1)
    var monitorId: String? = null
        set(value) {
            field = value
            setShowId(value)
        }

    var alias: String? = null
        set(value) {
            field = value
            setShowName(value)
        }

    /**
     * 经度
     */
    @Tag(2)
    var longitude: Double = 0.0
        set(value) {
            field = value
            setShowLongitude(value)
        }

    /**
     * 纬度
     */
    @Tag(3)
    var latitude: Double = 0.0
        set(value) {
            field = value
            setShowLatitude(value)
        }

    /**
     * 0-offline
     * 1-online
     */
    @JvmField
    @Tag(4)
    var status: Int = 0

    /**
     * 电压
     */
    @Tag(5)
    var voltage: Float = 0f

    /**
     * 电流
     */
    @Tag(6)
    var current: Float = 0f

    @JvmField
    @Tag(8)
    var direct: Int = 0

    @JvmField
    @Tag(9)
    var directAngle: Int = 0

    /**
     * 设备类型
     */
    @Tag(10)
    var type: Int = 0
        set(value) {
            field = value
            setMarkerType(Drone.MARKER_TYPE.MONITOR)
        }

    /**
     * 工作半径
     */
    @JvmField
    @Tag(11)
    var workRadius: Int = 0

    /**
     * IP地址
     */
    @Tag(12)
    var ip: String? = null

    @Tag(13)
    var createTime: Date? = null

    @Tag(14)
    var updateTime: Date? = null

    @Tag(15)
    var bgswitch: Int = 0

    /**
     * 频段
     */
    @Tag(7)
    var frequencyRange: MutableList<FrequencyRangeInfo> = mutableListOf()

    /**
     * 默认自动发射频段
     */
    var defaultFrequency: MutableList<FrequencyRangeInfo> = mutableListOf()

    var ext: String? = null
        set(value) {
            field = value
            setShowExt(value)
        }

    @JvmField
    var warningRadius: Int = 0

    @JvmField
    var discernRadius: Int = 0

    var monitorOrderDO: MonitorOrderDO? = null

    var childMonitorDevices: MutableList<MonitorDevice> = mutableListOf()
        set(value) {
            field = value
            childMonitorDeviceMap.clear()
            value.forEach { childDevice ->
                childDevice.monitorId?.let { childMonitorDeviceMap[it] = childDevice }
            }
        }

    var childMonitorDeviceMap: HashMap<String, MonitorDevice> = HashMap()

    //--- 其他方法保持不变，仅修改 setXXX 方法为属性 setter ---

    fun contains(equalsMonitorId: String): Boolean {
        if (TextUtils.isEmpty(equalsMonitorId)) return false
        if (monitorId == equalsMonitorId) return true
        for (childDevice in childMonitorDevices) {
            if (childDevice.monitorId == equalsMonitorId) return true
        }
        return false
    }

    val monitorDirectAngle: Int
        get() {
            var endAngle = directAngle
            if (childMonitorDevices.isNotEmpty()) {
                for (childDevice in childMonitorDevices) {
                    endAngle = max(endAngle, childDevice.directAngle)
                }
            }
            return endAngle
        }

    fun isRecognizable(): Boolean {
        if (type >= DEVICE_TYPE.MIN && type <= DEVICE_TYPE.MAX) {
            return true
        }
        return false
    }

    fun isCheckDroneType(): Boolean {
        return isDisturbDevice()
    }

    fun isDisturbDevice(): Boolean {
        return when (type) {
            DEVICE_TYPE.DISTURB_CAR, DEVICE_TYPE.DISTURB_PORTABLE_8QX360B01, DEVICE_TYPE.DISTURB_PORTABLE_09B01, DEVICE_TYPE.DISTURB_PORTABLE_09B02, DEVICE_TYPE.DISTURB_PORTABLE_PL120D01, DEVICE_TYPE.DISTURB_PORTABLE_CK120D01, DEVICE_TYPE.DISTURB_PORTABLE_CK120D02, DEVICE_TYPE.DISTURB_SHIP_ON, DEVICE_TYPE.DISTURB_RAILWAY_PROTECTION -> true
            else -> {
                false
            }
        }
    }

    fun isCheckDroneStatus(): Boolean {
        return when (status) {
            DEVICE_STATUS.POWER_OFF, DEVICE_STATUS.EXCEPTION, DEVICE_STATUS.MAINTAIN -> false
            else -> {
                true
            }
        }
    }

    fun isWgs84LatLng(): Boolean {
        // 手持设备坐标类型是gcj02
//        if (type == Constants.DIVICE_TYPE.DISTURB_HAND_06S01) {
//            return false;
//        }
        return true
    }

    /**
     * 表示可以是布置任务，如攻击任务和到达目的地任务
     *
     * @return
     */
    fun isCanExecuteTaskMonitor(): Boolean {
        var isCan = false
        when (type) {
            DEVICE_TYPE.DISTURB_CAR, DEVICE_TYPE.DISTURB_SHIP_ON, DEVICE_TYPE.DISTURB_HAND_06S01 -> isCan =
                true
        }
        return isCan
    }

    fun isCanRemoteOperationMonitor(): Boolean {
        var isCan = false
        when (type) {
            DEVICE_TYPE.DISTURB_HAND_06S01, DEVICE_TYPE.DISTURB_PISTOL, DEVICE_TYPE.DETECT_ABS_B, DEVICE_TYPE.DETECT_WEIBO, DEVICE_TYPE.DETECT_YUNSHAO, DEVICE_TYPE.DETECT_LEIDA, DEVICE_TYPE.DETECT_GPS -> isCan =
                false

            else -> {
                if (status != DEVICE_STATUS.POWER_OFF) {
                    isCan = true
                }
            }
        }
        return isCan
    }


    fun getTargetState(): Int {
        if (monitorOrderDO == null) {
            return ATTACK_STATE.FINISH
        }
        return monitorOrderDO!!.state
    }

    fun getTaskId(): Long {
        if (monitorOrderDO == null) {
            return 0
        }
        return monitorOrderDO!!.id
    }

    /**
     * 获取设备的目的地经纬度
     *
     * @return
     */
    fun getTargetLatlng(): MyLatLng? {
        if (monitorOrderDO == null) {
            return null
        }
        return monitorOrderDO!!.latLng
    }

    fun setTargetLatlng(latlng: MyLatLng?) {
        if (monitorOrderDO != null) {
            monitorOrderDO!!.latLng = latlng
        }
    }

    /**
     * 获取打击目标的无人机id
     *
     * @return
     */
    fun getTargetDroneId(): String? {
        if (monitorOrderDO == null) {
            return null
        }
        return monitorOrderDO!!.info
    }

    fun getCenterAngle(): Int {
        //计算设备的朝向中间角度
        val startAngle: Int = direct % 360
        return startAngle + (directAngle / 2)
    }

    fun getExtString(): String {
        return ResourceUtil.getContent(R.string.drone_ext_label, ext)
    }

    fun getLatLngString(): String {
        return ResourceUtil.getContent(R.string.drone_latlng_label, longitude, latitude)
    }

    fun getNameString(): String {
        return ResourceUtil.getContent(R.string.drone_name_label, alias)
    }

    fun getIdString(): String {
        return ResourceUtil.getContent(R.string.drone_id_label, monitorId)
    }

    fun getVAndIString(): String {
        return ResourceUtil.getContent(R.string.device_V_and_I_label, voltage, current)
    }

    fun getIpString(): String {
        if (TextUtils.isEmpty(ip)) {
            return ""
        }
        return ResourceUtil.getContent(R.string.device_ip_label, ip)
    }

    fun getCreateTimeString(): String {
        if (createTime == null) {
            return ""
        }
        return ResourceUtil.getContent(
            R.string.device_create_time_label,
            createTime.toString()
        )
    }

    fun getUpdateTimeString(): String {
        if (createTime == null) {
            return ""
        }
        return ResourceUtil.getContent(
            R.string.device_update_time_label,
            updateTime.toString()
        )
    }


    var myLatLng: MyLatLng
        get() = MyLatLng(latitude, longitude)
        set(value) {
            latitude = value.latitude
            longitude = value.longitude
        }

    fun setLatLng(latitude: Double, longitude: Double) {
        this.latitude = latitude
        this.longitude = longitude
    }

    fun updateShowInfo(monitorDevice: MonitorDevice) {
        this.voltage = monitorDevice.voltage
        this.current = monitorDevice.current
        this.frequencyRange = monitorDevice.frequencyRange
        this.defaultFrequency = monitorDevice.defaultFrequency
        this.ext = monitorDevice.ext
        this.createTime = monitorDevice.createTime
        this.ip = monitorDevice.ip
        this.updateTime = monitorDevice.updateTime
        this.childMonitorDevices = monitorDevice.childMonitorDevices
        this.childMonitorDeviceMap = monitorDevice.childMonitorDeviceMap
        super.copy(monitorDevice)
    }

    fun copy(monitorDevice: MonitorDevice) {
        this.monitorId = monitorDevice.monitorId
        this.status = monitorDevice.status
        this.longitude = monitorDevice.longitude
        this.latitude = monitorDevice.latitude
        this.alias = monitorDevice.alias
        this.bgswitch = monitorDevice.bgswitch
        this.direct = monitorDevice.direct
        this.directAngle = monitorDevice.directAngle
        this.workRadius = monitorDevice.workRadius
        this.warningRadius = monitorDevice.warningRadius
        this.discernRadius = monitorDevice.discernRadius
        this.type = monitorDevice.type
        updateShowInfo(monitorDevice)
        super.copy(monitorDevice)
    }

    object ATTACK_STATE {
        const val CREATE: Int = 0 // 创建
        const val CANCEL: Int = 1 // 取消
        const val FINISH: Int = 2 // 完成
    }

    /**
     * 自定义的状态：
     * -1 - 选中状态
     * -2 - 被入侵状态
     *
     *
     * 服务器返回的设备状态：
     * 0 - 关机
     * 1 - 开机（未工作）
     * 2 - 工作
     * 3 - 异常
     * 4 - 维护
     */
    object DEVICE_STATUS {
        const val SELECTED: Int = -3
        const val FIND_AVIATION: Int = -2
        const val FIND_DRONE: Int = -1

        const val POWER_OFF: Int = 0
        const val POWER_ON: Int = 1
        const val WORK: Int = 2
        const val EXCEPTION: Int = 3
        const val MAINTAIN: Int = 4
    }

    /**
     * 自定义类型用于点击时方便判断是属于那种设备
     */
    object DEVICE_TYPE {
        const val DISTURB_CAR: Int = 1 //车载
        const val DISTURB_PORTABLE_8QX360B01: Int = 2 //全向便携
        const val DISTURB_PORTABLE_09B01: Int = 3 //便携设备
        const val DISTURB_HAND_06S01: Int = 4 //手持设备
        const val DISTURB_PISTOL: Int = 5 //枪式设备
        const val DISTURB_PORTABLE_09B02: Int = 6 //便携设备
        const val DISTURB_SHIP_ON: Int = 7 //船载设备
        const val DISTURB_PORTABLE_PL120D01: Int = 8 //便携设备
        const val DISTURB_PORTABLE_CK120D01: Int = 9 //便携设备
        const val DISTURB_PORTABLE_CK120D02: Int = 10 //便携设备
        const val DISTURB_RAILWAY_PROTECTION: Int = 24 //铁路布防
        const val WEAPON: Int = 11

        const val DETECT_GPS: Int = 12
        const val DETECT_YUNSHAO: Int = 13
        const val DETECT_WEIBO: Int = 14
        const val DETECT_LEIDA: Int = 15
        const val DETECT_YUNTAI_PORTABLE: Int = 50

        const val WEAPON_GUANGDIAN: Int = 16
        const val WEAPON_ACOUSTICAL_SOUNDING: Int = 17
        const val WEAPON_OPTICAL_DETECTION: Int = 18

        const val DETECT_ABS_B: Int = 19

        const val COMMAND_CENTER_PRIMARY: Int = 20
        const val COMMAND_CENTER_SECONDARY: Int = 21
        const val COMMAND_CENTER_TERTIARY: Int = 22

        const val SCAN_OPERATOR = 51
        // 模拟设备
        const val ANALOG_DEVICES: Int = 52

        const val MIN: Int = 1
        const val MAX: Int = 52
    }
}
