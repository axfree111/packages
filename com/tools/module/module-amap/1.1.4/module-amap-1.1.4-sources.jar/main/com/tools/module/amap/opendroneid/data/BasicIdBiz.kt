package com.tools.module.amap.opendroneid.data

import com.tools.module.amap.R
import com.tools.module.amap.opendroneid.OpenDroneIdConstants
import com.tools.module.amap.opendroneid.parser.toPartString
import com.tools.module.common.utils.ResourceUtil
import java.nio.charset.StandardCharsets

class BasicIdBiz : MessageBizData() {
    var uaType: UaTypeEnum
    var idType: IdTypeEnum
    private var uasId: ByteArray?

    init {
        uaType = UaTypeEnum.None
        idType = IdTypeEnum.None
        uasId = ByteArray(0)
    }

    enum class UaTypeEnum(val key: Int, val description: String) {
        None(0, description = ResourceUtil.getContent(R.string.unknown)), // 0 未知或未定义
        Aeroplane(1, description = ResourceUtil.getContent(R.string.aeroplane)), // 1 固定翼飞机
        HelicopterOrMultirotor(2, description = ResourceUtil.getContent(R.string.helicopter_or_multirotor)), // 2直升飞机（或多旋翼飞机）
        Gyroplane(3, description = ResourceUtil.getContent(R.string.gyroplane)), // 3自转旋翼机
        // VTOL. Fixed wing aircraft that can take off vertically
        HybridLift(4, description = ResourceUtil.getContent(R.string.hybrid_lift)),  // 4垂直起降固定翼飞机
        Ornithopter(5, description = ResourceUtil.getContent(R.string.ornithopter)), // 5扑翼机
        Glider(6, description = ResourceUtil.getContent(R.string.glider)), // 6滑翔机
        Kite(7, description = ResourceUtil.getContent(R.string.kite)), // 7风筝
        FreeBalloon(8, description = ResourceUtil.getContent(R.string.free_balloon)), // 8自由气球
        CaptiveBalloon(9, description = ResourceUtil.getContent(R.string.captive_balloon)), // 9系留气球
        Airship(10, description = ResourceUtil.getContent(R.string.airship)), // 10飞艇
        FreeFallParachute(11, description = ResourceUtil.getContent(R.string.free_fall_parachute)),  // 11自由落体/降落伞（无动力）
        Rocket(12, description = ResourceUtil.getContent(R.string.rocket)), // 12火箭
        TetheredPoweredAircraft(13, description = ResourceUtil.getContent(R.string.tethered_powered_aircraft)), // 13系留动力飞机
        GroundObstacle(14, description = ResourceUtil.getContent(R.string.ground_obstacle)), // 14地面障碍物
        Other(15, description = ResourceUtil.getContent(R.string.other));

        companion object {
            fun keyOfType(key: Int): UaTypeEnum {
                for (type in UaTypeEnum.entries) {
                    if (type.key == key) {
                        return type
                    }
                }
                return UaTypeEnum.None
            }
        }
    }

    enum class IdTypeEnum(val key: Int, val description: String) {

        None(0, ResourceUtil.getContent(R.string.unknown)),
        SerialNumber(1, ResourceUtil.getContent(R.string.serial_number)),
        CAARegistrationID(2, ResourceUtil.getContent(R.string.caa_registration_id)),
        UTMAssignedID(3, ResourceUtil.getContent(R.string.utm_assigned_id)),
        SpecificSessionID(4, ResourceUtil.getContent(R.string.specific_session_id));

        companion object {
            fun keyOfType(key: Int): IdTypeEnum {
                for (type in IdTypeEnum.entries) {
                    if (type.key == key) {
                        return type
                    }
                }
                return IdTypeEnum.None
            }
        }
    }

    fun setUaType(uaType: Int) {
        this.uaType = UaTypeEnum.keyOfType(uaType)
    }

    fun setIdType(idType: Int) {
        this.idType = IdTypeEnum.keyOfType(idType)
    }

    fun getUasId(): ByteArray? {
        return uasId
    }

    fun getUasIdForAsciiString(): String {
        return uasId?.toPartString(StandardCharsets.US_ASCII)
            ?: ""
    }

    fun getUasIdForUtf8String(): String {
        if (uasId != null) {
            if (idType == IdTypeEnum.SerialNumber || idType == IdTypeEnum.CAARegistrationID) {
                for (c in uasId!!) {
                    if ((c <= 31 || c >= 127) && c.toInt() != 0) {
                        return ""
                    }
                }
                return String(uasId!!)
            } else if (idType == IdTypeEnum.UTMAssignedID || idType == IdTypeEnum.SpecificSessionID) {
                val sb = StringBuilder()
                sb.append("0x")
                for (b in uasId!!) {
                    sb.append(String.format("%02X", b))
                }
                return sb.toString()
            }
        }
        return uasId?.toPartString(StandardCharsets.UTF_8)
            ?: ""
    }

    fun setUasId(uasId: ByteArray) {
        if (uasId.size <= OpenDroneIdConstants.MAX_ID_BYTE_SIZE) this.uasId = uasId
    }

    override fun equals(o: Any?): Boolean {
        if (this === o) return true

        if (o == null || javaClass != o.javaClass) return false

        val that = o as BasicIdBiz
        return uaType == that.uaType && idType == that.idType && uasId.contentEquals(that.uasId)
    }
}
