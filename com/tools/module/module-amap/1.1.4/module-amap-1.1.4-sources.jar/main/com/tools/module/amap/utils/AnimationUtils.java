package com.tools.module.amap.utils;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;

/**
 * Created by jiajie on 2020-01-22.
 */
public class AnimationUtils {

    public static void translateAnimation(View view, int fromXDelta, int toXDelta, Animator.AnimatorListener listener) {
        if (view != null) {
            ObjectAnimator translationX = new ObjectAnimator().ofFloat(view, "translationX", fromXDelta, toXDelta);
            translationX.addListener(listener);
            AnimatorSet animatorSet = new AnimatorSet();  //组合动画
            animatorSet.playTogether(translationX); //设置动画
            animatorSet.setDuration(600);  //设置动画时间
            animatorSet.setInterpolator(new AccelerateDecelerateInterpolator());
            animatorSet.start(); //启动
        }
    }
}
