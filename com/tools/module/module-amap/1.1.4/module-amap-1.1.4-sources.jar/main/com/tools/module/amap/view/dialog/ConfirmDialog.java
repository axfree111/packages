package com.tools.module.amap.view.dialog;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.DrawableRes;
import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.annotation.StringRes;

import com.tools.module.amap.R;


public class ConfirmDialog implements Dialog.OnCancelListener, Dialog.OnDismissListener, View.OnClickListener {

    private Dialog mDialog = null;
    private Context mContext;

    private View mView = null;

    private OperationListener mListener = null;

    private boolean mCancelable = true;

    private Drawable topPicture;
    private Drawable closeIcon;
    private String title;
    private String message;
    private String positiveText;
    private String negativeText;

    private boolean dismissCallback = true;


    public ConfirmDialog(@NonNull Context context) {
        mContext = context;
    }

    public ConfirmDialog setContentView(@LayoutRes int layoutId) {
        LayoutInflater inflate = (LayoutInflater)
                mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mView = inflate.inflate(layoutId, null);
        return this;
    }

    public ConfirmDialog setContentView(View view) {
        mView = view;
        return this;
    }

    public ConfirmDialog setTopPicture(Drawable drawable) {
        topPicture = drawable;
        return this;
    }

    public ConfirmDialog setTopPicture(@DrawableRes int drawableId) {
        if (mContext != null && drawableId != 0) {
            topPicture = mContext.getResources().getDrawable(drawableId);
        }
        return this;
    }

    public ConfirmDialog setCloseIcon(Drawable drawable) {
        closeIcon = drawable;
        return this;
    }

    public ConfirmDialog setCloseIcon(@DrawableRes int drawableId) {
        if (mContext != null && drawableId != 0) {
            closeIcon = mContext.getResources().getDrawable(drawableId);
        }
        return this;
    }

    public ConfirmDialog setTitle(String text) {
        title = text;
        return this;
    }

    public ConfirmDialog setTitle(@StringRes int textId) {
        if (null != mContext && textId != 0) {
            title = mContext.getResources().getString(textId);
        }
        return this;
    }

    public ConfirmDialog setMessage(String text) {
        message = text;
        return this;
    }

    public ConfirmDialog setMessage(@StringRes int textId) {
        if (null != mContext && textId != 0) {
            message = mContext.getResources().getString(textId);
        }
        return this;
    }

    public ConfirmDialog setPositiveButtonText(String text) {
        positiveText = text;
        return this;
    }

    public ConfirmDialog setPositiveButtonText(@StringRes int textId) {
        if (null != mContext && textId != 0) {
            positiveText = mContext.getResources().getString(textId);
        }
        return this;
    }

    public ConfirmDialog setNegativeButtonText(String text) {
        negativeText = text;
        return this;
    }

    public ConfirmDialog setNegativeButtonText(@StringRes int textId) {
        if (null != mContext && textId != 0) {
            negativeText = mContext.getResources().getString(textId);
        }
        return this;
    }

    public ConfirmDialog setCancelable(boolean cancelable) {
        mCancelable = cancelable;
        return this;
    }

    public ConfirmDialog setOnOperationListener(OperationListener listener) {
        mListener = listener;
        return this;
    }

    public void dismiss() {
        if (null != mDialog && mDialog.isShowing()) {
            mDialog.dismiss();
            mDialog = null;
        }
    }

    public void show() {
        if (null == mView) {
            return;
        }

        mDialog = new Dialog(mContext);
        mDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setDialogWindow(mDialog.getWindow());

        mDialog.setContentView(mView);

        mDialog.setCancelable(mCancelable);
        mDialog.setCanceledOnTouchOutside(mCancelable);
        if (mCancelable) {
            mDialog.setOnCancelListener(this);
        }

        mDialog.setOnDismissListener(this);
        setView(mView);

        mDialog.show();
    }

    public boolean isShowing() {
        return (null != mDialog && mDialog.isShowing());
    }

    /**
     * 设置Dialog style
     * @param dialogWindow
     */
    private void setDialogWindow(Window dialogWindow) {
        //弹窗设置状态栏沉浸
        if (dialogWindow != null && dialogWindow.getDecorView() != null) {
            if (android.os.Build.VERSION.SDK_INT >= 21) {
                dialogWindow.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
                dialogWindow.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
                dialogWindow.setStatusBarColor(Color.TRANSPARENT);
            }
            dialogWindow.setBackgroundDrawableResource(android.R.color.transparent);
        }
    }

    /**
     * 设置view
     * @param rootView
     */
    private void setView(View rootView) {
        ImageView ivCloseIcon = (ImageView) rootView.findViewById(R.id.confirm_dialog_imageview_close_icon);
        if (ivCloseIcon != null) {
            if (mCancelable) {
                ivCloseIcon.setVisibility(View.GONE);
            } else {
                ivCloseIcon.setImageDrawable(closeIcon);
                ivCloseIcon.setVisibility(View.VISIBLE);
                ivCloseIcon.setOnClickListener(this);
            }
        }
        ImageView ivTopPicture = (ImageView) rootView.findViewById(R.id.confirm_dialog_imageview_top_picture);
        if (ivTopPicture != null) {
            if (topPicture == null) {
                ivTopPicture.setVisibility(View.GONE);
            } else {
                ivTopPicture.setImageDrawable(topPicture);
                ivTopPicture.setVisibility(View.VISIBLE);
            }
        }
        TextView tvTitle = (TextView) rootView.findViewById(R.id.confirm_dialog_textview_title);
        if (tvTitle != null) {
            if (TextUtils.isEmpty(title)) {
                tvTitle.setVisibility(View.GONE);
            } else {
                tvTitle.setText(title);
                tvTitle.setVisibility(View.VISIBLE);
            }
        }
        TextView tvMessage = (TextView) rootView.findViewById(R.id.confirm_dialog_textview_message);
        if (tvMessage != null) {
            if (TextUtils.isEmpty(message)) {
                tvMessage.setVisibility(View.GONE);
            } else {
                tvMessage.setText(message);
                tvMessage.setVisibility(View.VISIBLE);
            }
        }
        TextView tvPositive = (TextView) rootView.findViewById(R.id.confirm_dialog_textview_positive);
        if (tvPositive != null) {
            if (TextUtils.isEmpty(positiveText)) {
                tvPositive.setVisibility(View.GONE);
            } else {
                tvPositive.setText(positiveText);
                tvPositive.setVisibility(View.VISIBLE);
                tvPositive.setOnClickListener(this);
            }
        }
        TextView tvNegative = (TextView) rootView.findViewById(R.id.confirm_dialog_textview_nagative);
        if (tvNegative != null) {
            if (TextUtils.isEmpty(negativeText)) {
                tvNegative.setVisibility(View.GONE);
            } else {
                tvNegative.setText(negativeText);
                tvNegative.setVisibility(View.VISIBLE);
                tvNegative.setOnClickListener(this);
            }
        }
    }


    public enum Operation {
        POSITIVE_CLICK,
        NEGATIVE_CLICK,
        CLOSE,
        CANCEL,
        DISMISS
    }


    public interface OperationListener {
        void handle(Operation what);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.confirm_dialog_textview_positive) {
            callbackAndDismiss(Operation.POSITIVE_CLICK);
        } else if (view.getId() == R.id.confirm_dialog_textview_nagative) {
            callbackAndDismiss(Operation.NEGATIVE_CLICK);
        } else if (view.getId() == R.id.confirm_dialog_imageview_close_icon) {
            callbackAndDismiss(Operation.CLOSE);
        }
    }

    private void callbackAndDismiss(Operation op) {
        if (null != mListener) {
            mListener.handle(op);
            dismissCallback = false;
            dismiss();
        }
    }

    @Override
    public void onCancel(DialogInterface dialog) {
        if (null != mListener) {
            mListener.handle(Operation.CANCEL);
            dismissCallback = false;
        }
    }

    @Override
    public void onDismiss(DialogInterface dialog) {
        if (null != mListener && dismissCallback) {
            mListener.handle(Operation.DISMISS);
        }
    }
}
