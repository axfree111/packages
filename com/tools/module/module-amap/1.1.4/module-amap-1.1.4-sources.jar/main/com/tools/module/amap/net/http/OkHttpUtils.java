package com.tools.module.amap.net.http;

import android.os.Build;
import android.text.TextUtils;

import com.tools.module.amap.net.StatusCode;
import com.tools.module.amap.net.http.request.HttpRequestWrapper;
import com.tools.module.amap.net.http.request.IRequestHost;
import com.tools.module.amap.net.http.request.OkHttpUrlRequest;
import com.tools.module.amap.net.http.response.FileHttpResponseHandler;
import com.tools.module.common.utils.AppUtil;
import com.tools.module.common.utils.ByteArrayPool;
import com.tools.module.common.utils.XAppLogger;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.util.LinkedList;
import java.util.List;
import java.util.WeakHashMap;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Dispatcher;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

/**
 * Created by Changjiajie on 2018/3/21.
 */

public class OkHttpUtils {

    public static OkHttpClient okHttpClient = null;
    public static OkHttpClient.Builder builder = null;
    private static long timeOut = 10 * 1000;


    public static void init() {
        if (okHttpClient == null) {

            int maximumPoolSize = 4;

            // 根据处理器确认同时可执行的线程数和最大能同时创建的线程数
            if (Runtime.getRuntime().availableProcessors() > 4) {
                maximumPoolSize = Runtime.getRuntime().availableProcessors();
            } else if (Build.VERSION.SDK_INT >= 26) {
                // 8.0以上的手机，多分配线程池
                maximumPoolSize = 8;
            }

            Dispatcher dispatcher = new Dispatcher();
            dispatcher.setMaxRequests(maximumPoolSize);

            builder = new OkHttpClient.Builder()
                    .dispatcher(dispatcher);
            //  .dns(SyncOkHttpDns.getInstance())
        }
    }

    private static final WeakHashMap<Integer, List<WeakReference<Call>>> requestMap = new WeakHashMap<Integer, List<WeakReference<Call>>>();

    public static void execute(HttpRequestWrapper requestWeapper) {
        execute(requestWeapper, timeOut);
    }

    public static void execute(HttpRequestWrapper requestWeapper, long timeout) {
        builder.connectTimeout(timeout, TimeUnit.MILLISECONDS)
                .writeTimeout(timeout, TimeUnit.MILLISECONDS)
                .readTimeout(timeout, TimeUnit.MILLISECONDS);
        okHttpClient = builder.build();

        Call httpCall = new OkHttpUrlRequest().request(requestWeapper);

        requestWeapper.setCall(httpCall);

        int hashCode = requestWeapper.getContextHashCode();
        if (hashCode != 0 && httpCall != null) {
            // Add request to request map
            List<WeakReference<Call>> requestList = requestMap.get(hashCode);
            if (requestList == null) {
                requestList = new LinkedList<WeakReference<Call>>();
                requestMap.put(hashCode, requestList);
            }

            requestList.add(new WeakReference<Call>(httpCall));
        }
    }


    /**
     * 取消context对应的所有异步请求
     *
     * @param contextHashcode
     */
    public static void cancelRequests(int contextHashcode) {
        synchronized (requestMap) {
            List<WeakReference<Call>> httpCallList = requestMap.get(contextHashcode);
            if (httpCallList != null) {
                for (WeakReference<Call> httpCallRef : httpCallList) {
                    Call httpCall = httpCallRef.get();
                    if (httpCall != null) {
                        httpCall.cancel();
                    }
                }
            }
            requestMap.remove(contextHashcode);
        }
    }

    /**
     * 停止所有的请求
     */
    public static void stopAll() {
        synchronized (requestMap) {
            okHttpClient.dispatcher().cancelAll();
            requestMap.clear();
        }
    }


    public static void downloadAsync(final String url, final String savePath, final FileHttpResponseHandler responseHandler, final IRequestHost requestHost) throws Exception {
        if (TextUtils.isEmpty(url)) {
            if (responseHandler != null) {
                responseHandler.sendFailureMessage(url, new Exception("url is empty"), StatusCode.EMPTY_URL, null);
            }
            return;
        }
        // 需要使用Base64进行下载
        if (Base64ImageUrlDownloader.isSupport(url)) {
            Base64ImageUrlDownloader.handleBase64ImageUrlDownload(url, savePath, responseHandler, requestHost);
            return;
        }

        try {
            Request request = new Request.Builder()
                    .url(url)
                    // 明确标示需要下载webp图片
                    .addHeader("Accept", "image/webp, */*")
                    .build();
            okHttpClient.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException ioe) {
                    if (null != responseHandler) {
                        responseHandler.sendFailureMessage(url, ioe, StatusCode.getIOExceptionStatusCode(ioe), null);
                    }
                }

                @Override
                public void onResponse(Call call, Response response) {
                    handleDownloadResponse(response, url, savePath, responseHandler, requestHost);
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
            if (responseHandler != null) {
                responseHandler.sendFailureMessage(url, e, StatusCode.EXCEPTION, null);
            }
        }

    }


    /**
     * 下载文件
     *
     * @param url
     * @param savePath
     * @param responseHandler
     * @param requestHost
     * @throws Exception
     */
    public static void download(String url, String savePath, FileHttpResponseHandler responseHandler, IRequestHost requestHost) throws Exception {

        Response response = null;
        if (!TextUtils.isEmpty(url)) {
            try {
                Request request = new Request.Builder()
                        .url(url)
                        // 明确标示需要下载webp图片
                        .addHeader("Accept", "image/webp, */*")
                        .build();
                response = okHttpClient.newCall(request).execute();
            } catch (IOException e) {
                XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_ERROR, "okHttp failed, exception:" + e);
                throw e;
            } catch (Exception e) {
                // 线上出现这样的闪退
                // java.lang.IllegalArgumentException
                //     unexpected url: data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAA
                // 需要使用Base64进行下载
                if (Base64ImageUrlDownloader.isSupport(url)) {
                    Base64ImageUrlDownloader.handleBase64ImageUrlDownload(url, savePath, responseHandler, requestHost);
                    return;
                } else {
                    XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_ERROR, "okHttp failed, exception:" + e);
                    throw e;
                }
            }
        }

        handleDownloadResponse(response, url, savePath, responseHandler, requestHost);
    }

    /**
     * 处理文件下载的response
     *
     * @param response
     * @param url
     * @param savePath
     * @param responseHandler
     * @param requestHost
     */
    private static void handleDownloadResponse(Response response, String url, String savePath, FileHttpResponseHandler responseHandler, IRequestHost requestHost) {
        if (TextUtils.isEmpty(url)) {
            if (responseHandler != null) {
                responseHandler.sendFailureMessage(url, new Exception("url is empty"), StatusCode.EMPTY_URL, null);
            }
            return;
        }

        ResponseBody responseBody = response.body();

        if (response == null || responseBody == null) {
            if (responseHandler != null) {
                responseHandler.sendFailureMessage(url, new Exception("response is null"), StatusCode.EMPTY_RESPONSE, null);
            }
            return;
        }
        if (!response.isSuccessful()) {
            if (responseHandler != null) {
                Exception failException = TextUtils.isEmpty(response.message()) ? null : new Exception(response.message());
                responseHandler.sendFailureMessage(url, failException, response.code(), null);
            }
            responseBody.close();
            return;
        }

        // 判断文件长度是否可接受
        long total = responseBody.contentLength();

        if (responseHandler != null && !responseHandler.onAccept(response.code(), total)) {
            responseHandler.sendCancelMessage("responseHandler not accept");
            responseBody.close();
            return;
        }

        InputStream is = null;
        FileOutputStream fos = null;
        byte[] buff = null;
        try {
            File downloadFile = new File(savePath);
            if (!downloadFile.exists()) {
                downloadFile.createNewFile();
            }
            fos = new FileOutputStream(downloadFile);
            is = responseBody.byteStream();
            buff = ByteArrayPool.sDefaultPool.getBuf(1024);
            int len = 0;

            int sum = 0;
            while ((len = is.read(buff)) != -1) {
                // 判断下载任务是否被取消
                if (requestHost != null && !requestHost.isActive()) {
                    if (responseHandler != null) {
                        responseHandler.sendCancelMessage("requestHost isnot active");
                    }
                    return;
                }
                if (responseHandler != null && responseHandler.isCancelled()) {
                    responseHandler.sendCancelMessage("requestHost is cancelled");
                    return;
                }

                fos.write(buff, 0, len);
                sum += len;

                // 下载进度回调
                int progress = (int) (sum * 1.0f / total * 100);
                if (responseHandler != null) {
                    responseHandler.sendProgressMessage(progress, sum);
                }
            }
            fos.flush();

            // 下载完成
            if (responseHandler != null) {
                responseHandler.sendSuccessMessage(url, response.code(), downloadFile);
            }
        } catch (IOException ioe) {
            ioe.printStackTrace();
            if (responseHandler != null) {
                responseHandler.sendFailureMessage(url, ioe, StatusCode.getIOExceptionStatusCode(ioe), null);
            }
        } catch (Exception e) {
            e.printStackTrace();
            if (responseHandler != null) {
                responseHandler.sendFailureMessage(url, e, StatusCode.EXCEPTION, null);
            }
        } catch (OutOfMemoryError e) {
            e.printStackTrace();
            if (responseHandler != null) {
                responseHandler.sendFailureMessage(url, e, StatusCode.ERROR_OOM, null);
            }
        } finally {
            ByteArrayPool.sDefaultPool.returnBuf(buff);
            AppUtil.closeQuietly(is);
            AppUtil.closeQuietly(fos);

            responseBody.close();

            if (responseHandler != null) {
                responseHandler.sendFinishMessage();
            }
        }
    }
}
