package com.tools.module.amap.utils;

import android.app.Activity;
import android.content.SharedPreferences;

import com.tools.module.common.ContextStore;
import com.tools.module.common.utils.XAppLogger;

public class PreferencesUtils {

    private static final String SP_NAME = "DroneLocation";

    private static SharedPreferences getSP() {
        return ContextStore.getContext().getSharedPreferences(SP_NAME, Activity.MODE_PRIVATE);
    }

    public static void setIsRemind(boolean remind) {
        getSP().edit().putBoolean("remind", remind).commit();
    }

    public static boolean getIsRemind() {
        return getSP().getBoolean("remind", false);
    }


    public static String getUname() {
        return getSP().getString("uname", "");
    }

    public static void setUname(String uname) {
        uname = uname.replace(" ", "");
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_OTHER, " 存储手机号：" + uname);
        getSP().edit().putString("uname", uname).commit();
    }

    public static String getCode() {
        return getSP().getString("code", "");
    }

    public static void setCode(String code) {
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_OTHER, " 存储验证码：" + code);
        getSP().edit().putString("code", code).commit();
    }

    public static String getPwd() {
        return getSP().getString("pwd", "");
    }

    public static void setPwd(String pwd) {
        getSP().edit().putString("pwd", pwd).commit();
    }

    private static final String SOUND_SWITCH_KEY = "sound_switch_key";

    public static void setSoundSwitch(boolean isOpen) {
        getSP().edit().putBoolean(SOUND_SWITCH_KEY, isOpen).commit();
    }

    public static boolean getSoundSwitch() {
        return getSP().getBoolean(SOUND_SWITCH_KEY, true);
    }

    private static final String VIBRATOR_SWITCH_KEY = "vibrator_switch_key";

    public static void setVibratorSwitch(boolean isOpen) {
        getSP().edit().putBoolean(VIBRATOR_SWITCH_KEY, isOpen).commit();
    }

    public static boolean getVibratorSwitch() {
        return getSP().getBoolean(VIBRATOR_SWITCH_KEY, true);
    }

    private static final String FIGHT_CONTROL_AUTOMATIC_KEY = "fight_control_automatic_key";

    public static void setFightControlAutomatic(int automatic) {
        getSP().edit().putInt(FIGHT_CONTROL_AUTOMATIC_KEY, automatic).commit();
    }

    public static int getFightControlAutomatic() {
        return getSP().getInt(FIGHT_CONTROL_AUTOMATIC_KEY, 0);
    }

    private static final String NOFLY_ZONE_SHOW_DRONE_KEY = "nofly_zone_show_drone_key";

    public static void setNoflyZoneShowDrone(boolean show) {
        getSP().edit().putBoolean(NOFLY_ZONE_SHOW_DRONE_KEY, show).commit();
    }

    public static boolean getNoflyZoneShowDrone() {
        return getSP().getBoolean(NOFLY_ZONE_SHOW_DRONE_KEY, true);
    }

    private static final String SHOW_AIRCRAFTS_KEY = "show_aircrafts_key";

    public static void setShowAircrafts(boolean show) {
        getSP().edit().putBoolean(SHOW_AIRCRAFTS_KEY, show).commit();
    }

    public static boolean getShowAircrafts() {
        return getSP().getBoolean(SHOW_AIRCRAFTS_KEY, true);
    }

    private static final String SHOW_SHIP_KEY = "show_ship_key";

    public static void setShowShip(boolean show) {
        getSP().edit().putBoolean(SHOW_SHIP_KEY, show).commit();
    }

    public static boolean getShowShip() {
        return getSP().getBoolean(SHOW_SHIP_KEY, true);
    }

    private static final String ARC_POINT_TABLE_STR_KEY = "arc_point_table_str_key";

    public static void saveArcPointTable(String table) {
        getSP().edit().putString(ARC_POINT_TABLE_STR_KEY, table).commit();
    }

    public static String getArcPointTable() {
        return getSP().getString(ARC_POINT_TABLE_STR_KEY, "");
    }

    private static final String SHOW_SWITCH_DEBUGHOST = "show_switch_debughost";

    public static void setShowDebugHost(boolean show) {
        getSP().edit().putBoolean(SHOW_SWITCH_DEBUGHOST, show).commit();
    }

    public static boolean getShowDebugHost() {
        return getSP().getBoolean(SHOW_SWITCH_DEBUGHOST, false);
    }

    private static final String LOGIN_SYSTEM_MID = "login_company_name";

    public static void setSystemMid(int mid) {
        getSP().edit().putInt(LOGIN_SYSTEM_MID, mid).commit();
    }

    public static int getSystemMid() {
        return getSP().getInt(LOGIN_SYSTEM_MID, -1);
    }

}
