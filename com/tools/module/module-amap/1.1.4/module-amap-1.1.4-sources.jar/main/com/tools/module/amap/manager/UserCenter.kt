package com.tools.module.amap.manager

import com.drone.monitor.bean.AuthorityInfo
import com.drone.monitor.bean.ChannelsInfo
import com.drone.monitor.bean.LoginInfo
import com.drone.monitor.bean.RoleInfo
import com.drone.monitor.bean.UserInfo
import com.drone.monitor.bean.WebConfigInfo
import com.tools.module.amap.test.TestConstants
import com.tools.module.amap.utils.PreferencesUtils

/**
 * Date: 2025/4/1
 * Desc:
 *
 * author: jaje
 */
object UserCenter {

    //##########################################################
    var userInfo: UserInfo? = null
        set(value) {
            field = value
            if (TestConstants.ISTEST) {
                value?.userLevel = UserInfo.USER_LEVEL.SUPER_USER
            }
            isSuperUser = value?.userLevel == UserInfo.USER_LEVEL.SUPER_USER
        }
    val phoneNo: String
        @JvmStatic
        get() {
            return userInfo?.phoneNo ?: ""
        }
    val mid: Int
        get() {
            return userInfo?.mid ?: -1
        }
    val userLevel: Int
        get() {
            return userInfo?.userLevel ?: UserInfo.USER_LEVEL.OPERATOR_USER
        }
    val webConfig: WebConfigInfo?
        get() {
            return channelsInfo?.webConfig
        }
    var loginInfo: LoginInfo? = null
        set(value) {
            field = value
            userInfo = value?.userinfo
            roleInfo = value?.role
            channelsInfos = value?.channels
            if (value?.channels == null || value.channels?.size == null
                || value.channels?.size!! <= 0) {
                channelsInfo = null
            } else {
                if (userLevel == UserInfo.USER_LEVEL.SUPER_USER) {
                    for (info in value.channels) {
                        if (info != null && info.id == userInfo?.mid) {
                            channelsInfo = info
                            break
                        }
                    }
                } else {
                    channelsInfo = loginInfo?.channels?.get(0)
                }
            }
        }
    var channelsInfo: ChannelsInfo? = null
        set(value) {
            field = value ?: ChannelsInfo()
            if (value?.webConfig != null) {
                value.id.let {
                    PreferencesUtils.setSystemMid(it)
                    userInfo?.mid = it
                }
            }
        }
    var channelsInfos: List<ChannelsInfo>? = null
        get() {
            return field ?: emptyList()
        }
    var roleInfo: RoleInfo? = null
        set(value) {
            if (value != null) {
                field = value
            }
            authorityInfo = value?.authority
        }
    var authorityInfo: AuthorityInfo? = null
    var isSuperUser = false

    //##########################################################

    fun getRoleId(): String? {
        return userInfo?.roleId
    }

    fun getChannelsCompany(): String? {
        if (channelsInfo?.webConfig == null) {
            return ""
        }
        return channelsInfo?.webConfig?.company
    }

    //##########################################################
}