package com.tools.module.amap.map;

import com.drone.monitor.bean.custom.MyLatLng;

import com.drone.monitor.bean.custom.MyObject;

/**
 * Date: 2025/4/2
 * Desc:
 * <p>
 * author: jaje
 */
public class LocalMapConfig extends MyObject {

    // marker图标的缩放大小
    public static Float MARKER_ICON_SCALE_MULTIPLIER = 1.2f;
    // 电子围栏的最小点数
    public static final int FENCE_MIN_POINTS = 3;
    // 最小角度5度
    public static final int MIN_ANGLE = 5;
    public static final int INTERVAL = 500;
    public static final int INTERVAL_DENSE = 50;
    // Marker缩放的最小级别,大于这个级别不再放大
    public static final float LEVEL_MARKER_MAX = 13.5f;
    // Marker缩放的最大的级别,小于这个级别不再缩小
    public static final float LEVEL_MARKER_MIN = 5.5f;
    // Drone报警线的最大级别,小于这个级别不再缩小
    public static final float LEVEL_DRONE_WARING_LINE_MAX = 13f;
    // 半径字体显示的最大级别，小于这个级别后不显示
    public static final float SHOW_RADIUS_TV_LEVEL = 11f;
    // 设备名称字体显示的最大级别，小于这个级别后不显示
    public static final float SHOW_NAME_TV_LEVEL = 11f;//9.5
    // 动画显示的最大级别，小于这个级别不显示
    public static final float SHOW_ANIMATION_LEVEL = 10f;//11
    // 电子围栏的Icon层级 Zindex
    public static final int ZINDEX_FENCE_ICON = 7;
    // Icon层级 Zindex
    public static final int ZINDEX_ICON = 6;
    // 无人机Icon层级
    public static final int ZINDEX_DRONE_ICON = 100;
    // 电子围栏cover层级 Zindex
    public static final int ZINDEX_FENCE_COVER = 6;
    // cover层级 Zindex
    public static final int ZINDEX_COVER = 4;
    // 光栅图层级 Zindex
    public static final int ZINDEX_TILE_OVERLAY = 4;
    // 半径弧线层级 Zindex
    public static final int ZINDEX_RADIUS_LINE = 5;
    // 扫描线的层级
    public static final int ZINDEX_SCAN_LINE = 7;
    // 半径文字层级 Zindex
    public static final int ZINDEX_RADIUS_TV = 6;
    // 定位间隔时间
    public static final int LOCATION_SCANSPAN = 2000;
    public static double DEFAULT_FENCE_RADIUS = 10000;
    public static int DEFAULT_RADIUS = 10000;
    // 是否显示设备文字
    public static boolean SHOW_NAME_TV = false;
    // 是否显示无人机
    public static boolean IS_NOFLY_ZONE_SHOW_DRONE = true;
    // 是否显示民航机
    public static boolean IS_SHOW_AIRCRAFT = true;
    // 是否显示船舶信息
    public static boolean IS_SHOW_SHIP = true;
    // 显示动画,缩小到一定级别不显示动画效果
    public static boolean SHOW_ANIMATION = false;
    public static boolean USE_SPEAK = false;
    // 设备弧线宽度
    public static int DEVICE_POLYLINE_WIDTH = 2;
    // 折线宽度
    public static int BROKEN_LINE_WIDTH = 2;
    // 历史路径线宽度
    public static int ROUTE_LINE_WIDTH = 8;
    // 电子围栏半径线宽度
    public static int FENCE_RADIUS_LINE_WIDTH = 5;
    // 历史路径线宽度
    public static int HISTORY_NOTE_LINE_WIDTH = 3;
    // 扫描线宽度
    public static int SCAN_LINE_WIDTH = 4;
    // 电子围栏线宽度
    public static int DISTRICT_FENCE_LINE_WIDTH = 0;
    // 预警线宽度
    public static int WARNING_POLYLINE_WIDTH = 3;
    // 攻击线宽度
    public static int BATTLE_TARGET_WIDTH = 5;
    // 路线宽度
    public static int ROUTE_WIDTH = 8;
    // 绘制笔宽度
    public static int PAINT_WIDTH = 8;
    // 设备名称显示位置变量,正北方100米位置
    public static int DEVICE_NAME_SHOW_DISTANCE = 2000;
    public static int DEVICE_NAME_SHOW_ANGLE = 180;
    public static double LATITUDE = 0;
    public static double PAINT_CURRENT_VIEW_LATITUDE = LATITUDE;
    public static double CURRENT_VIEW_LATITUDE = LATITUDE;
    public static double LONGITUDE = 0;
    public static double PAINT_CURRENT_VIEW_LONGITUDE = LONGITUDE;
    public static double CURRENT_VIEW_LONGITUDE = LONGITUDE;
    public static double PAINT_LATITUDE = 0;
    public static double PAINT_LONGITUDE = 0;
    public static float CURRENT_PX_IN_METERS;
    public static float PAINT_CURRENT_PX_IN_METERS;
    // 是否显示预警区
    public static boolean SHOW_AREA_WARNING = false;
    // 是否显示检测区
    public static boolean SHOW_AREA_DISTERN = false;
    // 中心经纬度
    public MyLatLng center;
    // 当前zoom大小
    public float zoom;

    // 三分钟以内视频为新视频
    public static long NEW_VIDEO_TIME = 3 * 60 * 1000L;

    public interface MAP_TYPE {
        int BAIDU_MAP = -1;
        int A_MAP = 0;
        int GOOGLE_MAP = 1;
    }
}
