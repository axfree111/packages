package com.tools.module.amap.model;


import com.drone.monitor.bean.custom.MyLatLng;

import java.io.Serializable;


/**
 * Created by jiajie on 2020-04-19.
 */
public class MyLatLngBounds implements Serializable {
    public MyLatLng southwest;
    public MyLatLng northeast;

    public MyLatLngBounds() {

    }

    public MyLatLngBounds(MyLatLng southwest, MyLatLng northeast) {
        setLatLng(southwest, northeast);
    }

    public void setLatLng(MyLatLng southwest, MyLatLng northeast) {
        this.southwest = southwest;
        this.northeast = northeast;
    }

    public final boolean contains(MyLatLng var1) {
        if (southwest == null || northeast == null) {
            return false;
        }
        double var4 = var1.latitude;
        return this.southwest.latitude <= var4 && var4 <= this.northeast.latitude && this.zza(var1.longitude);
    }

    public final MyLatLngBounds including(MyLatLng var1) {
        if (southwest == null || northeast == null) {
            return new MyLatLngBounds();
        }
        double var3 = Math.min(this.southwest.latitude, var1.latitude);
        double var5 = Math.max(this.northeast.latitude, var1.latitude);
        double var7 = this.northeast.longitude;
        double var9 = this.southwest.longitude;
        double var11 = var1.longitude;
        if (!this.zza(var11)) {
            if (zza(var9, var11) < zzb(var7, var11)) {
                var9 = var11;
            } else {
                var7 = var11;
            }
        }

        return new MyLatLngBounds(new MyLatLng(var3, var9), new MyLatLng(var5, var7));
    }

    public final MyLatLng getCenter() {
        if (southwest == null || northeast == null) {
            return new MyLatLng(0, 0);
        }
        double var1 = (this.southwest.latitude + this.northeast.latitude) / 2.0D;
        double var3 = this.northeast.longitude;
        double var5;
        double var7;
        if ((var5 = this.southwest.longitude) <= var3) {
            var7 = (var3 + var5) / 2.0D;
        } else {
            var7 = (var3 + 360.0D + var5) / 2.0D;
        }

        return new MyLatLng(var1, var7);
    }

    static double zza(double var0, double var2) {
        return (var0 - var2 + 360.0D) % 360.0D;
    }

    static double zzb(double var0, double var2) {
        return (var2 - var0 + 360.0D) % 360.0D;
    }

    private final boolean zza(double var1) {
        if (this.southwest.longitude <= this.northeast.longitude) {
            return this.southwest.longitude <= var1 && var1 <= this.northeast.longitude;
        } else {
            return this.southwest.longitude <= var1 || var1 <= this.northeast.longitude;
        }
    }

    public final String toString() {
        return "southwest:" + southwest.getLatLngString() + " | northeast:" + northeast.getLatLngString();
    }
}
