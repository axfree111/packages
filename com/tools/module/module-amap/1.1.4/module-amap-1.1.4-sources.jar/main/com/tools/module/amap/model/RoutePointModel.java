package com.tools.module.amap.model;

import com.drone.monitor.bean.custom.MyLatLng;
import com.tools.module.amap.R;
import com.tools.module.amap.manager.ResourceManager;
import com.drone.monitor.bean.Drone;
import com.drone.monitor.bean.PlaneDetailData;
import com.drone.monitor.bean.ShipRouteHistoryData;
import com.drone.monitor.bean.custom.MyObject;
import com.tools.module.common.utils.ResourceUtil;

import java.util.Date;

/**
 * Created by jiajie on 2020-03-23.
 */
public class RoutePointModel extends MyObject {
    public Date time;
    public MyLatLng point;
    public int yaw;
    public double height = 0.0;
    public double speed = 0.0;
    public String name;
    public String tip;
    public int pointType = PointType.CENTER_POINT;
    public boolean isLabelEndPoint = false;
    public boolean isLabelStartPoint = false;

    public RoutePointModel copy(RoutePointModel pointModel) {
        time = pointModel.time;
        point = pointModel.point;
        yaw = pointModel.yaw;
        height = pointModel.height;
        speed = pointModel.speed;
        name = pointModel.name;
        tip = pointModel.tip;
        return this;
    }

    public RoutePointModel copy(PlaneDetailData.Line line) {
        time = new Date(line.getTime() * 1000);
        point = new MyLatLng(line.getPosition().getLat(), line.getPosition().getLng());
        yaw = line.getAngle();
        height = line.getHeight();
        speed = line.getSpeed();
        name = line.getName();
        tip = line.getTip();
        return this;
    }

    public void copy(ShipRouteHistoryData.PositionPoint pointModel) {
        time = pointModel.utc;
        point = new MyLatLng(pointModel.lat, pointModel.lng);
        yaw = pointModel.angle;
        height = pointModel.height;
        speed = pointModel.speed;
        name = pointModel.name;
    }

    public RoutePointModel copyDrone(Drone drone) {
        time = drone.createTime;
        point = drone.getMyLatLng();
        height = drone.height;
        yaw = drone.yaw;
        return this;
    }

    public String getHeightAndAngleString() {
        if (yaw < 0) {
            yaw = (yaw % 360) + 360;
        }
        int remainder = yaw % 45;
        int index = yaw / 45;
        return ResourceUtil.getContent(R.string.drone_height_and_angle_label, height, ResourceManager.INSTANCE.DRONE_ANGLE_STRING[index % 8], remainder);
    }

    public String getLatLngString() {
        return ResourceUtil.getContent(R.string.drone_latlng_label, point.longitude, point.latitude);
    }

    public interface PointType {
        int CENTER_POINT = 0;
        int START_POINT = 1;
        int END_POINT = 2;
    }
}
