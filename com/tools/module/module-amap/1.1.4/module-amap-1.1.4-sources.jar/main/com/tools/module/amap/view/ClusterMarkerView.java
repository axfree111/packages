package com.tools.module.amap.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.tools.module.amap.R;
import com.tools.module.amap.databinding.ViewClusterMarkerBinding;
import com.tools.module.amap.databinding.ViewHistoryNoteViewBinding;

/**
 * Created by jiajie on 2019-09-25.
 */
public class ClusterMarkerView extends FrameLayout {

    public ClusterMarkerView(@NonNull Context context) {
        this(context, null);
    }

    public ClusterMarkerView(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public ClusterMarkerView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        this(context, attrs, defStyleAttr, 0);
    }

    public ClusterMarkerView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        initV(context, attrs);
    }

    private ViewClusterMarkerBinding viewBinding;

    public void initV(Context context, AttributeSet attrs) {
        viewBinding = ViewClusterMarkerBinding.inflate(LayoutInflater.from(context), this, true);
    }

    public void setData(int resId, int num) {
        viewBinding.markerImg.setBackgroundResource(resId);
        if (num > 1) {
            viewBinding.markerNumTv.setText(String.valueOf(num));
            viewBinding.markerNumTv.setVisibility(VISIBLE);
        } else {
            viewBinding.markerNumTv.setVisibility(GONE);
        }
    }
}
