package com.tools.module.amap.model.amap;

import androidx.annotation.UiThread;

import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.LatLngBounds;
import com.amap.api.maps.model.Marker;
import com.amap.api.maps.model.Polygon;
import com.drone.monitor.bean.Drone;
import com.drone.monitor.bean.custom.MyLatLng;
import com.tools.module.amap.manager.ColorManager;
import com.tools.module.amap.map.amap.MaMapUtils;
import com.tools.module.amap.model.MarkerDataModel;
import com.tools.module.amap.model.SelectAreaModel;
import com.tools.module.amap.model.base.BaseSelectAreaModel;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by jiajie on 2020-03-22.
 */
public class AMapSelectAreaModel extends BaseSelectAreaModel {
    public List<Marker> markers = new ArrayList<>();
    private Polygon areaCover;

    @Override
    public void addMarker() {
        LatLngBounds visibleBounds = MaMapUtils.getInstance().getMap().getProjection().getVisibleRegion().latLngBounds;
        LatLng southwest = visibleBounds.southwest;
        LatLng northeast = visibleBounds.northeast;
        double differLng = (northeast.longitude - southwest.longitude) / 4;
        double differLat = (northeast.latitude - southwest.latitude) / 4;
        double minLng = southwest.longitude + differLng;
        double maxLng = northeast.longitude - differLng;
        double minLat = southwest.latitude + differLat;
        double maxLat = northeast.latitude - differLat;
        // 最大纬度 和 最小经度
        LatLng leftTopll = new LatLng(maxLat, minLng);
        // 最小纬度 和 最大经度
        LatLng rightBottomll = new LatLng(minLat, maxLng);
        Marker leftTopMarker = MaMapUtils.getInstance().getMap().addMarker(
                MaMapUtils.getFenceCenterMarkOptions(leftTopll));
        markers.add(leftTopMarker);
        MarkerDataModel mkData1 = new MarkerDataModel();
        mkData1.type = Drone.MARKER_TYPE.SELECT_AREA;
        SelectAreaModel fenceModel1 = new SelectAreaModel();
        fenceModel1.id = 1;
        fenceModel1.key = getClassKey();
        mkData1.data = fenceModel1;
        leftTopMarker.setObject(mkData1);

        Marker rightBottomMarker = MaMapUtils.getInstance().getMap().addMarker(
                MaMapUtils.getFenceCenterMarkOptions(rightBottomll));
        markers.add(rightBottomMarker);
        MarkerDataModel mkData2 = new MarkerDataModel();
        mkData2.type = Drone.MARKER_TYPE.SELECT_AREA;
        SelectAreaModel fenceModel2 = new SelectAreaModel();
        fenceModel2.id = 2;
        fenceModel2.key = getClassKey();
        mkData2.data = fenceModel2;
        rightBottomMarker.setObject(mkData2);

        List<LatLng> latLngs = getLatLngs(leftTopll, rightBottomll);
        areaCover = MaMapUtils.getInstance().getMap().addPolygon(
                MaMapUtils.getInstance().getDraggableCoverPolygonOptions(latLngs,
                        ColorManager.getSelectAreaCoverColor(), ColorManager.getSelectAreaCoverColor()));
    }


    private List<LatLng> getLatLngs(LatLng latLng1, LatLng latLng2) {
        double lat1 = latLng1.latitude;
        double lng1 = latLng1.longitude;
        double lat2 = latLng2.latitude;
        double lng2 = latLng2.longitude;
        double minLng = Math.min(lng1, lng2);
        double maxLng = Math.max(lng1, lng2);
        double minLat = Math.min(lat1, lat2);
        double maxLat = Math.max(lat1, lat2);
        List<LatLng> latLngs = new ArrayList<>();
        latLngs.add(new LatLng(minLat, minLng));
        latLngs.add(new LatLng(maxLat, minLng));
        latLngs.add(new LatLng(maxLat, maxLng));
        latLngs.add(new LatLng(minLat, maxLng));
        return latLngs;
    }

    @UiThread
    @Override
    public void removeAreaAndMarker() {
        if (markers != null) {
            for (Marker marker : markers) {
                marker.remove();
            }
            markers.clear();
        }
        if (areaCover != null) {
            areaCover.remove();
        }
    }

    @Override
    public void updateCover() {
        if (markers != null) {
            Marker leftTopMarker = markers.get(0);
            LatLng leftTopLatLngs = leftTopMarker.getPosition();
            Marker rightBottomMarker = markers.get(1);
            LatLng rightBottomLatLngs = rightBottomMarker.getPosition();
            List<LatLng> latLngs = getLatLngs(leftTopLatLngs, rightBottomLatLngs);
            if (areaCover != null) {
                areaCover.setPoints(latLngs);
            }
        }
    }

    @Override
    public List<MyLatLng> getMinAndMaxLatLng() {
        List<MyLatLng> latLngs = new ArrayList<>();
        if (markers != null && markers.size() >= 2) {
            Marker leftTopMarker = markers.get(0);
            // 最大纬度 和 最小经度
            LatLng leftTopLatLngs = leftTopMarker.getPosition();
            Marker rightBottomMarker = markers.get(1);
            // 最小纬度 和 最大经度
            LatLng rightBottomLatLngs = rightBottomMarker.getPosition();

            MyLatLng minLatLngs = new MyLatLng(rightBottomLatLngs.latitude, leftTopLatLngs.longitude);
            MyLatLng maxLatLngs = new MyLatLng(leftTopLatLngs.latitude, rightBottomLatLngs.longitude);
            latLngs.add(minLatLngs);
            latLngs.add(maxLatLngs);
        }
        return latLngs;
    }
}
