package com.tools.module.amap.model;

import com.drone.monitor.bean.custom.MyLatLng;

import java.io.Serializable;

/**
 * Created by jiajiecsf on 2020/11/14.
 */
public class MyPoiItem implements Serializable {
    private String businessArea;
    private String provinceName;
    private String cityName;
    private String adName;
    private String provinceCode;
    private String title;
    private String snippet;// 副标题
    private MyLatLng latLonPoint;

    public String getBusinessArea() {
        return businessArea;
    }

    public void setBusinessArea(String businessArea) {
        this.businessArea = businessArea;
    }

    public String getProvinceName() {
        return provinceName;
    }

    public void setProvinceName(String provinceName) {
        this.provinceName = provinceName;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getAdName() {
        return adName;
    }

    public void setAdName(String adName) {
        this.adName = adName;
    }

    public String getProvinceCode() {
        return provinceCode;
    }

    public void setProvinceCode(String provinceCode) {
        this.provinceCode = provinceCode;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSnippet() {
        return snippet;
    }

    public void setSnippet(String snippet) {
        this.snippet = snippet;
    }

    public MyLatLng getLatLonPoint() {
        return latLonPoint;
    }

    public void setLatLonPoint(MyLatLng latLonPoint) {
        this.latLonPoint = latLonPoint;
    }

    @Override
    public String toString() {
        return "MyPoiResult{" +
                "businessArea='" + businessArea + '\'' +
                ", provinceName='" + provinceName + '\'' +
                ", cityName='" + cityName + '\'' +
                ", adName='" + adName + '\'' +
                ", provinceCode='" + provinceCode + '\'' +
                ", title='" + title + '\'' +
                ", snippet='" + snippet + '\'' +
                ", latLonPoint='" + latLonPoint.toString() + '\'' +
                '}';
    }
}
