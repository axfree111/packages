package com.tools.module.amap;//package com.ad.drone.util;
//
//import android.annotation.SuppressLint;
//import android.app.Activity;
//import android.content.Context;
//import android.content.Intent;
//import android.graphics.Bitmap;
//import android.hardware.display.DisplayManager;
//import android.hardware.display.VirtualDisplay;
//import android.media.Image;
//import android.media.ImageReader;
//import android.media.projection.MediaProjection;
//import android.media.projection.MediaProjectionManager;
//import android.os.AsyncTask;
//import android.os.Build;
//
//import com.ad.drone.Constants;
//import com.ad.drone.base.AppContext;
//
//import java.io.File;
//import java.io.FileOutputStream;
//import java.io.IOException;
//import java.nio.ByteBuffer;
//import java.util.Date;
//
//public class ScreenShortUtils {
//
//    private static final String TAG = ScreenShortUtils.class.getSimpleName();
//    private MediaProjectionManager mProjectionManager;
//    private MediaProjection mMediaProjection;
//    private VirtualDisplay mVirtualDisplay;
//    private Intent mResultData = null;
//    private ImageReader mImageReader;
//    private Activity mContext;
//
//    public ScreenShortUtils(Activity context) {
//        mContext = context;
//    }
//
//    private void startScreenShot() {
//        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_OTHER, "startScreenShot()");
//        ThreadPoolHelper.getInstance().execute(new Runnable() {
//            @Override
//            public void run() {
//                startVirtual();
//                // capture the screen
//                startCapture();
//            }
//        });
//    }
//
//    private void startVirtual() {
//        if (mMediaProjection != null) {
//            virtualDisplay();
//        } else {
//            setUpMediaProjection();
//            virtualDisplay();
//        }
//    }
//
//
//    private void startCapture() {
//        Image image = mImageReader.acquireLatestImage();
//        if (image == null) {
//            startScreenShot();
//        } else {
//            SaveTask mSaveTask = new SaveTask();
//            // mSaveTask.execute(image);
//            if (Build.VERSION.SDK_INT >= 11) {
//                // From API 11 onwards, we need to manually select the
//                // THREAD_POOL_EXECUTOR
//                AsyncTaskCompatHoneycomb.executeParallel(mSaveTask, image);
//            } else {
//                // Before API 11, all tasks were run in parallel
//                mSaveTask.execute(image);
//            }
//            // AsyncTaskCompat.executeParallel(mSaveTask, image);
//        }
//    }
//
//    public void setUpMediaProjection() {
//        if (mResultData == null) {
//            Intent intent = new Intent(Intent.ACTION_MAIN);
//            intent.addCategory(Intent.CATEGORY_LAUNCHER);
//            mContext.startActivity(intent);
//        } else {
//            mMediaProjection = getProjectionManager().getMediaProjection(
//                    Activity.RESULT_OK, mResultData);
//        }
//    }
//
//    private MediaProjectionManager getProjectionManager() {
//        if (null == mProjectionManager) {
//            mProjectionManager = (MediaProjectionManager) ContextStore.getContext().getSystemService(Context.MEDIA_PROJECTION_SERVICE);
//        }
//        return mProjectionManager;
//    }
//
//    public class SaveTask extends AsyncTask<Image, Void, Bitmap> {
//
//        @Override
//        protected Bitmap doInBackground(Image... params) {
//            if (params == null || params.length < 1 || params[0] == null) {
//                return null;
//            }
//
//            Image image = params[0];
//            int width = image.getWidth();
//            int height = image.getHeight();
//            final Image.Plane[] planes = image.getPlanes();
//            final ByteBuffer buffer = planes[0].getBuffer();
//            // 每个像素的间距
//            int pixelStride = planes[0].getPixelStride();
//            // 总的间距
//            int rowStride = planes[0].getRowStride();
//            int rowPadding = rowStride - pixelStride * width;
//            Bitmap bitmap = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888);
//            bitmap.copyPixelsFromBuffer(buffer);
//            bitmap = Bitmap.createBitmap(bitmap, 0, 0, width, height);
//            image.close();
//            return bitmap;
//        }
//
//        @Override
//        protected void onPostExecute(Bitmap bitmap) {
//            super.onPostExecute(bitmap);
//            HandlerUtils.getUIHandler().post(new Runnable() {
//                @Override
//                public void run() {
//                    // TODO 回调完成显示界面
//                }
//            });
//            // 预览图片
//            if (bitmap != null) {
//                //也可以处理保存图片逻辑
//                saveBitmap(bitmap);
//            }
//        }
//    }
//
//    private void tearDownMediaProjection() {
//        if (mMediaProjection != null) {
//            mMediaProjection.stop();
//            mMediaProjection = null;
//        }
//    }
//
//    @SuppressLint("NewApi")
//    private void virtualDisplay() {
//        mVirtualDisplay = mMediaProjection.createVirtualDisplay(
//                "screen-mirror", AppContext.screenWidth, AppContext.screenHeight, (int) AppContext.density,
//                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
//                mImageReader.getSurface(), null, null);
//    }
//
//    /**
//     * 保存bitmap到本地
//     *
//     * @param
//     * @param mBitmap
//     * @return
//     */
//    public File saveBitmap(Bitmap mBitmap) {
//        if (null == mBitmap) {
//            return null;
//        }
//        File filePic;
//        String fileName = new Date().getTime() + ".png";
//        try {
//            filePic = new File(Constants.PATH_SREENSHOT + fileName);
//            if (!filePic.exists()) {
//                filePic.getParentFile().mkdirs();
//                filePic.createNewFile();
//            }
//            FileOutputStream fos = new FileOutputStream(filePic);
//            mBitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
//            fos.flush();
//            fos.close();
//
//            mContext.runOnUiThread(new Runnable() {
//                @Override
//                public void run() {
////                    ToastUtil.makeShortText("截图成功");
//                }
//            });
//        } catch (IOException e) {
//            XAppLogger.getInstance().writeError(e);
//            return null;
//        }
//
//        return filePic;
//    }
//
//    static class AsyncTaskCompatHoneycomb {
//
//        static <Params, Progress, Result> void executeParallel(AsyncTask<Params, Progress, Result> task, Params... params) {
//            // 这里显示调用了THREAD_POOL_EXECUTOR，所以就可以使用该线程池了
//            task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, params);
//        }
//
//    }
//}
