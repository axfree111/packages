package com.tools.module.amap.opendroneid.data

import com.tools.module.amap.R
import com.tools.module.amap.opendroneid.data.SystemBizData.UAClassValueEnum
import com.tools.module.common.utils.ResourceUtil
import java.util.Locale

class LocationBizData : MessageBizData() {
    var status: StatusEnum
    var heightType: HeightTypeEnum
    var direction = 361.0
        set(value) {
            if (value < 0 || value > 360) {
                field = 361.0 // 361 is defined in the specification as the Invalid value
            } else {
                field = value
            }
        }
    private var speedHorizontal = 255.0
    private var speedVertical = 63.0
    private var latitude = 0.0
    private var longitude = 0.0
    private var altitudePressure: Double
    private var altitudeGeodetic: Double
    private var height: Double
    var horizontalAccuracy: HorizontalAccuracyEnum
    var verticalAccuracy: VerticalAccuracyEnum
    var baroAccuracy: VerticalAccuracyEnum
    var speedAccuracy: SpeedAccuracyEnum
    var locationTimestamp: Double = 65535.0
        set(value) {
            var locationTimestamp = value
            if (locationTimestamp < 0) locationTimestamp = 0.0
            if (locationTimestamp != 65535.0 && locationTimestamp > 36000)
                locationTimestamp = 36000.0 // Max one hour is allowed. Unit is 0.1s
            field = locationTimestamp
        }
    private var timeAccuracy = 0.0
    var distance: Float = 0f

    init {
        status = StatusEnum.None
        heightType = HeightTypeEnum.Takeoff
        // 361 is the Invalid value in the specification
        // 255 is the Invalid value in the specification
        // 63 is the Invalid value in the specification
        altitudePressure = -1000.0 // -1000 is the Invalid value in the specification
        altitudeGeodetic = -1000.0 // -1000 is the Invalid value in the specification
        height = -1000.0 // -1000 is the Invalid value in the specification
        horizontalAccuracy = HorizontalAccuracyEnum.Unknown
        verticalAccuracy = VerticalAccuracyEnum.Unknown
        baroAccuracy = VerticalAccuracyEnum.Unknown
        speedAccuracy = SpeedAccuracyEnum.Unknown
    }

    enum class StatusEnum(val key: Int, val description: String) {
        None(0, ResourceUtil.getContent(R.string.undeclared)),
        Ground(1, ResourceUtil.getContent(R.string.ground)),
        Airborne(2, ResourceUtil.getContent(R.string.airborne)),
        Emergency(3, ResourceUtil.getContent(R.string.emergency)),
        StateLoseNoEmergency(4, ResourceUtil.getContent(R.string.state_lose_no_emergency)),
        StateLoseEmergency(5, ResourceUtil.getContent(R.string.state_lose_emergency)),
        RemoteIDSystemFailure(6, ResourceUtil.getContent(R.string.undeclared));

        companion object {
            fun keyOfType(key: Int): StatusEnum {
                for (type in StatusEnum.entries) {
                    if (type.key == key) {
                        return type
                    }
                }
                return StatusEnum.None
            }
        }
    }

    fun setStatus(status: Int) {
        this.status = StatusEnum.keyOfType(status)
    }

    enum class HeightTypeEnum(val key: Int, val description: String) {
        Takeoff(0, ResourceUtil.getContent(R.string.takeoff)),
        Ground(1, ResourceUtil.getContent(R.string.ground_standby)),
        Undeclared(3, ResourceUtil.getContent(R.string.undeclared));

        companion object {
            fun keyOfType(key: Int): HeightTypeEnum {
                for (type in HeightTypeEnum.entries) {
                    if (type.key == key) {
                        return type
                    }
                }
                return HeightTypeEnum.Undeclared
            }
        }
    }

    fun setHeightType(heightType: Int) {
        if (heightType == 1) this.heightType = HeightTypeEnum.Ground
        else this.heightType = HeightTypeEnum.Takeoff
    }

    fun getDirectionAsString(): String {
        return if (direction != 361.0) String.format(
            Locale.US,
            "%3.0f deg",
            direction
        )
        else ResourceUtil.getContent(R.string.unknown)
    }

    fun getSpeedHorizontal(): Double {
        return speedHorizontal
    }

    fun getSpeedHorizontalAsString(): String {
        return if (speedHorizontal != 255.0) String.format(
            Locale.US,
            "%3.2f m/s",
            speedHorizontal
        )
        else ResourceUtil.getContent(R.string.unknown)
    }

    fun getSpeedHorizontalLessPreciseAsString(): String {
        return if (speedHorizontal != 255.0) String.format(
            Locale.US,
            "%3.0fm/s",
            speedHorizontal
        )
        else ResourceUtil.getContent(R.string.unknown)
    }

    fun setSpeedHorizontal(speedHorizontal: Double) {
        var speedHorizontal = speedHorizontal
        if (speedHorizontal < 0 || speedHorizontal > 254.25) speedHorizontal =
            255.0 // 255 is defined in the specification as the Invalid value

        this.speedHorizontal = speedHorizontal
    }

    fun getSpeedVertical(): Double {
        return speedVertical
    }

    fun getSpeedVerticalAsString(): String {
        return if (speedVertical != 63.0) String.format(
            Locale.US,
            "%3.2f m/s",
            speedVertical
        )
        else ResourceUtil.getContent(R.string.unknown)
    }

    fun setSpeedVertical(speedVertical: Double) {
        var speedVertical = speedVertical
        if (speedVertical < -62 || speedVertical > 62) speedVertical =
            63.0 // 63 is defined in the specification as the Invalid value

        this.speedVertical = speedVertical
    }

    fun getLatitude(): Double {
        return latitude
    }

    fun getLatitudeAsString(): String {
        if (latitude == 0.0 && longitude == 0.0) return ResourceUtil.getContent(R.string.unknown)
        return String.format(Locale.US, "%3.7f", latitude)
    }

    fun setLatitude(latitude: Double) {
        var latitude = latitude
        if (latitude < -90 || latitude > 90) {
            latitude = 0.0
            this.longitude =
                0.0 // both equal to zero is defined in the specification as the Invalid value
        }
        this.latitude = latitude
    }

    fun getLongitude(): Double {
        return longitude
    }

    fun getLongitudeAsString(): String {
        if (latitude == 0.0 && longitude == 0.0) return ResourceUtil.getContent(R.string.unknown)
        return String.format(Locale.US, "%3.7f", longitude)
    }

    fun setLongitude(longitude: Double) {
        var longitude = longitude
        if (longitude < -180 || longitude > 180) {
            this.latitude = 0.0
            longitude =
                0.0 // both equal to zero is defined in the specification as the Invalid value
        }
        this.longitude = longitude
    }

    private fun getAltitudeAsString(altitude: Double, ): String {
        if (altitude == -1000.0) return ResourceUtil.getContent(R.string.unknown)
        return String.format(Locale.US, "%3.1f m", altitude)
    }

    fun getAltitudePressure(): Double {
        return altitudePressure
    }

    fun getAltitudePressureAsString(): String {
        return getAltitudeAsString(altitudePressure)
    }

    fun setAltitudePressure(altitudePressure: Double) {
        var altitudePressure = altitudePressure
        if (altitudePressure < -1000 || altitudePressure > 31767) altitudePressure =
            -1000.0 // -1000 is defined in the specification as the Invalid value

        this.altitudePressure = altitudePressure
    }

    fun getAltitudeGeodetic(): Double {
        return altitudeGeodetic
    }

    fun getAltitudeGeodeticAsString(): String {
        return getAltitudeAsString(altitudeGeodetic)
    }

    fun setAltitudeGeodetic(altitudeGeodetic: Double) {
        var altitudeGeodetic = altitudeGeodetic
        if (altitudeGeodetic < -1000 || altitudeGeodetic > 31767) altitudeGeodetic =
            -1000.0 // -1000 is defined in the specification as the Invalid value

        this.altitudeGeodetic = altitudeGeodetic
    }

    fun getHeight(): Double {
        return height
    }

    fun getHeightAsString(): String {
        return getAltitudeAsString(height)
    }

    fun getHeightLessPreciseAsString(): String {
        if (height == -1000.0) return ResourceUtil.getContent(R.string.unknown)
        return String.format(Locale.US, "%3.0fm", height)
    }

    fun setHeight(height: Double) {
        var height = height
        if (height < -1000 || height > 31767) height =
            -1000.0 // -1000 is defined in the specification as the Invalid value

        this.height = height
    }

    enum class HorizontalAccuracyEnum {
        Unknown,
        kilometers_18_52,
        kilometers_7_408,
        kilometers_3_704,
        kilometers_1_852,
        meters_926,
        meters_555_6,
        meters_185_2,
        meters_92_6,
        meters_30,
        meters_10,
        meters_3,
        meters_1,
    }

    fun getHorizontalAccuracyAsString(): String {
        return when (horizontalAccuracy) {
            HorizontalAccuracyEnum.kilometers_18_52 -> "< 18.52 km"
            HorizontalAccuracyEnum.kilometers_7_408 -> "< 7.408 km"
            HorizontalAccuracyEnum.kilometers_3_704 -> "< 3.704 km"
            HorizontalAccuracyEnum.kilometers_1_852 -> "< 1.852 km"
            HorizontalAccuracyEnum.meters_926 -> "< 926 m"
            HorizontalAccuracyEnum.meters_555_6 -> "< 555.6 m"
            HorizontalAccuracyEnum.meters_185_2 -> "< 185.2 m"
            HorizontalAccuracyEnum.meters_92_6 -> "< 92.6 m"
            HorizontalAccuracyEnum.meters_30 -> "< 30 m"
            HorizontalAccuracyEnum.meters_10 -> "< 10 m"
            HorizontalAccuracyEnum.meters_3 -> "< 3 m"
            HorizontalAccuracyEnum.meters_1 -> "< 1 m"
            else -> ResourceUtil.getContent(R.string.unknown)
        }
    }

    fun setHorizontalAccuracy(horizontalAccuracy: Int) {
        when (horizontalAccuracy) {
            1 -> this.horizontalAccuracy = HorizontalAccuracyEnum.kilometers_18_52
            2 -> this.horizontalAccuracy = HorizontalAccuracyEnum.kilometers_7_408
            3 -> this.horizontalAccuracy = HorizontalAccuracyEnum.kilometers_3_704
            4 -> this.horizontalAccuracy = HorizontalAccuracyEnum.kilometers_1_852
            5 -> this.horizontalAccuracy = HorizontalAccuracyEnum.meters_926
            6 -> this.horizontalAccuracy = HorizontalAccuracyEnum.meters_555_6
            7 -> this.horizontalAccuracy = HorizontalAccuracyEnum.meters_185_2
            8 -> this.horizontalAccuracy = HorizontalAccuracyEnum.meters_92_6
            9 -> this.horizontalAccuracy = HorizontalAccuracyEnum.meters_30
            10 -> this.horizontalAccuracy = HorizontalAccuracyEnum.meters_10
            11 -> this.horizontalAccuracy = HorizontalAccuracyEnum.meters_3
            12 -> this.horizontalAccuracy = HorizontalAccuracyEnum.meters_1
            else -> this.horizontalAccuracy = HorizontalAccuracyEnum.Unknown
        }
    }

    enum class VerticalAccuracyEnum {
        Unknown,
        meters_150,
        meters_45,
        meters_25,
        meters_10,
        meters_3,
        meters_1,
    }

    fun getVerticalAccuracyAsString(accuracy: VerticalAccuracyEnum, ): String {
        return when (accuracy) {
            VerticalAccuracyEnum.meters_150 -> "< 150 m"
            VerticalAccuracyEnum.meters_45 -> "< 45 m"
            VerticalAccuracyEnum.meters_25 -> "< 25 m"
            VerticalAccuracyEnum.meters_10 -> "< 10 m"
            VerticalAccuracyEnum.meters_3 -> "< 3 m"
            VerticalAccuracyEnum.meters_1 -> "< 1 m"
            else -> ResourceUtil.getContent(R.string.unknown)
        }
    }

    private fun intToVerticalAccuracy(verticalAccuracy: Int): VerticalAccuracyEnum {
        return when (verticalAccuracy) {
            1 -> VerticalAccuracyEnum.meters_150
            2 -> VerticalAccuracyEnum.meters_45
            3 -> VerticalAccuracyEnum.meters_25
            4 -> VerticalAccuracyEnum.meters_10
            5 -> VerticalAccuracyEnum.meters_3
            6 -> VerticalAccuracyEnum.meters_1
            else -> VerticalAccuracyEnum.Unknown
        }
    }

    fun setVerticalAccuracy(verticalAccuracy: Int) {
        this.verticalAccuracy = intToVerticalAccuracy(verticalAccuracy)
    }

    fun setBaroAccuracy(verticalAccuracy: Int) {
        this.baroAccuracy = intToVerticalAccuracy(verticalAccuracy)
    }

    enum class SpeedAccuracyEnum {
        Unknown,
        meter_per_second_10,
        meter_per_second_3,
        meter_per_second_1,
        meter_per_second_0_3,
    }

    fun getSpeedAccuracyAsString(): String {
        return when (speedAccuracy) {
            SpeedAccuracyEnum.meter_per_second_10 -> "< 10 m/s"
            SpeedAccuracyEnum.meter_per_second_3 -> "< 3 m/s"
            SpeedAccuracyEnum.meter_per_second_1 -> "< 1 m/s"
            SpeedAccuracyEnum.meter_per_second_0_3 -> "< 0.3 m/s"
            else -> ResourceUtil.getContent(R.string.unknown)
        }
    }

    fun setSpeedAccuracy(speedAccuracy: Int) {
        when (speedAccuracy) {
            1 -> this.speedAccuracy = SpeedAccuracyEnum.meter_per_second_10
            2 -> this.speedAccuracy = SpeedAccuracyEnum.meter_per_second_3
            3 -> this.speedAccuracy = SpeedAccuracyEnum.meter_per_second_1
            4 -> this.speedAccuracy = SpeedAccuracyEnum.meter_per_second_0_3
            else -> this.speedAccuracy = SpeedAccuracyEnum.Unknown
        }
    }

    private val timeStampMinutes: Double
        get() = (((locationTimestamp / 10).toInt()) / 60).toFloat().toDouble()
    private val timeStampSeconds: Double
        get() = (locationTimestamp / 10) % 60
    val locationTimestampAsString: String
        get() {
            if (locationTimestamp == 65535.0) return "--:--"
            return String.format(
                Locale.US,
                "%02.0f:%02.0f",
                timeStampMinutes,
                timeStampSeconds
            )
        }

    fun getTimeAccuracy(): Double {
        return timeAccuracy
    }

    fun getTimeAccuracyAsString(): String {
        return if (timeAccuracy == 0.0) ResourceUtil.getContent(R.string.unknown)
        else String.format(Locale.US, "<= %1.1f s", timeAccuracy)
    }

    fun setTimeAccuracy(timeAccuracy: Double) {
        var timeAccuracy = timeAccuracy
        if (timeAccuracy < 0) timeAccuracy = 0.0
        if (timeAccuracy > 1.5) timeAccuracy = 1.5 // 1.5s is the maximum value in the specification

        this.timeAccuracy = timeAccuracy
    }

    val distanceAsString: String
        get() = String.format(Locale.US, "~%.0f m", distance)

    override fun toString(): String {
        return "LocationData(locationTimestampAsString='$locationTimestampAsString', " +
                "distanceAsString='$distanceAsString', " +
                "speedAccuracy=$speedAccuracy, " +
                "baroAccuracy=$baroAccuracy, " +
                "verticalAccuracy=$verticalAccuracy, " +
                "horizontalAccuracy=$horizontalAccuracy, " +
                "height=$height, latitude=$latitude, " +
                "longitude=$longitude, " +
                "speedHorizontal=$speedHorizontal, " +
                "speedVertical=$speedVertical, " +
                "status=$status, direction=$direction, " +
                "altitudePressure=$altitudePressure, " +
                "altitudeGeodetic=$altitudeGeodetic, " +
                "distance=$distance)"
    }

}
