package com.tools.module.amap.opendroneid.parser

import android.location.Location
import com.tools.module.amap.opendroneid.log.LogMessageEntry
import com.tools.module.common.utils.XAppLogger
import java.nio.ByteBuffer
import java.nio.ByteOrder

object OpenDroneIdParser {
    private const val TAG = "OpenDroneIdParser"

    fun parseData(
        payload: ByteArray, offset: Int, timestamp: Long,
        logMessageEntry: LogMessageEntry,
        receiverLocation: android.location.Location?
    ): Message<DronePackData.Payload?>? {
        if (offset <= 0 || payload.size < offset + Constants.MAX_MESSAGE_SIZE) return null
        // 数据前一位 msgCounter
        val msgCounter = payload[offset - 1].toInt() and 0xFF
        return parseMessage(payload, offset, timestamp, logMessageEntry, receiverLocation, msgCounter)
    }

    fun parseMessage(
        payload: ByteArray, offset: Int, timestamp: Long,
        logMessageEntry: LogMessageEntry,
        receiverLocation: android.location.Location?, msgCounter: Int
    ): Message<DronePackData.Payload?>? {
        if (payload.size < offset + Constants.MAX_MESSAGE_SIZE) return null

        // payload 数据结构 抛出偏移量，如果加上偏移量后后边的解析每个都需要加上个偏移量
        // 1-8 (0-4位)存放的是消息类型值，(5-8)存放的是版本号的值
        val byteBuffer = ByteBuffer.wrap(payload, offset, Constants.MAX_MESSAGE_SIZE)
        // 用小端序处理，低字节 低地址
        byteBuffer.order(ByteOrder.LITTLE_ENDIAN)

        val header = DronePackData.Header()
        // 第一个字节
        // 1. 取1个字节，8位 & 1111 1111（十六进制中一位对应4位二进制），目的消除符号位
        // 当为负数时toInit()扩展后为0xFFFFFFFF，$ 0xFF能消除前边位置
        val b = byteBuffer.get().toInt() and 0xFF
        // 3. 提取出 高四位 且 右移4位，也就是最大为15的一个消息类型
        val type = (b and 0xF0) shr 4
        header.type = DronePackData.Type.fromId(type)
        if (header.type == null) {
            XAppLogger.getInstance().writeLog("$TAG Header type unknown")
            return null
        }
        // 4. 提取出 低四位，也就是最大15的一个版本号
        header.version = b and 0x0F

        var payloadObj: DronePackData.Payload? = null
        when (header.type) {
            DronePackData.Type.BASIC_ID -> payloadObj = parseBasicId(byteBuffer)
            DronePackData.Type.LOCATION -> payloadObj = parseLocation(byteBuffer, receiverLocation)
            DronePackData.Type.AUTH -> payloadObj = parseAuthentication(byteBuffer)
            DronePackData.Type.DESCRIPTION_ID -> payloadObj = parseDescriptionID(byteBuffer)
            DronePackData.Type.SYSTEM -> payloadObj = parseSystem(byteBuffer)
            DronePackData.Type.OPERATOR_ID -> payloadObj = parseOperatorID(byteBuffer)
            DronePackData.Type.MESSAGE_PACK -> {
                payloadObj = parseMessagePack(payload, offset)
            }
            else -> XAppLogger.getInstance().writeError("$TAG Received unhandled message type: id=$type")

        }
        val message = Message(header, payloadObj, timestamp, msgCounter)
        logMessageEntry.msgVersion = message.header.version
        if (header.type != DronePackData.Type.MESSAGE_PACK) logMessageEntry.add(message)
        return message
    }

    private fun parseBasicId(byteBuffer: ByteBuffer): DronePackData.BasicId {
        val basicId = DronePackData.BasicId()
        // 第一个字节
        val type = byteBuffer.get().toInt()
        basicId.idType = (type and 0xF0) shr 4
        basicId.uaType = type and 0x0F
        // 从目标数据中读取数据存在uasId数组中的第一个位置
        byteBuffer[basicId.uasId, 0, Constants.MAX_ID_BYTE_SIZE]
        return basicId
    }

    private fun parseLocation(
        byteBuffer: ByteBuffer,
        receiverLocation: android.location.Location?
    ): DronePackData.Location {
        val location = DronePackData.Location()

        // 第1个字节
        // 9-16 (9-12)status (14)heightType (15)EWDirection (16)speedMult
        val b = byteBuffer.get().toInt()
        location.runStatus = (b and 0xF0) shr 4
        // & 0000 0100，右移2位，获取到第3位
        location.heightType = (b and 0x0100) shr 2
        location.EWDirection = (b and 0x0010) shr 1
        location.speedMult = b and 0x01

        // 第2个字节
        // 17-24 direction
        location.direction = byteBuffer.get().toInt() and 0xFF

        // 第3个字节
        // 25-32 speedHori 地速
        location.speedHori = (byteBuffer.get().toInt() and 0xFF).toFloat()
        // 第4个字节
        // 33-40 speedVert，可以是负数，所以不用去符号处理
        location.speedVert = byteBuffer.get().toFloat()

        // 第5-8个字节
        // 41-72 4个字节 droneLat
        location.droneLat = byteBuffer.getInt().toDouble()
        // 第9-12个字节
        // 73-104 4个字节 droneLon
        location.droneLon = byteBuffer.getInt().toDouble()

        // 第13-14个字节
        // 105-120 2个字节 altitudePressure 气压高度
        location.altitudePressure = (byteBuffer.getShort().toInt() and 0xFFFF).toFloat()
        // 第15-16个字节
        // 121-136 2个字节 altitudeGeodetic 几何高度
        location.altitudeGeodetic = (byteBuffer.getShort().toInt() and 0xFFFF).toFloat()
        // 第17-18个字节
        // 137-148 2个字节 height 距离地面高度
        location.height = (byteBuffer.getShort().toInt() and 0xFFFF).toFloat()

        // 第19个字节
        // 149-164 2个字节 水平精度
        val horiVertAccuracy = byteBuffer.get().toInt()
        location.horizontalAccuracy = horiVertAccuracy and 0x0F
        // 垂直精度
        location.verticalAccuracy = (horiVertAccuracy and 0xF0) shr 4
        // 第20个字节
        val speedBaroAccuracy = byteBuffer.get().toInt()
        // 气压精度
        location.baroAccuracy = (speedBaroAccuracy and 0xF0) shr 4
        location.speedAccuracy = speedBaroAccuracy and 0x0F
        // 第21-22个字节
        location.timestamp = byteBuffer.getShort().toInt() and 0xFFFF
        // 第23个字节
        location.timeAccuracy = byteBuffer.get().toInt() and 0x0F

        // Use an older retrieved receiver location to calculate the distance to the drone
        if (location.droneLat != 0.0 && location.droneLon != 0.0) {
            val droneLoc = Location("")
            droneLoc.latitude = location.droneLat
            droneLoc.longitude = location.droneLon
            if (receiverLocation != null) location.distance = receiverLocation.distanceTo(droneLoc)
        }

        return location
    }

    private fun parseAuthentication(byteBuffer: ByteBuffer): DronePackData.Authentication {
        val authentication = DronePackData.Authentication()

        // 9-16 (9-12)authType (13-16)authDataPage
        val type = byteBuffer.get().toInt()
        authentication.authType = (type and 0xF0) shr 4
        authentication.authDataPage = type and 0x0F

        var offset = 0
        var amount = Constants.MAX_AUTH_PAGE_ZERO_SIZE
        if (authentication.authDataPage == 0) {
            // 17-24 authLastPageIndex
            authentication.authLastPageIndex = byteBuffer.get().toInt() and 0xFF
            // 25-32 authLength
            authentication.authLength = byteBuffer.get().toInt() and 0xFF
            // 33-64 authTimestamp
            authentication.authTimestamp = byteBuffer.getInt().toLong() and 0xFFFFFFFFL

            // For an explanation, please see the description for struct ODID_Auth_data in:
            // https://github.com/opendroneid/opendroneid-core-c/blob/master/libopendroneid/opendroneid.h
            val len = authentication.authLastPageIndex * Constants.MAX_AUTH_PAGE_NON_ZERO_SIZE +
                    Constants.MAX_AUTH_PAGE_ZERO_SIZE
            if (authentication.authLastPageIndex >= Constants.MAX_AUTH_DATA_PAGES ||
                authentication.authLength > len
            ) {
                authentication.authLastPageIndex = 0
                authentication.authLength = 0
                authentication.authTimestamp = 0
            } else {
                // Display both normal authentication data and any possible additional data
                authentication.authLength = len
            }
        } else {
            offset = Constants.MAX_AUTH_PAGE_ZERO_SIZE +
                    (authentication.authDataPage - 1) * Constants.MAX_AUTH_PAGE_NON_ZERO_SIZE
            amount = Constants.MAX_AUTH_PAGE_NON_ZERO_SIZE
        }
        if (authentication.authDataPage >= 0 && authentication.authDataPage < Constants.MAX_AUTH_DATA_PAGES) for (i in offset until offset + amount) authentication.authData[i] =
            byteBuffer.get()
        return authentication
    }

    private fun parseDescriptionID(byteBuffer: ByteBuffer): DronePackData.DescriptionID {
        val descriptionID = DronePackData.DescriptionID()
        // 第1个字节
        // 9-16 descriptionType
        /**
         * 0：文字描述
         * 1-200：预留
         * 201-255：私人使用
         */
        descriptionID.descriptionType = byteBuffer.get().toInt() and 0xFF
        // OpenDroneId 用UTF-8 ,DroneID 用ASCII 字符描述
        byteBuffer[descriptionID.operationDescription, 0, Constants.MAX_STRING_BYTE_SIZE]
        return descriptionID
    }

    private fun parseSystem(byteBuffer: ByteBuffer): DronePackData.SystemMsg {
        val s = DronePackData.SystemMsg()

        // 第1个字节
        // 9-16 (9-10)operatorLocationType (11-13)classificationType
        var b = byteBuffer.get().toInt()
        /**
         * 无人驾驶航空器操控员的位置
         * 类型及取值：
         * 0: 起飞位置
         * 1: 动态位置
         * 2: 固定位置
         */
        // 解析 0-1位
        s.operatorLocationType = b and 0x0011
        /**
         * 0：未定义
         * 1: EU
         * 2：中国
         * 3-7：预留
         */
        // 解析 4-2位  0x1c 0001 1100
        s.operatorClassificationType = (b and 0x00011100) shr 2
        // openDroneId 无坐标系类型，也可以直接解析使用
        // 解析 6-5位
        s.positionType = b shr 4 and 0x011
        // 第2-5个字节
        // 17-48 operatorLatitude
        s.operatorLatitude = byteBuffer.getInt().toDouble()
        // 第6-9个字节
        // 48-80 operatorLongitude
        s.operatorLongitude = byteBuffer.getInt().toDouble()
        // 第10-11个字节
        // 81-96 areaCount
        s.areaCount = byteBuffer.getShort().toInt() and 0xFFFF
        // 第12个字节
        // 97-104 areaRadius
        s.areaRadius = byteBuffer.get().toInt() and 0xFF
        // 第13-14个字节
        // 105-120 areaCeiling 运行区域高度上限
        s.areaCeiling = byteBuffer.getShort().toInt() and 0xFFFF
        // 第15-16个字节
        // 121-136 areaCeiling 运行区域高度下限
        s.areaFloor = byteBuffer.getShort().toInt() and 0xFFFF
        // 137-144 (137-140)category (141-144)classValue
        // 第17个字节
        b = byteBuffer.get().toInt()
        /**
         *      * UA 运行类别
         *      * 0：未定义
         *      * 1：开放类
         *      * 2：特许类
         *      * 3：审定类
         *      * 4~5：预留
         */
        s.uaRunCategory = (b and 0xF0) shr 4
        /**
         *      * UA 等级
         *      * 取值范围 0~15
         *      * 0：微型无人驾驶航空器
         *      * 1：轻型无人驾驶航空器
         *      * 2：小型无人驾驶航空器
         *      * 3：具备运行识别功能的其它无人驾驶航空器
         *      * 4~15：预留
         */
        s.uaClassValue = b and 0x0F
        // 145-160 operatorAltitudeGeo 无人机加时航空器操控员高度
        // 第18-19个字节
        s.operatorAltitudeGeo = (byteBuffer.getShort().toInt() and 0xFFFF).toDouble()
        // 第20-23个字节
        // 161-192 systemTimestamp
        s.systemTimestamp = byteBuffer.getInt().toLong() and 0xFFFFFFFFL
        return s
    }

    private fun parseOperatorID(byteBuffer: ByteBuffer): DronePackData.OperatorID {
        val operatorID = DronePackData.OperatorID()
        // 9-16 operatorIdType
        operatorID.operatorIdType = byteBuffer.get().toInt() and 0xFF
        byteBuffer[operatorID.operatorId, 0, Constants.MAX_ID_BYTE_SIZE]
        return operatorID
    }


    private fun parseMessagePack(payload: ByteArray, offset: Int): DronePackData.MessagePack? {
        // 偏移量再 + 1
        // 第1个字节,报文长度
        // 0-16 (0-8)messageSize (9-16)messagesInPack
        var byteBuffer = ByteBuffer.wrap(payload, offset + 1, 2)
        byteBuffer.order(ByteOrder.LITTLE_ENDIAN)

        val messagePack = DronePackData.MessagePack()
        // 第1个字节 报文长度固定25个字节
        messagePack.messageSize = byteBuffer.get().toInt() and 0xFF
        // 第2个字节 报文数量
        messagePack.messagesLength = byteBuffer.get().toInt() and 0xFF

        // openDroneId 最大为9条
        // DroneId 最大为10条
        // 这里只用条数*每个报文长度来计算符合标准就解析
        if (messagePack.messageSize != Constants.MAX_MESSAGE_SIZE
            || messagePack.messagesLength <= 0
            || payload.size < offset + 1 + 2 + messagePack.messageSize * messagePack.messagesLength)
            return null

        // Now that we know how much data is in the message, re-wrap and extract the data
        // + 1 是表示报头、+2 表示pack报文中的前两个字节, 子包会在DataManager中继续
        byteBuffer = ByteBuffer.wrap(payload, offset + 1 + 2, messagePack.messageSize * messagePack.messagesLength)
        byteBuffer[messagePack.messages, 0, messagePack.messageSize * messagePack.messagesLength]
        return messagePack
    }

}