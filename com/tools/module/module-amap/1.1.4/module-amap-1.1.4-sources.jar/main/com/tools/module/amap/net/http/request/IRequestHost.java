package com.tools.module.amap.net.http.request;

/**
 * HTTP Request的所有者, 提供接口判断当前request是否还需要执行
 * BaseActivity可以继承该接口, 当onStop和onStart()切换存活状态
 * 
 * @author changjijie
 *
 */
public interface IRequestHost {

	/**
	 * 是否存活, 如果Host不存活, 则所属的request不会执行
	 * @return
	 */
	boolean isActive();
}
