package com.tools.module.amap.opendroneid.data

import com.tools.module.amap.R
import com.tools.module.amap.opendroneid.OpenDroneIdConstants
import com.tools.module.amap.opendroneid.parser.toPartString
import com.tools.module.common.utils.ResourceUtil
import java.nio.charset.StandardCharsets
import java.sql.Timestamp
import java.util.Locale

class AuthenticationBizData : MessageBizData() {
    @JvmField
    var authType: AuthTypeEnum
    private var authDataPage = 0
    private var authLastPageIndex = 0
    private var authLength = 0
    @JvmField
    var authTimestamp: Long = 0
    @JvmField
    var authData: ByteArray

    init {
        authType = AuthTypeEnum.None
        authData = ByteArray(0)
    }

    fun getAuthDataForUtf8String(): String {
        return authData.toPartString(StandardCharsets.UTF_8)
    }

    fun getAuthDataForAsciiString(): String {
        return authData.toPartString(StandardCharsets.US_ASCII)
    }

    enum class AuthTypeEnum(val id: Int) {
        None(0),
        UAS_ID_Signature(1),
        Operator_ID_Signature(2),
        Message_Set_Signature(3),
        Network_Remote_ID(4),
        Specific_Authentication(5),
        Private_Use_0xA(0xA),
        Private_Use_0xB(0xB),
        Private_Use_0xC(0xC),
        Private_Use_0xD(0xD),
        Private_Use_0xE(0xE),
        Private_Use_0xF(0xF)
    }

    fun setAuthType(authType: Int) {
        when (authType) {
            1 -> this.authType = AuthTypeEnum.UAS_ID_Signature
            2 -> this.authType = AuthTypeEnum.Operator_ID_Signature
            3 -> this.authType = AuthTypeEnum.Message_Set_Signature
            4 -> this.authType = AuthTypeEnum.Network_Remote_ID
            5 -> this.authType = AuthTypeEnum.Specific_Authentication
            0xA -> this.authType = AuthTypeEnum.Private_Use_0xA
            0xB -> this.authType = AuthTypeEnum.Private_Use_0xB
            0xC -> this.authType = AuthTypeEnum.Private_Use_0xC
            0xD -> this.authType = AuthTypeEnum.Private_Use_0xD
            0xE -> this.authType = AuthTypeEnum.Private_Use_0xE
            0xF -> this.authType = AuthTypeEnum.Private_Use_0xF
            else -> this.authType = AuthTypeEnum.None
        }
    }

    fun getAuthDataPage(): Int {
        return authDataPage
    }

    fun setAuthDataPage(authDataPage: Int) {
        var authDataPage = authDataPage
        if (authDataPage < 0) authDataPage = 0
        if (authDataPage > (OpenDroneIdConstants.MAX_AUTH_DATA_PAGES - 1)) authDataPage =
            OpenDroneIdConstants.MAX_AUTH_DATA_PAGES - 1
        this.authDataPage = authDataPage
    }

    fun getAuthLastPageIndex(): Int {
        return authLastPageIndex
    }

    val authLastPageIndexAsString: String
        get() = String.format(Locale.US, "%d pages", authLastPageIndex)

    fun setAuthLastPageIndex(authLastPageIndex: Int) {
        var authLastPageIndex = authLastPageIndex
        if (authLastPageIndex < 0) authLastPageIndex = 0
        if (authLastPageIndex > (OpenDroneIdConstants.MAX_AUTH_DATA_PAGES - 1)) authLastPageIndex =
            OpenDroneIdConstants.MAX_AUTH_DATA_PAGES - 1
        this.authLastPageIndex = authLastPageIndex
    }

    fun getAuthLength(): Int {
        return authLength
    }

    val authLengthAsString: String
        get() = String.format(Locale.US, "%d bytes", authLength)

    fun setAuthLength(authLength: Int) {
        var authLength = authLength
        if (authLength < 0) authLength = 0
        if (authLength > OpenDroneIdConstants.MAX_AUTH_DATA) authLength =
            OpenDroneIdConstants.MAX_AUTH_DATA
        this.authLength = authLength
    }

    fun getAuthTimestampAsString(): String {
        if (authTimestamp == 0L) return ResourceUtil.getContent(R.string.unknown)
        val time = Timestamp((1546300800L + authTimestamp) * 1000)
        return time.toString()
    }


    val authenticationDataAsString: String
        get() {
            val sb = StringBuilder()
            for (i in 0 until authLength) {
                sb.append(String.format("%02X ", authData[i]))
            }
            return sb.toString()
        }
}
