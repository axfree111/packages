package com.tools.module.amap.opendroneid.utils

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.Charset

/**
 * Date: 2025/4/5
 * Desc:
 *
 * author: jaje
 */
class ByteArrayReader(private var byteArray: ByteArray, private val endian: ByteOrder = ByteOrder.BIG_ENDIAN) {
    private var position = 0

    // 读取指定长度的字节数组
    fun readBytes(length: Int): ByteArray {
        checkRemaining(length)
        val result = byteArray.copyOfRange(position, position + length)
        position += length
        return result
    }

    // 读取字符串（需指定编码，默认UTF-8）
    fun readString(length: Int, charset: Charset = Charsets.UTF_8): String {
        checkRemaining(length)
        val bytes = readBytes(length)
        return String(bytes, charset)
    }

    // 读取Double（4字节）
    fun readDouble(): Float {
        checkRemaining(4)
        val buffer = ByteBuffer.wrap(byteArray, position, 4).order(endian)
        val value = buffer.float
        position += 4
        return value
    }

    // 读取Float（4字节）
    fun readFloat(): Float {
        checkRemaining(4)
        val buffer = ByteBuffer.wrap(byteArray, position, 4).order(endian)
        val value = buffer.float
        position += 4
        return value
    }

    // 读取Short（2字节）
    fun readShort(): Short {
        checkRemaining(2)
        val buffer = ByteBuffer.wrap(byteArray, position, 2).order(endian)
        val value = buffer.short
        position += 2
        return value
    }

    // 检查剩余字节是否足够
    private fun checkRemaining(required: Int) {
        if (byteArray.size - position < required) {
            throw IndexOutOfBoundsException("ByteArrayReader 检查剩余字节时发现长度不够解析 Required: $required, Available: ${byteArray.size - position}")
        }
    }

    // 剩余字节数
    fun remaining(): Int = byteArray.size - position
}