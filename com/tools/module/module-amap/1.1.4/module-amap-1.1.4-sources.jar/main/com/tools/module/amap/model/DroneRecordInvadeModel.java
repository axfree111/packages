package com.tools.module.amap.model;

import com.drone.monitor.bean.custom.MyLatLng;
import com.tools.module.amap.model.base.BaseMonitorModel;

import java.io.Serializable;

/**
 * Created by jiajie on 2019-10-26.
 */
public class DroneRecordInvadeModel  implements Serializable {
    private String id;
    private String alias;
    private int invadeType = BaseMonitorModel.INVADE_AREA_TYPE.NO;
    private MyLatLng deviceLatlng;

    public String getId() {
        return id;
    }

    public void setId(String monitorId) {
        this.id = monitorId;
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public int getInvadeType() {
        return invadeType;
    }

    public void setInvadeType(int invadeType) {
        this.invadeType = invadeType;
    }

    public MyLatLng getDeviceLatlng() {
        return deviceLatlng;
    }

    public void setDeviceLatlng(MyLatLng deviceLatlng) {
        this.deviceLatlng = deviceLatlng;
    }

    @Override
    public String toString() {
        return "DroneRecordInvadeModel{" +
                "id='" + id + '\'' +
                ", invadeType=" + invadeType +
                '}';
    }
}
