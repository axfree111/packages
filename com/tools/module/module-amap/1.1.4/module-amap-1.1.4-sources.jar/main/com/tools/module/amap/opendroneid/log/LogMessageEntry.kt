package com.tools.module.amap.opendroneid.log

import com.tools.module.amap.opendroneid.parser.Constants
import com.tools.module.amap.opendroneid.parser.DronePackData
import com.tools.module.amap.opendroneid.parser.Message


class LogMessageEntry {
    private val messages: MutableList<Message<DronePackData.Payload?>> = mutableListOf()
    var msgVersion: Int = 0

    fun add(message: Message<DronePackData.Payload?>) {
        messages.add(message)
    }

    val messageLogEntry: StringBuilder?
        get() {
            if (messages.size == 0) return null

            // 使用 sort() 方法直接修改原列表
            messages.sort()

            val entry = StringBuilder()
            var i = 0

            for (j in 0..1) {
                if (i < messages.size && messages[i].header.type == DronePackData.Type.BASIC_ID) {
                    val message =
                        messages[i] as Message<DronePackData.BasicId>
                    entry.append(message.payload.toCsvString())
                    i++
                } else {
                    entry.append(DELIM_BASIC_ID)
                }
            }
            // Only two Basic ID messages are logged from message packs. Skip additional messages
            while (i < messages.size && messages[i].header.type == DronePackData.Type.BASIC_ID) i++

            if (i < messages.size && messages[i].header.type == DronePackData.Type.LOCATION) {
                val message =
                    messages[i] as Message<DronePackData.Location>
                entry.append(message.payload.toCsvString())
                i++
            } else {
                entry.append(DELIM_LOCATION)
            }
            while (i < messages.size && messages[i].header.type == DronePackData.Type.LOCATION) i++

            // Skip all authentication messages. They are added at the end
            while (i < messages.size && messages[i].header.type == DronePackData.Type.AUTH) i++

            if (i < messages.size && messages[i].header.type == DronePackData.Type.DESCRIPTION_ID) {
                val message =
                    messages[i] as Message<DronePackData.DescriptionID>
                entry.append(message.payload.toCsvString())
                i++
            } else {
                entry.append(DELIM_DESCRIPTION_ID)
            }
            while (i < messages.size && messages[i].header.type == DronePackData.Type.DESCRIPTION_ID) i++

            if (i < messages.size && messages[i].header.type == DronePackData.Type.SYSTEM) {
                val message =
                    messages[i] as Message<DronePackData.SystemMsg>
                entry.append(message.payload.toCsvString())
                i++
            } else {
                entry.append(DELIM_SYSTEM)
            }
            while (i < messages.size && messages[i].header.type == DronePackData.Type.SYSTEM) i++

            if (i < messages.size && messages[i].header.type == DronePackData.Type.OPERATOR_ID) {
                val message =
                    messages[i] as Message<DronePackData.OperatorID>
                entry.append(message.payload.toCsvString())
            } else {
                entry.append(DELIM_OPERATOR)
            }

            // Add the authentication data at the end. It is often not present but adds a lot of columns
            // in the log file, which can make it hard to find the self ID, System and Operator ID data
            i = 0
            while (i < messages.size && messages[i].header.type == DronePackData.Type.BASIC_ID) i++
            while (i < messages.size && messages[i].header.type == DronePackData.Type.LOCATION) i++
            for (j in 0 until Constants.MAX_AUTH_DATA_PAGES) {
                if (i < messages.size && messages[i].header.type == DronePackData.Type.AUTH) {
                    val message =
                        messages[i] as Message<DronePackData.Authentication>
                    if (message.payload.authDataPage == j) {
                        entry.append(message.payload.toCsvString())
                        i++
                    } else {
                        entry.append(DELIM_AUTHENTICATION)
                    }
                } else {
                    entry.append(DELIM_AUTHENTICATION)
                }
            }

            return entry
        }

    companion object {
        private const val DELIM = Constants.DELIM
        private const val DELIM_BASIC_ID = DELIM + DELIM + DELIM
        private const val DELIM_LOCATION = DELIM + DELIM + DELIM + DELIM + DELIM + DELIM +
                DELIM + DELIM + DELIM + DELIM + DELIM + DELIM +
                DELIM + DELIM + DELIM + DELIM + DELIM + DELIM +
                DELIM
        private const val DELIM_AUTHENTICATION = DELIM + DELIM + DELIM + DELIM + DELIM +
                DELIM
        private const val DELIM_DESCRIPTION_ID = DELIM + DELIM
        private const val DELIM_SYSTEM = DELIM + DELIM + DELIM + DELIM + DELIM + DELIM + DELIM +
                DELIM + DELIM + DELIM + DELIM + DELIM + DELIM
        private const val DELIM_OPERATOR = DELIM + DELIM
    }
}
