package com.tools.module.amap.utils;

import android.text.TextUtils;

import com.tools.module.common.utils.GsonUtils;
import com.tools.module.common.utils.XAppLogger;
import com.tools.module.amap.manager.ThreadPoolHelper;
import com.tools.module.amap.map.LocalMapConfig;
import com.tools.module.amap.model.ArcPointOffset;
import com.tools.module.amap.model.CatchPointsData;
import com.tools.module.amap.model.MonitorConfig;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by jiajie on 2020-01-28.
 */
public class ComputeDataProvider {

    public static List<List<ArcPointOffset>> ARC_POINT_TABLE = new ArrayList<>();

    public static void initData() {
        ThreadPoolHelper.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                // 初始化点
                String tableJson = PreferencesUtils.getArcPointTable();
                if (!TextUtils.isEmpty(tableJson)) {
                    CatchPointsData catchPointsData = GsonUtils.getGson().fromJson(tableJson, new TypeToken<CatchPointsData>() {
                    }.getType());
                    ARC_POINT_TABLE = catchPointsData.ARC_POINT_TABLE;
                }
                if (ARC_POINT_TABLE == null || ARC_POINT_TABLE.size() < MonitorConfig.MAX_RANGE) {
                    XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_OTHER, "初始化不同半径弧线上的点偏移量数据");
                    for (int radii = 0; radii < MonitorConfig.MAX_RANGE; radii++) {
                        ArrayList<ArcPointOffset> pointOffsets = new ArrayList<>();
                        for (int angle = 0; angle < 72; angle++) {
                            ArcPointOffset pointOffset = new ArcPointOffset();
                            pointOffset.lat = ComputeUtils.getArcPointLatOffset((radii + 1) * LocalMapConfig.INTERVAL, angle * LocalMapConfig.MIN_ANGLE);
                            pointOffset.lng = ComputeUtils.getArcPointlngOffset((radii + 1) * LocalMapConfig.INTERVAL, angle * LocalMapConfig.MIN_ANGLE);
                            pointOffsets.add(pointOffset);
                        }
                        ARC_POINT_TABLE.add(pointOffsets);
                    }
                    if (ARC_POINT_TABLE.size() > 0) {
                        CatchPointsData catchPointsData = new CatchPointsData();
                        catchPointsData.ARC_POINT_TABLE = ARC_POINT_TABLE;
                        String json = GsonUtils.getGson().toJson(catchPointsData);
                        if (!TextUtils.isEmpty(json)) {
                            PreferencesUtils.saveArcPointTable(json);
                        }
                    }
                }
            }
        });
    }
}
