package com.tools.module.amap.map.amap.overlay;

import android.graphics.Bitmap;

import com.tools.module.common.ContextStore;
import com.tools.module.amap.map.amap.AMapBitmapManager;
import com.tools.module.amap.map.amap.AMapPositionsUtils;
import com.tools.module.amap.map.amap.MaMapUtils;
import com.tools.module.amap.model.RouteMarkerModel;
import com.amap.api.maps.model.BitmapDescriptor;
import com.amap.api.maps.model.BitmapDescriptorFactory;
import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.LatLngBounds;
import com.amap.api.maps.model.Marker;
import com.amap.api.maps.model.MarkerOptions;
import com.amap.api.maps.model.Polyline;
import com.amap.api.maps.model.PolylineOptions;
import com.drone.monitor.bean.Drone;
import com.drone.monitor.bean.custom.MyLatLng;
import com.tools.module.amap.model.RoutePointModel;
import com.tools.module.amap.manager.ColorManager;
import com.tools.module.amap.map.LocalMapConfig;
import com.tools.module.amap.map.MapController;
import com.tools.module.amap.utils.ComputeUtils;
import com.tools.module.common.utils.TimeUtil;
import com.tools.module.amap.view.HistoryNoteInfoView;

import java.util.Iterator;
import java.util.Vector;

public class RouteOverlay {
    protected Vector<Marker> noteMarkers = new Vector<>();
    protected Vector<Marker> orientationMarkers = new Vector<Marker>();
    protected Vector<Marker> infouMarkers = new Vector<Marker>();
    protected Vector<Polyline> allPolyLines = new Vector<Polyline>();
    protected Vector<Polyline> markerPolyLines = new Vector<Polyline>();
    protected MyLatLng startPoint;
    protected MyLatLng endPoint;
    private Bitmap startBit, endBit, objectBit;
    protected boolean nodeIconVisible = true;
    protected int mMarkerType;
    protected int mObjType;
    protected int status;
    protected boolean isOmnibearing;
    protected boolean isAddMaping = false;


    public RouteOverlay(int markerType, int objType) {
        this.mMarkerType = markerType;
        this.mObjType = objType;
    }

    public RouteOverlay(int markerType, int dType, int status, boolean isOmnibearing) {
        this.mMarkerType = markerType;
        this.mObjType = dType;
        this.status = status;
        this.isOmnibearing = isOmnibearing;
    }

    /**
     * 去掉BusRouteOverlay上所有的Marker。
     *
     * @since V2.1.0
     */
    public synchronized void removeFromMap() {
        for (Marker marker : noteMarkers) {
            marker.remove();
        }
        for (Marker marker : infouMarkers) {
            marker.remove();
        }
        for (Marker marker : orientationMarkers) {
            marker.remove();
        }
        for (Polyline line : allPolyLines) {
            line.remove();
        }
        for (Polyline line : markerPolyLines) {
            line.remove();
        }
        destroyBit();
    }

    private void destroyBit() {
        if (startBit != null) {
            startBit.recycle();
            startBit = null;
        }
        if (endBit != null) {
            endBit.recycle();
            endBit = null;
        }
        if (objectBit != null) {
            objectBit.recycle();
            objectBit = null;
        }
    }

    protected void addRoutToMap(RoutePointModel firstPoint, RoutePointModel twoPoint, int position) {
        isAddMaping = true;
        boolean isLeft = (position + 1) % 2 == 0;
        // 计算方向
        float angle = ComputeUtils.getAngle(firstPoint.point, twoPoint.point);
        // 添加路线
        PolylineOptions polylineOptions = getRouteLineOptions(firstPoint, twoPoint);
        if (polylineOptions != null) {
            addPolyLine(polylineOptions);
        }

        // 添加朝向箭头
        addJiantouMarker(firstPoint, twoPoint, angle);

        // 添加结点图标
        addNoteMarker(getNoteMarkerOptions(firstPoint), firstPoint);

        if (isShowNoteInfo()) {
            // 添加结点信息(引线和文字)
            addNoteLineAndText(firstPoint, twoPoint, angle, isLeft);
        }
        isAddMaping = false;
    }

    /**
     * 控制是否显示路线旁边的节点信息
     *
     * @return
     */
    protected boolean isShowNoteInfo() {
        switch (mMarkerType) {
            case Drone.MARKER_TYPE.DRONE:
            case Drone.MARKER_TYPE.MONITOR:
            case Drone.MARKER_TYPE.SHIP:
                return true;
            case Drone.MARKER_TYPE.AIRCRAFT:
                return false;
        }
        return false;
    }

    /**
     * 添加信息marker
     *
     * @param options
     * @param pointModel
     * @param isLeft
     */
    private void addInfoMarker(MarkerOptions options, RoutePointModel pointModel, boolean isLeft) {
        if (options == null) {
            return;
        }
        Marker marker = MaMapUtils.getInstance().getMap().addMarker(options);
        if (marker != null) {
            RouteMarkerModel markerModel = new RouteMarkerModel();
            markerModel.type = RouteMarkerModel.RouteMarkerType.INFO;
            markerModel.pointModel = pointModel;
            markerModel.isLeft = isLeft;
            marker.setObject(markerModel);
            infouMarkers.add(marker);
        }
    }

    private void addOrientationMarker(MarkerOptions options, float angle, boolean isDisconnect) {
        if (options == null) {
            return;
        }
        Marker marker = MaMapUtils.getInstance().getMap().addMarker(options);
        if (marker != null) {
            RouteMarkerModel markerModel = new RouteMarkerModel();
            markerModel.type = RouteMarkerModel.RouteMarkerType.JIANTOU;
            markerModel.angle = angle;
            markerModel.isDisconnect = isDisconnect;
            marker.setObject(markerModel);
            orientationMarkers.add(marker);
        }
    }

    private void addNoteMarker(MarkerOptions options, RoutePointModel point) {
        if (options == null) {
            return;
        }
        Marker marker = MaMapUtils.getInstance().getMap().addMarker(options);
        if (marker != null) {
            RouteMarkerModel markerModel = new RouteMarkerModel();
            markerModel.type = RouteMarkerModel.RouteMarkerType.NOTE;
            markerModel.pointModel = point;
            marker.setObject(markerModel);
            noteMarkers.add(marker);
        }
    }

    private synchronized void addPolyLine(PolylineOptions options) {
        if (options == null) {
            return;
        }
        Polyline polyline = MaMapUtils.getInstance().getMap().addPolyline(options);
        if (polyline != null) {
            markerPolyLines.add(polyline);
        }
    }

    public synchronized void onMapStatusChange(float currentZoomLevel) {
        if (isAddMaping) {
            return;
        }
        Vector<Marker> copyNoteMarkers = new Vector<>();
        copyNoteMarkers.addAll(noteMarkers);
        Iterator<Marker> iterator = copyNoteMarkers.iterator();
        while (iterator.hasNext()) {
            if (isAddMaping) {
                return;
            }
            Marker marker = iterator.next();
            if (marker != null && marker.getObject() != null) {
                RouteMarkerModel routeModel = (RouteMarkerModel) marker.getObject();
                if (routeModel != null && routeModel.pointModel != null) {
                    marker.setIcon(getNoteMarkerBitmapDescriptor(routeModel.pointModel));
                }
            }
        }
        if (isAddMaping) {
            return;
        }
        Vector<Marker> copyOrientationMarkers = new Vector<>();
        copyOrientationMarkers.addAll(orientationMarkers);
        Iterator<Marker> iterator1 = copyOrientationMarkers.iterator();
        while (iterator1.hasNext()) {
            if (isAddMaping) {
                return;
            }
            Marker marker = iterator1.next();
            if (marker != null && marker.getObject() != null) {
                RouteMarkerModel routeModel = (RouteMarkerModel) marker.getObject();
                if (routeModel != null) {
                    marker.setIcon(getJiantouBitmapDescriptor(routeModel.isDisconnect));
                }
            }
        }
//        for (Marker marker : infouMarkers) {
//            if (marker != null && marker.getObject() != null) {
//                RouteMarkerModel routeModel = (RouteMarkerModel) marker.getObject();
//                if (routeModel != null && routeModel.pointModel != null) {
//                    marker.setIcon(getNoteInfoMarkerBitmapDescriptor(routeModel.pointModel));
//                }
//            }
//        }
    }

    /**
     * 给起点Marker设置图标，并返回更换图标的图片。如不用默认图片，需要重写此方法。
     *
     * @return 更换的Marker图片。
     * @since V2.1.0
     */
    protected BitmapDescriptor getStartBitmapDescriptor() {
        return AMapBitmapManager.getInstance().getRouteStartNoteBitmap(MapController.CURRENT_ZOOM_LEVEL);
    }

    /**
     * 给终点Marker设置图标，并返回更换图标的图片。如不用默认图片，需要重写此方法。
     *
     * @return 更换的Marker图片。
     * @since V2.1.0
     */
    protected BitmapDescriptor getEndBitmapDescriptor() {
        return AMapBitmapManager.getInstance().getRouteEndNoteBitmap(MapController.CURRENT_ZOOM_LEVEL);
    }

    // ------------------------- 添加结点相关 ----------------------------------

    private void addNoteLineAndText(RoutePointModel firstPoint, RoutePointModel twoPoint, float angle, boolean isLeft) {
        double distance = ComputeUtils.getDistance(firstPoint.point, twoPoint.point);
        float newAngle = isLeft ? angle - 30f : angle + 30f;
        MyLatLng showLatLng = ComputeUtils.eOffsetBearing(firstPoint.point, distance / 5, newAngle);

        // 添加引线
        addPolyLine(getNoteLineOptions(firstPoint, showLatLng));

        // 添加文字
        addInfoMarker(getNoteInfoMakerOptions(firstPoint, showLatLng, isLeft), firstPoint, isLeft);
    }

    private PolylineOptions getNoteLineOptions(RoutePointModel pointModel, MyLatLng toPoint) {
        PolylineOptions polylineOptions = new PolylineOptions();
        polylineOptions.add(AMapPositionsUtils.transformAMapPosition(pointModel.point),
                AMapPositionsUtils.transformAMapPosition(toPoint))
                .color(ColorManager.getNoteInfoLineColor())
                .width(LocalMapConfig.HISTORY_NOTE_LINE_WIDTH);
        return polylineOptions;
    }

    private MarkerOptions getNoteInfoMakerOptions(RoutePointModel pointModel, MyLatLng showLatLng, boolean isLeft) {
        return new MarkerOptions().
                position(AMapPositionsUtils.transformAMapPosition(showLatLng))
                .anchor(isLeft ? 0.0f : 1.0f, 0.5f)
                .icon(getNoteInfoMarkerBitmapDescriptor(pointModel));
    }

    private BitmapDescriptor getNoteInfoMarkerBitmapDescriptor(RoutePointModel pointModel) {
        HistoryNoteInfoView noteInfoView = new HistoryNoteInfoView(ContextStore.getContext());
        noteInfoView.setData(TimeUtil.getTimeStr(pointModel.time), pointModel.getHeightAndAngleString(), pointModel.yaw + "");
        return BitmapDescriptorFactory.fromBitmap(AMapBitmapManager.getInstance().getBitmapfromView(noteInfoView));
    }

    private MarkerOptions getNoteMarkerOptions(RoutePointModel point) {
        MarkerOptions markerOptions = new MarkerOptions()
                .position(AMapPositionsUtils.transformAMapPosition(point.point))
                .anchor(0.5f, 0.5f);
        markerOptions.icon(getNoteMarkerBitmapDescriptor(point));
        return markerOptions;
    }

    private BitmapDescriptor getNoteMarkerBitmapDescriptor(RoutePointModel point) {
        if (point.pointType == RoutePointModel.PointType.START_POINT) {
            return getStartBitmapDescriptor();
        } else if (point.pointType == RoutePointModel.PointType.END_POINT) {
            return getEndBitmapDescriptor();
        } else {
            return getCenterNoteBitmapDescriptor();
        }
    }
    // ------------------------- 添加结点相关 ----------------------------------

    // ------------------------- 添加路线相关 ----------------------------------

    /**
     * 获取路线Options
     *
     * @param firstPoint
     * @param twoPoint
     * @return
     */
    private PolylineOptions getRouteLineOptions(RoutePointModel firstPoint, RoutePointModel twoPoint) {
        // 路线Options
        if ((firstPoint.pointType == RoutePointModel.PointType.CENTER_POINT
                || firstPoint.pointType == RoutePointModel.PointType.START_POINT)
                && (twoPoint.pointType == RoutePointModel.PointType.CENTER_POINT
                || twoPoint.pointType == RoutePointModel.PointType.END_POINT)) {
            PolylineOptions polylineOptions = new PolylineOptions();
            polylineOptions.add(AMapPositionsUtils.transformAMapPosition(firstPoint.point),
                    AMapPositionsUtils.transformAMapPosition(twoPoint.point))
                    .width(LocalMapConfig.ROUTE_LINE_WIDTH) // 绘制实线
                    .color(getRouteColor());
            return polylineOptions;
        } else if (firstPoint.pointType == RoutePointModel.PointType.END_POINT
                && twoPoint.pointType == RoutePointModel.PointType.START_POINT) {
            PolylineOptions polylineOptions = new PolylineOptions();
            polylineOptions.add(AMapPositionsUtils.transformAMapPosition(firstPoint.point),
                    AMapPositionsUtils.transformAMapPosition(twoPoint.point))
                    .width(LocalMapConfig.ROUTE_LINE_WIDTH - 3)
                    .color(getDisconnectRouteColor())
                    .setDottedLine(true); // 绘制虚线
            return polylineOptions;
        }
        return null;
    }

    /**
     * 添加箭头marker
     *
     * @param firstPoint
     * @param twoPoint
     */
    private void addJiantouMarker(RoutePointModel firstPoint, RoutePointModel twoPoint, float angle) {
        if ((firstPoint.pointType == RoutePointModel.PointType.CENTER_POINT
                || firstPoint.pointType == RoutePointModel.PointType.START_POINT)
                && (twoPoint.pointType == RoutePointModel.PointType.CENTER_POINT
                || twoPoint.pointType == RoutePointModel.PointType.END_POINT)) {
            // 计算路线中间位置
            MyLatLng centerPoint = ComputeUtils.getCenterPoint(firstPoint.point, twoPoint.point);
            // 绘制朝向箭头
            addOrientationMarker(getJiantouMarkerOptions(centerPoint, angle, false), angle, false);
        }
    }

    /**
     * 添加虚线箭头marker
     *
     * @param firstPoint
     * @param twoPoint
     */
    private void addDisconnectJiantouMarker(RoutePointModel firstPoint, RoutePointModel twoPoint) {
        if ((firstPoint.pointType == RoutePointModel.PointType.CENTER_POINT
                || firstPoint.pointType == RoutePointModel.PointType.START_POINT)
                && (twoPoint.pointType == RoutePointModel.PointType.CENTER_POINT
                || twoPoint.pointType == RoutePointModel.PointType.END_POINT)) {
            // 计算方向
            float angle = ComputeUtils.getAngle(firstPoint.point, twoPoint.point);
            // 计算路线中间位置
            MyLatLng centerPoint = ComputeUtils.getCenterPoint(firstPoint.point, twoPoint.point);
            // 绘制朝向箭头
            addOrientationMarker(getJiantouMarkerOptions(centerPoint, angle, true), angle, true);
        }
    }

    private MarkerOptions getJiantouMarkerOptions(MyLatLng pointLatLng, float angle, boolean isDisconnect) {
        MarkerOptions markerOptions = new MarkerOptions()
                .position(AMapPositionsUtils.transformAMapPosition(pointLatLng))
                .anchor(0.5f, 0.5f)
                .rotateAngle(-angle)
                .icon(getJiantouBitmapDescriptor(isDisconnect));
        return markerOptions;
    }

    private BitmapDescriptor getJiantouBitmapDescriptor(boolean isDisconnect) {
        return isDisconnect ?
                AMapBitmapManager.getInstance().getRouteDisconnectJiantouBitmap(MapController.CURRENT_ZOOM_LEVEL)
                : AMapBitmapManager.getInstance().getRouteJiantouBitmap(MapController.CURRENT_ZOOM_LEVEL);
    }
    // ------------------------- 添加路线相关 ----------------------------------

    /**
     * 移动镜头到当前的视角。
     *
     * @since V2.1.0
     */
    public void zoomToSpan() {
//        if (startPoint != null) {
//            try {
//                LatLngBounds bounds = getLatLngBounds();
//                MaMapUtils.getInstance().getMap().animateCamera(CameraUpdateFactory
//                        .newLatLngBounds(bounds, 100));
//            } catch (Throwable e) {
//                e.printStackTrace();
//            }
//        }
    }

    private LatLngBounds getLatLngBounds() {
        LatLngBounds.Builder b = LatLngBounds.builder();
        b.include(new LatLng(startPoint.latitude, startPoint.longitude));
        b.include(new LatLng(endPoint.latitude, endPoint.longitude));
        return b.build();
    }

    /**
     * 路段节点图标控制显示接口。
     *
     * @param visible true为显示节点图标，false为不显示。
     * @since V2.3.1
     */
    public void setNodeIconVisibility(boolean visible) {
        try {
            nodeIconVisible = visible;
            if (this.noteMarkers != null && this.noteMarkers.size() > 0) {
                for (int i = 0; i < this.noteMarkers.size(); i++) {
                    this.noteMarkers.get(i).setVisible(visible);
                }
            }
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }

    protected BitmapDescriptor getCenterNoteBitmapDescriptor() {
        return AMapBitmapManager.getInstance().getRouteNoteBitmap(MapController.CURRENT_ZOOM_LEVEL);
    }

    protected int getRouteColor() {
        return ColorManager.getRouteLineColor();
    }

    protected int getDisconnectRouteColor() {
        return ColorManager.getDisconnectRouteLineColor();
    }
}
