package com.tools.module.amap.model;

import com.drone.monitor.bean.Drone;
import com.drone.monitor.bean.MonitorDevice;
import com.drone.monitor.bean.VideoInfo;
import com.tools.module.common.utils.XAppLogger;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by jiajie on 2020-03-23.
 */
public class MarkerDataModel implements Serializable {
    public String markerId;
    public int type;
    public boolean isList = false;
    public boolean isSelected = false;
    public Object data;
    public List<Object> datas = new ArrayList<>();
    public Object extra;
    public List<Object> extras = new ArrayList<>();

    public boolean equals(MarkerDataModel equalsData) {
        if (equalsData == null) {
            return false;
        }
        if (equalsData.type == type) {
            try {
                switch (type) {
                    case Drone.MARKER_TYPE.DRONE:
                    case Drone.MARKER_TYPE.AIRCRAFT:
                    case Drone.MARKER_TYPE.SHIP:
                        Drone drone = null;
                        if (!equalsData.isList) {
                            drone = (Drone) equalsData.data;
                        } else {
                            List<Drone> drones = (List<Drone>) equalsData.data;
                            if (drones != null && drones.size() > 0) {
                                drone = drones.get(0);
                            }
                        }
                        Drone mDrone = null;
                        if (!isList) {
                            mDrone = (Drone) data;
                        } else {
                            List<Drone> drones = (List<Drone>) data;
                            if (drones != null && drones.size() > 0) {
                                mDrone = drones.get(0);
                            }
                        }
                        if (drone != null && mDrone != null) {
                            if (drone.getItemId().equals(mDrone.getItemId())) {
                                return true;
                            }
                        }
                        break;
                    case Drone.MARKER_TYPE.VIDEO:
                        VideoInfo video = (VideoInfo) equalsData.data;
                        VideoInfo mVideo = (VideoInfo) data;
                        if (video != null && mVideo != null) {
                            if (video.getVideoObjectKey().equals(mVideo.getVideoObjectKey())) {
                                return true;
                            }
                        }
                        break;
                    case Drone.MARKER_TYPE.MONITOR:
                        MonitorDevice monitorDevice = (MonitorDevice) equalsData.data;
                        MonitorDevice mMonitorDevice = (MonitorDevice) data;
                        if (monitorDevice != null && mMonitorDevice != null) {
                            if (monitorDevice.getMonitorId().equals(mMonitorDevice.getMonitorId())) {
                                return true;
                            }
                        }
                        break;
                }
            } catch (Exception e) {
                XAppLogger.getInstance().writeError(e);
            }
        }
        return false;
    }

    public static class VideoExtraModel implements Serializable {

    }

    public static class DroneExtraModel implements Serializable {
        public boolean isShowTrack;
    }

    public static class DeviceExtraModel implements Serializable {

    }
}
