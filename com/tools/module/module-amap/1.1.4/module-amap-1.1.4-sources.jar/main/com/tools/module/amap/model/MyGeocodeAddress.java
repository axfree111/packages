package com.tools.module.amap.model;

import com.drone.monitor.bean.custom.MyLatLng;

import java.io.Serializable;

/**
 * Created by jiajiecsf on 2020/11/11.
 */
public class MyGeocodeAddress implements Serializable {
    public MyLatLng latLng;
    public String city;
    public String district;
    public String formatAddress;
    public String sampleAddress;

    @Override
    public String toString() {
        return "MyGeocodeAddress{" +
                "latLng=" + latLng.toString() +
                ", city='" + city + '\'' +
                ", district='" + district + '\'' +
                ", formatAddress='" + formatAddress + '\'' +
                ", sampleAddress='" + sampleAddress + '\'' +
                '}';
    }
}
