package com.tools.module.common.log;

/**
 * ILogger
 *
 * 
 * 
 */
public interface ILogger {

    void setLogLevel(Level level);

    void d(String tag, String msg);
    void i(String tag, String msg);
    void w(String tag, String msg);
    void e(String tag, String msg);
    void e(String tag, String msg, Throwable tr);

}
