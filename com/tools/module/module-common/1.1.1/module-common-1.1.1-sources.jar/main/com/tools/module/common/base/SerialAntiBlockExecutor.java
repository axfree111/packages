package com.tools.module.common.base;

import com.tools.module.common.log.XLog;

import java.util.ArrayDeque;
import java.util.concurrent.ExecutorService;

/**
 * SerialAntiBlockExecutor
 * 串行防阻塞Executor，队列中若发生任务堆积，则仅执行最新的任务
 *
 * 
 * 
 */
public class SerialAntiBlockExecutor {
    private static final String TAG = "SerialAntiBlockExecutor";

    private final ExecutorService mWorkExecutor;

    private final ArrayDeque<Runnable> mTasks = new ArrayDeque<>();
    private Runnable mActive;

    /**
     * SerialAntiBlockExecutor
     * @param workExector 实际执行任务的ExecutorService
     */
    public SerialAntiBlockExecutor(ExecutorService workExector) {
        mWorkExecutor = workExector;
    }

    public synchronized void execute(final AntiBlockTask r) {
        mTasks.offer(() -> {
            try {
                if (shouldIgnoreTask(r)) {
                    r.onTaskIgnored();
                } else {
                    r.run();
                }
            } catch (Throwable e) {
                XLog.e(TAG, "execute error", e);
            } finally {
                scheduleNext();
            }
        });
        if (mActive == null) {
            scheduleNext();
        }
    }

    private synchronized void scheduleNext() {
        if ((mActive = mTasks.poll()) != null) {
            if (mWorkExecutor != null && !mWorkExecutor.isShutdown() && !mWorkExecutor.isTerminated()) {
                mWorkExecutor.submit(mActive);
            }
        }
    }

    private synchronized boolean shouldIgnoreTask(final AntiBlockTask r) {
        return mTasks.size() > 0;
    }

}
