package com.tools.module.common.log;

import com.tools.module.common.log.impl.EmptyLogger;

/**
 * XLog
 *
 * 
 * 
 */
public class XLog {

    private static volatile ILogger sFileLogger = new EmptyLogger();
    private static volatile ILogger sConsoleLogger = new EmptyLogger();



    public static void init(ILogger fileLogger, ILogger consoleLogger) {
        if (fileLogger != null) {
            sFileLogger = fileLogger;
        }
        if (consoleLogger != null) {
            sConsoleLogger = consoleLogger;
        }
    }

    public static void setLogLevel(Level level) {
        sConsoleLogger.setLogLevel(level);
        sFileLogger.setLogLevel(level);
    }

    public static void d(String tag, String msg) {
        sConsoleLogger.d(tag, msg);
        sFileLogger.d(tag, msg);
    }

    public static void i(String tag, String msg) {
        sConsoleLogger.i(tag, msg);
        sFileLogger.i(tag, msg);
    }

    public static void w(String tag, String msg) {
        sConsoleLogger.w(tag, msg);
        sFileLogger.w(tag, msg);
    }

    public static void e(String tag, String msg) {
        sConsoleLogger.e(tag, msg);
        sFileLogger.e(tag, msg);
    }

    public static void e(String tag, String msg, Throwable tr) {
        sConsoleLogger.e(tag, msg, tr);
        sFileLogger.e(tag, msg, tr);
    }

}
