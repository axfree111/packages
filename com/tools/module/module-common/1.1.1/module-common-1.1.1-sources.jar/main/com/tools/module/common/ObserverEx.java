package com.tools.module.common;

import androidx.lifecycle.Observer;

/**
 * Observer的升级版，对onChanged事件做消重
 *
 */
public abstract class ObserverEx<T> implements Observer<T> {

    private T mLastValue;

    public ObserverEx() {
        this(null);
    }

    public ObserverEx(T defaultValue) {
        mLastValue = defaultValue;
    }

    @Override
    public final void onChanged(T newValue) {
        if (newValue != null && !newValue.equals(mLastValue)) {
            onChangedEx(newValue);
            mLastValue = newValue;
        } else if (newValue == null && mLastValue != null) {
            onChangedEx(newValue);
            mLastValue = newValue;
        }
    }

    public final T getLastValue() {
        return mLastValue;
    }

    public final void reset() {
        mLastValue = null;
    }

    protected abstract void onChangedEx(T newValue);

}
