package com.tools.module.common.task

import com.tools.module.common.base.BaseExecutors
import com.tools.module.common.ext.subscribeX
import com.tools.module.common.log.XLog
import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers
import io.reactivex.rxjava3.core.Observable
import io.reactivex.rxjava3.disposables.CompositeDisposable
import io.reactivex.rxjava3.subjects.PublishSubject
import io.reactivex.rxjava3.subjects.Subject
import java.util.*
import java.util.concurrent.ConcurrentLinkedDeque
import kotlin.math.max

/**
 * TaskQueue
 *
 * 
 * 
 */
class TaskQueue<Data>(description: String, private val maxParallelTaskNum: Int) {

    companion object {
        private const val TAG = "TaskQueue"
    }

    private val subjectTasksState: Subject<ITask<Data>> = PublishSubject.create()
    private val subjectTasksProgress: Subject<ITask<Data>> = PublishSubject.create()

    private val executor = BaseExecutors.newThreadExecutor(
            "p-task-queue-$description",
            max(maxParallelTaskNum / 2, 1),
            max(maxParallelTaskNum, 1)
    )
    private val queue: Queue<BaseTask<Data>> = ConcurrentLinkedDeque()
    @Volatile
    private var scheduleEnabled = true

    private val taskDisposable: MutableMap<String, CompositeDisposable> = mutableMapOf()



    fun getTasks(predicate: (ITask<Data>) -> Boolean): List<ITask<Data>> {
        return queue.filter(predicate).toList()
    }

    @Synchronized
    fun addTask(task: ITask<Data>): Boolean {
        XLog.i(TAG, "addTask ${task.id}")
        if (!(task is BaseTask)) {
            XLog.w(TAG, "addTask failed, task must be subclass of BaseTask")
            return false
        }
        if (queue.contains(task)) {
            XLog.w(TAG, "addTask failed, already in the queue")
            return false
        }
        // Step1：加到队列中
        queue.offer(task)
        // Step2：监听task状态、进度变化
        taskDisposable[task.id] = CompositeDisposable()
        task.observerStateChanged().observeOn(AndroidSchedulers.mainThread()).doOnSubscribe {
            taskDisposable[task.id]?.add(it)
        }.doOnNext {
            dispatchTaskStateChanged(task)
        }.subscribeX()
        task.observerProgressChanged().observeOn(AndroidSchedulers.mainThread()).doOnSubscribe {
            taskDisposable[task.id]?.add(it)
        }.doOnNext {
            dispatchTaskProgressChanged(task)
        }.subscribeX()
        // Step3：根据autoStart标志位，自动启动task
        if (task.autoStart) {
            task.start().subscribeX()
        }
        return true
    }

    fun removeTasks(predicate: (ITask<Data>) -> Boolean) {
        queue.filter(predicate).forEach { task ->
            if (task.state == TaskState.RUNNING) {
                XLog.i(TAG, "removeTask stop ${task.id}")
                task.stop().doFinally {
                    removeTaskInternal(task)
                }.subscribeX()
            } else {
                removeTaskInternal(task)
            }
        }
    }

    @Synchronized
    private fun removeTaskInternal(task: ITask<Data>) {
        XLog.i(TAG, "removeTaskInternal ${task.id}")
        // 清理资源
        task.destroy().doOnSubscribe {
            task.state = TaskState.SWITCHING
        }.doFinally {
            task.state = TaskState.DESTROYED
        }.subscribeX()
        // 从队列中移除
        queue.remove(task)
    }

    fun setTaskScheduleEnabled(enabled: Boolean) {
        XLog.i(TAG, "setTaskScheduleEnabled enabled=$enabled")
        scheduleEnabled = enabled
        if (enabled) {
            scheduleNext()
        }
    }



    private fun dispatchTaskStateChanged(task: ITask<Data>) {
        XLog.d(TAG, "dispatchTaskStateChanged ${task.id} state=${task.state}")
        if (task.state != TaskState.SWITCHING) {
            scheduleNext()
        }
        if (task.state == TaskState.DESTROYED) {
            taskDisposable[task.id]?.dispose()
            taskDisposable[task.id]?.clear()
        }
        subjectTasksState.onNext(task)
    }

    private fun dispatchTaskProgressChanged(task: ITask<Data>) {
        subjectTasksProgress.onNext(task)
    }

    fun observerTasksStateChanged(): Observable<ITask<Data>> {
        return subjectTasksState.toSerialized()
    }

    fun observerTasksProgressChanged(): Observable<ITask<Data>> {
        return subjectTasksProgress.toSerialized()
    }

    @Synchronized
    private fun scheduleNext() {
        if (!scheduleEnabled) {
            XLog.i(TAG, "scheduleNext ignored, scheduleEnabled=false")
            return
        }
        // RUNNING 和 SWITCHING 的task都算正忙
        // 并发环境下，可能 TaskA 处于 SWITCHING -> RUNNING 时，TaskB 在 PENDING，从而导致 TaskB 也被同时 execute
        val busyTasks = queue.filter { it.state == TaskState.RUNNING || it.state == TaskState.SWITCHING }
        if (busyTasks.size >= maxParallelTaskNum) {
            XLog.i(TAG, "scheduleNext ignored, busyTasks=${busyTasks.size}, limit=$maxParallelTaskNum")
            return
        }
        queue.firstOrNull { it.state == TaskState.PENDING && it.executable() }?.let { pendingTask ->
            XLog.i(TAG, "scheduleNext task=${pendingTask.id}")
            pendingTask.execute(executor)
        } ?: kotlin.run {
            XLog.i(TAG, "scheduleNext ignored, pendingTask is empty")
        }
    }

}