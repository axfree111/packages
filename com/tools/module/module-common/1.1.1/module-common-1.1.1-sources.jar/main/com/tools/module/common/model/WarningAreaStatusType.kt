package com.tools.module.common.model

/**
 * Date: 2025/3/27
 * Desc:
 *
 * author: jaje
 */
object WarningAreaStatusType {

    /**
     * 执行计划
     * 0 - 正常显示且过滤区域内无人机
     * 1 - 正常显示且不过滤区域内无人机
     * 2 - 删除传入
     */
    const val HIDE_DRONE: Int = 0
    const val SHOW_DRONE: Int = 1
    const val DELETE: Int = -1
}