package com.tools.module.common.log;

/**
 * Level
 *
 * 
 * 
 */
public enum Level {

    //注意：Level的数值需要与xlog.cpp中的保持一致
    VERBOSE(2, "V"),
    DEBUG(3, "D"),
    INFO(4, "I"),
    WARN(5, "W"),
    ERROR(6, "E");

    private final int mLevel;
    private final String mShortName;

    Level(int level, String shortName) {
        mLevel = level;
        mShortName = shortName;
    }

    public int getLevel() {
        return mLevel;
    }

    String shortName() {
        return mShortName;
    }

}
