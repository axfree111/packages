package com.tools.module.common.ext

/**
 *  author : guoshichao
 *  date : 2024/4/24 14:54
 *  description :
 */

// Boolean
fun Boolean?.orFalse(): Boolean = this ?: false
fun Boolean?.orTrue(): Boolean = this ?: true

// 数值类型
fun Int?.orNegOne(): Int = this ?: -1
fun Int?.orZero(): Int = this ?: 0
fun Int?.orElse(default: Int) = this ?: default
fun Long?.orNegOne(): Long = this ?: -1L
fun Long?.orZero(): Long = this ?: 0L
fun Long?.orElse(default: Long) = this ?: default
fun Float?.orNegOne(): Float = this ?: -1f
fun Float?.orZero(): Float = this ?: 0f
fun Float?.orElse(default: Float) = this ?: default
fun Double?.orNegOne(): Double = this ?: -1.0
fun Double?.orZero(): Double = this ?: 0.0
fun Double?.orElse(default: Double) = this ?: default

// String
//源代码已提供
//fun String?.orEmpty(): String = this ?: ""

// collections
fun <K, V> Map<K, V>?.orEmpty(): Map<K, V> = this ?: emptyMap()
fun <E> List<E>?.orEmpty(): List<E> = this ?: emptyList()
fun <E> Set<E>?.orEmpty(): Set<E> = this ?: emptySet()