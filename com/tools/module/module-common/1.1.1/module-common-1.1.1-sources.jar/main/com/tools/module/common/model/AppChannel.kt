package com.tools.module.common.model

/**
 * Date: 2025/3/27
 * Desc:
 *
 * author: jaje
 */
object AppChannel {
    const val POLICE: String = "c0101c" // 公安部系统
    const val SELL: String = "c0102c" // 销售系统
    const val TEST_POLICE: String = "c9998c" // 公安部测试服务
    const val TEST_SELL: String = "c9999c" // 销售测试服务

}