package com.tools.module.common.utils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.internal.LinkedTreeMap;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * GsonUtils
 *
 * 
 * 
 */
public class GsonUtils {

    private static Gson GSON;
    public static Gson getGson(){
        if (GSON == null) {
            GSON = create();
        }
        return GSON;
    }

    public static Gson create() {
        return new GsonBuilder()
                .registerTypeAdapterFactory(ObjectTypeAdapter.FACTORY)
                .create();
    }

    public static Gson createPretty() {
        return new GsonBuilder()
                .setPrettyPrinting()
                .registerTypeAdapterFactory(ObjectTypeAdapter.FACTORY)
                .create();
    }

    public static Gson create(GsonBuilder builder) {
        return builder
                .registerTypeAdapterFactory(ObjectTypeAdapter.FACTORY)
                .create();
    }

    public static <T> T loadFromFile(Gson gson, File file, Class<T> clz) {
        if (gson != null && file != null && clz != null) {
            if (file.exists() && file.canRead()) {
                InputStreamReader reader = null;
                try {
                    reader = new InputStreamReader(new FileInputStream(file));
                    return gson.fromJson(reader, clz);
                } catch (Exception ignored) {
                } finally {
                    IOUtils.closeStream(reader);
                }
            }
        }
        return null;
    }

    public static <T> T loadFromFile(Gson gson, File file, Type type) {
        if (gson != null && file != null && type != null) {
            if (file.exists() && file.canRead()) {
                InputStreamReader reader = null;
                try {
                    reader = new InputStreamReader(new FileInputStream(file));
                    return gson.fromJson(reader, type);
                } catch (Exception ignored) {
                } finally {
                    IOUtils.closeStream(reader);
                }
            }
        }
        return null;
    }

    public static boolean write2File(Gson gson, File file, Object data) {
        if (gson != null && file != null && data != null) {
            FileWriter writer = null;
            try {
                if (!file.exists()) {
                    file.getParentFile().mkdirs();
                    file.createNewFile();
                }
                writer = new FileWriter(file);
                gson.toJson(data, writer);
                writer.flush();
                return true;
            } catch (Exception ignored) {
            } finally {
                IOUtils.closeStream(writer);
            }
        }
        return false;
    }



    /**
     * 基于 https://github.com/google/gson/blob/master/gson/src/main/java/com/google/gson/internal/bind/ObjectTypeAdapter.java
     * 解决了Long被解析成Double的问题
     */
    private static class ObjectTypeAdapter extends TypeAdapter<Object> {

        public static final TypeAdapterFactory FACTORY = new TypeAdapterFactory() {
            @SuppressWarnings("unchecked")
            @Override
            public <T> TypeAdapter<T> create(Gson gson, TypeToken<T> type) {
                boolean intercept = false;
                if (type.getRawType() == Object.class) {
                    intercept = true;
                }
                if (type.getType() instanceof ParameterizedType) {
                    Type[] typeArgs = ((ParameterizedType)type.getType()).getActualTypeArguments();
                    for (Type typeArg: typeArgs) {
                        if (typeArg == Object.class) {
                            intercept = true;
                            break;
                        }
                    }
                }
                return intercept ? (TypeAdapter<T>)new ObjectTypeAdapter(gson) : null;
            }
        };

        private final Gson gson;

        ObjectTypeAdapter(Gson gson) {
            this.gson = gson;
        }

        @Override
        public Object read(JsonReader in) throws IOException {
            JsonToken token = in.peek();
            switch (token) {
                case BEGIN_ARRAY:
                    List<Object> list = new ArrayList<Object>();
                    in.beginArray();
                    while (in.hasNext()) {
                        list.add(read(in));
                    }
                    in.endArray();
                    return list;
                case BEGIN_OBJECT:
                    Map<String, Object> map = new LinkedTreeMap<>();
                    in.beginObject();
                    while (in.hasNext()) {
                        map.put(in.nextName(), read(in));
                    }
                    in.endObject();
                    return map;
                case STRING:
                    return in.nextString();
                case NUMBER:
                    double value = in.nextDouble();
                    if ((long)value == value) {
                        return (long)value;
                    } else {
                        return value;
                    }
                case BOOLEAN:
                    return in.nextBoolean();
                case NULL:
                    in.nextNull();
                    return null;
                default:
                    throw new IllegalStateException();
            }
        }

        @SuppressWarnings("unchecked")
        @Override
        public void write(JsonWriter out, Object value) throws IOException {
            if (value == null) {
                out.nullValue();
                return;
            }

            TypeAdapter<Object> typeAdapter = (TypeAdapter<Object>) gson.getAdapter(value.getClass());
            if (typeAdapter instanceof ObjectTypeAdapter) {
                out.beginObject();
                out.endObject();
                return;
            }

            typeAdapter.write(out, value);
        }
    }

}
