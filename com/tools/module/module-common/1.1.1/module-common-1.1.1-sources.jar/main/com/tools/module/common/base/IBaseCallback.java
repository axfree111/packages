package com.tools.module.common.base;

/**
 * IBaseCallback
 *
 */
public interface IBaseCallback<Data, ErrorCode, ErrorMsg> {

    void onSuccess(Data data);
    void onFail(ErrorCode errorCode, ErrorMsg errorMsg);

}
