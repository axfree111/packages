package com.tools.module.common.base;

/**
 * ExceptionHandler
 *
 * 
 * 
 */
public interface ExceptionHandler {

    void onException(String msg, Throwable tr);

}
