package com.tools.module.common.utils

import com.tools.module.common.log.XLog
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers

/**
 * Date: 2023/7/3
 * Desc:
 *
 * author: jaje
 */
object CoroutineScopeUtils {
    private val TAG: String = CoroutineScopeUtils::class.java.simpleName

    private val coroutineExceptionHandler = CoroutineExceptionHandler { coroutineContext, throwable ->
        XLog.i(TAG, "CoroutineExceptionHandler Exception \ncoroutineContext $coroutineContext \nthrowable $throwable")
    }

    val mainScope = CoroutineScope(Dispatchers.Main + coroutineExceptionHandler)
    var scope = CoroutineScope(Dispatchers.IO + coroutineExceptionHandler)
}