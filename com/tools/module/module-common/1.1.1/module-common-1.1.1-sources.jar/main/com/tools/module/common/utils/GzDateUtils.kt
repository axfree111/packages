package com.tools.module.common.utils

import android.content.Context
import android.text.format.DateFormat
import java.util.Calendar
import java.util.Date
import java.util.GregorianCalendar
import java.util.TimeZone
import kotlin.math.abs

/**
 * DateUtils
 *
 * 
 * 
 */
object GzDateUtils {

    /**
     * 由于系统方法内部timeZoneId为null会抛NullPointerException，所以这里做个封装
     * 获取时区类，校验timeZoneId是否为空，为空用默认的时区
     *
     */
    @JvmStatic
    fun getTimeZone(timeZoneId: String? = null): TimeZone {
        return if (timeZoneId.isNullOrEmpty()) {
            TimeZone.getDefault()
        } else {
            TimeZone.getTimeZone(timeZoneId)
        }
    }

    /**
     * 时区转换为数字：e.g. +0800
     * @return String
     */
    @JvmStatic
    fun formatTimezone(timeZone: TimeZone): String {
        //夏令时标记, DST, Daylight Saving Time
        val inDst = timeZone.inDaylightTime(Date())
        val dstFlag = if (inDst) ".DST" else ""
        val dstOffset = if (inDst) timeZone.dstSavings else 0
        val offsetInHours = (timeZone.rawOffset + dstOffset) / 3600000
        val offsetInHoursAbs = abs(offsetInHours.toDouble()).toInt()
        val sign = if (offsetInHours > 0) "+" else "-"
        //注意，这里不要用String.format，String.format太慢
        val hour = if (offsetInHoursAbs >= 10) "" + offsetInHoursAbs else "0$offsetInHoursAbs"
        return sign + hour + "00" + dstFlag
    }


    fun createCalendarInstance(timeZoneId: String? = null, timestamp: Long? = null): Calendar {
        val calendar = Calendar.getInstance()
        if (timeZoneId != null) {
            val timezone = getTimeZone(timeZoneId)
            calendar.timeZone = timezone
        }
        if (timestamp != null) {
            calendar.timeInMillis = timestamp
        }
        return calendar

    }

    const val MINUTE_IN_SECONDS = 60L
    const val HOUR_IN_SECONDS = 60 * 60L
    const val DAY_IN_SECONDS = 24 * 60 * 60L
    const val MINUTE_IN_MILLIS = MINUTE_IN_SECONDS * 1000L
    const val HOUR_IN_MILLIS = HOUR_IN_SECONDS * 1000L
    const val DAY_IN_MILLIS = DAY_IN_SECONDS * 1000L
    fun getTodayTickMillis(hour: Int, minute: Int): Long {
        return getTodayTick(hour, minute).timeInMillis
    }

    @JvmStatic
    fun getTodayTick(hour: Int, minute: Int): Calendar {
        val now = GregorianCalendar()
        now[Calendar.HOUR_OF_DAY] = hour
        now[Calendar.MINUTE] = minute
        now[Calendar.SECOND] = 0
        now[Calendar.MILLISECOND] = 0
        return now
    }

    fun getTomorrowTickMillis(hour: Int, minute: Int): Long {
        return getTomorrowTick(hour, minute).timeInMillis
    }

    fun getTomorrowTick(hour: Int, minute: Int): Calendar {
        val now = GregorianCalendar()
        now.add(Calendar.DAY_OF_YEAR, 1)
        now[Calendar.HOUR_OF_DAY] = hour
        now[Calendar.MINUTE] = minute
        now[Calendar.SECOND] = 0
        now[Calendar.MILLISECOND] = 0
        return now
    }

    fun getTickMillis(timeZoneId: String?, year: Int, month: Int, day: Int): Long {
        return getTick(timeZoneId, year, month, day).timeInMillis
    }

    fun getTickMillis(timeZoneId: String?, year: Int, month: Int, day: Int, hour: Int, minute: Int, second: Int): Long {
        return getTick(timeZoneId, year, month, day, hour, minute, second).timeInMillis
    }

    fun getTick(timeZoneId: String?, year: Int, month: Int, day: Int): Calendar {
        return getTick(timeZoneId, year, month, day, 0, 0, 0)
    }

    fun getTick(timeZoneId: String?, year: Int, month: Int, day: Int, hour: Int, minute: Int, second: Int): Calendar {
        val now = GregorianCalendar()
        if (timeZoneId != null) {
            val timezone = getTimeZone(timeZoneId)
            now.timeZone = timezone
        }
        now[Calendar.YEAR] = year
        now[Calendar.MONTH] = month - 1
        now[Calendar.DAY_OF_MONTH] = day
        now[Calendar.HOUR_OF_DAY] = hour
        now[Calendar.MINUTE] = minute
        now[Calendar.SECOND] = second
        now[Calendar.MILLISECOND] = 0
        return now
    }

    fun isSameDay(time1: Long, time2: Long, timeZoneId: String? = null): Boolean {
        return isSameDay(Date(time1), Date(time2),timeZoneId)
    }

    fun isSameDay(date1: Date?, date2: Date?, timeZoneId: String? = null): Boolean {
        val cal1 = Calendar.getInstance()
        val cal2 = Calendar.getInstance()
        if (timeZoneId != null) {
            val timezone = getTimeZone(timeZoneId)
            cal1.timeZone = timezone
            cal2.timeZone = timezone
        }
        cal1.time = date1
        cal2.time = date2
        return cal1[Calendar.YEAR] == cal2[Calendar.YEAR] && cal1[Calendar.MONTH] == cal2[Calendar.MONTH] && cal1[Calendar.DAY_OF_YEAR] == cal2[Calendar.DAY_OF_YEAR]
    }

    fun isSameDay(calendar1: GregorianCalendar?, calendar2: GregorianCalendar?): Boolean {
        return if (calendar1 == null || calendar2 == null) {
            false
        } else calendar1[Calendar.YEAR] == calendar2[Calendar.YEAR] && calendar1[Calendar.MONTH] == calendar2[Calendar.MONTH] && calendar1[Calendar.DAY_OF_YEAR] == calendar2[Calendar.DAY_OF_YEAR]
    }

    /**
     * 判断两个日期是否在同一周
     *
     * @param date1
     * @param date2
     * @return
     */
    fun isSameWeekDates(date1: Date?, date2: Date?): Boolean {
        val cal1 = Calendar.getInstance()
        val cal2 = Calendar.getInstance()
        cal1.time = date1
        cal2.time = date2
        val subYear = cal1[Calendar.YEAR] - cal2[Calendar.YEAR]
        if (0 == subYear) {
            if (cal1[Calendar.WEEK_OF_YEAR] == cal2[Calendar.WEEK_OF_YEAR]) return true
        } else if (1 == subYear && Calendar.DECEMBER == cal2[Calendar.MONTH]) {
            // 如果12月的最后一周横跨来年第一周的话则最后一周即算做来年的第一周
            if (cal1[Calendar.WEEK_OF_YEAR] == cal2[Calendar.WEEK_OF_YEAR]) return true
        } else if (-1 == subYear && Calendar.DECEMBER == cal1[Calendar.MONTH]) {
            if (cal1[Calendar.WEEK_OF_YEAR] == cal2[Calendar.WEEK_OF_YEAR]) return true
        }
        return false
    }

    /**
     * 得到指定或者当前时间前n天的Calendar
     *
     * @param c
     * @param n
     * @return
     */
    fun beforeNDays(c: Calendar?, n: Int,timeZoneId:String?): Calendar {
        //偏移量，给定n天的毫秒数
        val offset = (n * 24 * 60 * 60 * 1000).toLong()
        var calendar: Calendar? = null
        calendar = c ?: createCalendarInstance(timeZoneId)
        calendar.timeInMillis = calendar.timeInMillis - offset
        return calendar
    }

    /**
     * 得到指定或者当前时间后n天的Calendar
     *
     * @param c
     * @param n
     * @return
     */
    fun afterNDays(c: Calendar?, n: Int,timeZoneId:String?): Calendar {
        //偏移量，给定n天的毫秒数
        val offset = (n * 24 * 60 * 60 * 1000).toLong()
        var calendar: Calendar? = null
        calendar = c ?: createCalendarInstance(timeZoneId)
        calendar.timeInMillis = calendar.timeInMillis + offset
        return calendar
    }

    /**
     * 是否为12小时制
     */
    fun isTimeSystem12h(context: Context?): Boolean {
        return !DateFormat.is24HourFormat(context)
    }

    /**
     * 是否为24小时制
     */
    fun isTimeSystem24h(context: Context?): Boolean {
        return DateFormat.is24HourFormat(context)
    }

    /**
     * @return times[0]:当前时间点 times[1]:当前时间点距离当天0点的时间
     */
    fun currentTimeMillisArray(timeZoneId: String?): LongArray {
        val times = LongArray(2)
        val calendar = createCalendarInstance(timeZoneId, null)

        //当前时间点
        times[0] = calendar.timeInMillis
        calendar[Calendar.HOUR_OF_DAY] = 0
        calendar[Calendar.MINUTE] = 0
        calendar[Calendar.SECOND] = 0
        calendar[Calendar.MILLISECOND] = 0

        //当前时间点距离当天0点的时间
        times[1] = times[0] - calendar.timeInMillis
        return times
    }

    fun getCalendarTimeMillis(timeZoneId: String?, timeInMillis: Long): Long {
        val calendar = createCalendarInstance(timeZoneId, timeInMillis)
        calendar[Calendar.HOUR_OF_DAY] = 0
        calendar[Calendar.MINUTE] = 0
        calendar[Calendar.SECOND] = 0
        calendar[Calendar.MILLISECOND] = 0
        return calendar.timeInMillis
    }

    fun getFirstMonthDay(timeZoneId: String?, year: Int, month: Int): Long {
        //通过Calendar.getInstance()方法创建一个Calendar实例对象。
        val calendar = GregorianCalendar(year, month - 1, 1)
        calendar.timeZone = getTimeZone(timeZoneId)
        //使用calendar.set(Calendar.DAY_OF_MONTH, 1)方法将日期设置为当月的第一天
        calendar.set(Calendar.DAY_OF_MONTH, 1)
        //返回calendar.getTime()获取时间并返回
        return calendar.timeInMillis
    }

    fun getLastMonthDay(timeZoneId: String?, year: Int, month: Int): Long {
        //通过Calendar.getInstance()方法创建一个Calendar实例对象。
        val calendar = GregorianCalendar(year, month - 1, 1)
        calendar.timeZone = getTimeZone(timeZoneId)
        //使用calendar.set(Calendar.DAY_OF_MONTH, 1)方法将日期设置为当月的第一天
        calendar.set(Calendar.DAY_OF_MONTH, 1)
        //使用calendar.add(Calendar.MONTH, 1)方法将月份加1，即切换到下一个月
        calendar.add(Calendar.MONTH, 1)
        //再使用calendar.add(Calendar.DATE, -1)方法将日期减去1天，即得到当前月份的最后一天
        calendar.add(Calendar.DATE, -1)
        //使用calendar.get(Calendar.DAY_OF_MONTH)方法获取最后一天的日期，并将其赋值给变量lastDay
//        val lastDay = calendar.get(Calendar.DAY_OF_MONTH);
        //返回calendar.getTime()获取最后一天的时间并返回
        return calendar.timeInMillis
    }
}