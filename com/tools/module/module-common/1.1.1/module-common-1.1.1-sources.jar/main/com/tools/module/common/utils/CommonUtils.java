package com.tools.module.common.utils;

import android.app.Service;
import android.content.Context;
import android.os.Vibrator;
import android.view.WindowManager;

import com.tools.module.common.function.IFunction;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * CommonUtils
 *
 * 
 * 
 */
public class CommonUtils {

    /**
     * list转map
     * @param list 输入list
     * @param keyGetter 根据list元素获取map的key
     * @param valueGetter 根据list元素获取map的value
     * @param <T> list的元素类型
     * @param <Key> map key 的类型
     * @param <Value> map value 的类型
     * @return Map<Key, Value>
     */
    public static<T, Key, Value> Map<Key, Value> list2Map(Collection<T> list,
                                                          IFunction<T, Key> keyGetter,
                                                          IFunction<T, Value> valueGetter) {
        Map<Key, Value> map = new HashMap<>();
        if (list != null) {
            for (T item : list) {
                if (item != null) {
                    Key newKey = keyGetter.apply(item);
                    Value newValue = valueGetter.apply(item);
                    if (newKey != null) {
                        map.put(newKey, newValue);
                    }
                }
            }
        }
        return map;
    }

    /**
     * list转list，将老list的元素通过converter转换为新list的元素
     * @param list 老的list
     * @param converter 元素转换方法
     * @param <OldValue> 老list的元素类型
     * @param <NewValue> 新list的元素类型
     * @return List<NewValue>
     */
    public static<OldValue, NewValue> List<NewValue> list2List(Collection<OldValue> list, IFunction<OldValue, NewValue> converter) {
        List<NewValue> newList = new ArrayList<>();
        if (list != null) {
            for (OldValue oldValue : list) {
                if (oldValue != null) {
                    NewValue newValue = converter.apply(oldValue);
                    if (newValue != null) {
                        newList.add(newValue);
                    }
                }
            }
        }
        return newList;
    }

    /**
     * list转set，将老list的元素通过converter转换为新set的元素
     * @param list 老的list
     * @param converter 元素转换方法
     * @param <OldValue> 老list的元素类型
     * @param <NewValue> 新set的元素类型
     * @return Set<NewValue>
     */
    public static<OldValue, NewValue> Set<NewValue> list2Set(List<OldValue> list, IFunction<OldValue, NewValue> converter) {
        Set<NewValue> newSet = new HashSet<>();
        if (list != null) {
            for (OldValue oldValue : list) {
                if (oldValue != null) {
                    NewValue newValue = converter.apply(oldValue);
                    if (newValue != null) {
                        newSet.add(converter.apply(oldValue));
                    }
                }
            }
        }
        return newSet;
    }

    @SafeVarargs
    public static<T> List<T> mergeList(Collection<T>... lists) {
        List<T> mergedList = new ArrayList<>();
        if (lists != null) {
            for (Collection<T> list : lists) {
                if (list != null) {
                    mergedList.addAll(list);
                }
            }
        }
        return mergedList;
    }

    @SafeVarargs
    public static<K, V> Map<K, V> mergeMap(Map<K, V>... maps) {
        Map<K, V> mergedMap = new HashMap<>();
        if (maps != null) {
            for (Map<K, V> map : maps) {
                if (map != null) {
                    mergedMap.putAll(map);
                }
            }
        }
        return mergedMap;
    }

    public static boolean equalsInteger(Integer left, Integer right) {
        if (left == null && right == null) {
            return true;
        }
        if (left != null && right != null) {
            return left.intValue() == right.intValue();
        }
        return false;
    }

    /**
     * 震动功能，需要申请"android.permission.VIBRATE"权限
     * @param context      Context实例
     * @param milliseconds 震动时长 , 单位毫秒
     */
    public static void vibrate(Context context, long milliseconds) {
        Vibrator vib = (Vibrator) context.getSystemService(Service.VIBRATOR_SERVICE);
        vib.vibrate(milliseconds);
    }

    /**
     * 震动功能
     * @param context  Context实例
     * @param pattern  自定义震动模式 。数组中数字的含义依次是[静止时长，震动时长，静止时长，震动时长。。。]单位是毫秒
     * @param isRepeat true-> 反复震动，false-> 只震动一次
     */
    public static void vibrate(Context context, long[] pattern, boolean isRepeat) {
        Vibrator vib = (Vibrator) context.getSystemService(Service.VIBRATOR_SERVICE);
        vib.vibrate(pattern, isRepeat ? 1 : -1);
    }

    /**
     * 获取屏幕高度
     *
     * @param context
     */
    public static int getScreenHeight(Context context) {
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        return wm.getDefaultDisplay().getHeight();
    }
}
