package com.tools.module.common.utils;

/**
 * BytesUtils
 *
 * 
 * 
 */
public class BytesUtils {

    public static final byte[] BITS_1 = new byte[] {
            (byte)0,               // 00000000 00000000
            (byte)((1 << 1) - 1),  // 00000000 00000001
            (byte)((1 << 2) - 1),  // 00000000 00000011
            (byte)((1 << 3) - 1),  // 00000000 00000111
            (byte)((1 << 4) - 1),  // 00000000 00001111
            (byte)((1 << 5) - 1),  // 00000000 00011111
            (byte)((1 << 6) - 1),  // 00000000 00111111
            (byte)((1 << 7) - 1),  // 00000000 01111111
            (byte)((1 << 8) - 1),  // 00000000 11111111
            (byte)((1 << 9) - 1),  // 00000001 11111111
            (byte)((1 << 10) - 1), // 00000011 11111111
            (byte)((1 << 11) - 1), // 00000111 11111111
            (byte)((1 << 12) - 1), // 00001111 11111111
            (byte)((1 << 13) - 1), // 00011111 11111111
            (byte)((1 << 14) - 1), // 00111111 11111111
            (byte)((1 << 15) - 1), // 01111111 11111111
            (byte)((1 << 16) - 1), // 11111111 11111111
    };

    public static byte[] int32ToBytes(int value) {
        return longToBytesLittleEndian(value, 4);
    }

    public static byte[] longToBytes(long value, int length) {
        return longToBytesLittleEndian(value, length);
    }

    public static byte[] longToBytesLittleEndian(long value, int length) {
        final byte[] buf = new byte[length];
        for (int i = 0; i < length; ++i) {
            buf[i] = (byte)((value >> (i << 3)) & 0xFF);
        }
        return buf;
    }

    public static byte[] shortToBytesLittleEndian(short value, int length) {
        final byte[] buf = new byte[length];
        for (int i = 0; i < length; ++i) {
            buf[i] = (byte)((value >> (i << 3)) & 0xFF);
        }
        return buf;
    }

    public static byte[] longToBytesBigEndian(long value, int length) {
        final byte[] buf = new byte[length];
        for (int i = 0; i < length; ++i) {
            buf[i] = (byte)((value >> ((length - i - 1) << 3)) & 0xFF);
        }
        return buf;
    }

    public static long bytesToLong(byte[] buf) {
        return bytesToLongLittleEndian(buf);
    }

    public static long bytesToLongLittleEndian(byte[] buf) {
        long value = 0L;
        for (int i = 0; i != buf.length; ++i) {
            value += ((buf[i] & 0xFF) << (i << 3));
        }
        return value;
    }

    public static short bytesToShortLittleEndian(byte[] buf, int position, int length) {
        short value = 0;
        for (int i = 0; i < length; ++i) {
            value += ((buf[position + i] & 0xFF) << (i << 3));
        }
        return value;
    }

    public static long bytesToLongBigEndian(byte[] buf) {
        long value = 0L;
        for (int i = 0; i != buf.length; ++i) {
            value += ((buf[i] & 0xFF) << ((buf.length - i - 1) << 3));
        }
        return value;
    }



    /**
     * 按大端序，从字节数组buf的指定offset位置，读取1个二进制位，并转成int输出
     * @param buf    字节数组
     * @param offset 按位偏移量
     * @return 0 或 1
     */
    public static int getBitAsInt(byte[] buf, int offset) {
        return (buf[offset >> 3] >> (7 - (offset & 7))) & 1;
    }

    /**
     * 按大端序，从字节数组buf的指定offset位置，连续读取length个二进制位，并转成int输出
     * @param buf    字节数组
     * @param offset 按位偏移量
     * @param length 读取二进制位长度
     * @return int
     */
    public static int getBitsAsInt(byte[] buf, int offset, int length) {
        int result = 0;
        for (int i = 0; i < length; ++i) {
            result = result | (getBitAsInt(buf, offset + i) << (length - i - 1));
        }
        return result;
    }

    /**
     * 按大端序，取value的最后一位数据，向字节数组buf的指定offset位置，写入1个二进制位
     * @param buf    字节数组
     * @param offset 按位偏移量
     * @param value  写入的数据，取 (value & 1) 写入
     */
    public static void putBitWithInt(byte[] buf, int offset, int value) {
        if ((value & 1) != 0) {
            buf[offset >> 3] |= 1 << (7 - (offset & 7));
        } else {
            buf[offset >> 3] &= ~(1 << (7 - (offset & 7)));
        }
    }

    /**
     * 按大端序，取value的低length位数据，向字节数组buf的指定offset位置，连续写入length个二进制位
     * @param buf    字节数组
     * @param offset 按位偏移量
     * @param length 写入二进制位长度
     * @param value  写入的数据
     */
    public static void putBitsWithInt(byte[] buf, int offset, int length, int value) {
        for (int i = 0; i < length; ++i) {
            putBitWithInt(buf, offset + i, (value >> (length - i - 1)) & 1);
        }
    }

}
