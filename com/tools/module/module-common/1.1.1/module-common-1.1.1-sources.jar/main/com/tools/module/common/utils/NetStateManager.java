package com.tools.module.common.utils;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.net.NetworkRequest;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.telephony.PhoneStateListener;
import android.telephony.ServiceState;
import android.telephony.SignalStrength;
import android.telephony.TelephonyManager;

import com.tools.module.common.MethodMonitor;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * 网络状态的管理类
 * Created by wangxi on 2018/6/19.
 */

public class NetStateManager {

    private ConnectivityManager mConnectivityManager;
    private WifiManager mWifiManager;
    private TelephonyManager mTelephonyManager;

    private SimStateListener mSimStateListener;

    /**
     * 存储接受网络状态变化消息的方法的map
     */
    Map<Object, NetWorkStateReceiverMethod> mNetWorkStateChangedMethodMap = new HashMap<>();
    private Context mContext;

    private NetStateManager() {
    }

    private static class SingletonHolder {
        static NetStateManager INSTANCE = new NetStateManager();
    }

    public static NetStateManager getInstance() {
        return SingletonHolder.INSTANCE;
    }


    @MethodMonitor("NetStateManager.init()")
    public void init(Context context) {
        mContext = context;
        if (context != null) {
            final Context appContext = context.getApplicationContext();
            mConnectivityManager = (ConnectivityManager) appContext.getSystemService(Context.CONNECTIVITY_SERVICE);
            mWifiManager = (WifiManager) appContext.getSystemService(Context.WIFI_SERVICE);
            mTelephonyManager = (TelephonyManager) appContext.getSystemService(Context.TELEPHONY_SERVICE);
            mSimStateListener = new SimStateListener();
            mTelephonyManager.listen(mSimStateListener,
                    PhoneStateListener.LISTEN_DATA_CONNECTION_STATE
                            | PhoneStateListener.LISTEN_SIGNAL_STRENGTHS
                            | PhoneStateListener.LISTEN_SERVICE_STATE);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {//API 大于26时
                mConnectivityManager.registerDefaultNetworkCallback(networkCallback);
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {//API 大于21时
                NetworkRequest.Builder builder = new NetworkRequest.Builder();
                NetworkRequest request = builder.build();
                mConnectivityManager.registerNetworkCallback(request, networkCallback);
            } else {//低版本
                IntentFilter intentFilter = new IntentFilter();
                intentFilter.addAction(ANDROID_NET_CHANGE_ACTION);
                context.registerReceiver(receiver, intentFilter);
            }
        }
    }


    private class SimStateListener extends PhoneStateListener {
        private static final int DEFAULT_LEVEL_COUNT = 5;

        private int mSimSignalLevel;
        private int mSimSignalLevelCount = DEFAULT_LEVEL_COUNT;

        SimStateListener() {
            try {
                //Android原生系统将Sim卡信号强度划分为五档(0~4)："none", "poor", "moderate", "good", "great"
                //某些厂商（比如MIUI 10）会将Sim卡信号强度划分为六档(0~5)："none", "poor", "moderate", "good", "great", "excellent"
                //在AndroidP、AndroidQ中该接口都属于灰名单，还可以反射调用，后续Android版本可能会将这个接口列入黑名单
                //在计算百分比的时候，兼容措施是超过最高档的认为都是100%
                mSimSignalLevelCount = ReflectUtils.getIntField(SignalStrength.class, null, "NUM_SIGNAL_STRENGTH_BINS", DEFAULT_LEVEL_COUNT);
            } catch (Exception ignored) {
            }
        }

        @Override
        public void onDataConnectionStateChanged(int state) {
        }

        @Override
        public void onSignalStrengthsChanged(SignalStrength signalStrength) {
            try {
                //mSimSignalLevelCount为5的时候，mSimSignalLevel范围是 0 ~ 4，以此类推
                mSimSignalLevel = ReflectUtils.invokeMethodReturnInt(SignalStrength.class, signalStrength, "getLevel", 0);
            } catch (Exception ignored) {
            }
        }

        @Override
        public void onServiceStateChanged(ServiceState serviceState) {
            final int state = serviceState.getState();
            if (state == ServiceState.STATE_OUT_OF_SERVICE || state == ServiceState.STATE_POWER_OFF) {
                mSimSignalLevel = 0;
            }
        }

        int getSimSignalLevelPercent() {
            if (mSimSignalLevelCount > 0 && mSimSignalLevel >= 0) {
                if (mSimSignalLevel < mSimSignalLevelCount) {
                    return (mSimSignalLevel + 1) * 100 / mSimSignalLevelCount;
                } else {
                    return 100;
                }
            }
            return -1;
        }
    }

    ConnectivityManager.NetworkCallback networkCallback = new ConnectivityManager.NetworkCallback() {
        /**
         * 网络可用的回调连接成功
         */
        @Override
        public void onAvailable(Network network) {
            super.onAvailable(network);
            postNetState(getNetworkState());
        }

        /**
         * 网络不可用时调用和onAvailable成对出现
         */
        @Override
        public void onLost(Network network) {
            super.onLost(network);
            postNetState(getNetworkState());
        }

        /**
         * 在网络连接正常的情况下，丢失数据会有回调 即将断开时
         */
        @Override
        public void onLosing(Network network, int maxMsToLive) {
            super.onLosing(network, maxMsToLive);
        }

        /**
         * 网络功能更改 满足需求时调用
         * @param network network
         * @param networkCapabilities networkCapabilities
         */
        @Override
        public void onCapabilitiesChanged(Network network, NetworkCapabilities networkCapabilities) {
            super.onCapabilitiesChanged(network, networkCapabilities);
        }

        /**
         * 网络连接属性修改时调用
         * @param network network
         * @param linkProperties linkProperties
         */
        @Override
        public void onLinkPropertiesChanged(Network network, LinkProperties linkProperties) {
            super.onLinkPropertiesChanged(network, linkProperties);
        }

        /**
         * 网络缺失network时调用
         */
        @Override
        public void onUnavailable() {
            super.onUnavailable();
            postNetState(getNetworkState());
        }
    };

    private static final String ANDROID_NET_CHANGE_ACTION = "android.net.conn.CONNECTIVITY_CHANGE";
    BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equalsIgnoreCase(ANDROID_NET_CHANGE_ACTION)) {
                //网络发生变化 没有网络-0：WIFI网络1：4G网络-4：3G网络-3：2G网络-2
                postNetState(getNetworkState());
            }
        }
    };

    private NetWorkStateReceiverMethod findMethod(Object object) {
        NetWorkStateReceiverMethod targetMethod = null;
        if (object != null) {
            Class myClass = object.getClass();
            //获取所有的方法
            Method[] methods = myClass.getDeclaredMethods();
            for (Method method : methods) {
                //如果参数个数不是1个 直接忽略
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    if (method.getParameterCount() != 1) {
                        continue;
                    }
                }
                //获取方法参数
                Class[] parameters = method.getParameterTypes();
                if (parameters == null || parameters.length != 1) {
                    continue;
                }
                //参数的类型需要时NetWorkState类型
                if (parameters[0].getName().equals(NetStateManager.NetworkState.class.getName())) {
                    //是NetWorkState类型的参数
                    NetWorkMonitor netWorkMonitor = method.getAnnotation(NetWorkMonitor.class);
                    targetMethod = new NetWorkStateReceiverMethod();
                    //如果没有添加注解，默认就是所有网络状态变化都通知
                    if (netWorkMonitor != null) {
                        NetStateManager.NetworkState[] netWorkStates = netWorkMonitor.monitorFilter();
                        targetMethod.setNetWorkState(netWorkStates);
                    }
                    targetMethod.setMethod(method);
                    targetMethod.setObject(object);
                    //只添加第一个符合的方法
                    return targetMethod;
                }
            }
        }
        return targetMethod;
    }

    @Retention(RetentionPolicy.RUNTIME)//运行时注解
    @Target(ElementType.METHOD)//标记在方法上
    public @interface NetWorkMonitor {
        //监听的网络状态变化 默认全部监听并提示
        NetStateManager.NetworkState[] monitorFilter() default {NetStateManager.NetworkState.NET_UNKNOWN, NetStateManager.NetworkState.NET_WIFI, NetStateManager.NetworkState.NET_2G, NetStateManager.NetworkState.NET_3G, NetStateManager.NetworkState.NET_4G};
    }

    /**
     * 反注册广播
     */
    private void onDestroy() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            this.mContext.unregisterReceiver(receiver);
        }
    }

    /**
     * 注入
     *
     * @param object
     */
    public void register(Object object) {
        if (this.mContext == null) {
            throw new NullPointerException("application can not be null,please call the method init(Application application) to add the Application");
        }
        if (object != null) {
            NetWorkStateReceiverMethod netWorkStateReceiverMethod = findMethod(object);
            if (netWorkStateReceiverMethod != null) {
                mNetWorkStateChangedMethodMap.put(object, netWorkStateReceiverMethod);
            }
        }
    }

    /**
     * 删除
     *
     * @param object
     */


    public void unregister(Object object) {
        if (object != null && mNetWorkStateChangedMethodMap != null) {
            mNetWorkStateChangedMethodMap.remove(object);
        }
    }

    /**
     * 网络状态发生变化，需要去通知更改
     *
     * @param netWorkState
     */
    private void postNetState(NetStateManager.NetworkState netWorkState) {
        Set<Object> set = mNetWorkStateChangedMethodMap.keySet();
        Iterator iterator = set.iterator();
        while (iterator.hasNext()) {
            Object object = iterator.next();
            NetWorkStateReceiverMethod netWorkStateReceiverMethod = mNetWorkStateChangedMethodMap.get(object);
            invokeMethod(netWorkStateReceiverMethod, netWorkState);

        }
    }

    /**
     * 具体执行方法
     *
     * @param netWorkStateReceiverMethod
     * @param netWorkState
     */
    private void invokeMethod(NetWorkStateReceiverMethod netWorkStateReceiverMethod, NetStateManager.NetworkState netWorkState) {
        if (netWorkStateReceiverMethod != null) {
            try {
                NetStateManager.NetworkState[] netWorkStates = netWorkStateReceiverMethod.getNetWorkState();
                for (NetStateManager.NetworkState myState : netWorkStates) {
                    if (myState == netWorkState) {
                        netWorkStateReceiverMethod.getMethod().invoke(netWorkStateReceiverMethod.getObject(), netWorkState);
                        return;
                    }
                }

            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
        }
    }

    private boolean isWifiConnected() {
        if (mConnectivityManager != null) {
            try {
                final NetworkInfo networkInfo = mConnectivityManager.getActiveNetworkInfo();
                if (networkInfo != null && networkInfo.getType() == ConnectivityManager.TYPE_WIFI) {
                    return true;
                }
            } catch (Exception ignored) {
            }
        }
        return false;
    }

    /**
     * 获取WiFi的信号强度 0~100，对应为 0% ~ 100%
     */
    private int getWifiSignalLevel() {
        if (mWifiManager != null) {
            try {
                final WifiInfo wifiInfo = mWifiManager.getConnectionInfo();
                if (wifiInfo != null) {
                    return WifiManager.calculateSignalLevel(wifiInfo.getRssi(), 101);
                }
            } catch (Exception ignored) {
            }
        }
        return -1;
    }

    /**
     * 获取Sim卡的信号强度 0~100，对应为 0% ~ 100%
     */
    private int getSimSignalLevel() {
        return mSimStateListener != null ? mSimStateListener.getSimSignalLevelPercent() : -1;
    }

    public int getSignalLevel() {
        if (isWifiConnected()) {
            return getWifiSignalLevel();
        } else {
            return getSimSignalLevel();
        }
    }


    public NetworkState getNetworkState() {
        if (mConnectivityManager != null && mTelephonyManager != null) {
            try {
                final NetworkInfo networkInfo = mConnectivityManager.getActiveNetworkInfo();
                if (networkInfo != null && networkInfo.getType() == ConnectivityManager.TYPE_WIFI) {
                    return NetworkState.NET_WIFI;
                }
                // networkInfo.getSubtype() Google也不建议使用了，后续可能需要更换新API，新API需要权限
                switch (networkInfo.getSubtype()) {
                    case TelephonyManager.NETWORK_TYPE_GPRS:
                    case TelephonyManager.NETWORK_TYPE_CDMA:
                    case TelephonyManager.NETWORK_TYPE_1xRTT:
                    case TelephonyManager.NETWORK_TYPE_EDGE:
                    case TelephonyManager.NETWORK_TYPE_IDEN:
                        return NetworkState.NET_2G;
                    case TelephonyManager.NETWORK_TYPE_UMTS:
                    case TelephonyManager.NETWORK_TYPE_EVDO_0:
                    case TelephonyManager.NETWORK_TYPE_EVDO_A:
                    case TelephonyManager.NETWORK_TYPE_EVDO_B:
                    case TelephonyManager.NETWORK_TYPE_EHRPD:
                    case TelephonyManager.NETWORK_TYPE_HSDPA:
                    case TelephonyManager.NETWORK_TYPE_HSUPA:
                    case TelephonyManager.NETWORK_TYPE_HSPA:
                    case TelephonyManager.NETWORK_TYPE_HSPAP:
                        return NetworkState.NET_3G;
                    case TelephonyManager.NETWORK_TYPE_LTE:
                        return NetworkState.NET_4G;
                    case TelephonyManager.NETWORK_TYPE_NR:
                        return NetworkState.NET_5G;
                }
            } catch (Exception ignored) {
            }
        }
        return NetworkState.NET_UNKNOWN;
    }

    public boolean isNetAvailable() {
        boolean connected = false;
        if (mConnectivityManager != null) {
            NetworkInfo networkInfo = mConnectivityManager.getActiveNetworkInfo();
            if (networkInfo != null && networkInfo.isAvailable() && networkInfo.isConnected()) { //网络状态为已连接
                connected = true;
            }
        }
        return connected;
    }

    public enum NetworkState {
        NET_UNKNOWN, NET_2G, NET_3G, NET_4G, NET_5G, NET_WIFI
    }


    /**
     * 保存接受状态变化的方法对象
     * AnnotationApplication
     * Created by anonyper on 2019/6/10.
     */
    public class NetWorkStateReceiverMethod {
        /**
         * 网络改变执行的方法
         */
        Method method;
        /**
         * 网络改变执行的方法所属的类
         */
        Object object;
        /**
         * 监听的网络改变类型
         */
        NetStateManager.NetworkState[] netWorkState = {NetStateManager.NetworkState.NET_UNKNOWN, NetStateManager.NetworkState.NET_WIFI, NetStateManager.NetworkState.NET_2G, NetStateManager.NetworkState.NET_3G, NetStateManager.NetworkState.NET_4G};

        public Method getMethod() {
            return method;
        }

        public void setMethod(Method method) {
            this.method = method;
        }

        public Object getObject() {
            return object;
        }

        public void setObject(Object object) {
            this.object = object;
        }

        public NetStateManager.NetworkState[] getNetWorkState() {
            return netWorkState;
        }

        public void setNetWorkState(NetStateManager.NetworkState[] netWorkState) {
            this.netWorkState = netWorkState;
        }
    }
}


