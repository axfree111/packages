@file:JvmName("WindowUtils")

package com.tools.module.common.utils

import android.app.Activity
import android.content.Context
import android.content.res.Configuration
import android.provider.Settings
import android.view.WindowManager
import androidx.fragment.app.Fragment

/**
 * ScreenUtils
 *
 * 
 * 
 */

/**
 * 保持屏幕常亮
 */
fun Fragment?.keepScreenOn() {
    this?.activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
}

/**
 * 移除屏幕常亮
 */
fun Fragment?.removeKeepScreenOn() {
    this?.activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
}

/**
 * 1.获取系统默认屏幕亮度值 屏幕亮度值范围（0-255）
 */
fun getScreenBrightness(context: Context): Int {
    val contentResolver = context.contentResolver
    val defVal = 125
    return Settings.System.getInt(contentResolver,
            Settings.System.SCREEN_BRIGHTNESS, defVal)
}

/**
 * 2.设置 APP界面屏幕亮度值方法
 */
fun setAppScreenBrightness(activity: Activity, brightnessValue: Int) {
    val window = activity.window
    val lp = window.attributes
    lp.screenBrightness = brightnessValue / 255.0f
    window.attributes = lp
}

fun isLandscape(activity: Activity): Boolean {
    return activity.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE;
}

