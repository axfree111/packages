package com.tools.module.common.utils;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;

/**
 * FormatUtils
 *
 * 
 * 
 */
public class FormatUtils {

    /**
     * 格式化当前时间
     *
     * @return HH:mm:ss
     */
    public static String formatTime() {
        return formatTime(System.currentTimeMillis());
    }

    /**
     * 格式化时间
     *
     * @return HH:mm:ss
     */
    public static String formatTime(Long timestamp) {
        if (timestamp != null) {
            final GregorianCalendar calendar = new GregorianCalendar();
            calendar.setTimeInMillis(timestamp);
            return padding2String(calendar.get(Calendar.HOUR_OF_DAY), '0', 2) + ":"
                    + padding2String(calendar.get(Calendar.MINUTE), '0', 2) + ":"
                    + padding2String(calendar.get(Calendar.SECOND), '0', 2);
        } else {
            return "N/A";
        }
    }

    /**
     * 格式化当前日期
     *
     * @return yyyyMMdd
     */
    public static String formatDate() {
        return formatDate(System.currentTimeMillis());
    }

    /**
     * 格式化日期
     *
     * @param timestamp 时间戳
     * @return yyyyMMdd
     */
    public static String formatDate(Long timestamp) {
        if (timestamp != null) {
            //直接用"yyyyMMdd"格式化偶现时间戳正确，但格式化输出日期错误，故换方案内部实现，下同。
            final Calendar calendar = GzDateUtils.INSTANCE.createCalendarInstance(null, timestamp);
            return padding2String(calendar.get(Calendar.YEAR), '0', 4)
                    + padding2String(calendar.get(Calendar.MONTH) + 1, '0', 2)
                    + padding2String(calendar.get(Calendar.DAY_OF_MONTH), '0', 2);
        } else {
            return "N/A";
        }
    }

    /**
     * 解析日期为时间戳
     *
     * @param date yyyyMMdd
     * @return 时间戳
     */
    public static long parseDate(String date, String timeZoneId) {
        try {
            date = date.replaceAll("[-/_]", "");
            int year = parseInteger(date.substring(0, 4), -1);
            int month = parseInteger(date.substring(4, 6), -1);
            int day = parseInteger(date.substring(6, 8), -1);
            if (year > 0 && month > 0 && day > 0) {
                final Calendar calendar = GzDateUtils.INSTANCE.createCalendarInstance(timeZoneId, null);
                calendar.set(Calendar.YEAR, year);
                calendar.set(Calendar.MONTH, month - 1);
                calendar.set(Calendar.DAY_OF_MONTH, day);
                return calendar.getTimeInMillis();
            }
        } catch (Exception ignored) {
        }
        return -1;
    }

    /**
     * 格式化当前日期+时间
     *
     * @return yyyy/MM/dd HH:mm:ss
     */
    public static String formatDateTime() {
        return formatDateTime(System.currentTimeMillis());
    }

    /**
     * 格式化日期+时间
     *
     * @param timestamp 时间戳
     * @return yyyy/MM/dd HH:mm:ss
     */
    public static String formatDateTime(Long timestamp) {
        if (timestamp != null && timestamp != 0L) {
            final GregorianCalendar calendar = new GregorianCalendar();
            calendar.setTimeInMillis(timestamp);
            return padding2String(calendar.get(Calendar.YEAR), '0', 4) + "/"
                    + padding2String(calendar.get(Calendar.MONTH) + 1, '0', 2) + "/"
                    + padding2String(calendar.get(Calendar.DAY_OF_MONTH), '0', 2) + " "
                    + padding2String(calendar.get(Calendar.HOUR_OF_DAY), '0', 2) + ":"
                    + padding2String(calendar.get(Calendar.MINUTE), '0', 2) + ":"
                    + padding2String(calendar.get(Calendar.SECOND), '0', 2);

        } else {
            return "N/A";
        }
    }

    /**
     * 格式化日期+时间，简略格式
     *
     * @param timestamp 时间戳
     * @return yyyyMMdd_HHmmss
     */
    public static String formatDateTimeBrief(Long timestamp) {
        if (timestamp != null) {
            final GregorianCalendar calendar = new GregorianCalendar();
            calendar.setTimeInMillis(timestamp);
            return padding2String(calendar.get(Calendar.YEAR), '0', 4)
                    + padding2String(calendar.get(Calendar.MONTH) + 1, '0', 2)
                    + padding2String(calendar.get(Calendar.DAY_OF_MONTH), '0', 2) + "_"
                    + padding2String(calendar.get(Calendar.HOUR_OF_DAY), '0', 2)
                    + padding2String(calendar.get(Calendar.MINUTE), '0', 2)
                    + padding2String(calendar.get(Calendar.SECOND), '0', 2);

        } else {
            return "N/A";
        }
    }

    /**
     * 解析简略格式的日期+时间为时间戳
     *
     * @param datetimeBrief yyyyMMdd_HHmmss
     * @return 时间戳
     */
    public static long parseDateTimeBrief(String datetimeBrief) {
        try {
            int year = parseInteger(datetimeBrief.substring(0, 4), -1);
            int month = parseInteger(datetimeBrief.substring(4, 6), -1);
            int day = parseInteger(datetimeBrief.substring(6, 8), -1);
            int hour = parseInteger(datetimeBrief.substring(9, 11), -1);
            int minute = parseInteger(datetimeBrief.substring(11, 13), -1);
            int second = parseInteger(datetimeBrief.substring(13, 15), -1);
            if (year > 0 && month > 0 && day > 0 && hour >= 0 && minute >= 0 && second >= 0) {
                final GregorianCalendar calendar = new GregorianCalendar();
                calendar.set(Calendar.YEAR, year);
                calendar.set(Calendar.MONTH, month - 1);
                calendar.set(Calendar.DAY_OF_MONTH, day);
                calendar.set(Calendar.HOUR_OF_DAY, hour);
                calendar.set(Calendar.MINUTE, minute);
                calendar.set(Calendar.SECOND, second);
                return calendar.getTimeInMillis();
            }
        } catch (Exception ignored) {
        }
        return -1;
    }

    /**
     * 格式化当前日期+时间，包含毫秒
     *
     * @return yyyy/MM/dd HH:mm:ss.SSS
     */
    public static String formatDateTimeMillis() {
        return formatDateTimeMillis(System.currentTimeMillis());
    }

    /**
     * 格式化日期+时间，包含毫秒
     *
     * @param timestamp 时间戳
     * @return yyyy/MM/dd HH:mm:ss.SSS
     */
    public static String formatDateTimeMillis(Long timestamp) {
        if (timestamp != null) {
            final GregorianCalendar calendar = new GregorianCalendar();
            calendar.setTimeInMillis(timestamp);
            return padding2String(calendar.get(Calendar.YEAR), '0', 4) + "/"
                    + padding2String(calendar.get(Calendar.MONTH) + 1, '0', 2) + "/"
                    + padding2String(calendar.get(Calendar.DAY_OF_MONTH), '0', 2) + " "
                    + padding2String(calendar.get(Calendar.HOUR_OF_DAY), '0', 2) + ":"
                    + padding2String(calendar.get(Calendar.MINUTE), '0', 2) + ":"
                    + padding2String(calendar.get(Calendar.SECOND), '0', 2) + "."
                    + padding2String(calendar.get(Calendar.MILLISECOND), '0', 3);

        } else {
            return "N/A";
        }
    }

    /**
     * 解析包含毫秒的日期+时间为时间戳
     *
     * @param dateTimeMillis yyyy/MM/dd HH:mm:ss.SSS
     * @return 时间戳
     */
    public static long parseDateTimeMillis(String dateTimeMillis) {
        try {
            int year = parseInteger(dateTimeMillis.substring(0, 4), -1);
            int month = parseInteger(dateTimeMillis.substring(5, 7), -1);
            int day = parseInteger(dateTimeMillis.substring(8, 10), -1);
            int hour = parseInteger(dateTimeMillis.substring(11, 13), -1);
            int minute = parseInteger(dateTimeMillis.substring(14, 16), -1);
            int second = parseInteger(dateTimeMillis.substring(17, 19), -1);
            int millis = parseInteger(dateTimeMillis.substring(20, 23), -1);
            if (year > 0 && month > 0 && day > 0 && hour >= 0 && minute >= 0 && second >= 0) {
                final GregorianCalendar calendar = new GregorianCalendar();
                calendar.set(Calendar.YEAR, year);
                calendar.set(Calendar.MONTH, month - 1);
                calendar.set(Calendar.DAY_OF_MONTH, day);
                calendar.set(Calendar.HOUR_OF_DAY, hour);
                calendar.set(Calendar.MINUTE, minute);
                calendar.set(Calendar.SECOND, second);
                calendar.set(Calendar.MILLISECOND, millis);
                return calendar.getTimeInMillis();
            }
        } catch (Exception ignored) {
        }
        return -1;
    }

    public static String formatDateTimeSelection(Long start, Long end) {
        if (start != null && end != null) {
            return "{"
                    + formatDateTime(start)
                    + ", "
                    + formatDateTime(end)
                    + "}";
        } else {
            return "{N/A}";
        }
    }


    /**
     * 格式化文件大小
     *
     * @param sizeInBytes 原始大小（单位：字节）
     * @param precision   小数点保留几位
     * @return 格式化大小，如3.23MB
     */
    public static String formatFileSize(long sizeInBytes, int precision) {
        if (sizeInBytes <= 0 || precision < 0) {
            return "" + sizeInBytes + "B";
        }

        final int carry = 1024;
        final String[] unit = {"B", "KB", "MB", "GB"};
        float finalSize = sizeInBytes;
        String finalUnit = "";

        for (int u = 0; u != unit.length; ++u) {
            if (finalSize < carry) {
                finalUnit = unit[u];
                break;
            } else {
                finalSize /= carry;
            }
        }

        return String.format(Locale.US, "%." + precision + "f" + finalUnit, finalSize);
    }


    public static int parseInteger(String str, int defaultValue) {
        if (str != null && str.length() > 0) {
            try {
                return Integer.parseInt(str);
            } catch (Exception ignored) {
            }
        }
        return defaultValue;
    }

    public static long parseLong(String str, long defaultValue) {
        if (str != null && str.length() > 0) {
            try {
                return Long.parseLong(str);
            } catch (Exception ignored) {
            }
        }
        return defaultValue;
    }

    public static float parseFloat(String str, float defaultValue) {
        if (str != null && str.length() > 0) {
            try {
                return Float.parseFloat(str);
            } catch (Exception ignored) {
            }
        }
        return defaultValue;
    }

    public static double parseDouble(String str, double defaultValue) {
        if (str != null && str.length() > 0) {
            try {
                return Double.parseDouble(str);
            } catch (Exception ignored) {
            }
        }
        return defaultValue;
    }


    /**
     * 转成string并补齐长度（比String.format效率高）
     *
     * @param object  原始对象
     * @param padding 补齐长度使用的字符
     * @param length  输出string长度
     * @return string
     */
    public static String padding2String(Object object, char padding, int length) {
        final String str = object instanceof String ? (String) object : String.valueOf(object);
        if (str.length() >= length) {
            return str;
        } else {
            StringBuilder sb = new StringBuilder();
            while (sb.length() < length - str.length()) {
                sb.append(padding);
            }
            sb.append(str);
            return sb.toString();
        }
    }

}
