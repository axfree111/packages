package com.tools.module.common.concurrent;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * CountDownLatchEx
 *
 */
public class CountDownLatchEx extends CountDownLatch {

    private volatile int mTotalCount = 0;
    private final AtomicInteger mSuccessCount = new AtomicInteger(0);

    /**
     * Constructs a {@code CountDownLatch} initialized with the given count.
     *
     * @param count the number of times {@link #countDown} must be invoked
     *              before threads can pass through {@link #await}
     * @throws IllegalArgumentException if {@code count} is negative
     */
    public CountDownLatchEx(int count) {
        super(count);
        mTotalCount = count;
    }

    public void cancel() {
        while (getCount() > 0) {
            super.countDown();
        }
    }

    @Override
    public void countDown() {
        mSuccessCount.addAndGet(1);
        super.countDown();
    }

    public int totalCount() {
        return mTotalCount;
    }

    public int successCount() {
        return mSuccessCount.get();
    }

}
