package com.tools.module.common.task

import io.reactivex.rxjava3.core.Observable
import io.reactivex.rxjava3.core.Single

/**
 * 任务的接口定义
 *
 * 
 * 
 */
interface ITask<Data> {

    var id: String
    var priority: Int
    var progress: Int
    var data: Data?

    var state: TaskState
    var error: Throwable?

    val autoStart: Boolean

    fun executable(): Boolean {
        return true
    }

    fun start(): Single<Boolean>

    fun stop(): Single<Boolean>

    fun pause(): Single<Boolean>

    fun resume(): Single<Boolean>

    fun destroy(): Single<Boolean>

    fun observerStateChanged(): Observable<TaskState>

    fun observerProgressChanged(): Observable<Int>

}