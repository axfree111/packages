package com.tools.module.common.task

/**
 * 任务状态机
 *
 * 
 * 
 */
enum class TaskState {

    /**
     * 空闲
     */
    IDLE,

    /**
     * 排队中
     */
    PENDING,
    /**
     * 正在执行
     */
    RUNNING,
    /**
     * 状态切换中
     */
    SWITCHING,

    /**
     * 已停止
     */
    STOPPED,
    /**
     * 已暂停
     */
    PAUSED,
    /**
     * 已完成
     */
    COMPLETED,
    /**
     * 已失败
     */
    FAILED,
    /**
     * 已销毁
     */
    DESTROYED,

}