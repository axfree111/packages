package com.tools.module.common.base;

/**
 * IConverter
 *
 */
public interface IConverter<FromType, ToType> {
    ToType convert(FromType data);
}
