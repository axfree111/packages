package com.tools.module.common;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;

import com.tools.module.common.base.ConfigProvider;
import com.tools.module.common.log.XLog;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.File;
import java.util.Map;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import kotlin.Deprecated;

/**
 * Created by Snser on 2017/5/14.
 */
@Deprecated(message = "请使用DataStore")
public class BasePrefs {
    private static final String TAG = "BasePrefs";

    private static final Gson GSON = new Gson();

    private static final Gson GSON1 = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();

    private static final String APPLICATION_ID = ContextStore.getApplicationId();
    private static final String PREFS_NAME_COMMON = APPLICATION_ID + ".common.prefs";
    private static final SharedPreferences PREFS_COMMON = getPrefsContext().getSharedPreferences(PREFS_NAME_COMMON, Context.MODE_PRIVATE);

    private static final String PREFS_NAME_STABLE = APPLICATION_ID + ".stable.prefs";
    private static ConfigProvider.Config sStableConfigInternal = new ConfigProvider.ConfigEmptyImpl();
    private static ConfigProvider.Config sStableConfigExternal = new ConfigProvider.ConfigEmptyImpl();
    private static ConfigProvider.Config sStableConfigMemory = new ConfigProvider.ConfigEmptyImpl();
    private static boolean sStablePrefsLoaded = false;

    public static Gson getExcludeFieldsWithoutExposeGson() {
        return GSON1;
    }


    public static Gson getGson() {
        return GSON;
    }

    @MethodMonitor("BasePrefs.init()")
    public static void init() {
        migrateSharedPreferences();
        initStablePrefs();
        initMemoryStablePrefs();
    }

    private static boolean initStablePrefs() {
        if (sStablePrefsLoaded) {
            return true;
        }
        if (BasePrefs.checkRequiredPermissions()) {
            //必须等到有外置sdcard权限时，再同时加载内置和外置的stable config，不要只加载一个，避免数据同步问题
            sStableConfigInternal = ConfigProvider.create(new File(getPrefsContext().getFilesDir(), PREFS_NAME_STABLE));
            sStableConfigExternal = ConfigProvider.create(new File(ContextStore.getExternalFilesDir(), PREFS_NAME_STABLE));
            Map<String, Object> configsInternal = sStableConfigInternal.getAll();
            Map<String, Object> configsExternal = sStableConfigExternal.getAll();
            XLog.i(TAG, "initStablePrefs configsInternal.size=" + configsInternal.size() + " configsExternal.size=" + configsExternal.size());
            if (configsInternal.size() != configsExternal.size()) {
                if (configsInternal.size() == 0) {
                    XLog.i(TAG, "initStablePrefs sync external to internal");
                    sStableConfigInternal.putAll(configsExternal);
                } else {
                    XLog.i(TAG, "initStablePrefs sync internal to external");
                    sStableConfigExternal.clear();
                    sStableConfigExternal.putAll(configsInternal);
                }
            }
            XLog.i(TAG, "initStablePrefs done");
            sStablePrefsLoaded = true;
            return true;
        } else {
            XLog.e(TAG, "initStablePrefs fail");
            return false;
        }
    }

    private static void initMemoryStablePrefs() {
        sStableConfigMemory = ConfigProvider.createMemory();
    }

    public static boolean checkRequiredPermissions() {
        final Context context = ContextStore.getContext();
        final String[] permissions = new String[]{
                Manifest.permission.WRITE_EXTERNAL_STORAGE
        };
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }

    public static boolean getBoolean(String key, boolean defValue) {
        return PREFS_COMMON.getBoolean(key, defValue);
    }

    public static void putBoolean(String key, boolean value) {
        PREFS_COMMON.edit().putBoolean(key, value).apply();
    }

    public static int getInt(String key, int defValue) {
        return PREFS_COMMON.getInt(key, defValue);
    }

    public static void putInt(String key, int value) {
        PREFS_COMMON.edit().putInt(key, value).apply();
    }

    public static long getLong(String key, long defValue) {
        return PREFS_COMMON.getLong(key, defValue);
    }

    public static void putLong(String key, long value) {
        PREFS_COMMON.edit().putLong(key, value).apply();
    }

    public static float getFloat(String key, float defValue) {
        return PREFS_COMMON.getFloat(key, defValue);
    }

    public static void putFloat(String key, float value) {
        PREFS_COMMON.edit().putFloat(key, value).apply();
    }

    public static String getString(String key, @Nullable String defValue) {
        return PREFS_COMMON.getString(key, defValue);
    }

    public static void putString(String key, @Nullable String value) {
        PREFS_COMMON.edit().putString(key, value).apply();
    }

    public static <T> T getObject(String key, @NonNull Class<T> clz) {
        T object = null;
        try {
            object = GSON.fromJson(PREFS_COMMON.getString(key, null), clz);
        } catch (Exception ignored) {
        }
        return object;
    }

    public static <T> void putObject(String key, @NonNull T value) {
        try {
            PREFS_COMMON.edit().putString(key, GSON.toJson(value)).apply();
        } catch (Exception ignored) {
        }
    }


    public static String getStable(String key, @Nullable String defValue) {
        initStablePrefs();
        return sStableConfigInternal.getString(key, defValue);
    }

    public static boolean putStable(String key, @Nullable String value) {
        if (initStablePrefs()) {
            sStableConfigInternal.putString(key, value);
            sStableConfigExternal.putString(key, value);
            return true;
        }
        return false;
    }

    public static void remove(String key) {
        PREFS_COMMON.edit().remove(key).apply();
    }

    public static String getMemoryString(String key) {
        return sStableConfigMemory.getString(key, null);
    }

    public static String getMemoryString(String key, @Nullable String defValue) {
        return sStableConfigMemory.getString(key, defValue);
    }

    public static boolean putMemoryString(String key, @Nullable String value) {
        sStableConfigMemory.putString(key, value);
        return false;
    }

    public static boolean getMemoryBoolean(String key) {
        return sStableConfigMemory.getBoolean(key, false);
    }

    public static boolean getMemoryBoolean(String key, boolean defValue) {
        return sStableConfigMemory.getBoolean(key, defValue);
    }

    public static boolean putMemoryBoolean(String key, boolean value) {
        sStableConfigMemory.putBoolean(key, value);
        return true;
    }

    public static int getMemoryInt(String key) {
        return sStableConfigMemory.getInt(key, 0);
    }

    public static int getMemoryInt(String key, int defValue) {
        return sStableConfigMemory.getInt(key, defValue);
    }

    public static boolean putMemoryInt(String key, int value) {
        sStableConfigMemory.putInt(key, value);
        return true;
    }

    public static long getMemoryLong(String key) {
        return sStableConfigMemory.getLong(key, 0);
    }

    public static long getMemoryLong(String key, long defValue) {
        return sStableConfigMemory.getLong(key, defValue);
    }

    public static boolean putMemoryLong(String key, long value) {
        sStableConfigMemory.putLong(key, value);
        return true;
    }

    public static void clearMemory() {
        sStableConfigMemory.clear();
    }

    private static Context getPrefsContext() {
        //Android N及以上版本中，需要用DeviceProtectedStorageContext创建SharedPreferences，能保证在设备开机解锁前/后均能访问prefs
        //普通方式创建的SharedPreferences，在设备解锁前取不到实际内容
        final Context context = ContextStore.getContext();
        final Context protectedContext = ContextCompat.createDeviceProtectedStorageContext(context);
        return protectedContext != null ? protectedContext : context;
    }

    /**
     * Move existing preferences file from credential protected storage to device protected storage.
     * This is used to migrate data between storage locations after an Android upgrade from
     * Build.VERSION < N to Build.VERSION >= N.
     */
    private static void migrateSharedPreferences() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            final Context context = ContextStore.getContext();
            final Context protectedContext = ContextCompat.createDeviceProtectedStorageContext(context);
            if (protectedContext != null) {
                protectedContext.moveSharedPreferencesFrom(context, PREFS_NAME_COMMON);
            }
        }
    }

}
