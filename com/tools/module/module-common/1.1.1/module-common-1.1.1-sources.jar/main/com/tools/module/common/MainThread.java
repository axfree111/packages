package com.tools.module.common;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;

/**
 * 主线程
 * Created by Snser on 2020/11/8.
 */

public class MainThread {

    private static final Handler MAIN_HANDLER = new Handler(Looper.getMainLooper());

    public static boolean ensureMainThread() {
        return MAIN_HANDLER.getLooper() == Looper.myLooper();
    }

    public static void run(Runnable runnable) {
        if (runnable != null) {
            if (ensureMainThread()) {
                runnable.run();
            } else {
                post(runnable);
            }
        }
    }

    public static void post(Runnable runnable) {
        postDelayed(null, runnable, 0);
    }

    public static void post(Integer what, Runnable runnable) {
        postDelayed(what, runnable, 0);
    }

    public static void postDelayed(Runnable runnable, long delayMillis) {
        postDelayed(null, runnable, delayMillis);
    }

    public static void postDelayed(Integer what, Runnable runnable, long delayMillis) {
        if (runnable != null && delayMillis >= 0) {
            final Message message = Message.obtain(MAIN_HANDLER, runnable);
            if (what != null) {
                message.what = what;
            }
            MAIN_HANDLER.sendMessageDelayed(message, delayMillis);
        }
    }

    public static void cancel(Runnable runnable) {
        if (runnable != null) {
            MAIN_HANDLER.removeCallbacks(runnable);
        }
    }

    public static void cancel(int what) {
        MAIN_HANDLER.removeMessages(what);
    }

    public static boolean hasMessages(int what) {
        return MAIN_HANDLER.hasMessages(what);
    }

}
