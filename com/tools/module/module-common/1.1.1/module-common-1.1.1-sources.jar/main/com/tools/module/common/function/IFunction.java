package com.tools.module.common.function;

/**
 * IFunction
 *
 * 
 * 
 */
public interface IFunction<T, R> {

    R apply(T value);

}
