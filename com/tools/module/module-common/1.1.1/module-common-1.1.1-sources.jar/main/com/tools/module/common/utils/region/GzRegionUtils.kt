package com.tools.module.common.utils.region

import java.util.Locale

/**
 * GzRegionUtils
 *
 * https://wiki.glazero.com/pages/viewpage.action?pageId=14489509
 *
 * 
 * 
 */
object GzRegionUtils {

    private fun isLanguageSupported(language: String?): Boolean {
        val regex = Regex("^(zh|en|fr|de|es|it|ja|pl).*")
        return language?.toLowerCase(Locale.ENGLISH)?.matches(regex) ?: false
    }

    /**
     * 获取封装的语言标识符。用于服务端、H5。
     */
    fun getLanguageTagBusiness(): String {
        val language = RegionUtils.getLanguageTag()
        when {
            language.startsWith("zh-Hant", true) -> {
                return "zh-Hant"
            }
            language.startsWith("zh", true) -> {
                return "zh"
            }
            language.startsWith("en-GB", true) -> {
                return "en-GB"
            }
            language.startsWith("en", true) -> {
                return "en"
            }
            language.startsWith("de", true) -> {
                return "de"
            }
            language.startsWith("it", true) -> {
                return "it"
            }
            language.startsWith("fr", true) -> {
                return "fr"
            }
            language.startsWith("es", true) -> {
                return "es"
            }
            language.startsWith("ja", true) -> {
                return "ja"
            }
            language.startsWith("pl", true) -> {
                return "pl"
            }
            else -> {
                return "en"
            }
        }
    }

    /**
     * 获取固件使用的语言标识符。用于固件TTS区分语言。
     */
    fun getLanguageTagFirmware(): String {
        val language = RegionUtils.getLanguageTag()
        when {
            language.startsWith("zh-Hant-HK", true) -> {
                return "hk"
            }
            language.startsWith("zh-Hant-MO", true) -> {
                return "mo"
            }
            language.startsWith("zh-Hant-TW", true) -> {
                return "tw"
            }
            language.startsWith("zh", true) -> {
                return "cn"
            }
            language.startsWith("en-GB", true) -> {
                return "uk"
            }
            language.startsWith("en", true) -> {
                return "us"
            }
            language.startsWith("de", true) -> {
                return "de"
            }
            language.startsWith("it", true) -> {
                return "it"
            }
            language.startsWith("fr", true) -> {
                return "fr"
            }
            language.startsWith("es", true) -> {
                return "es"
            }
            language.startsWith("ja", true) -> {
                return "jp"
            }
            language.startsWith("pl", true) -> {
                return "pl"
            }
            else -> {
                return "us"
            }
        }
    }

}