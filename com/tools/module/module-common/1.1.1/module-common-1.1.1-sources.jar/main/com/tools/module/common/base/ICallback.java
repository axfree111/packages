package com.tools.module.common.base;

/**
 * ICallback
 *
 */
public interface ICallback<Data> {

    void onSuccess(Data data);
    void onFail(Integer errorCode, String errorMsg);

    default void onFail(Integer errorCode, String errorMsg, Data data) {
        onFail(errorCode, errorMsg);
    }

}
