package com.tools.module.common.model

/**
 * Date: 2025/3/27
 * Desc:
 *
 * author: jaje
 */
object OperationType {
    /**
     * drone 查询无人机
     * monitor 查询设备
     * order 发送指令
     * heartbeat 心跳指令
     */
    const val DRONE: String = "drone"
    const val MONITOR: String = "monitor"
    const val ORDER: String = "order"
    const val HEARTBEAT: String = "heartbeat"
}