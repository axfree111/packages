package com.tools.module.common.utils;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Build;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.text.TextUtils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.concurrent.atomic.AtomicBoolean;

import androidx.annotation.VisibleForTesting;

@SuppressWarnings("WeakerAccess")
public class DeviceUtils {

    public interface CustomIdSupplier {
        String getCustomId();
    }

    private static final String IMEI = "imei_";
    private static final String VIRTUAL_DEVICE_ID = "virtual_device_id_";

    private static final AtomicBoolean sInitial = new AtomicBoolean(false);
    @SuppressLint("StaticFieldLeak")
    private static Context sContext;

    private static String sCachedDeviceId;
    private static CustomIdSupplier sCustomIdSupplier;

    public static void init(Context context) {
        init(context, true);
    }

    public static void init(Context context, boolean preload) {
        if (sInitial.getAndSet(true)) return;

        requireNonNull(context);

        sContext = context.getApplicationContext();
        sContext = sContext == null ? context : sContext;

        //预加载
        if (preload) {
            AsyncTask.THREAD_POOL_EXECUTOR.execute(() -> {
                getDeviceId(sContext);
            });
        }
    }

    /**
     * 设置自定义 device id 实现以替换现有逻辑
     *
     * @param supplier 自定义 id 提供者
     */
    public static synchronized void setCustomIdSupplier(CustomIdSupplier supplier) {
        sCustomIdSupplier = supplier;
    }

    /**
     * 无Context 调用，需要在之前调用init
     *
     * @return DeviceId
     */
    public static synchronized String getDeviceId() {
        if (!sInitial.get()) {
            throw new IllegalStateException("Init not called");
        }
        return getDeviceId(sContext);
    }

    @SuppressLint({"MissingPermission", "HardwareIds"})
    public static synchronized String getDeviceId(Context context) {
        requireNonNull(context);

        // step1 检查自定义实现
        if (sCustomIdSupplier != null) {
            return sCustomIdSupplier.getCustomId();
        }

        // step2 检查内存
        if (!TextUtils.isEmpty(sCachedDeviceId)) {
            return sCachedDeviceId;
        }

        // step3 检查sp
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        String spCache = sp.getString(IMEI, null);

        if (!TextUtils.isEmpty(spCache)) {
            sCachedDeviceId = spCache;
            return spCache;
        }

        String deviceId = null;

        // step4 ANDROID_ID
        if (TextUtils.isEmpty(deviceId)) {
            try {
                deviceId = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
            } catch (Exception ignore) {
            }
        }

        // step6 VirtualDeviceId
        if (TextUtils.isEmpty(deviceId)) {
            deviceId = getVirtualDeviceId(context);
        }

        sp.edit().putString(IMEI, deviceId).apply();
        sCachedDeviceId = deviceId;

        return deviceId;
    }

    @VisibleForTesting
    static boolean isValidDeviceId(String imei) {
        if (TextUtils.isEmpty(imei)) return false;
        if (imei.length() < 15) return false;

        boolean sameChar = true;
        for (int i = 0; i < imei.length() - 1; i++) {
            if (imei.charAt(i) != imei.charAt(i + 1)) {
                sameChar = false;
                break;
            }
        }

        return !sameChar;
    }

    private static String md5(String inputString) {
        try {
            MessageDigest digest = MessageDigest.getInstance("MD5");
            digest.update(inputString.getBytes());
            StringBuilder builder = new StringBuilder();
            byte[] digestData = digest.digest();
            for (byte b : digestData) {
                builder.append(Integer.toHexString(b >> 4 & 15).toLowerCase());
                builder.append(Integer.toHexString(b & 15).toLowerCase());
            }

            return builder.toString();
        } catch (NoSuchAlgorithmException e) {
            return null;
        }
    }

    private static String createVirtualDeviceId() {
        SecureRandom rand = new SecureRandom();
        String virtualDeviceId = md5(Build.BRAND + Build.MODEL + Build.FINGERPRINT
                + System.nanoTime() + rand.nextLong());

        if (!TextUtils.isEmpty(virtualDeviceId)) {
            return virtualDeviceId;
        } else {
            return "35"
                    + Build.BOARD.length() % 10
                    + Build.BRAND.length() % 10
                    + Build.CPU_ABI.length() % 10
                    + Build.DEVICE.length() % 10
                    + Build.DISPLAY.length() % 10
                    + Build.HOST.length() % 10
                    + Build.ID.length() % 10
                    + Build.MANUFACTURER.length() % 10
                    + Build.MODEL.length() % 10
                    + Build.PRODUCT.length() % 10
                    + Build.TAGS.length() % 10
                    + Build.TYPE.length() % 10
                    + Build.USER.length() % 10;
        }
    }

    /**
     * 获取虚拟设备ID
     * 虚拟设备ID要满足以下要求：
     * 1. 不能频繁变化
     * 2. 不同设备的虚拟设备ID不能重复
     *
     * @param context 当前上下文
     * @return 虚拟设备ID
     */
    private static String getVirtualDeviceId(Context context) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        String virtualImei = sp.getString(VIRTUAL_DEVICE_ID, null);
        if (TextUtils.isEmpty(virtualImei)) {
            virtualImei = createVirtualDeviceId();
            sp.edit().putString(VIRTUAL_DEVICE_ID, virtualImei).apply();
        }
        return virtualImei;
    }

    private static <T> T requireNonNull(T obj) {
        if (obj == null)
            throw new NullPointerException();
        return obj;
    }
}
