package com.tools.module.common.model

/**
 * Date: 2025/3/27
 * Desc:
 *
 * author: jaje
 */
object MidType {
    const val OTHER: Int = 0 // 其他
    const val POLICE: Int = 1 // 公安部
    const val DIPLOMACY: Int = 2 // 外交部
    const val RAILWAYS: Int = 3 // 铁道部
    const val LOCAL: Int = 4 // 本地
    const val SALES: Int = 5 // 自销
    const val HAINAN_TEQIN: Int = 6 // 海南特勤局
    const val HAINAN_ZAZD: Int = 7 // 海南省治安总队

}