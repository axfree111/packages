package com.tools.module.common.utils

import android.content.Context
import com.tools.module.common.MethodMonitor
import com.tools.module.common.log.XLog
import com.tools.module.common.utils.region.RegionUtils

/**
 * LocaleAssetLoader
 *
 * 
 * 
 */
object LocaleAssetLoader {

    private const val TAG = "LocaleAssetLoader"

    private var assetsList = listOf<String>()

    @MethodMonitor("LocaleAssetLoader.init()")
    fun init(context: Context) {
        this.assetsList = loadAssets(context)
    }

    private fun loadAssets(context: Context): List<String> {
        TimeRecorder.start("$TAG.loadAssets")
        // 友盟崩溃捕获，#9681575686011，特定机型某些用户偶现
        val assets = try {
            context.assets.list("")?.toList() ?: listOf()
        } catch (e: Exception) {
            listOf()
        }
        val duration = TimeRecorder.stop("$TAG.loadAssets")
        XLog.i(TAG, "loadAssets duration=${duration}ms")
        return assets
    }

    /**
     * 加载多语言版本的asset名称
     *
     * 原始的asset名称
     * 多语言版本的asset，需要在原始名称基础上，加上locale后缀，后缀规则同 res/values-xxx
     *
     * e.g.
     * 原始名称：lottie_guide_qrcode
     * assets文件夹中，包含 lottie_guide_qrcode、lottie_guide_qrcode@de、lottie_guide_qrcode@zh-rCN 三个多语言版本资源
     *
     * 接口调用时传原始名称，如：LocaleAssetLoader.load("lottie_guide_qrcode")
     *  - 手机为德语：   load方法返回lottie_guide_qrcode@de
     *  - 手机为简体中文：load方法返回lottie_guide_qrcode@zh-rCN
     *  - 手机为繁体中文：load方法返回lottie_guide_qrcode
     *  - 手机为其它语言：load方法返回lottie_guide_qrcode
     *
     * @param assetName 原始的 asset 名称
     * @return 多语言版本的 asset 名称
     */
    fun load(assetName: String): String {
        val resourceLocale = RegionUtils.getResourceLocale()
        val resourceLanguage = RegionUtils.getResourceLanguage()
        // 优先精准匹配语言+国家，例如：zh-rCN
        if (assetsList.contains("${assetName}@${resourceLocale}")) {
            XLog.d(TAG, "load $assetName -> ${assetName}@${resourceLocale}")
            return "${assetName}@${resourceLocale}"
        }
        // TODO 有些手机（OnePlus8）语言和区域可以分开设置，现在如果设置繁体+中国，系统显示英文，此方法返回中文
        // 其次仅匹配语言，例如：zh
        assetsList.forEach { assets->
            if (assets.startsWith("${assetName}@${resourceLanguage}")) {
                XLog.d(TAG, "load $assetName -> ${assetName}@${resourceLanguage}")
                return assets
            }
        }
        // 未匹配到多语言的资源，返回原始name
        return assetName
    }

}