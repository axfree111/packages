package com.tools.module.common.log.impl;

import com.tools.module.common.log.ILogger;
import com.tools.module.common.log.Level;
import com.tools.module.common.log.LogUtils;

import java.util.HashMap;
import java.util.Map;

/**
 * JavaConsoleLogger
 *
 * 
 * 
 */
public final class JavaConsoleLogger implements ILogger {

    private static final String STYLE_DEFAULT = "[0m";
    private static final Map<Level, String> STYLE_LOG = new HashMap<Level, String>(){{
        put(Level.DEBUG, "[36m");
        put(Level.INFO,  "[30m");
        put(Level.WARN,  "[33;1m");
        put(Level.ERROR, "[31;1m");
    }};

    private volatile Level mLevel = Level.DEBUG;

    public JavaConsoleLogger(Level level) {
        setLogLevel(level);
    }

    @Override
    public void setLogLevel(Level level) {
        if (level != null) {
            mLevel = level;
        }
    }

    @Override
    public void d(String tag, String msg) {
        log(Level.DEBUG, tag, msg, null);
    }

    @Override
    public void i(String tag, String msg) {
        log(Level.INFO, tag, msg, null);
    }

    @Override
    public void w(String tag, String msg) {
        log(Level.WARN, tag, msg, null);
    }

    @Override
    public void e(String tag, String msg) {
        log(Level.ERROR, tag, msg, null);
    }

    @Override
    public void e(String tag, String msg, Throwable tr) {
        log(Level.ERROR, tag, msg, tr);
    }

    private void log(Level level, String tag, String msg, Throwable tr) {
        if (level.getLevel() >= mLevel.getLevel()) {
            System.out.println("\033" + STYLE_LOG.get(level) + LogUtils.formatLog(level, tag, msg, tr) + "\033" + STYLE_DEFAULT);
        }
    }

}
