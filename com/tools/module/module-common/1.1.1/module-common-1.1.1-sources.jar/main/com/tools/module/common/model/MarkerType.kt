package com.tools.module.common.model

/**
 * Date: 2025/3/27
 * Desc:
 *
 *
 * author: jaje
 */
object MarkerType {
    const val DRONE: Int = 1
    const val SHIP: Int = 2
    const val AIRCRAFT: Int = 3
    const val VIDEO: Int = 4
    const val MONITOR: Int = 5
    const val SELECT_AREA: Int = 6
    const val DISTRICT_FENCE: Int = 7
}
