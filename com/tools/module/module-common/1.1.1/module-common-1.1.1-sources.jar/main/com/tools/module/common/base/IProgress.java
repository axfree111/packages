package com.tools.module.common.base;

/**
 * IProgress
 *
 */
public interface IProgress<Progress, Result> {

    void onStart();
    default void onProgress(Progress progress) {}
    void onCompleted(Result result);
    void onError(Integer errorCode, String errorMsg);

}
