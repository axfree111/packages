package com.tools.module.common.model

/**
 * Date: 2025/3/27
 * Desc:
 *
 * author: jaje
 */
object OrderRunType {
    /**
     * 执行计划
     * 0 - 立即执行
     * 1 - 延迟执行
     * 2 - 停止
     */
    const val NOW: Int = 1
    const val DELAY: Int = 2
    const val STOP: Int = 3
}