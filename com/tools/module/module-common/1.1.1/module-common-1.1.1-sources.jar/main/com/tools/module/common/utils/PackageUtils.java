package com.tools.module.common.utils;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.pm.Signature;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.TextUtils;

import java.io.File;
import java.security.MessageDigest;
import java.util.List;

public class PackageUtils {

    public static String getSelfVersion(Context context) {
        return getVersion(context, context.getPackageName());
    }

    public static String getVersion(Context context, String pkgname) {
        return getVersionName(context, pkgname) + "." + getVersionCode(context, pkgname);
    }

    public static String getSelfVersionName(Context context) {
        return getVersionName(context, context.getPackageName());
    }

    public static String getVersionName(Context context, String pkgname) {
        final PackageManager pm = context.getPackageManager();
        try {
            final PackageInfo packageInfo = pm.getPackageInfo(pkgname, 0);
            if (packageInfo != null) {
                return packageInfo.versionName;
            }
        } catch (Exception ignored) {
        }
        return "";
    }

    public static int getSelfVersionCode(Context context) {
        return getVersionCode(context, context.getPackageName());
    }

    public static int getVersionCode(Context context, String pkgname) {
        final PackageManager pm = context.getPackageManager();
        try {
            final PackageInfo packageInfo = pm.getPackageInfo(pkgname, 0);
            if (packageInfo != null) {
                return packageInfo.versionCode;
            }
        } catch (Exception ignored) {
        }
        return 0;
    }

    public static String getSelfLabel(Context context) {
        return getLabel(context, context.getPackageName());
    }

    public static String getLabel(Context context, String pkgname) {
        final PackageManager pm = context.getPackageManager();
        try {
            final PackageInfo packageInfo = pm.getPackageInfo(pkgname, 0);
            if (packageInfo != null && packageInfo.applicationInfo != null) {
                return packageInfo.applicationInfo.loadLabel(pm).toString();
            }
        } catch (Exception ignored) {
        }
        return "";
    }

    public static Drawable getSelfIcon(Context context) {
        return getIcon(context, context.getPackageName());
    }

    public static Drawable getIcon(Context context, String pkgname) {
        final PackageManager pm = context.getPackageManager();
        try {
            final PackageInfo packageInfo = pm.getPackageInfo(pkgname, 0);
            if (packageInfo != null && packageInfo.applicationInfo != null) {
                //deep copy, loadIcon always return same instance
                return ImageUtils.clone(context, packageInfo.applicationInfo.loadIcon(pm));
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    public static File getSelfApkInstallFile(Context context) {
        return getApkInstallFile(context, context.getPackageName());
    }

    public static File getApkInstallFile(Context context, String pkgname) {
        final PackageManager pm = context.getPackageManager();
        try {
            final PackageInfo packageInfo = pm.getPackageInfo(pkgname, 0);
            if (packageInfo != null && packageInfo.applicationInfo != null) {
                return new File(packageInfo.applicationInfo.sourceDir);
            }
        } catch (Exception ignored) {
        }
        return null;
    }



    public static ProviderInfo getSelfContentProvider(Context context, String name) {
        return getContentProvider(context, context.getPackageName(), name);
    }

    public static ProviderInfo getContentProvider(Context context, String pkgname, String name) {
        final PackageManager pm = context.getPackageManager();
        try {
            List<ProviderInfo> providerInfos = pm.queryContentProviders(pkgname, android.os.Process.myUid(), 0);
            if (providerInfos != null) {
                for (ProviderInfo providerInfo : providerInfos) {
                    if (TextUtils.equals(providerInfo.name, name)) {
                        return providerInfo;
                    }
                }
            }
        } catch (Exception ignored) {
        }
        return null;
    }



    public static String getSelfSignatureMD5(Context context) {
        return getSignatureMD5(context, context.getPackageName());
    }

    @SuppressLint("PackageManagerGetSignatures")
    public static String getSignatureMD5(Context context, String pkgname) {
        final PackageManager pm = context.getPackageManager();
        try {
            final PackageInfo packageInfo = pm.getPackageInfo(pkgname, PackageManager.GET_SIGNATURES);
            if (packageInfo != null && packageInfo.signatures != null && packageInfo.signatures.length > 0) {
                return getSignature(packageInfo.signatures[0], "MD5");
            }
        } catch (Exception ignored) {
        }
        return "";
    }

    public static String getSelfSignatureSHA1(Context context) {
        return getSignatureSHA1(context, context.getPackageName());
    }

    @SuppressLint("PackageManagerGetSignatures")
    public static String getSignatureSHA1(Context context, String pkgname) {
        final PackageManager pm = context.getPackageManager();
        try {
            final PackageInfo packageInfo = pm.getPackageInfo(pkgname, PackageManager.GET_SIGNATURES);
            if (packageInfo != null && packageInfo.signatures != null && packageInfo.signatures.length > 0) {
                return getSignature(packageInfo.signatures[0], "SHA1");
            }
        } catch (Exception ignored) {
        }
        return "";
    }

    private static String getSignature(Signature signature, String digestAlgorithm) {
        try {
            byte[] bytes = signature != null ? signature.toByteArray() : null;
            if (bytes != null && bytes.length > 0) {
                MessageDigest digest = MessageDigest.getInstance(digestAlgorithm);
                if (digest != null) {
                    return HexUtils.bytesToHex(digest.digest(bytes));
                }
            }
        } catch (Exception ignored) {
        }
        return "";
    }



    public static Bundle getSelfMetaData(Context context) {
        return getMetaData(context, context.getPackageName());
    }

    public static Bundle getMetaData(Context context, String pkgname) {
        try {
            final Bundle metaData = context.getPackageManager().getApplicationInfo(
                    pkgname, PackageManager.GET_META_DATA
            ).metaData;
            if (metaData != null) {
                return metaData;
            }
        } catch (Exception ignored) {
        }
        return new Bundle();
    }

}
