package com.tools.module.common.task

import com.tools.module.common.ext.subscribeX
import com.tools.module.common.log.XLog
import io.reactivex.rxjava3.core.Observable
import io.reactivex.rxjava3.core.Single
import io.reactivex.rxjava3.disposables.Disposable
import io.reactivex.rxjava3.subjects.PublishSubject
import io.reactivex.rxjava3.subjects.Subject
import java.util.concurrent.ExecutorService

/**
 * BaseTask，负责管理状态机，业务层的Task需继承自BaseTask
 *
 */
abstract class BaseTask<Data>: ITask<Data>, Runnable {

    companion object {
        const val TAG = "BaseTask"
    }

    private val subjectState: Subject<TaskState> = PublishSubject.create()
    private val subjectProgress: Subject<Int> = PublishSubject.create()

    @Volatile
    override var progress: Int = 0
        set(value) {
            XLog.i(TAG, "task $id update progress $field -> $value")
            if (field != value) {
                field = value
                subjectProgress.onNext(field)
            }
        }

    @Volatile
    override var state: TaskState = TaskState.IDLE
        set(value) {
            XLog.i(TAG, "task $id update state $field -> $value")
            if (field != value) {
                field = value
                subjectState.onNext(field)
            }
            if (field != TaskState.FAILED) {
                error = null
            }
        }

    @Volatile
    override var error: Throwable? = null

    private var runningDisposable: Disposable? = null



    internal fun execute(executor: ExecutorService) {
        // 先更新状态，避免重复submit
        state = TaskState.SWITCHING
        // 然后放到线程池中执行
        executor.submit(this)
    }

    final override fun run() {
        XLog.i(TAG, "task $id real start")
        handleTaskRealStart().doOnSubscribe {
            runningDisposable = it
            state = TaskState.RUNNING
        }.doOnNext {
            if (state == TaskState.RUNNING && it in 0..100) {
                progress = it
            }
        }.doOnComplete {
            state = TaskState.COMPLETED
        }.doOnError {
            XLog.w(TAG, "task $id real start failed, error=$it")
            state = TaskState.FAILED
            error = it
        }.subscribeX()
    }

    final override fun start(): Single<Boolean> {
        XLog.i(TAG, "task $id pending start")
        /**
         * start只是切换task状态，task会排队执行
         * 实际任务的执行处理，应当在handleTaskExecute回调中进行
         */
        if (state != TaskState.IDLE && state != TaskState.STOPPED) {
            XLog.w(TAG, "task $id pending start failed, invalid state=$state")
            return Single.error(IllegalStateException("task $id pending start failed, invalid state=$state"))
        }
        return handleTaskPendingStart().doOnSubscribe {
            state = TaskState.SWITCHING
        }.doOnSuccess {
            state = TaskState.PENDING
        }.doOnError {
            XLog.e(TAG, "task $id start failed, error=$it", it)
            state = TaskState.FAILED
            error = it
        }
    }

    final override fun stop(): Single<Boolean> {
        XLog.i(TAG, "task $id stop")
        if (state != TaskState.RUNNING) {
            XLog.w(TAG, "task $id stop failed, invalid state=$state")
            return Single.error(IllegalStateException("task $id stop failed, invalid state=$state"))
        }
        return handleTaskStop().doOnSubscribe {
            // 释放资源，避免run()走到timeout error
            runningDisposable?.dispose()
            state = TaskState.SWITCHING
        }.doOnSuccess {
            state = TaskState.STOPPED
            progress = 0
        }.doOnError {
            XLog.e(TAG, "task $id stop failed, error=$it", it)
            state = TaskState.FAILED
            error = it
        }
    }

    final override fun pause(): Single<Boolean> {
        XLog.i(TAG, "task $id pause")
        if (state != TaskState.RUNNING) {
            XLog.w(TAG, "task $id pause, invalid state=$state")
            return Single.error(IllegalStateException("task $id pause failed, invalid state=$state"))
        }
        return handleTaskPause().doOnSubscribe {
            // 释放资源，避免run()走到timeout error
            runningDisposable?.dispose()
            state = TaskState.SWITCHING
        }.doOnSuccess {
            state = TaskState.PAUSED
        }.doOnError {
            XLog.e(TAG, "task $id pause failed, error=$it", it)
            state = TaskState.FAILED
            error = it
        }
    }

    final override fun resume(): Single<Boolean> {
        XLog.i(TAG, "task $id resume")
        if (state != TaskState.PAUSED) {
            XLog.w(TAG, "task $id resume failed, invalid state=$state")
            return Single.error(IllegalStateException("task $id resume failed, invalid state=$state"))
        }
        return handleTaskResume().doOnSubscribe {
            state = TaskState.SWITCHING
        }.doOnSuccess {
            state = TaskState.PENDING
        }.doOnError {
            XLog.e(TAG, "task $id resume failed, error=$it", it)
            state = TaskState.FAILED
            error = it
        }
    }

    final override fun destroy(): Single<Boolean> {
        XLog.i(TAG, "task $id destroy")
        return handleTaskDestroy().doFinally {
            runningDisposable?.dispose()
        }
    }



    override fun observerStateChanged(): Observable<TaskState> {
        return subjectState.toSerialized()
    }

    override fun observerProgressChanged(): Observable<Int> {
        return subjectProgress.toSerialized()
    }



    /**
     * 任务开始、添加到队列
     */
    protected abstract fun handleTaskPendingStart(): Single<Boolean>

    /**
     * 任务实际执行
     *
     * @return Observable<Int> 进度回调
     */
    protected abstract fun handleTaskRealStart(): Observable<Int>

    /**
     * 任务停止
     */
    protected abstract fun handleTaskStop(): Single<Boolean>

    /**
     * 任务暂停
     */
    protected abstract fun handleTaskPause(): Single<Boolean>

    /**
     * 任务恢复
     */
    protected abstract fun handleTaskResume(): Single<Boolean>

    /**
     * 任务销毁
     */
    protected abstract fun handleTaskDestroy(): Single<Boolean>

}