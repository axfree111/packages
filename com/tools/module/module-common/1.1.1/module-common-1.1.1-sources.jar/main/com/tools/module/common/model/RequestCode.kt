package com.tools.module.common.model

/**
 * Date: 2025/3/27
 * Desc:
 *
 * author: jaje
 */
object RequestCode {
    const val GOOGLE_AUTO_SELECT_PLACE: Int = 4 //跳转到google位置选择
}