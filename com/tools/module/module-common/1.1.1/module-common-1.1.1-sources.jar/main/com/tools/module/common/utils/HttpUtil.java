package com.tools.module.common.utils;

import android.net.Uri;

import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/**
 * HttpUtil
 *
 * 
 * 
 */
public class HttpUtil {

    public static String urlEncode(CharSequence url) {
        return urlEncode(url != null ? url.toString() : null);
    }

    public static String urlEncode(String url) {
        try {
            return URLEncoder.encode(url, StandardCharsets.UTF_8.name()).replaceAll("\\+", "%20");
        } catch (Exception ignored) {
        }
        return url;
    }

    public static String urlDecode(CharSequence url) {
        return urlDecode(url != null ? url.toString() : null);
    }

    public static String urlDecode(String url) {
        try {
            return URLDecoder.decode(url, StandardCharsets.UTF_8.name());
        } catch (Exception ignored) {
        }
        return url;
    }

    public static Map<String, String> getQueryParams(String url) {
        final Map<String, String> params = new HashMap<>();
        try {
            final Uri uri = Uri.parse(url);
            for (String key : uri.getQueryParameterNames()) {
                params.put(key, uri.getQueryParameter(key));
            }
        } catch (Exception ignored) {
        }
        return params;
    }

}
