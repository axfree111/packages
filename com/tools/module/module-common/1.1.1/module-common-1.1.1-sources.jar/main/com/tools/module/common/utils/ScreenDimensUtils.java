package com.tools.module.common.utils;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Display;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;

import com.tools.module.common.ContextStore;

import java.lang.reflect.Field;

public class ScreenDimensUtils {

    /**
     * QVGA, 320*240
     */
    public static final int QVGA = 1;

    /**
     * HVGA, 480*320
     */
    public static final int HVGA = 2;

    /**
     * WVGA, 800*480
     */
    public static final int WVGA = 3;

    /**
     * WXXVGA,
     */
    public static final int WXXVGA = 4;

    public static final int DENSITY_LOW = 120;
    public static final int DENSITY_MEDIUM = 160;
    public static final int DENSITY_TV = 213;
    public static final int DENSITY_HIGH = 240;
    public static final int DENSITY_XHIGH = 320;
    public static final int DENSITY_XXHIGH = 480;

    /**
     * 返回屏幕类型
     *
     * @param context
     * @return
     */
    public static final int getScreenType(final Context context) {
        final DisplayMetrics dm = context.getResources().getDisplayMetrics();
        final int w = dm.widthPixels;
        final int h = dm.heightPixels;
        final int max = w > h ? w : h;
        if (max <= 320) {
            return QVGA;
        }
        if (max <= 480) {
            return HVGA;
        }
        if (max < 1024) {
            return WVGA;
        }
        return WXXVGA;
    }

    public static int[] getDisplayDimension(Context context) {
        Display display = ScreenDimensUtils.getDefaultDisplay(context);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        display.getRealMetrics(displayMetrics);
        boolean isPortrait = displayMetrics.widthPixels < displayMetrics.heightPixels;
        final int width = isPortrait ? displayMetrics.widthPixels : displayMetrics.heightPixels;
        final int height = isPortrait ? displayMetrics.heightPixels : displayMetrics.widthPixels;
        return new int[]{width, height};
    }

    public static int getScreenShortAxisWidth(Context context) {
        Display display = ScreenDimensUtils.getDefaultDisplay(context);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        display.getRealMetrics(displayMetrics);
        return Math.min(displayMetrics.widthPixels, displayMetrics.heightPixels);
    }

    public static int getScreenLongAxisWidth(Context context) {
        Display display = ScreenDimensUtils.getDefaultDisplay(context);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        display.getRealMetrics(displayMetrics);
        return Math.max(displayMetrics.widthPixels, displayMetrics.heightPixels);
    }

    public static int getScreenWidth(Context context) {
        Display display = ScreenDimensUtils.getDefaultDisplay(context);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        display.getRealMetrics(displayMetrics);
        return displayMetrics.widthPixels;
    }

    public static int getScreenHeight(Context context) {
        Display display = ScreenDimensUtils.getDefaultDisplay(context);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        display.getRealMetrics(displayMetrics);
        return displayMetrics.heightPixels;
    }

    private static int sScreenRealShortAxis = -1;
    private static int sScreenRealLongAxis = -1;
    private static int sScreenRealWidth = -1;
    private static int sScreenRealHeight = -1;
    private static int sReflectStatusBarHeight = -1;

    public static int getScreenRealWidth(Context context) {
        if (sScreenRealWidth < 0) {
            if (sScreenRealShortAxis < 0 || sScreenRealLongAxis < 0) {
                initScreenRealAxis(context);
            }
            sScreenRealWidth = isPortrait(context) ? sScreenRealShortAxis : sScreenRealLongAxis;
        }
        return sScreenRealWidth;
    }

    public static int getScreenRealHeight(Context context) {
        if (sScreenRealHeight < 0) {
            if (sScreenRealShortAxis < 0 || sScreenRealLongAxis < 0) {
                initScreenRealAxis(context);
            }
            sScreenRealHeight = isPortrait(context) ? sScreenRealLongAxis : sScreenRealShortAxis;
        }
        return sScreenRealHeight;
    }

    private static void initScreenRealAxis(Context context) {
        int shortAxis = -1, longAxis = -1;
        Display display = ScreenDimensUtils.getDefaultDisplay(context);

        try {
            if (Build.VERSION.SDK_INT == 13) {
                shortAxis = ReflectUtils.invokeDeclaredMethodReturnInt(Display.class, display, "getRealWidth", -1);
                longAxis = ReflectUtils.invokeDeclaredMethodReturnInt(Display.class, display, "getRealHeight", -1);
            } else if (Build.VERSION.SDK_INT > 16) {
                final DisplayMetrics metrics = new DisplayMetrics();
                ReflectUtils.invokeDeclaredMethodReturnObject(Display.class, display, "getRealMetrics", metrics);
                shortAxis = metrics.widthPixels;
                longAxis = metrics.heightPixels;
            } else if (Build.VERSION.SDK_INT > 13) {
                shortAxis = ReflectUtils.invokeDeclaredMethodReturnInt(Display.class, display, "getRawWidth", -1);
                longAxis = ReflectUtils.invokeDeclaredMethodReturnInt(Display.class, display, "getRawHeight", -1);
            }
        } catch (Exception e) {
            // ignore
        }

        if (shortAxis <= 0) {
            shortAxis = display.getWidth();
        }

        if (longAxis <= 0) {
            longAxis = display.getHeight();
        }

        sScreenRealShortAxis = Math.min(shortAxis, longAxis);
        sScreenRealLongAxis = Math.max(shortAxis, longAxis);
    }

    public static int getScreenDensity(Context context) {
        DisplayMetrics metric = new DisplayMetrics();
        Display display = ScreenDimensUtils.getDefaultDisplay(context);
        display.getMetrics(metric);
        return metric.densityDpi;
    }

    private static Display mDisplay = null;

    public static Display getDefaultDisplay(Context context) {
        if (mDisplay == null) {
            if (context != null) {
                mDisplay = ((WindowManager) context.getApplicationContext().getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
            } else {
                mDisplay = ((WindowManager) ContextStore.getContext().getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
            }
        }

        return mDisplay;
    }

    public static boolean isFullScreen(Activity activity) {
        return (activity.getWindow().getAttributes().flags & WindowManager.LayoutParams.FLAG_FULLSCREEN) != 0;
    }

    private static int sScreenWidthPixels = -1;

    private static int sScreenHeightPixels = -1;

    private static DisplayMetrics mDisplayMetrics;

    public static int getScreenWidthPixels(Context context) {
        if (sScreenWidthPixels < 0) {
            initScreenPixels(context);
        }

        return sScreenWidthPixels;
    }

    public static int getScreenHeightPixels(Context context) {
        if (sScreenHeightPixels < 0) {
            initScreenPixels(context);
        }

        return sScreenHeightPixels;
    }

    private static void initScreenPixels(Context context) {
        if (mDisplayMetrics == null) {
            mDisplayMetrics = new DisplayMetrics();
        }

        ((WindowManager) context.getApplicationContext().getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getMetrics(mDisplayMetrics);
        sScreenWidthPixels = mDisplayMetrics.widthPixels;
        sScreenHeightPixels = mDisplayMetrics.heightPixels;
    }

    private static boolean isPortrait(Context context) {
        return isPortrait(context.getResources().getConfiguration());
    }

    private static boolean isPortrait(Configuration newConfig) {
        if (newConfig != null && newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            return false;
        }
        return true;
    }

    public static int getStatusBarHeightByReflect(Context context) {
        if (sReflectStatusBarHeight < 0) {
            try {
                Class<?> c = Class.forName("com.android.internal.R$dimen");
                Object obj = c.newInstance();
                Field field = c.getField("status_bar_height");
                int x = Integer.parseInt(field.get(obj).toString());
                sReflectStatusBarHeight = context.getResources().getDimensionPixelSize(x);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        //如果反射没取到，则使用默认值
        if (sReflectStatusBarHeight < 0) {
            sReflectStatusBarHeight = ScreenDimensUtils.dip2px(context, 25);
        }
        return sReflectStatusBarHeight;
    }

    public static void onConfigurationChanged() {

        sScreenRealWidth = -1;
        sScreenRealHeight = -1;

        sScreenRealShortAxis = -1;
        sScreenRealLongAxis = -1;

        sScreenWidthPixels = -1;
        sScreenHeightPixels = -1;

        sReflectStatusBarHeight = -1;

        mDisplay = null;
    }

    /**
     * Get the current nav bar height
     *
     * @param context current context
     * @return The current nav bar height in dps
     */
    public static int getNavBarHeight(final Context context) {
        int navBarHeight;

        try {
            /* TODO Identify or request robust APIs to obtain the nav bar height */
            final Resources resources = context.getResources();
            navBarHeight = resources.getDimensionPixelSize(
                    resources.getIdentifier("navigation_bar_height", "dimen", "android"));
        } catch (Resources.NotFoundException e) {
            navBarHeight = 0;
        }

        return navBarHeight;
    }

    /**
     * 判断是否存在NavigationBar
     * @param context
     * @return
     */
    public static boolean hasNavigationBar(Context context) {
        if (getStatusBarHeight(context) + getScreenHeight(context) < getScreenRealHeight(context)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Get the current status bar height
     *
     * @param context current context
     * @return The current status bar height in dps
     */
    public static int getStatusBarHeight(final Context context) {
        int statusBarHeight;
        try {
            /* TODO Identify or request robust APIs to obtain the status bar height */
            final Resources resources = context.getResources();
            statusBarHeight = resources.getDimensionPixelSize(
                    resources.getIdentifier("status_bar_height", "dimen", "android"));
        } catch (Resources.NotFoundException e) {
            statusBarHeight = 0;
        }

        return statusBarHeight;
    }

    public static int getActionBarSize(Context context) {
        int actionBarSize = dip2px(context, 44);
        final TypedValue typedValue = new TypedValue();
        if (context.getTheme().resolveAttribute(android.R.attr.actionBarSize, typedValue, true)) {
            actionBarSize = TypedValue.complexToDimensionPixelSize(typedValue.data, context.getResources().getDisplayMetrics());
        }
        return actionBarSize;
    }

    public static int getInputMethodVisibleHeight(Context context) {
        int height = 0;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            final InputMethodManager inputMethodManager = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
            height = ReflectUtils.invokeMethodReturnInt(
                    InputMethodManager.class, inputMethodManager, "getInputMethodWindowVisibleHeight", 0);
        }
        return height;
    }

    public static int dip2px(Context context, float dpValue) {
        float density = context.getResources().getDisplayMetrics().density;
        return (int) (dpValue * density + 0.5f);
    }

    private static String getResNameById(Context context, int id) {
        try {
            return context.getResources().getResourceEntryName(id);
        } catch (Exception ignore) {
            return "";
        }
    }

}