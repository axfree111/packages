package com.tools.module.common.utils;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class ReflectUtils {

    public static Class<?> getClass(String className) {
        try {
            return Class.forName(className);
        } catch (Exception ignored) {
        }
        return null;
    }



    public static boolean getBooleanField(Class<?> cls, Object object, String field, boolean defaultValue) {
        boolean ret = defaultValue;
        try {
            ret = cls.getField(field).getBoolean(object);
        } catch (Exception ignored) {
        }
        return ret;
    }

    public static boolean getBooleanDeclaredField(Class<?> cls, Object object, String field, boolean defaultValue) {
        boolean ret = defaultValue;
        try {
            Field declaredField = cls.getDeclaredField(field);
            declaredField.setAccessible(true);
            ret = declaredField.getBoolean(object);
        } catch (Exception ignored) {
        }
        return ret;
    }

    public static void setBooleanField(Class<?> cls, Object object, String field, boolean value) {
        try {
            cls.getField(field).setBoolean(object, value);
        } catch (Exception ignored) {
        }
    }

    public static void setBooleanDeclaredField(Class<?> cls, Object object, String field, boolean value) {
        try {
            Field declaredField = cls.getDeclaredField(field);
            declaredField.setAccessible(true);
            declaredField.setBoolean(object, value);
        } catch (Exception ignored) {
        }
    }



    public static int getIntField(Class<?> cls, Object object, String field, int defaultValue) {
        int ret = defaultValue;
        try {
            ret = cls.getField(field).getInt(object);
        } catch (Exception ignored) {
        }
        return ret;
    }

    public static int getIntDeclaredField(Class<?> cls, Object object, String field, int defaultValue) {
        int ret = defaultValue;
        try {
            Field declaredField = cls.getDeclaredField(field);
            declaredField.setAccessible(true);
            ret = declaredField.getInt(object);
        } catch (Exception ignored) {
        }
        return ret;
    }

    public static void setIntField(Class<?> cls, Object object, String field, int value) {
        try {
            cls.getField(field).setInt(object, value);
        } catch (Exception ignored) {
        }
    }

    public static void setIntDeclaredField(Class<?> cls, Object object, String field, int value) {
        try {
            Field declaredField = cls.getDeclaredField(field);
            declaredField.setAccessible(true);
            declaredField.setInt(object, value);
        } catch (Exception ignored) {
        }
    }



    public static long getLongField(Class<?> cls, Object object, String field, long defaultValue) {
        long ret = defaultValue;
        try {
            ret = cls.getField(field).getLong(object);
        } catch (Exception ignored) {
        }
        return ret;
    }

    public static long getLongDeclaredField(Class<?> cls, Object object, String field, long defaultValue) {
        long ret = defaultValue;
        try {
            Field declaredField = cls.getDeclaredField(field);
            declaredField.setAccessible(true);
            ret = declaredField.getLong(object);
        } catch (Exception ignored) {
        }
        return ret;
    }

    public static void setLongField(Class<?> cls, Object object, String field, long value) {
        try {
            cls.getField(field).setLong(object, value);
        } catch (Exception ignored) {
        }
    }

    public static void setLongDeclaredField(Class<?> cls, Object object, String field, long value) {
        try {
            Field declaredField = cls.getDeclaredField(field);
            declaredField.setAccessible(true);
            declaredField.setLong(object, value);
        } catch (Exception ignored) {
        }
    }



    public static String getStringField(Class<?> cls, Object object, String field, String defaultValue) {
        String ret = defaultValue;
        try {
            ret = (String)cls.getField(field).get(object);
        } catch (Exception ignored) {
        }
        return ret;
    }

    public static String getStringDeclaredField(Class<?> cls, Object object, String field, String defaultValue) {
        String ret = defaultValue;
        try {
            Field declaredField = cls.getDeclaredField(field);
            declaredField.setAccessible(true);
            ret = (String)declaredField.get(object);
        } catch (Exception ignored) {
        }
        return ret;
    }

    public static void setStringField(Class<?> cls, Object object, String field, String value) {
        try {
            cls.getField(field).set(object, value);
        } catch (Exception ignored) {
        }
    }

    public static void setStringDeclaredField(Class<?> cls, Object object, String field, String value) {
        try {
            Field declaredField = cls.getDeclaredField(field);
            declaredField.setAccessible(true);
            declaredField.set(object, value);
        } catch (Exception ignored) {
        }
    }



    public static Object getObjectField(Class<?> cls, Object object, String field) {
        Object ret = null;
        try {
            ret = cls.getField(field).get(object);
        } catch (Exception ignored) {
        }
        return ret;
    }

    public static Object getObjectDeclaredField(Class<?> cls, Object object, String field) {
        Object ret = null;
        try {
            Field declaredField = cls.getDeclaredField(field);
            declaredField.setAccessible(true);
            ret = declaredField.get(object);
        } catch (Exception ignored) {
        }
        return ret;
    }

    public static void setObjectField(Class<?> cls, Object object, String field, Object value) {
        try {
            cls.getField(field).set(object, value);
        } catch (Exception ignored) {
        }
    }

    public static void setObjectDeclaredField(Class<?> cls, Object object, String field, Object value) {
        try {
            Field declaredField = cls.getDeclaredField(field);
            declaredField.setAccessible(true);
            declaredField.set(object, value);
        } catch (Exception ignored) {
        }
    }



    private static Class<?>[] autoParseClasses(Object... objs) {
        Class<?>[] classes = null;
        if (objs != null && objs.length > 0) {
            final int nObj = objs.length;
            classes = new Class<?>[objs.length];
            if (nObj > 0) {
                for (int c = 0; c != nObj; ++c) {
                    Object obj = objs[c];
                    if (obj != null) {
                        Class<?> cls = obj.getClass();
                        //强制处理一下基本数据类型
                        if (cls == Boolean.class) {
                            classes[c] = boolean.class;
                        } else if (cls == Integer.class) {
                            classes[c] = int.class;
                        } else if (cls == Long.class) {
                            classes[c] = long.class;
                        } else {
                            classes[c] = cls;
                        }
                    } else {
                        classes[c] = Object.class;
                    }
                }
            }
        }
        return classes;
    }

    private static Method autoGetMethod(Class<?> cls, String mothodName, Object... args) {
        Method method = null;
        try {
            Class<?>[] classes = autoParseClasses(args);
            method = (classes != null ? cls.getMethod(mothodName, classes) : cls.getMethod(mothodName));
        } catch (Exception ignored) {
        }
        return method;
    }

    private static Method autoGetDeclaredMethod(Class<?> cls, String mothodName, Object... args) {
        Method method = null;
        try {
            Class<?>[] classes = autoParseClasses(args);
            method = (classes != null ? cls.getDeclaredMethod(mothodName, classes) : cls.getDeclaredMethod(mothodName));
            if (method != null) {
                method.setAccessible(true);
            }
        } catch (Exception ignored) {
        }
        return method;
    }

    public static Method getMethod(Class<?> cls, String mothodName, Class<?>... parameterTypes) {
        Method method = null;
        try {
            method = cls.getMethod(mothodName, parameterTypes);
        } catch (Exception ignored) {
        }
        return method;
    }

    public static Method getDeclaredMethod(Class<?> cls, String mothodName, Class<?>... parameterTypes) {
        Method method = null;
        try {
            method = cls.getDeclaredMethod(mothodName, parameterTypes);
            if (method != null) {
                method.setAccessible(true);
            }
        } catch (Exception ignored) {
        }
        return method;
    }

    public static Object invokeMethodReturnObject(Class<?> cls, Object object, String mothodName, Object... args) {
        Object ret = null;
        try {
            Method method = autoGetMethod(cls, mothodName, args);
            if (method != null) {
                ret = method.invoke(object, args);
            }
        } catch (Exception ignored) {
        }
        return ret;
    }

    public static Object invokeMethodReturnObject(Class<?> cls, Object object, Method method, Object... args) {
        Object ret = null;
        try {
            if (method != null) {
                ret = method.invoke(object, args);
            }
        } catch (Exception ignored) {
        }
        return ret;
    }

    public static Object invokeDeclaredMethodReturnObject(Class<?> cls, Object object, String mothodName, Object... args) {
        Object ret = null;
        try {
            Method method = autoGetDeclaredMethod(cls, mothodName, args);
            if (method != null) {
                ret = method.invoke(object, args);
            }
        } catch (Exception ignored) {
        }
        return ret;
    }

    public static Object invokeDeclaredMethodReturnObject(Class<?> cls, Object object, Method method, Object... args) {
        Object ret = null;
        try {
            if (method != null) {
                method.setAccessible(true);
                ret = method.invoke(object, args);
            }
        } catch (Exception ignored) {
        }
        return ret;
    }

    public static boolean invokeMethodReturnBoolean(Class<?> cls, Object object, String mothodName, boolean defaultRetValue, Object... args) {
        boolean ret = defaultRetValue;
        try {
            Method method = autoGetMethod(cls, mothodName, args);
            if (method != null) {
                ret = (boolean)method.invoke(object, args);
            }
        } catch (Exception ignored) {
        }
        return ret;
    }

    public static boolean invokeDeclaredMethodReturnBoolean(Class<?> cls, Object object, String mothodName, boolean defaultRetValue, Object... args) {
        boolean ret = defaultRetValue;
        try {
            Method method = autoGetDeclaredMethod(cls, mothodName, args);
            if (method != null) {
                ret = (boolean)method.invoke(object, args);
            }
        } catch (Exception ignored) {
            ignored.printStackTrace();
        }
        return ret;
    }

    public static int invokeMethodReturnInt(Class<?> cls, Object object, String mothodName, int defaultRetValue, Object... args) {
        int ret = defaultRetValue;
        try {
            Method method = autoGetMethod(cls, mothodName, args);
            if (method != null) {
                ret = (int)method.invoke(object, args);
            }
        } catch (Exception ignored) {
        }
        return ret;
    }

    public static int invokeDeclaredMethodReturnInt(Class<?> cls, Object object, String mothodName, int defaultRetValue, Object... args) {
        int ret = defaultRetValue;
        try {
            Method method = autoGetDeclaredMethod(cls, mothodName, args);
            if (method != null) {
                ret = (int)method.invoke(object, args);
            }
        } catch (Exception ignored) {
        }
        return ret;
    }

    public static String invokeMethodReturnString(Class<?> cls, Object object, String mothodName, String defaultValue, Object... args) {
        String ret = defaultValue;
        try {
            Method method = autoGetMethod(cls, mothodName, args);
            if (method != null) {
                ret = (String)method.invoke(object, args);
            }
        } catch (Exception ignored) {
        }
        return ret;
    }

    public static String invokeDeclaredMethodReturnString(Class<?> cls, Object object, String mothodName, String defaultValue, Object... args) {
        String ret = defaultValue;
        try {
            Method method = autoGetDeclaredMethod(cls, mothodName, args);
            if (method != null) {
                ret = (String)method.invoke(object, args);
            }
        } catch (Exception ignored) {
        }
        return ret;
    }



    public static String getProperty(String key) {
        final Class<?> SystemProperties = getClass("android.os.SystemProperties");
        return invokeMethodReturnString(SystemProperties, null, "get", "", key);
    }

    public static void setProperty(String key, String value) {
        final Class<?> SystemProperties = getClass("android.os.SystemProperties");
        invokeMethodReturnObject(SystemProperties, null, "set", key, value);
    }

}
