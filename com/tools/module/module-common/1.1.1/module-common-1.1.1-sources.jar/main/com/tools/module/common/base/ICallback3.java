package com.tools.module.common.base;

/**
 * ICallback3
 *
 */
public interface ICallback3<Data1, Data2, Data3> {

    void onSuccess(Data1 data1, Data2 data2, Data3 data3);
    void onFail(Integer errorCode, String errorMsg);

}
