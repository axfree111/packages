package com.tools.module.common.utils;

import android.widget.Toast;

import com.tools.module.common.ContextStore;
import com.tools.module.common.MainThread;


/**
 * Toast类,防止连续多次调用toast时,toast超时显示. Created by zzk on 2014/7/21.
 */
public class ToastUtil {
    private static Toast t;
    private static int duration;

    private static void makeText(String msg, int duration) {
        MainThread.post(new Runnable() {
            @Override
            public void run() {
                if (ContextStore.getContext() != null) {
                    if (ToastUtil.duration != duration) {
                        if (t != null) {
                            t.cancel();
                        }
                        t = Toast.makeText(ContextStore.getContext(), msg, duration);
                    } else {
                        if (t == null) {
                            t = Toast.makeText(ContextStore.getContext(), msg, duration);
                        } else {
                            t.setText(msg);
                        }
                    }
                    ToastUtil.duration = duration;
                    t.show();
                }
            }
        });
    }

    public static void makeText(int resId, int duration) {
        makeText(ContextStore.getContext().getResources().getString(resId), duration);
    }

    public static void makeShortText(String msg) {
        makeText(msg, Toast.LENGTH_SHORT);
    }

    public static void makeShortText(int resId) {
        makeText(resId, Toast.LENGTH_SHORT);
    }

    public static void makeLongText(String msg) {
        makeText(msg, Toast.LENGTH_LONG);
    }

    public static void makeLongText(int resId) {
        makeText(resId, Toast.LENGTH_LONG);
    }

}
