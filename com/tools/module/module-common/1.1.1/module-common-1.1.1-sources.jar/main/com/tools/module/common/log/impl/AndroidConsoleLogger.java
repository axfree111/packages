package com.tools.module.common.log.impl;

import com.tools.module.common.log.ILogger;
import com.tools.module.common.log.Level;

import java.lang.reflect.Method;

/**
 * AndroidConsoleLogger
 *
 * 
 * 
 */
public final class AndroidConsoleLogger implements ILogger {

    private static Method LogD = null;
    private static Method LogI = null;
    private static Method LogW = null;
    private static Method LogE = null;
    private static Method LogEE = null;

    static {
        try {
            Class<?> Log = Class.forName("android.util.Log");
            LogD = Log.getMethod("d", String.class, String.class);
            LogI = Log.getMethod("i", String.class, String.class);
            LogW = Log.getMethod("w", String.class, String.class);
            LogE = Log.getMethod("e", String.class, String.class);
            LogEE = Log.getMethod("e", String.class, String.class, Throwable.class);
        } catch (Exception ignored) {
        }
    }

    private volatile Level mLevel = Level.DEBUG;



    public AndroidConsoleLogger() {
        this(Level.DEBUG);
    }

    public AndroidConsoleLogger(Level level) {
        setLogLevel(level);
    }

    @Override
    public void setLogLevel(Level level) {
        if (level != null) {
            mLevel = level;
        }
    }

    @Override
    public void d(String tag, String msg) {
        log(Level.DEBUG, LogD, tag, msg, null);
    }

    @Override
    public void i(String tag, String msg) {
        log(Level.INFO, LogI, tag, msg, null);
    }

    @Override
    public void w(String tag, String msg) {
        log(Level.WARN, LogW, tag, msg, null);
    }

    @Override
    public void e(String tag, String msg) {
        log(Level.ERROR, LogE, tag, msg, null);
    }

    @Override
    public void e(String tag, String msg, Throwable tr) {
        log(Level.ERROR, LogEE, tag, msg, tr);
    }

    private void log(Level level, Method method, String tag, String msg, Throwable tr) {
        if (method != null && level.getLevel() >= mLevel.getLevel()) {
            try {
                if (tr != null) {
                    method.invoke(null, tag, msg, tr);
                } else {
                    method.invoke(null, tag, msg);
                }
            } catch (Exception ignored) {
            }
        }
    }

}
