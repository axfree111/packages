package com.tools.module.common.ext

import android.graphics.Typeface
import android.text.Spannable
import android.text.SpannableString
import android.text.TextPaint
import android.text.TextUtils
import android.text.style.ClickableSpan
import android.text.style.LeadingMarginSpan
import android.text.style.StyleSpan
import android.view.View

fun SpannableString.appendLeadingSpan(firstLinePx: Int, restLinePx: Int): SpannableString {
    val leadingSpan = LeadingMarginSpan.Standard(
            firstLinePx, // 首行左缩进（像素）
            restLinePx   // 其它行左缩进（像素）
    )
    return this.apply {
        setSpan(leadingSpan, 0, this.length, Spannable.SPAN_INCLUSIVE_INCLUSIVE)
    }
}

fun SpannableString.appendBoldSpan(boldText: String): SpannableString {
    if (TextUtils.isEmpty(boldText)) {
        return this
    }
    val fullText = this.toString()
    val start = fullText.indexOf(boldText)
    val end = start + boldText.length
    if (start < 0 || end < 0) {
        return this
    }
    this.setSpan(StyleSpan(Typeface.BOLD), start, end, Spannable.SPAN_INCLUSIVE_INCLUSIVE)
    return this
}

fun SpannableString.appendClickableSpan(clickText: String? = null, clickAction: (() -> Unit)? = null, clickColor: Int? = null): SpannableString {
    if (ensureAnyNull(clickText, clickAction)) {
        return this
    }

    val fullText = this.toString()
    val start = fullText.indexOf(clickText!!)
    val end = start + clickText.length
    if (start < 0 || end < 0) {
        return this
    }

    val clickableSpan = object : ClickableSpan() {
        override fun onClick(widget: View) {
            clickAction?.invoke()
        }

        override fun updateDrawState(ds: TextPaint) {
            ds.isUnderlineText = false
            ds.color = clickColor ?: ds.linkColor
        }
    }
    return this.apply {
        setSpan(clickableSpan, start, end, Spannable.SPAN_INCLUSIVE_INCLUSIVE)
    }
}