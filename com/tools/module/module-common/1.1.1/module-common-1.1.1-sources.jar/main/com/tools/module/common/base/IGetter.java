package com.tools.module.common.base;

/**
 * IGetter
 *
 * 
 * 
 */
public interface IGetter<T> {

    T get();

}
