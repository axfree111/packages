package com.tools.module.common.security;

import androidx.annotation.NonNull;

import java.nio.charset.StandardCharsets;

/**
 * Base64
 *
 * 
 * 
 */
public class Base64 {
    /**
     * base64编码
     */
    public static String encode(@NonNull byte[] bytes) {
        return new String(Base64Java.getEncoder().encode(bytes));
    }

    /**
     * base64编码
     */
    public static String encode(@NonNull String str) {
        return Base64.encode(str.getBytes(StandardCharsets.UTF_8));
    }

    /**
     * base64解码
     */
    public static byte[] decode(@NonNull String base64) {
        return Base64Java.getDecoder().decode(base64.getBytes());
    }

}
