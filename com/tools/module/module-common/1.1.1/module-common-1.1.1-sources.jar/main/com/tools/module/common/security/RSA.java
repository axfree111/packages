package com.tools.module.common.security;

import com.tools.module.common.utils.IOUtils;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

import javax.crypto.Cipher;

/**
 * Created by Snser on 2017/10/30.
 */

public class RSA {

    /**
     * 加密算法RSA
     */
    private static final String KEY_ALGORITHM = "RSA";

    /**
     * 签名算法
     */
    private static final String SIGNATURE_ALGORITHM = "MD5withRSA";

    /**
     * 密钥长度（位）
     */
    private static final int KEY_SIZE = 2048;

    /**
     * RSA最大加密明文大小
     */
    private static final int MAX_ENCRYPT_BLOCK = (KEY_SIZE >> 3) - 11;

    /**
     * RSA最大解密密文大小
     */
    private static final int MAX_DECRYPT_BLOCK = KEY_SIZE >> 3;



    /**
     * <p>
     * 生成密钥对(公钥和私钥)
     * </p>
     *
     * @return Arrays.asList(publicKey, privateKey)
     */
    public static Key[] generateKeyPair() {
        try {
            KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance(KEY_ALGORITHM);
            keyPairGen.initialize(KEY_SIZE);
            KeyPair keyPair = keyPairGen.generateKeyPair();
            return new Key[] {keyPair.getPublic(), keyPair.getPrivate()};
        } catch (Exception ignored) {
            return null;
        }
    }

    /**
     * <p>
     * 生成base64密钥对(公钥和私钥)
     * </p>
     *
     * @return Arrays.asList(publicKeyBase64, privateKeyBase64)
     */
    public static String[] generateKeyPairBase64() {
        try {
            KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance(KEY_ALGORITHM);
            keyPairGen.initialize(KEY_SIZE);
            KeyPair keyPair = keyPairGen.generateKeyPair();
            String publicKeyBase64 = Base64.encode(keyPair.getPublic().getEncoded());
            String privateKeyBase64 = Base64.encode(keyPair.getPrivate().getEncoded());
            return new String[] {publicKeyBase64, privateKeyBase64};
        } catch (Exception ignored) {
            return null;
        }
    }



    /**
     * <p>
     * 生成数字签名
     * </p>
     *
     * @param data 数据
     * @param privateKeyBase64 base64私钥
     */
    public static String sign(String data, String privateKeyBase64) {
        return sign(data.getBytes(StandardCharsets.UTF_8), Base64.decode(privateKeyBase64));
    }

    /**
     * <p>
     * 生成数字签名
     * </p>
     *
     * @param data 数据
     * @param privateKeyBase64 base64私钥
     */
    public static String sign(byte[] data, String privateKeyBase64) {
        return sign(data, Base64.decode(privateKeyBase64));
    }

    /**
     * <p>
     * 生成数字签名
     * </p>
     *
     * @param data 数据
     * @param privateKey 私钥
     */
    public static String sign(byte[] data, byte[] privateKey) {
        try {
            PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(privateKey);
            KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
            PrivateKey privateK = keyFactory.generatePrivate(pkcs8KeySpec);
            Signature signature = Signature.getInstance(SIGNATURE_ALGORITHM);
            signature.initSign(privateK);
            signature.update(data);
            return Base64.encode(signature.sign());
        } catch (Exception ignored) {
            return null;
        }
    }

    /**
     * <p>
     * 校验数字签名
     * </p>
     *
     * @param data 数据
     * @param publicKeyBase64 base64公钥
     * @param sign 数字签名
     */
    public static boolean verify(String data, String publicKeyBase64, String sign) {
        return verify(data.getBytes(StandardCharsets.UTF_8), Base64.decode(publicKeyBase64), sign);
    }

    /**
     * <p>
     * 校验数字签名
     * </p>
     *
     * @param data 数据
     * @param publicKeyBase64 base64公钥
     * @param sign 数字签名
     */
    public static boolean verify(byte[] data, String publicKeyBase64, String sign) {
        return verify(data, Base64.decode(publicKeyBase64), sign);
    }

    /**
     * <p>
     * 校验数字签名
     * </p>
     *
     * @param data 数据
     * @param publicKey 公钥
     * @param sign 数字签名
     */
    public static boolean verify(byte[] data, byte[] publicKey, String sign) {
        try {
            X509EncodedKeySpec keySpec = new X509EncodedKeySpec(publicKey);
            KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
            PublicKey publicK = keyFactory.generatePublic(keySpec);
            Signature signature = Signature.getInstance(SIGNATURE_ALGORITHM);
            signature.initVerify(publicK);
            signature.update(data);
            return signature.verify(Base64.decode(sign));
        } catch (Exception ignored) {
            return false;
        }
    }



    /**
     * <p>
     * 公钥加密
     * </p>
     *
     * @param data 源数据
     * @param publicKeyBase64 base64公钥
     */
    public static String encryptByPublicKey(String data, String publicKeyBase64) {
        final byte[] encryptedData = encryptByPublicKey(data.getBytes(StandardCharsets.UTF_8), Base64.decode(publicKeyBase64));
        return Base64.encode(encryptedData);
    }

    /**
     * <p>
     * 公钥加密
     * </p>
     *
     * @param data 源数据
     * @param publicKey 公钥
     */
    public static byte[] encryptByPublicKey(byte[] data, byte[] publicKey) {
        byte[] encryptedData = null;
        ByteArrayOutputStream bos = null;
        try {
            X509EncodedKeySpec x509KeySpec = new X509EncodedKeySpec(publicKey);
            KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
            Key publicK = keyFactory.generatePublic(x509KeySpec);
            // 对数据加密
            Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
            cipher.init(Cipher.ENCRYPT_MODE, publicK);
            int inputLen = data.length;
            bos = new ByteArrayOutputStream();
            int offSet = 0;
            byte[] cache;
            int i = 0;
            // 对数据分段加密
            while (inputLen - offSet > 0) {
                if (inputLen - offSet > MAX_ENCRYPT_BLOCK) {
                    cache = cipher.doFinal(data, offSet, MAX_ENCRYPT_BLOCK);
                } else {
                    cache = cipher.doFinal(data, offSet, inputLen - offSet);
                }
                bos.write(cache, 0, cache.length);
                i++;
                offSet = i * MAX_ENCRYPT_BLOCK;
            }
            encryptedData = bos.toByteArray();
        } catch (Exception ignored) {
        } finally {
            IOUtils.closeStream(bos);
        }
        return encryptedData;
    }



    /**
     * <p>
     * 私钥加密
     * </p>
     *
     * @param data 源数据
     * @param privateKeyBase64 base64私钥
     */
    public static String encryptByPrivateKey(String data, String privateKeyBase64) {
        final byte[] encryptedData = encryptByPrivateKey(data.getBytes(StandardCharsets.UTF_8), Base64.decode(privateKeyBase64));
        return Base64.encode(encryptedData);
    }

    /**
     * <p>
     * 私钥加密
     * </p>
     *
     * @param data 源数据
     * @param privateKey 私钥
     */
    public static byte[] encryptByPrivateKey(byte[] data, byte[] privateKey) {
        byte[] encryptedData = null;
        ByteArrayOutputStream bos = null;
        try {
            PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(privateKey);
            KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
            Key privateK = keyFactory.generatePrivate(pkcs8KeySpec);
            Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
            cipher.init(Cipher.ENCRYPT_MODE, privateK);
            int inputLen = data.length;
            bos = new ByteArrayOutputStream();
            int offSet = 0;
            byte[] cache;
            int i = 0;
            // 对数据分段加密
            while (inputLen - offSet > 0) {
                if (inputLen - offSet > MAX_ENCRYPT_BLOCK) {
                    cache = cipher.doFinal(data, offSet, MAX_ENCRYPT_BLOCK);
                } else {
                    cache = cipher.doFinal(data, offSet, inputLen - offSet);
                }
                bos.write(cache, 0, cache.length);
                i++;
                offSet = i * MAX_ENCRYPT_BLOCK;
            }
            encryptedData = bos.toByteArray();
        } catch (Exception ignored) {
        } finally {
            IOUtils.closeStream(bos);
        }
        return encryptedData;
    }



    /**
     * <p>
     * 公钥解密
     * </p>
     *
     * @param encryptedDataBase64 base64已加密数据
     * @param publicKeyBase64 base64公钥
     */
    public static String decryptByPublicKey(String encryptedDataBase64, String publicKeyBase64) {
        final byte[] decryptedData = decryptByPublicKey(Base64.decode(encryptedDataBase64), Base64.decode(publicKeyBase64));
        return new String(decryptedData, StandardCharsets.UTF_8);
    }

    /**
     * <p>
     * 公钥解密
     * </p>
     *
     * @param encryptedData 已加密数据
     * @param publicKey 公钥
     */
    public static byte[] decryptByPublicKey(byte[] encryptedData, byte[] publicKey) {
        byte[] decryptedData = null;
        ByteArrayOutputStream bos = null;
        try {
            X509EncodedKeySpec x509KeySpec = new X509EncodedKeySpec(publicKey);
            KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
            Key publicK = keyFactory.generatePublic(x509KeySpec);
            Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
            cipher.init(Cipher.DECRYPT_MODE, publicK);
            int inputLen = encryptedData.length;
            bos = new ByteArrayOutputStream();
            int offSet = 0;
            byte[] cache;
            int i = 0;
            // 对数据分段解密
            while (inputLen - offSet > 0) {
                if (inputLen - offSet > MAX_DECRYPT_BLOCK) {
                    cache = cipher.doFinal(encryptedData, offSet, MAX_DECRYPT_BLOCK);
                } else {
                    cache = cipher.doFinal(encryptedData, offSet, inputLen - offSet);
                }
                bos.write(cache, 0, cache.length);
                i++;
                offSet = i * MAX_DECRYPT_BLOCK;
            }
            decryptedData = bos.toByteArray();
        } catch (Exception ignored) {
        } finally {
            IOUtils.closeStream(bos);
        }
        return decryptedData;
    }



    /**
     * <P>
     * 私钥解密
     * </p>
     *
     * @param encryptedDataBase64 base64已加密数据
     * @param privateKeyBase64 base64私钥
     */
    public static String decryptByPrivateKey(String encryptedDataBase64, String privateKeyBase64) {
        final byte[] decryptedData = decryptByPrivateKey(Base64.decode(encryptedDataBase64), Base64.decode(privateKeyBase64));
        return new String(decryptedData, StandardCharsets.UTF_8);
    }

    /**
     * <P>
     * 私钥解密
     * </p>
     *
     * @param encryptedData 已加密数据
     * @param privateKey 私钥
     */
    public static byte[] decryptByPrivateKey(byte[] encryptedData, byte[] privateKey) {
        byte[] decryptedData = null;
        ByteArrayOutputStream bos = null;
        try {
            PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(privateKey);
            KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM);
            Key privateK = keyFactory.generatePrivate(pkcs8KeySpec);
            Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
            cipher.init(Cipher.DECRYPT_MODE, privateK);
            int inputLen = encryptedData.length;
            bos = new ByteArrayOutputStream();
            int offSet = 0;
            byte[] cache;
            int i = 0;
            // 对数据分段解密
            while (inputLen - offSet > 0) {
                if (inputLen - offSet > MAX_DECRYPT_BLOCK) {
                    cache = cipher.doFinal(encryptedData, offSet, MAX_DECRYPT_BLOCK);
                } else {
                    cache = cipher.doFinal(encryptedData, offSet, inputLen - offSet);
                }
                bos.write(cache, 0, cache.length);
                i++;
                offSet = i * MAX_DECRYPT_BLOCK;
            }
            decryptedData = bos.toByteArray();
        } catch (Exception ignored) {
        } finally {
            IOUtils.closeStream(bos);
        }
        return decryptedData;
    }

}
