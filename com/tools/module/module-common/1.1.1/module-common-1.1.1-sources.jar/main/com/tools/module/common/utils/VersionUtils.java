package com.tools.module.common.utils;

/**
 * VersionUtils
 *
 * 
 * 
 */
public class VersionUtils {

    public static int compareVersion(String a, String b) {
        String[] subVersionsA = a != null ? a.split("\\.") : new String[]{};
        String[] subVersionsB = b != null ? b.split("\\.") : new String[]{};
        int i = 0;
        while (i < subVersionsA.length && i < subVersionsB.length) {
            int subVersionA = parseInteger(subVersionsA[i]);
            int subVersionB = parseInteger(subVersionsB[i]);
            if (subVersionA != subVersionB) {
                return subVersionA - subVersionB;
            }
            ++i;
        }
        return subVersionsA.length - subVersionsB.length;
    }

    private static int parseInteger(String str) {
        try {
            return Integer.parseInt(str);
        } catch (NumberFormatException e) {
            return -1;
        }
    }

}
