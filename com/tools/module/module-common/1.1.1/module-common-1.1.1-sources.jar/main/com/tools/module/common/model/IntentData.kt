package com.tools.module.common.model

/**
 * Date: 2025/3/27
 * Desc:
 *
 * author: jaje
 */
object IntentData {
    const val ID: String = "id"
    const val MARKER_MODEL: String = "markerModel"
    const val HEIGHT: String = "height"
    const val YAW: String = "yaw"
    const val VIDEO_MODEL: String = "videoModel"
}