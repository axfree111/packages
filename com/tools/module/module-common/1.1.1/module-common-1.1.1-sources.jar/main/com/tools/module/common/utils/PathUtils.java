package com.tools.module.common.utils;

/**
 * Created by jiajie on 2020-02-19.
 */
public enum PathUtils {
    HTTP("http"),
    HTTPS("https"),
    FILE("file"),
    CONTENT("content"),
    ASSETS("assets"),
    DRAWABLE("drawable"),
    UNKNOWN("");

    private String scheme;
    private String uriPrefix;

    private PathUtils(String scheme) {
        this.scheme = scheme;
        this.uriPrefix = scheme + "://";
    }

    public static PathUtils ofUri(String uri) {
        if (uri != null) {
            PathUtils[] var1 = values();
            int var2 = var1.length;

            for (int var3 = 0; var3 < var2; ++var3) {
                PathUtils s = var1[var3];
                if (s.belongsTo(uri)) {
                    return s;
                }
            }
        }

        return UNKNOWN;
    }

    private boolean belongsTo(String uri) {
        return uri.startsWith(this.uriPrefix);
    }

    public String wrap(String path) {
        return this.uriPrefix + path;
    }

    public String crop(String uri) {
        if (!this.belongsTo(uri)) {
            throw new IllegalArgumentException(String.format("URI [%1$s] doesn't have expected scheme [%2$s]", uri, this.scheme));
        } else {
            return uri.substring(this.uriPrefix.length());
        }
    }
}
