package com.tools.module.common.model

/**
 * Date: 2025/3/27
 * Desc:
 *
 * author: jaje
 */
object AttackState {
    const val CREATE: Int = 0 // 创建
    const val CANCEL: Int = 1 // 取消
    const val FINISH: Int = 2 // 完成
}