package com.tools.module.common.model

/**
 * Date: 2025/3/27
 * Desc:
 *
 * author: jaje
 */
object WhatDataMsg {
    const val RESPONSE_DRONE_DATA: Int = 3
    const val RESPONSE_FIRST_DRONE_DATA: Int = 4
    const val WEBSOCKET_DRONE_DATA: Int = 5
    const val TIMING_GET_DRONE_DATA: Int = 6

    const val RESPONSE_DRONES_HISTORY_DATA: Int = 10
    const val RESPONSE_SINGLE_DRONES_HISTORY_DATA: Int = 11
    const val RESPONSE_SINGLE_DRONES_HISTORY_DATA_AND_SHOW: Int = 12
    const val RESPONSE_PLANE_HISTORY_DATA: Int = 13

    const val RESPONSE_MONITOR_DATA: Int = 30
    const val WEBSOCKET_MONITOR_DATA: Int = 31
    const val TIMING_GET_MONITOR_DATA: Int = 32

    const val RESPONSE_VIDEOS_DATA: Int = 40
    const val TIMING_GET_VIDEOS_DATA: Int = 41

    const val RESPONSE_SHIP_DATA: Int = 50
    const val TIMING_GET_SHIP_DATA: Int = 51
    const val TIMING_GET_PLANE_DATA: Int = 52
    const val TIMING_GET_SECON_PLANE_DATA: Int = 54
    const val RESPONSE_PLANE_DATA: Int = 53

    const val TIMING_GET_WARNING_AREA_DATA: Int = 60

    const val RESPONSE_SHIP_HISTORY_DATA: Int = 70
    const val RESPONSE_SINGLE_SHIP_HISTORY_DATA: Int = 71
    const val RESPONSE_SINGLE_SHIP_HISTORY_DATA_AND_SHOW: Int = 72

    const val RECONNECT_SOCKET: Int = 101
    const val HEARTBEAT: Int = 100
}