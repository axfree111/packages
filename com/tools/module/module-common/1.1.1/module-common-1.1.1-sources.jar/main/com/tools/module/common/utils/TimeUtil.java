package com.tools.module.common.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * <p>Copyright © 2017 Zego. All rights reserved.</p>
 *
 * @author realuei on 24/10/2017.
 */

public class TimeUtil {
    static final private SimpleDateFormat sFormat = new SimpleDateFormat("yyyy/MM/dd/HH:mm:ss:SSS");
    static final private SimpleDateFormat fileFormat = new SimpleDateFormat("yyyyMMddHHmmss");
    static final private SimpleDateFormat file1Format = new SimpleDateFormat("yyyy-MM-dd_hhmmss");
    static final private SimpleDateFormat file2Format = new SimpleDateFormat("yyyy-MM-dd-hh-mm-ss");
    static final private SimpleDateFormat timeStrFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    static final private SimpleDateFormat sLogFormat = new SimpleDateFormat("HH:mm:ss.SSS");

    static public String getNowTimeStr() {
        return sFormat.format(new Date());
    }

    static public String getFileTimeStr() {
        return fileFormat.format(new Date());
    }

    static public String getFile2TimeStr() {
        return file2Format.format(new Date());
    }

    static public String getFile1TimeStr() {
        return file1Format.format(new Date());
    }

    static public String getLogStr() {
        return sLogFormat.format(new Date());
    }

    static public String getNowTimeStr1() {
        return timeStrFormat.format(new Date());
    }

    static public String getTimeStr(Date date) {
        if (date == null) {
            return "";
        }
        return timeStrFormat.format(date);
    }

    static public Date getTimeStrDate(String timeStr) {
        try {
            //转换为Date类
            Date date = timeStrFormat.parse(timeStr);
            return date;
        } catch (Exception e) {
            XAppLogger.getInstance().writeError(e);
        }
        return new Date();
    }

    static public Long getTimeLong(String timeStr) {
        try {
            //转换为Date类
            Date date = timeStrFormat.parse(timeStr);
            return date.getTime();
        } catch (Exception e) {
            XAppLogger.getInstance().writeError(e);
        }
        return 0L;
    }

}
