package com.tools.module.common.utils;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.Drawable;

import com.tools.module.common.ContextStore;

public class ResourceUtil {
    public static String getContent(int rid, Object... formatArgs) {
        return getResources().getString(rid, formatArgs);
    }

    public static int getColor(int rid) {
        return getResources().getColor(rid);
    }

    public static float getDimension(int rid) {
        return getResources().getDimension(rid);
    }

    public static Drawable getDrawable(int rid) {
        return getResources().getDrawable(rid);
    }

    public static Bitmap getBitmap(int rid) {
        return BitmapFactory.decodeResource(getResources(), rid);
    }

    public static String[] getStringArray(int rid) {
        return getResources().getStringArray(rid);
    }

    public static Resources getResources() {
        return ContextStore.getContext().getResources();
    }

    public static String Color_16(int color) {
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append("#");
        stringBuffer.append(Integer.toHexString(Color.alpha(color)));
        stringBuffer.append(Integer.toHexString(Color.red(color)));
        stringBuffer.append(Integer.toHexString(Color.green(color)));
        stringBuffer.append(Integer.toHexString(Color.blue(color)));
        return stringBuffer.toString();
    }

    public static String Color_16_NoAlpha(int color) {
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append("#");
        stringBuffer.append(Integer.toHexString(Color.red(color)));
        stringBuffer.append(Integer.toHexString(Color.green(color)));
        stringBuffer.append(Integer.toHexString(Color.blue(color)));
        return stringBuffer.toString();
    }
}
