package com.tools.module.common.base;

import com.tools.module.common.model.MapType;

/**
 * Created by jiajie on 2019-08-28.
 */
public class AppConfig {

    // TODO 需要处理这块
//    public static final String BUGLY_APPID = ResourceUtil.getContent(R.string.bugly_appid);
    public static int mapType = MapType.A_MAP;

    // 是否用socket请求数据
    public static final boolean USE_SOCKET = false;
    public static final boolean SHOW_LOG = true;
    // 显示闪动效果,缩小到一定级别不显示闪动
    public final static boolean SHOW_TWINKLE = false;

    // 是否显示预警区闪烁
    public static boolean SHOW_TWINKLE_ATTACK = false;
    // 是否显示预警区报警提示
    public static boolean SHOW_TWINKLE_WARNING = false;
    // 是否显示检测区报警提示
    public static boolean SHOW_TWINKLE_DISTERN = false;
    // 是否显示预警区
    public static boolean SHOW_AREA_WARNING = false;
    // 是否显示检测区
    public static boolean SHOW_AREA_DISTERN = false;
    // 掉线的移动设备显示开关
    public static boolean SHOW_OFFLINE_CAR_MONITOR = false;
    // 掉线的便携设备显示开关
    public static boolean SHOW_OFFLINE_PORTABLE_MONITOR = false;
    // 掉线的手持设备显示开关
    public static boolean SHOW_OFFLINE_HAND_MONITOR = false;
    // 掉线的abs_b设备显示开关
    public static boolean SHOW_OFFLINE_ABS_B_MONITOR = false;
    // 掉线的设备显示点击是否要显示信息开关
    public static boolean SHOW_OFFLINE_MONITOR_INFO = false;
    // 显示设备id
    public static final boolean SHOW_MONITOR_ID = false;
    // 是否显示POI
    public static final boolean SHOW_POI = true;
    // 是否显示交通道路
    public static final boolean SHOW_TRAFFIC = false;
    // 是否显示半径文字
    public static final boolean SHOW_RADIUS_TV = false;
    // 首先需要开启SHOW_RADIUS_TV,是否显示警告区半径文字
    public static final boolean SHOW_WARNING_RADIUS_TV = false;
    // 是否半径弧线
    public static boolean SHOW_RADIUS_LINE = false;
    // 是否把log保存到内存
    public static boolean SAVE_LOG_MEMORY = false;
    // 设备掉线和异常是否报警
    public static boolean MONITOR_EXCEPTION_WARNING = false;
    // 是否显示视频水印
    public static boolean SHOW_WATER_MARK = false;
    // 显示扫描线
    public static boolean SHOW_SCAN = true;
}
