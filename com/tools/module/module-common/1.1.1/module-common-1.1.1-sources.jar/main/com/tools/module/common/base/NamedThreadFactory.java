package com.tools.module.common.base;

import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * NamedThreadFactory
 * 支持指定线程名称的ThreadFactory
 *
 * 
 * 
 */
public class NamedThreadFactory implements ThreadFactory {

    private final String mThreadName;
    private final boolean mMultiThread;

    private final AtomicInteger mCounter = new AtomicInteger(0);

    public NamedThreadFactory(String threadName, boolean multiThread) {
        mThreadName = threadName;
        mMultiThread = multiThread;
    }

    @SuppressWarnings("NullableProblems")
    @Override
    public Thread newThread(Runnable r) {
        return new Thread(r, mThreadName + (mMultiThread ? "-" + mCounter.incrementAndGet() : ""));
    }

}
