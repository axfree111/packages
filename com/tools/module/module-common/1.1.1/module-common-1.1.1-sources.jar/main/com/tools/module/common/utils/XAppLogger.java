package com.tools.module.common.utils;

import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;

import com.tools.module.common.ContextStore;
import com.tools.module.common.base.AppConfig;

import java.io.BufferedWriter;
import java.io.Closeable;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

/**
 * Date: 2019/9/12-22
 * author: jiajie
 * Description:
 */
public class XAppLogger {

    private static final String TAG = "Drone_log";

    private static final int MSG_ID_WRITE_LOG = 1;
    private static final int MSG_ID_NOTIFICATION = 2;
    // LOG更新时间
    public static final int LOG_DATA_DELAY_TIME = 10 * 1000;
    private static final int FILE_COUNT = 6;
    private static final int LOG_MAX_SIZE = 300;
    private static final int LOG_MAX_LENGTH = 4000;
    private static final int LOG_ONELINE_LENGTH = 2000;
    private static final int SINGLE_LOG_FILE_MAX_SIZE = 10 * 1024 * 1024;   // 10M
    public static final String LOG_PREFIX = "L";
    public static final String ERROR_PREFIX = "E";
    private static final String LOG_FILE_SUFFIX = ".txt";

    // 武器log文件
    private static final String MONITOR_FILE_PREFIX = "drone_monitor";
    private static final String MONITOR_FILE_NAME = MONITOR_FILE_PREFIX + LOG_FILE_SUFFIX;

    // 无人机log文件
    private static final String DRONE_FILE_PREFIX = "drone_drone";
    private static final String DRONE_FILE_NAME = DRONE_FILE_PREFIX + LOG_FILE_SUFFIX;

    // 船舶log文件
    private static final String SHIP_FILE_PREFIX = "drone_ship";
    private static final String SHIP_FILE_NAME = SHIP_FILE_PREFIX + LOG_FILE_SUFFIX;

    // 民航log文件
    private static final String AIRCRAFT_FILE_PREFIX = "drone_aircraft";
    private static final String AIRCRAFT_FILE_NAME = AIRCRAFT_FILE_PREFIX + LOG_FILE_SUFFIX;

    // 指令log文件
    private static final String ORDER_FILE_PREFIX = "drone_order";
    private static final String ORDER_FILE_NAME = ORDER_FILE_PREFIX + LOG_FILE_SUFFIX;

    // socket log文件
    private static final String SOCKET_FILE_PREFIX = "drone_socket";
    private static final String SOCKET_FILE_NAME = SOCKET_FILE_PREFIX + LOG_FILE_SUFFIX;

    // 其他log文件
    private static final String OTHER_FILE_PREFIX = "drone_other";
    private static final String OTHER_FILE_NAME = OTHER_FILE_PREFIX + LOG_FILE_SUFFIX;

    // http log文件
    private static final String HTTP_FILE_PREFIX = "drone_http";
    private static final String HTTP_FILE_NAME = HTTP_FILE_PREFIX + LOG_FILE_SUFFIX;

    private static final String VIDEO_FILE_PREFIX = "drone_video";
    private static final String VIDEO_FILE_NAME = VIDEO_FILE_PREFIX + LOG_FILE_SUFFIX;

    private static final String ERROR_FILE_PREFIX = "drone_error";
    private static final String ERROR_FILE_NAME = ERROR_FILE_PREFIX + LOG_FILE_SUFFIX;

    private static XAppLogger sInstance;

    private ArrayList<OnLogChangedListener> mListeners = new ArrayList<>();

    private final List<String> mMonitorLogList = new Vector<>();
    private final List<String> mDroneLogList = new Vector<>();
    private final List<String> mOrderLogList = new Vector<>();
    private final List<String> mSocketLogList = new Vector<>();
    private final List<String> mOtherLogList = new Vector<>();
    private final List<String> mErrorLogList = new Vector<>();
    private final List<String> mVideoLogList = new Vector<>();
    private final List<String> mHttpLogList = new Vector<>();

    private Handler mLogHandler;

    private File mMonitorFile;
    private Writer mMonitorWriter;
    private File mDroneFile;
    private Writer mDroneWriter;
    private File mAircraftFile;
    private Writer mAircraftWriter;
    private File mShipFile;
    private Writer mShipWriter;
    private File mOrderFile;
    private Writer mOrderWriter;
    private File mSocketFile;
    private Writer mSocketWriter;
    private File mOtherFile;
    private Writer mOtherWriter;
    private File mErrorFile;
    private Writer mErrorWriter;
    private File mVideoFile;
    private Writer mVideoWriter;
    private File mHttpFile;
    private Writer mHttpWriter;

    private int logLoopCnt = 0;
    private final int checkFileMaxCnt = 50;

    private List<Integer> writeLogTypes = new ArrayList<>();
    private XAppLogger() {
        if (writeLogTypes.isEmpty()) {
            writeLogTypes.add(LOG_TYPE.TYPE_SOCKET);
            writeLogTypes.add(LOG_TYPE.TYPE_HTTP);
            writeLogTypes.add(LOG_TYPE.TYPE_ERROR);
            writeLogTypes.add(LOG_TYPE.TYPE_OTHER);
        }
        if (mLogHandler == null) {
            mLogHandler = new Handler(HandlerThreadUtils.getInstance().getLogHandlerThread().getLooper()) {

                @Override
                public void handleMessage(Message msg) {
                    switch (msg.what) {
                        case MSG_ID_WRITE_LOG: {
                            String message = (String) msg.obj;
                            String message_with_time;
                            String typeTag = "";
                            switch (msg.arg1) {
                                case LOG_TYPE.TYPE_MONITOR:
                                    typeTag = TAG_MONITOR;
                                    break;
                                case LOG_TYPE.TYPE_DRONE:
                                    typeTag = TAG_DRONE;
                                    break;
                                case LOG_TYPE.TYPE_ORDER:
                                    typeTag = TAG_ORDER;
                                    break;
                                case LOG_TYPE.TYPE_SOCKET:
                                    typeTag = TAG_SOCKET;
                                    break;
                                case LOG_TYPE.TYPE_OTHER:
                                    typeTag = TAG_OTHER;
                                    break;
                                case LOG_TYPE.TYPE_ERROR:
                                    typeTag = TAG_ERROR;
                                    break;
                                case LOG_TYPE.TYPE_VIDEO:
                                    typeTag = TAG_VIDEO;
                                    break;
                                case LOG_TYPE.TYPE_SHIP:
                                    typeTag = TAG_SHIP;
                                    break;
                                case LOG_TYPE.TYPE_AIRCRAFT:
                                    typeTag = TAG_AIRCRAFT;
                                    break;
                                default: {
                                    typeTag = TAG_HTTP;
                                }
                            }
                            if (msg.arg1 == LOG_TYPE.TYPE_ERROR) {
                                message_with_time = String.format("%s %s %s  %s", ERROR_PREFIX, TimeUtil.getNowTimeStr(), TAG + typeTag, message);
                            } else {
                                message_with_time = String.format("%s %s %s  %s", LOG_PREFIX, TimeUtil.getNowTimeStr(), TAG + typeTag, message);
                            }

                            if (AppConfig.SAVE_LOG_MEMORY) {
                                switch (msg.arg1) {
                                    case LOG_TYPE.TYPE_MONITOR:
                                        addLogToList(mMonitorLogList, message_with_time);
                                        break;
                                    case LOG_TYPE.TYPE_AIRCRAFT:
                                    case LOG_TYPE.TYPE_SHIP:
                                    case LOG_TYPE.TYPE_DRONE:
                                        addLogToList(mDroneLogList, message_with_time);
                                        break;
                                    case LOG_TYPE.TYPE_ORDER:
                                        addLogToList(mOrderLogList, message_with_time);
                                        break;
                                    case LOG_TYPE.TYPE_SOCKET:
                                        addLogToList(mSocketLogList, message_with_time);
                                        break;
                                    case LOG_TYPE.TYPE_OTHER:
                                        addLogToList(mOtherLogList, message_with_time);
                                        break;
                                    case LOG_TYPE.TYPE_ERROR:
                                        addLogToList(mErrorLogList, message_with_time);
                                        break;
                                    case LOG_TYPE.TYPE_VIDEO:
                                        addLogToList(mVideoLogList, message_with_time);
                                        break;
                                    default: {
                                        addLogToList(mHttpLogList, message_with_time);
                                    }
                                }
                            }
                            if (AppConfig.SHOW_LOG) {
                                safeWriteLogFile(msg.arg1, message_with_time);
                            }
                            if (AppConfig.SHOW_LOG) {
                                showLogCat(message_with_time);
                            }
                        }
                        break;
                        case MSG_ID_NOTIFICATION: {
                            mLogHandler.removeMessages(MSG_ID_NOTIFICATION);
                            mLogHandler.sendEmptyMessageDelayed(MSG_ID_NOTIFICATION, LOG_DATA_DELAY_TIME);
                            for (OnLogChangedListener listener : mListeners) {
                                listener.onLogDataChanged();
                            }
                        }
                        break;
                    }
                }
            };
        }
        initLogFile();
        mLogHandler.removeMessages(MSG_ID_NOTIFICATION);
        mLogHandler.sendEmptyMessage(MSG_ID_NOTIFICATION);
    }

    static public XAppLogger getInstance() {
        if (sInstance == null) {
            synchronized (XAppLogger.class) {
                if (sInstance == null) {
                    sInstance = new XAppLogger();
                }
            }
        }
        return sInstance;
    }

    public void setWriteLogTypes(List<Integer> writeTypes) {
        writeLogTypes.clear();
        writeLogTypes.addAll(writeTypes);
    }

    private void initLogFile() {
        checkFile(LOG_TYPE.TYPE_SOCKET);
        checkFile(LOG_TYPE.TYPE_MONITOR);
        checkFile(LOG_TYPE.TYPE_DRONE);
        checkFile(LOG_TYPE.TYPE_ORDER);
        checkFile(LOG_TYPE.TYPE_OTHER);
        checkFile(LOG_TYPE.TYPE_ERROR);
        checkFile(LOG_TYPE.TYPE_HTTP);
        checkFile(LOG_TYPE.TYPE_VIDEO);
    }

    private void checkFile(final int type) {
        mLogHandler.post(new Runnable() {
            @Override
            public void run() {
                // 文件重命名
                String fileName = getFileName(type);
                checkFileToRename(fileName, type);
                File baseFile = ContextStore.getContext().getExternalFilesDir("log");
                switch (type) {
                    case LOG_TYPE.TYPE_MONITOR:
                        mMonitorFile = new File(baseFile, fileName);
                        try {
                            if (!mMonitorFile.exists()) {
                                mMonitorFile.createNewFile();
                            }
                            mMonitorWriter = new BufferedWriter(new FileWriter(mMonitorFile, true));
                        } catch (IOException e) {
                            XAppLogger.getInstance().writeError(e);
                        }
                        break;
                    case LOG_TYPE.TYPE_DRONE:
                        mDroneFile = new File(baseFile, fileName);
                        try {
                            if (!mDroneFile.exists()) {
                                mDroneFile.createNewFile();
                            }
                            mDroneWriter = new BufferedWriter(new FileWriter(mDroneFile, true));
                        } catch (IOException e) {
                            XAppLogger.getInstance().writeError(e);
                        }
                        break;
                    case LOG_TYPE.TYPE_SHIP:
                        mShipFile = new File(baseFile, fileName);
                        try {
                            if (!mShipFile.exists()) {
                                mShipFile.createNewFile();
                            }
                            mShipWriter = new BufferedWriter(new FileWriter(mShipFile, true));
                        } catch (IOException e) {
                            XAppLogger.getInstance().writeError(e);
                        }
                        break;
                    case LOG_TYPE.TYPE_AIRCRAFT:
                        mAircraftFile = new File(baseFile, fileName);
                        try {
                            if (!mAircraftFile.exists()) {
                                mAircraftFile.createNewFile();
                            }
                            mAircraftWriter = new BufferedWriter(new FileWriter(mAircraftFile, true));
                        } catch (IOException e) {
                            XAppLogger.getInstance().writeError(e);
                        }
                        break;
                    case LOG_TYPE.TYPE_ORDER:
                        mOrderFile = new File(baseFile, fileName);
                        try {
                            if (!mOrderFile.exists()) {
                                mOrderFile.createNewFile();
                            }
                            mOrderWriter = new BufferedWriter(new FileWriter(mOrderFile, true));
                        } catch (IOException e) {
                            XAppLogger.getInstance().writeError(e);
                        }
                        break;
                    case LOG_TYPE.TYPE_SOCKET:
                        mSocketFile = new File(baseFile, fileName);
                        try {
                            if (!mSocketFile.exists()) {
                                mSocketFile.createNewFile();
                            }
                            mSocketWriter = new BufferedWriter(new FileWriter(mSocketFile, true));
                        } catch (IOException e) {
                            XAppLogger.getInstance().writeError(e);
                        }
                        break;
                    case LOG_TYPE.TYPE_OTHER:
                        mOtherFile = new File(baseFile, fileName);
                        try {
                            if (!mOtherFile.exists()) {
                                mOtherFile.createNewFile();
                            }
                            mOtherWriter = new BufferedWriter(new FileWriter(mOtherFile, true));
                        } catch (IOException e) {
                            XAppLogger.getInstance().writeError(e);
                        }
                        break;
                    case LOG_TYPE.TYPE_ERROR:
                        mErrorFile = new File(baseFile, fileName);
                        try {
                            if (!mErrorFile.exists()) {
                                mErrorFile.createNewFile();
                            }
                            mErrorWriter = new BufferedWriter(new FileWriter(mErrorFile, true));
                        } catch (IOException e) {
                            XAppLogger.getInstance().writeError(e);
                        }
                        break;
                    case LOG_TYPE.TYPE_VIDEO:
                        mVideoFile = new File(baseFile, fileName);
                        try {
                            if (!mVideoFile.exists()) {
                                mVideoFile.createNewFile();
                            }
                            mVideoWriter = new BufferedWriter(new FileWriter(mVideoFile, true));
                        } catch (IOException e) {
                            XAppLogger.getInstance().writeError(e);
                        }
                        break;
                    default: {
                        mHttpFile = new File(baseFile, fileName);
                        try {
                            if (!mHttpFile.exists()) {
                                mHttpFile.createNewFile();
                            }
                            mHttpWriter = new BufferedWriter(new FileWriter(mHttpFile, true));
                        } catch (IOException e) {
                            XAppLogger.getInstance().writeError(e);
                        }
                    }
                }
            }
        });
    }

    private void checkFileToRename(String logFileName, int type) {
        File baseFile = ContextStore.getContext().getExternalFilesDir("log");
        File logFile = new File(baseFile, logFileName);
        if (logFile.exists()) {
            if (logFile.length() >= SINGLE_LOG_FILE_MAX_SIZE) {    // 日志文件大于 10M 时，备份日志
                for (int i = 0; i <= FILE_COUNT; i++) {
                    File bakLogFile = new File(baseFile, createFileName(type, i));
                    if (!bakLogFile.exists()) {
                        safeCloseStream(type);
                        logFile.renameTo(bakLogFile);
                        break;
                    } else {
                        if (i == FILE_COUNT) { // 是个文件都存储满了，遍历删除所有文件
                            for (int j = 0; j <= FILE_COUNT; j++) {
                                File bakLogFile1 = new File(baseFile, createFileName(type, j));
                                if (bakLogFile1.exists()) {
                                    bakLogFile1.delete();
                                    if (j == 0) {
                                        safeCloseStream(type);
                                        logFile.renameTo(bakLogFile1);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private void showLogCat(String message_with_time) {
        int size = message_with_time.length();
        if (size > LOG_MAX_LENGTH) {
            final int LINE_MAX = LOG_ONELINE_LENGTH;
            int count = (size / LINE_MAX) + ((size % LINE_MAX == 0) ? 0 : 1);
            int index = 1;
            int start = 0;
            int end;

            while (start < size) {
                if (start + LINE_MAX < size) {
                    end = start + LINE_MAX;
                } else {
                    end = size;
                }
                Log.v(TAG, String.format("[%d/%d] %s", index, count, message_with_time.substring(start, end)));
                start = end;
                index += 1;
            }
        } else {
            Log.v(TAG, message_with_time);
        }
    }

    private void addLogToList(List<String> logList, String message_with_time) {
        logList.add(message_with_time);
        int logSize = logList.size();
        int excessCount = logSize - LOG_MAX_SIZE;
        if (excessCount > 0) {
            for (int i = 0; i < excessCount; i++) {
                logList.remove(i);
            }
        }
    }

    private String getFileName(int type) {
        switch (type) {
            case LOG_TYPE.TYPE_MONITOR:
                return MONITOR_FILE_NAME;
            case LOG_TYPE.TYPE_DRONE:
                return DRONE_FILE_NAME;
            case LOG_TYPE.TYPE_AIRCRAFT:
                return AIRCRAFT_FILE_NAME;
            case LOG_TYPE.TYPE_SHIP:
                return SHIP_FILE_NAME;
            case LOG_TYPE.TYPE_ORDER:
                return ORDER_FILE_NAME;
            case LOG_TYPE.TYPE_SOCKET:
                return SOCKET_FILE_NAME;
            case LOG_TYPE.TYPE_OTHER:
                return OTHER_FILE_NAME;
            case LOG_TYPE.TYPE_ERROR:
                return ERROR_FILE_NAME;
            case LOG_TYPE.TYPE_VIDEO:
                return VIDEO_FILE_NAME;
            default: {
                return HTTP_FILE_NAME;
            }
        }
    }

    private String createFileName(int type, int index) {
        switch (type) {
            case LOG_TYPE.TYPE_MONITOR:
                return MONITOR_FILE_PREFIX + "_" + index + LOG_FILE_SUFFIX;
            case LOG_TYPE.TYPE_DRONE:
                return DRONE_FILE_PREFIX + "_" + index + LOG_FILE_SUFFIX;
            case LOG_TYPE.TYPE_SHIP:
                return SHIP_FILE_PREFIX + "_" + index + LOG_FILE_SUFFIX;
            case LOG_TYPE.TYPE_AIRCRAFT:
                return AIRCRAFT_FILE_PREFIX + "_" + index + LOG_FILE_SUFFIX;
            case LOG_TYPE.TYPE_ORDER:
                return ORDER_FILE_PREFIX + "_" + index + LOG_FILE_SUFFIX;
            case LOG_TYPE.TYPE_SOCKET:
                return SOCKET_FILE_PREFIX + "_" + index + LOG_FILE_SUFFIX;
            case LOG_TYPE.TYPE_OTHER:
                return OTHER_FILE_PREFIX + "_" + index + LOG_FILE_SUFFIX;
            case LOG_TYPE.TYPE_ERROR:
                return ERROR_FILE_PREFIX + "_" + index + LOG_FILE_SUFFIX;
            case LOG_TYPE.TYPE_VIDEO:
                return VIDEO_FILE_PREFIX + "_" + index + LOG_FILE_SUFFIX;
            default: {
                return HTTP_FILE_PREFIX + "_" + index + LOG_FILE_SUFFIX;
            }
        }
    }

    private void safeWriteLogFile(int type, String content) {
        if (writeLogTypes.contains(type)) {
            logLoopCnt++;
            File file;
            Writer writer;
            switch (type) {
                case LOG_TYPE.TYPE_MONITOR:
                    file = mMonitorFile;
                    writer = mMonitorWriter;
                    break;
                case LOG_TYPE.TYPE_DRONE:
                    file = mDroneFile;
                    writer = mDroneWriter;
                    break;
                case LOG_TYPE.TYPE_AIRCRAFT:
                    file = mAircraftFile;
                    writer = mAircraftWriter;
                    break;
                case LOG_TYPE.TYPE_SHIP:
                    file = mShipFile;
                    writer = mShipWriter;
                    break;
                case LOG_TYPE.TYPE_ORDER:
                    file = mOrderFile;
                    writer = mOrderWriter;
                    break;
                case LOG_TYPE.TYPE_SOCKET:
                    file = mSocketFile;
                    writer = mSocketWriter;
                    break;
                case LOG_TYPE.TYPE_ERROR:
                    file = mErrorFile;
                    writer = mErrorWriter;
                    break;
                case LOG_TYPE.TYPE_VIDEO:
                    file = mVideoFile;
                    writer = mVideoWriter;
                    break;
                case LOG_TYPE.TYPE_OTHER:
                    file = mOtherFile;
                    writer = mOtherWriter;
                    break;
                default: {
                    file = mHttpFile;
                    writer = mHttpWriter;
                    break;
                }
            }
            if (writer != null) {
                try {
                    writer.write(content);
                    writer.write("\r\n");
                    if (logLoopCnt >= checkFileMaxCnt) {
                        writer.flush();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else {
                this.initLogFile();
            }
            if (logLoopCnt >= checkFileMaxCnt && file.length() >= SINGLE_LOG_FILE_MAX_SIZE) {
                logLoopCnt = 0;
                checkFile(type);
            }
        }
    }

    private void safeCloseStream(int type) {
        Closeable stream;
        switch (type) {
            case LOG_TYPE.TYPE_MONITOR:
                stream = mMonitorWriter;
                break;
            case LOG_TYPE.TYPE_DRONE:
                stream = mDroneWriter;
                break;
            case LOG_TYPE.TYPE_SHIP:
                stream = mShipWriter;
                break;
            case LOG_TYPE.TYPE_AIRCRAFT:
                stream = mAircraftWriter;
                break;
            case LOG_TYPE.TYPE_ORDER:
                stream = mOrderWriter;
                break;
            case LOG_TYPE.TYPE_SOCKET:
                stream = mSocketWriter;
                break;
            case LOG_TYPE.TYPE_ERROR:
                stream = mErrorWriter;
                break;
            case LOG_TYPE.TYPE_VIDEO:
                stream = mVideoWriter;
                break;
            default: {
                stream = mOtherWriter;
                break;
            }
        }
        if (stream != null) {
            try {
                stream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public boolean isErrorLog(String log) {
        if (TextUtils.isEmpty(log)) return false;
        if (log.startsWith(ERROR_PREFIX)) {
            return true;
        }
        return false;
    }

    public void writeError(Throwable ex) {
        writeLog(LOG_TYPE.TYPE_ERROR, AppUtil.getExceptionString(ex));
    }

    public void writeError(String format, final Object... args) {
        writeLog(LOG_TYPE.TYPE_ERROR, format, args);
    }

    public void writeLog(final String format, final Object... args) {
        String data;

        if (args.length == 0) {
            data = format;
        } else {
            data = String.format(format, args);
        }

        Message msg = Message.obtain();
        msg.what = MSG_ID_WRITE_LOG;
        msg.arg1 = LOG_TYPE.TYPE_OTHER;
        msg.obj = data;
        mLogHandler.sendMessage(msg);
    }

    public void writeLog(final int type, final String format, final Object... args) {
        String data;

        if (args.length == 0) {
            data = format;
        } else {
            data = String.format(format, args);
        }

        Message msg = Message.obtain();
        msg.what = MSG_ID_WRITE_LOG;
        msg.arg1 = type;
        msg.obj = data;
        mLogHandler.sendMessage(msg);
    }

    public List<String> getMonitorLogList() {
        return mMonitorLogList;
    }

    public List<String> getDroneLogList() {
        return mDroneLogList;
    }

    public List<String> getOrderLogList() {
        return mOrderLogList;
    }

    public List<String> getSocketLogList() {
        return mSocketLogList;
    }

    public List<String> getOtherLogList() {
        return mOtherLogList;
    }

    public List<String> getErrorLogList() {
        return mErrorLogList;
    }

    public void clearLog(int type) {
        synchronized (XAppLogger.this) {
            List<String> clearList;
            switch (type) {
                case LOG_TYPE.TYPE_MONITOR:
                    clearList = mMonitorLogList;
                    break;
                case LOG_TYPE.TYPE_AIRCRAFT:
                case LOG_TYPE.TYPE_SHIP:
                case LOG_TYPE.TYPE_DRONE:
                    clearList = mDroneLogList;
                    break;
                case LOG_TYPE.TYPE_ORDER:
                    clearList = mOrderLogList;
                    break;
                case LOG_TYPE.TYPE_SOCKET:
                    clearList = mSocketLogList;
                    break;
                case LOG_TYPE.TYPE_ERROR:
                    clearList = mErrorLogList;
                    break;
                case LOG_TYPE.TYPE_VIDEO:
                    clearList = mVideoLogList;
                    break;
                default: {
                    clearList = mOtherLogList;
                    break;
                }
            }
            if (clearList != null) {
                clearList.clear();
            }
        }
    }

    public void clearAll() {
        synchronized (XAppLogger.this) {
            mMonitorLogList.clear();
            mDroneLogList.clear();
            mOrderLogList.clear();
            mSocketLogList.clear();
            mOtherLogList.clear();
            mErrorLogList.clear();
            mLogHandler.removeMessages(MSG_ID_NOTIFICATION);
            mLogHandler.sendEmptyMessage(MSG_ID_NOTIFICATION);
        }
    }

    public void registerLogChangedListener(final OnLogChangedListener listener) {
        if (listener == null) return;

        mLogHandler.post(new Runnable() {
            @Override
            public void run() {
                boolean inExists = false;
                for (OnLogChangedListener _listener : mListeners) {
                    if (listener == _listener) {
                        inExists = true;
                        break;
                    }
                }

                if (!inExists) {
                    mListeners.add(listener);
                }
            }
        });
    }

    public void unregisterLogChangedListener(final OnLogChangedListener listener) {
        if (listener == null) return;
        mLogHandler.post(new Runnable() {
            @Override
            public void run() {
                int idx = -1;
                for (int i = 0; i < mListeners.size(); i++) {
                    if (mListeners.get(i) == listener) {
                        idx = i;
                        break;
                    }
                }
                if (idx >= 0) {
                    mListeners.remove(idx);
                }
            }
        });
    }

    public interface OnLogChangedListener {
        void onLogDataChanged();
    }

    public interface LOG_TYPE {
        int TYPE_MONITOR = 1;
        int TYPE_DRONE = 2;
        int TYPE_ORDER = 3;
        int TYPE_SOCKET = 4;
        int TYPE_OTHER = 5;
        int TYPE_ERROR = 6;
        int TYPE_HTTP = 7;
        int TYPE_DOWNLOAD_FILE = 8;
        int TYPE_UPLOAD_FILE = 9;
        int TYPE_VIDEO = 10;
        int TYPE_SHIP = 11;
        int TYPE_AIRCRAFT = 12;
    }

    public static final String TAG_MONITOR = "-monitor";
    public static final String TAG_DRONE = "-drone";
    public static final String TAG_SOCKET = "-socket";
    public static final String TAG_ORDER = "-order";
    public static final String TAG_OTHER = "-other";
    public static final String TAG_ERROR = "-error";
    public static final String TAG_VIDEO = "-video";
    public static final String TAG_SHIP = "-ship";
    public static final String TAG_AIRCRAFT = "-aircraft";
    public static final String TAG_HTTP = "-http";
    public static final String TAG_TEST = "@@@ ";
}
