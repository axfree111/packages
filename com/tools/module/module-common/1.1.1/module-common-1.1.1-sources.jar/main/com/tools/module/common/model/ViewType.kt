package com.tools.module.common.model

/**
 * Date: 2025/3/27
 * Desc:
 *
 * author: jaje
 */
object ViewType {
    const val FRENQUENCYRANGE_INFO: Int = 0
    const val FIGHT_CONTROL: Int = 1
}