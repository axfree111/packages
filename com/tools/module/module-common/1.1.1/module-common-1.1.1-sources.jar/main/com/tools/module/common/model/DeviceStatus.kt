package com.tools.module.common.model

/**
 * Date: 2025/3/27
 * Desc:
 *
 *
 *
 * author: jaje
 */
object DeviceStatus {
    /**
     * 自定义的状态：
     * -1 - 选中状态
     * -2 - 被入侵状态
     *
     *
     * 服务器返回的设备状态：
     * 0 - 关机
     * 1 - 开机（未工作）
     * 2 - 工作
     * 3 - 异常
     * 4 - 维护
     */
    const val SELECTED: Int = -3
    const val FIND_AVIATION: Int = -2
    const val FIND_DRONE: Int = -1

    const val POWER_OFF: Int = SwitchStatus.OFF
    const val POWER_ON: Int = SwitchStatus.ON
    const val WORK: Int = 2
    const val EXCEPTION: Int = 3
    const val MAINTAIN: Int = 4
}
