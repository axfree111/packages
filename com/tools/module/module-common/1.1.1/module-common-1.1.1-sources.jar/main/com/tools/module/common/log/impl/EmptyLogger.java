package com.tools.module.common.log.impl;

import com.tools.module.common.log.ILogger;
import com.tools.module.common.log.Level;

/**
 * EmptyLogger
 *
 * 
 * 
 */
public class EmptyLogger implements ILogger {

    @Override
    public void setLogLevel(Level level) {
    }

    @Override
    public void d(String tag, String msg) {
    }

    @Override
    public void i(String tag, String msg) {
    }

    @Override
    public void w(String tag, String msg) {
    }

    @Override
    public void e(String tag, String msg) {
    }

    @Override
    public void e(String tag, String msg, Throwable tr) {
    }

}
