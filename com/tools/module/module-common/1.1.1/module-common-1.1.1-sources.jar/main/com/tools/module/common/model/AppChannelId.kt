package com.tools.module.common.model

/**
 * Date: 2025/3/27
 * Desc:
 *
 * author: jaje
 */
object AppChannelId {
    const val SELL_ID: Int = 0
    const val POLICE_ID: Int = 1
}