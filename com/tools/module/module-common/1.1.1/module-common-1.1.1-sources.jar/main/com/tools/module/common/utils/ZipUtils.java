package com.tools.module.common.utils;

import com.tools.module.common.base.IFilter;
import com.tools.module.common.log.XLog;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * ZipUtils
 *
 * 
 * 
 */
public class ZipUtils {

    private static final String TAG = "ZipUtils";

    public static void zip(File source, File target) {
        zip(source, target, null);
    }

    @SuppressWarnings("ResultOfMethodCallIgnored")
    public static void zip(File source, File target, IFilter<File> filter) {
        if (source == null || !source.canRead()) {
            XLog.e(TAG, "zip fail invalid source=" + source);
            return;
        }
        if (target == null || target.isDirectory() || target.getAbsolutePath().endsWith(File.separator)) {
            XLog.e(TAG, "zip fail invalid target=" + target);
            return;
        }
        if (target.exists()) {
            target.delete();
        }
        if (target.getParentFile() != null) {
            target.getParentFile().mkdirs();
        }

        ZipOutputStream zipOutputStream = null;
        try {
            zipOutputStream = new ZipOutputStream(new FileOutputStream(target));
            zip(source, source.getName(), zipOutputStream, filter);
            zipOutputStream.finish();
        } catch (Exception e) {
            XLog.e(TAG, "zip fail e=" + e.getMessage());
        } finally {
            IOUtils.closeStream(zipOutputStream);
        }
    }

    private static void zip(File source, String zipEntryName, ZipOutputStream zipOutputStream, IFilter<File> filter) {
        if (filter != null && !filter.accept(source)) {
            return;
        }
        if (source.isFile()) {
            FileInputStream fis = null;
            try {
                ZipEntry zipEntry = new ZipEntry(zipEntryName);
                zipEntry.setTime(source.lastModified());
                zipOutputStream.putNextEntry(zipEntry);
                fis = new FileInputStream(source);
                IOUtils.copy(fis, zipOutputStream);
                zipOutputStream.closeEntry();
            } catch (Exception e) {
                XLog.e(TAG, "zip fail e=" + e.getMessage());
            } finally {
                IOUtils.closeStream(fis);
            }
        } else {
            File[] files = source.listFiles();
            if (files != null && files.length > 0) {
                for (File file : files) {
                    zip(file, zipEntryName + File.separator + file.getName(), zipOutputStream, filter);
                }
            } else {
                try {
                    ZipEntry zipEntry = new ZipEntry(zipEntryName + File.separator);
                    zipEntry.setTime(source.lastModified());
                    zipOutputStream.putNextEntry(zipEntry);
                    zipOutputStream.closeEntry();
                } catch (Exception e) {
                    XLog.e(TAG, "zip fail e=" + e.getMessage());
                }
            }
        }
    }

    @SuppressWarnings("ResultOfMethodCallIgnored")
    public static void unzip(File source, File target) {
        if (source == null || !source.canRead()) {
            XLog.e(TAG, "unzip fail invalid source=" + source);
            return;
        }
        if (target == null || target.isFile()) {
            XLog.e(TAG, "unzip fail invalid target=" + target);
            return;
        }

        ZipInputStream zipInputStream = null;
        ZipEntry zipEntry = null;
        try {
            zipInputStream = new ZipInputStream(new FileInputStream(source));
            zipEntry = zipInputStream.getNextEntry();
        } catch (Exception e) {
            XLog.e(TAG, "unzip fail e=" + e.getMessage());
        }
        while (zipEntry != null) {
            String zipEntryName = zipEntry.getName();
            File file = new File(target, zipEntryName);
            // "a/" -> "a.1/"
            // "a/b/c/" -> "a.1/b/c/"
            // "z.txt" -> "z.txt.1"
            // "a/b/c/z.txt" -> "a.1/b/c/z.txt"
            while (file.exists()) {
                int spIndex = zipEntryName.indexOf(File.separator);
                if (spIndex >= 0) {
                    zipEntryName = zipEntryName.substring(0, spIndex) + ".1" + File.separator + zipEntryName.substring(spIndex + 1);
                } else {
                    zipEntryName = zipEntryName + ".1";
                }
                file = new File(target, zipEntryName);
            }
            if (zipEntryName.endsWith(File.separator)) {
                try {
                    file.mkdirs();
                    zipInputStream.closeEntry();
                    zipEntry = zipInputStream.getNextEntry();
                } catch (Exception e) {
                    XLog.e(TAG, "unzip fail e=" + e.getMessage());
                    break;
                }
            } else {
                FileOutputStream fos = null;
                try {
                    file.getParentFile().mkdirs();
                    fos = new FileOutputStream(file);
                    IOUtils.copy(zipInputStream, fos);
                    file.setLastModified(zipEntry.getTime());
                    zipInputStream.closeEntry();
                    zipEntry = zipInputStream.getNextEntry();
                } catch (Exception e) {
                    XLog.e(TAG, "unzip fail e=" + e.getMessage());
                    break;
                } finally {
                    IOUtils.closeStream(fos);
                }
            }
        }

        IOUtils.closeStream(zipInputStream);
    }

}
