package com.tools.module.common.utils

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.tools.module.common.log.XLog
import java.io.File
import java.io.FileDescriptor
import java.io.OutputStream


/**
 * Package: com.tools.module.common.utils
 * Date:    2021/4/20
 * Desc:    com.tools.module.common.utils
 *
 * 
 */


fun parseUri(context: Context, mediaFile: File): Uri {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
        FileProvider.getUriForFile(context, context.packageName + ".provider", mediaFile)
    } else {
        Uri.fromFile(mediaFile)
    }
}

var connection: MediaScannerConnection? = null
fun scanFile(context: Context, path: String) {
    connection = MediaScannerConnection(context, object : MediaScannerConnection.MediaScannerConnectionClient {
        override fun onMediaScannerConnected() {
            if (connection!!.isConnected) {
                MediaScannerConnection.scanFile(
                        context,
                        arrayOf(path),
                        arrayOf(MimeUtils.matchMimeTypeFromExtension(path))
                )
                { path,
                  uri ->
                    XLog.d("scanFile", "path" + path + "uri" + uri)
                }
            }
        }

        override fun onScanCompleted(path: String?, uri: Uri?) {
            XLog.d("scanFile", "path" + path + "uri" + uri)
        }

    })

    connection?.connect()

}

fun saveToMediaImage(context: Context, file: File, relativePath: String, fileName: String, fileDescription: String?, mimeType: String) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        val values = ContentValues()
        values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
        values.put(MediaStore.Images.Media.DESCRIPTION, fileDescription)
        values.put(MediaStore.Images.Media.MIME_TYPE, mimeType)
        values.put(MediaStore.Images.Media.RELATIVE_PATH, relativePath)
        val insertUri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        var outputStream: OutputStream? = null
        if (insertUri != null) {
            outputStream = context.contentResolver.openOutputStream(insertUri)
            val input = file.inputStream()
            android.os.FileUtils.copy(input, outputStream!!)
        }
        outputStream?.close()
    }
}

fun saveToMediaVideo(context: Context, file: File, relativePath: String, fileName: String, fileDescription: String?, mimeType: String) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        val values = ContentValues()
        values.put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
        values.put(MediaStore.Video.Media.DESCRIPTION, fileDescription)
        values.put(MediaStore.Video.Media.MIME_TYPE, mimeType)
        values.put(MediaStore.Video.Media.RELATIVE_PATH, relativePath)
        val insertUri = context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
        var outputStream: OutputStream? = null
        if (insertUri != null) {
            outputStream = context.contentResolver.openOutputStream(insertUri)
            val input = file.inputStream()
            android.os.FileUtils.copy(input, outputStream!!)
        }
        outputStream?.close()
    }
}

// 通过uri获取bitmap
fun getBitmapFromUri(context: Context, uri: Uri?): Bitmap? {
    try {
        val parcelFileDescriptor = context.contentResolver.openFileDescriptor(uri!!, "r")
        val fileDescriptor: FileDescriptor = parcelFileDescriptor!!.fileDescriptor
        val image = BitmapFactory.decodeFileDescriptor(fileDescriptor)
        parcelFileDescriptor.close()
        return image
    } catch (e: Exception) {
        e.printStackTrace()
    }
    return null
}


