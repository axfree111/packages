package com.tools.module.common.ext

import com.tools.module.common.utils.FormatUtils
import java.math.RoundingMode

/**
 * KotlinLangExt
 *
 * 
 * 
 */

fun <R> ensureNotNull(vararg args: Any?, block: () -> R) =
        when (args.filterNotNull().size) {
            args.size -> block()
            else -> null
        }

fun ensureNotNull(vararg args: Any?) : Boolean =
        when (args.filterNotNull().size) {
            args.size -> true
            else -> false
        }

fun <R> ensureAnyNull(vararg args: Any?, block: () -> R) =
        when (args.filterNotNull().size) {
            args.size -> null
            else -> block()
        }

fun ensureAnyNull(vararg args: Any?) : Boolean =
        when (args.filterNotNull().size) {
            args.size -> false
            else -> true
        }



fun <V> condition(condition: Boolean, trueValue: V?, falseValue: V?) : V? =
        when (condition) {
            true -> trueValue
            false -> falseValue
        }

fun <V> condition(block: () -> Boolean, trueValue: V?, falseValue: V?) : V? =
        when (block()) {
            true -> trueValue
            false -> falseValue
        }


data class Tuple1<T1>(val t1: T1)
data class Tuple2<T1, T2>(val t1: T1, val t2: T2)
data class Tuple3<T1, T2, T3>(val t1: T1, val t2: T2, val t3: T3)
data class Tuple4<T1, T2, T3, T4>(val t1: T1, val t2: T2, val t3: T3, val t4: T4)
data class Tuple5<T1, T2, T3, T4, T5>(val t1: T1, val t2: T2, val t3: T3, val t4: T4, val t5: T5)
data class Tuple6<T1, T2, T3, T4, T5, T6>(val t1: T1, val t2: T2, val t3: T3, val t4: T4, val t5: T5, val t6: T6)
data class Tuple7<T1, T2, T3, T4, T5, T6, T7>(val t1: T1, val t2: T2, val t3: T3, val t4: T4, val t5: T5, val t6: T6, val t7: T7)
data class Tuple8<T1, T2, T3, T4, T5, T6, T7, T8>(val t1: T1, val t2: T2, val t3: T3, val t4: T4, val t5: T5, val t6: T6, val t7: T7, val t8: T8)
data class Tuple9<T1, T2, T3, T4, T5, T6, T7, T8, T9>(val t1: T1, val t2: T2, val t3: T3, val t4: T4, val t5: T5, val t6: T6, val t7: T7, val t8: T8, val t9: T9)
data class Tuple10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10>(val t1: T1, val t2: T2, val t3: T3, val t4: T4, val t5: T5, val t6: T6, val t7: T7, val t8: T8, val t9: T9, val t10: T10)



inline fun <T1: Any> guardLet(p1: T1?, block: () -> Nothing): Tuple1<T1> {
    return if (p1 != null) {
        Tuple1(p1)
    } else {
        block()
    }
}

inline fun <T1: Any, T2: Any> guardLet(p1: T1?, p2: T2?, block: () -> Nothing): Tuple2<T1, T2> {
    return if (p1 != null && p2 != null) {
        Tuple2(p1, p2)
    } else {
        block()
    }
}

inline fun <T1: Any, T2: Any, T3: Any> guardLet(p1: T1?, p2: T2?, p3: T3?, block: () -> Nothing): Tuple3<T1, T2, T3> {
    return if (p1 != null && p2 != null && p3 != null) {
        Tuple3(p1, p2, p3)
    } else {
        block()
    }
}

inline fun <T1: Any, T2: Any, T3: Any, T4: Any> guardLet(p1: T1?, p2: T2?, p3: T3?, p4: T4?, block: () -> Nothing): Tuple4<T1, T2, T3, T4> {
    return if (p1 != null && p2 != null && p3 != null && p4 != null) {
        Tuple4(p1, p2, p3, p4)
    } else {
        block()
    }
}

inline fun <T1: Any, T2: Any, T3: Any, T4: Any, T5: Any> guardLet(p1: T1?, p2: T2?, p3: T3?, p4: T4?, p5: T5?, block: () -> Nothing): Tuple5<T1, T2, T3, T4, T5> {
    return if (p1 != null && p2 != null && p3 != null && p4 != null && p5 != null) {
        Tuple5(p1, p2, p3, p4, p5)
    } else {
        block()
    }
}

inline fun <T1: Any, T2: Any, T3: Any, T4: Any, T5: Any, T6: Any> guardLet(p1: T1?, p2: T2?, p3: T3?, p4: T4?, p5: T5?, p6: T6?, block: () -> Nothing): Tuple6<T1, T2, T3, T4, T5, T6> {
    return if (p1 != null && p2 != null && p3 != null && p4 != null && p5 != null && p6 != null) {
        Tuple6(p1, p2, p3, p4, p5, p6)
    } else {
        block()
    }
}

inline fun <T1: Any, T2: Any, T3: Any, T4: Any, T5: Any, T6: Any, T7: Any> guardLet(p1: T1?, p2: T2?, p3: T3?, p4: T4?, p5: T5?, p6: T6?, p7: T7?, block: () -> Nothing): Tuple7<T1, T2, T3, T4, T5, T6, T7> {
    return if (p1 != null && p2 != null && p3 != null && p4 != null && p5 != null && p6 != null && p7 != null) {
        Tuple7(p1, p2, p3, p4, p5, p6, p7)
    } else {
        block()
    }
}

inline fun <T1: Any, T2: Any, T3: Any, T4: Any, T5: Any, T6: Any, T7: Any, T8: Any> guardLet(p1: T1?, p2: T2?, p3: T3?, p4: T4?, p5: T5?, p6: T6?, p7: T7?, p8: T8?, block: () -> Nothing): Tuple8<T1, T2, T3, T4, T5, T6, T7, T8> {
    return if (p1 != null && p2 != null && p3 != null && p4 != null && p5 != null && p6 != null && p7 != null && p8 != null) {
        Tuple8(p1, p2, p3, p4, p5, p6, p7, p8)
    } else {
        block()
    }
}

inline fun <T1: Any, T2: Any, T3: Any, T4: Any, T5: Any, T6: Any, T7: Any, T8: Any, T9: Any> guardLet(p1: T1?, p2: T2?, p3: T3?, p4: T4?, p5: T5?, p6: T6?, p7: T7?, p8: T8?, p9: T9?, block: () -> Nothing): Tuple9<T1, T2, T3, T4, T5, T6, T7, T8, T9> {
    return if (p1 != null && p2 != null && p3 != null && p4 != null && p5 != null && p6 != null && p7 != null && p8 != null && p9 != null) {
        Tuple9(p1, p2, p3, p4, p5, p6, p7, p8, p9)
    } else {
        block()
    }
}

inline fun <T1: Any, T2: Any, T3: Any, T4: Any, T5: Any, T6: Any, T7: Any, T8: Any, T9: Any, T10: Any> guardLet(p1: T1?, p2: T2?, p3: T3?, p4: T4?, p5: T5?, p6: T6?, p7: T7?, p8: T8?, p9: T9?, p10: T10?, block: () -> Nothing): Tuple10<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10> {
    return if (p1 != null && p2 != null && p3 != null && p4 != null && p5 != null && p6 != null && p7 != null && p8 != null && p9 != null && p10 != null) {
        Tuple10(p1, p2, p3, p4, p5, p6, p7, p8, p9, p10)
    } else {
        block()
    }
}

inline fun <T1: Any, R> ifLet(p1: T1?, block: (T1) -> R): R? {
    return if (p1 != null) {
        block(p1)
    } else {
        null
    }
}

inline fun <T1: Any, T2: Any, R> ifLet(p1: T1?, p2: T2?, block: (T1, T2) -> R): R? {
    return if (p1 != null && p2 != null) {
        block(p1, p2)
    } else {
        null
    }
}

inline fun <T1: Any, T2: Any, T3: Any, R> ifLet(p1: T1?, p2: T2?, p3: T3?, block: (T1, T2, T3) -> R): R? {
    return if (p1 != null && p2 != null && p3 != null) {
        block(p1, p2, p3)
    } else {
        null
    }
}

inline fun <T1: Any, T2: Any, T3: Any, T4: Any, R> ifLet(p1: T1?, p2: T2?, p3: T3?, p4: T4?, block: (T1, T2, T3, T4) -> R): R? {
    return if (p1 != null && p2 != null && p3 != null && p4 != null) {
        block(p1, p2, p3, p4)
    } else {
        null
    }
}

inline fun <T1: Any, T2: Any, T3: Any, T4: Any, T5: Any, R> ifLet(p1: T1?, p2: T2?, p3: T3?, p4: T4?, p5: T5?, block: (T1, T2, T3, T4, T5) -> R): R? {
    return if (p1 != null && p2 != null && p3 != null && p4 != null && p5 != null) {
        block(p1, p2, p3, p4, p5)
    } else {
        null
    }
}

inline fun <T1: Any, T2: Any, T3: Any, T4: Any, T5: Any, T6: Any, R> ifLet(p1: T1?, p2: T2?, p3: T3?, p4: T4?, p5: T5?, p6: T6?, block: (T1, T2, T3, T4, T5, T6) -> R): R? {
    return if (p1 != null && p2 != null && p3 != null && p4 != null && p5 != null && p6 != null) {
        block(p1, p2, p3, p4, p5, p6)
    } else {
        null
    }
}

inline fun <T1: Any, T2: Any, T3: Any, T4: Any, T5: Any, T6: Any, T7: Any, R> ifLet(p1: T1?, p2: T2?, p3: T3?, p4: T4?, p5: T5?, p6: T6?, p7: T7?, block: (T1, T2, T3, T4, T5, T6, T7) -> R): R? {
    return if (p1 != null && p2 != null && p3 != null && p4 != null && p5 != null && p6 != null && p7 != null) {
        block(p1, p2, p3, p4, p5, p6, p7)
    } else {
        null
    }
}

inline fun <T1: Any, T2: Any, T3: Any, T4: Any, T5: Any, T6: Any, T7: Any, T8: Any, R> ifLet(p1: T1?, p2: T2?, p3: T3?, p4: T4?, p5: T5?, p6: T6?, p7: T7?, p8: T8?, block: (T1, T2, T3, T4, T5, T6, T7, T8) -> R): R? {
    return if (p1 != null && p2 != null && p3 != null && p4 != null && p5 != null && p6 != null && p7 != null && p8 != null) {
        block(p1, p2, p3, p4, p5, p6, p7, p8)
    } else {
        null
    }
}

inline fun <T1: Any, T2: Any, T3: Any, T4: Any, T5: Any, T6: Any, T7: Any, T8: Any, T9: Any, R> ifLet(p1: T1?, p2: T2?, p3: T3?, p4: T4?, p5: T5?, p6: T6?, p7: T7?, p8: T8?, p9: T9?, block: (T1, T2, T3, T4, T5, T6, T7, T8, T9) -> R): R? {
    return if (p1 != null && p2 != null && p3 != null && p4 != null && p5 != null && p6 != null && p7 != null && p8 != null && p9 != null) {
        block(p1, p2, p3, p4, p5, p6, p7, p8, p9)
    } else {
        null
    }
}

inline fun <T1: Any, T2: Any, T3: Any, T4: Any, T5: Any, T6: Any, T7: Any, T8: Any, T9: Any, T10: Any, R> ifLet(p1: T1?, p2: T2?, p3: T3?, p4: T4?, p5: T5?, p6: T6?, p7: T7?, p8: T8?, p9: T9?, p10: T10?, block: (T1, T2, T3, T4, T5, T6, T7, T8, T9, T10) -> R): R? {
    return if (p1 != null && p2 != null && p3 != null && p4 != null && p5 != null && p6 != null && p7 != null && p8 != null && p9 != null && p10 != null) {
        block(p1, p2, p3, p4, p5, p6, p7, p8, p9, p10)
    } else {
        null
    }
}



@JvmOverloads
fun byteToMb(size: Long, scale: Int = 1): Double {
    val kb = 1024
    val mb = 1024 * kb
    val tmp = size.toDouble() / mb
    return tmp.toBigDecimal().setScale(scale, RoundingMode.HALF_UP).toDouble()
}

fun String.toIntSafely(defaultValue: Int): Int {
    try {
        return Integer.parseInt(this)
    } catch (ignored: Exception) {
        return defaultValue
    }
}

fun String.toLongSafely(defaultValue: Long): Long {
    try {
        return java.lang.Long.parseLong(this)
    } catch (ignored: Exception) {
        return defaultValue
    }
}

fun Boolean.toInt(): Int {
    return if (this) 1 else 0
}

data class MutablePair<A, B>(var first: A, var second: B) {
    override fun toString(): String = "($first, $second)"
}

data class MutableTriple<A, B, C>(var first: A, var second: B, var third: C) {
    override fun toString(): String = "($first, $second, $third)"
}

fun Long.formatDataTime(): String {
    return FormatUtils.formatDateTime(this)
}
