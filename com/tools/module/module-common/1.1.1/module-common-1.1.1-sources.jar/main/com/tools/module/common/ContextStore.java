package com.tools.module.common;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.ComponentCallbacks;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.IntentSender;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.UserHandle;
import android.util.Log;
import android.view.Display;
import android.view.View;

import com.tools.module.common.utils.TextUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import androidx.annotation.Keep;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.content.ContextCompat;

/**
 * ContextStore
 *
 * 
 * 
 */
@Keep //在android_env.cpp中会反射用到，需要@keep
public class ContextStore {

    @SuppressLint("StaticFieldLeak")
    private static volatile Context sContext;
    private static volatile String sApplicationId;
    private static volatile Boolean sDebugMode = null;
    private static volatile File sExternalFilesDir = null;

    public static void setContext(Context context) {
        if (context != null) {
            sContext = context.getApplicationContext();
            sApplicationId = context.getPackageName();
        }
    }

    /**
     * View在EditMode（预览模式）下初始化ContextStore，以解决依赖ContextStore初始化导致预览失败
     */
    public static void setContextInEditMode(View view) {
        if (getContext() == null && view != null && view.isInEditMode()) {
            setContext(view.getContext().getApplicationContext());
        }
    }

    public static Context getContext() {
        return sContext;
    }

    public static Context getDeviceProtectedStorageContext() {
        return getDeviceProtectedStorageContext(sContext);
    }

    public static Context getDeviceProtectedStorageContext(Context context) {
        return new DeviceProtectedStorageContextWrapper(context);
    }

    public static String getApplicationId() {
        return sApplicationId;
    }

    public static boolean isDebugMode() {
        if (sDebugMode == null) {
            try {
                sDebugMode = (sContext.getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0;
            } catch (Exception ignored) {
                sDebugMode = false;
            }
        }
        return sDebugMode;
    }

    public static boolean isMainProcess() {
        return TextUtils.equals(getCurrentProcessName(), getApplicationId());
    }

    public static String getCurrentProcessName() {
        final int pid = android.os.Process.myPid();
        final ActivityManager manager = (ActivityManager) getContext().getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> processList = manager.getRunningAppProcesses();
        if (processList != null) {
            for (ActivityManager.RunningAppProcessInfo process : processList) {
                if (process.pid == pid) {
                    return process.processName;
                }
            }
        }

        return "";
    }

    @SuppressWarnings("ResultOfMethodCallIgnored")
    public static File getExternalFilesDir() {
        if (sExternalFilesDir == null) {
            String subDir = ".drone" + File.separator + getApplicationId();
            sExternalFilesDir = new File(Environment.getExternalStorageDirectory(), subDir);
            sExternalFilesDir.mkdirs();
        }
        return sExternalFilesDir;
    }



    static class DeviceProtectedStorageContextWrapper extends Context {
        private final Context mBaseContext;
        private final Context mAppContext;

        DeviceProtectedStorageContextWrapper(Context context) {
            Log.d("scontext", "DeviceProtectedStorageContextWrapper trace=" + Log.getStackTraceString(new Throwable()));
            mBaseContext = ContextCompat.createDeviceProtectedStorageContext(context);
            mAppContext = ContextCompat.createDeviceProtectedStorageContext(context.getApplicationContext());
        }

        @Override
        public AssetManager getAssets() {
            return mBaseContext.getAssets();
        }

        @Override
        public Resources getResources() {
            return mBaseContext.getResources();
        }

        @Override
        public PackageManager getPackageManager() {
            return mBaseContext.getPackageManager();
        }

        @Override
        public ContentResolver getContentResolver() {
            return mBaseContext.getContentResolver();
        }

        @Override
        public Looper getMainLooper() {
            return mBaseContext.getMainLooper();
        }

        @Override
        public Context getApplicationContext() {
            //要俄罗斯套娃，避免sdk内部context传参之后再getApplicationContext
            return new DeviceProtectedStorageContextWrapper(mAppContext);
        }

        @Override
        public void setTheme(int resid) {
            mBaseContext.setTheme(resid);
        }

        @Override
        public Resources.Theme getTheme() {
            return mBaseContext.getTheme();
        }

        @Override
        public ClassLoader getClassLoader() {
            return mBaseContext.getClassLoader();
        }

        @Override
        public String getPackageName() {
            return mBaseContext.getPackageName();
        }

        @Override
        public ApplicationInfo getApplicationInfo() {
            return mBaseContext.getApplicationInfo();
        }

        @Override
        public String getPackageResourcePath() {
            return mBaseContext.getPackageResourcePath();
        }

        @Override
        public String getPackageCodePath() {
            return mBaseContext.getPackageCodePath();
        }

        @Override
        public SharedPreferences getSharedPreferences(String name, int mode) {
            return mBaseContext.getSharedPreferences(name, mode);
        }

        @RequiresApi(api = Build.VERSION_CODES.N)
        @Override
        public boolean moveSharedPreferencesFrom(Context sourceContext, String name) {
            return mBaseContext.moveSharedPreferencesFrom(sourceContext, name);
        }

        @RequiresApi(api = Build.VERSION_CODES.N)
        @Override
        public boolean deleteSharedPreferences(String name) {
            return mBaseContext.deleteSharedPreferences(name);
        }

        @Override
        public FileInputStream openFileInput(String name) throws FileNotFoundException {
            return mBaseContext.openFileInput(name);
        }

        @Override
        public FileOutputStream openFileOutput(String name, int mode) throws FileNotFoundException {
            return mBaseContext.openFileOutput(name, mode);
        }

        @Override
        public boolean deleteFile(String name) {
            return mBaseContext.deleteFile(name);
        }

        @Override
        public File getFileStreamPath(String name) {
            return mBaseContext.getFileStreamPath(name);
        }

        @RequiresApi(api = Build.VERSION_CODES.N)
        @Override
        public File getDataDir() {
            return mBaseContext.getDataDir();
        }

        @Override
        public File getFilesDir() {
            return mBaseContext.getFilesDir();
        }

        @Override
        public File getNoBackupFilesDir() {
            return mBaseContext.getNoBackupFilesDir();
        }

        @Nullable
        @Override
        public File getExternalFilesDir(@Nullable String type) {
            return mBaseContext.getExternalFilesDir(type);
        }

        @Override
        public File[] getExternalFilesDirs(String type) {
            return mBaseContext.getExternalFilesDirs(type);
        }

        @Override
        public File getObbDir() {
            return mBaseContext.getObbDir();
        }

        @Override
        public File[] getObbDirs() {
            return mBaseContext.getObbDirs();
        }

        @Override
        public File getCacheDir() {
            return mBaseContext.getCacheDir();
        }

        @Override
        public File getCodeCacheDir() {
            return mBaseContext.getCodeCacheDir();
        }

        @Nullable
        @Override
        public File getExternalCacheDir() {
            return mBaseContext.getExternalCacheDir();
        }

        @Override
        public File[] getExternalCacheDirs() {
            return mBaseContext.getExternalCacheDirs();
        }

        @Override
        public File[] getExternalMediaDirs() {
            return mBaseContext.getExternalMediaDirs();
        }

        @Override
        public String[] fileList() {
            return mBaseContext.fileList();
        }

        @Override
        public File getDir(String name, int mode) {
            return mBaseContext.getDir(name, mode);
        }

        @Override
        public SQLiteDatabase openOrCreateDatabase(String name, int mode, SQLiteDatabase.CursorFactory factory) {
            return mBaseContext.openOrCreateDatabase(name, mode, factory);
        }

        @Override
        public SQLiteDatabase openOrCreateDatabase(String name, int mode, SQLiteDatabase.CursorFactory factory, @Nullable DatabaseErrorHandler errorHandler) {
            return mBaseContext.openOrCreateDatabase(name, mode, factory, errorHandler);
        }

        @RequiresApi(api = Build.VERSION_CODES.N)
        @Override
        public boolean moveDatabaseFrom(Context sourceContext, String name) {
            return mBaseContext.moveDatabaseFrom(sourceContext, name);
        }

        @Override
        public boolean deleteDatabase(String name) {
            return mBaseContext.deleteDatabase(name);
        }

        @Override
        public File getDatabasePath(String name) {
            return mBaseContext.getDatabasePath(name);
        }

        @Override
        public String[] databaseList() {
            return mBaseContext.databaseList();
        }

        @Override
        public Drawable getWallpaper() {
            return mBaseContext.getWallpaper();
        }

        @Override
        public Drawable peekWallpaper() {
            return mBaseContext.peekWallpaper();
        }

        @Override
        public int getWallpaperDesiredMinimumWidth() {
            return mBaseContext.getWallpaperDesiredMinimumWidth();
        }

        @Override
        public int getWallpaperDesiredMinimumHeight() {
            return mBaseContext.getWallpaperDesiredMinimumHeight();
        }

        @Override
        public void setWallpaper(Bitmap bitmap) throws IOException {
            mBaseContext.setWallpaper(bitmap);
        }

        @Override
        public void setWallpaper(InputStream data) throws IOException {
            mBaseContext.setWallpaper(data);
        }

        @Override
        public void clearWallpaper() throws IOException {
            mBaseContext.clearWallpaper();
        }

        @Override
        public void startActivity(Intent intent) {
            mBaseContext.startActivity(intent);
        }

        @Override
        public void startActivity(Intent intent, @Nullable Bundle options) {
            mBaseContext.startActivity(intent, options);
        }

        @Override
        public void startActivities(Intent[] intents) {
            mBaseContext.startActivities(intents);
        }

        @Override
        public void startActivities(Intent[] intents, Bundle options) {
            mBaseContext.startActivities(intents, options);
        }

        @Override
        public void startIntentSender(IntentSender intent, @Nullable Intent fillInIntent, int flagsMask, int flagsValues, int extraFlags) throws IntentSender.SendIntentException {
            mBaseContext.startIntentSender(intent, fillInIntent, flagsMask, flagsValues, extraFlags);
        }

        @Override
        public void startIntentSender(IntentSender intent, @Nullable Intent fillInIntent, int flagsMask, int flagsValues, int extraFlags, @Nullable Bundle options) throws IntentSender.SendIntentException {
            mBaseContext.startIntentSender(intent, fillInIntent, flagsMask, flagsValues, extraFlags, options);
        }

        @Override
        public void sendBroadcast(Intent intent) {
            mBaseContext.sendBroadcast(intent);
        }

        @Override
        public void sendBroadcast(Intent intent, @Nullable String receiverPermission) {
            mBaseContext.sendBroadcast(intent, receiverPermission);
        }

        @Override
        public void sendOrderedBroadcast(Intent intent, @Nullable String receiverPermission) {
            mBaseContext.sendOrderedBroadcast(intent, receiverPermission);
        }

        @Override
        public void sendOrderedBroadcast(@NonNull Intent intent, @Nullable String receiverPermission, @Nullable BroadcastReceiver resultReceiver, @Nullable Handler scheduler, int initialCode, @Nullable String initialData, @Nullable Bundle initialExtras) {
            mBaseContext.sendOrderedBroadcast(intent, receiverPermission, resultReceiver, scheduler, initialCode, initialData, initialExtras);
        }

        @SuppressLint("MissingPermission")
        @Override
        public void sendBroadcastAsUser(Intent intent, UserHandle user) {
            mBaseContext.sendBroadcastAsUser(intent, user);
        }

        @SuppressLint("MissingPermission")
        @Override
        public void sendBroadcastAsUser(Intent intent, UserHandle user, @Nullable String receiverPermission) {
            mBaseContext.sendBroadcastAsUser(intent, user, receiverPermission);
        }

        @SuppressLint("MissingPermission")
        @Override
        public void sendOrderedBroadcastAsUser(Intent intent, UserHandle user, @Nullable String receiverPermission, BroadcastReceiver resultReceiver, @Nullable Handler scheduler, int initialCode, @Nullable String initialData, @Nullable Bundle initialExtras) {
            mBaseContext.sendOrderedBroadcastAsUser(intent, user, receiverPermission, resultReceiver, scheduler, initialCode, initialData, initialExtras);
        }

        @SuppressLint("MissingPermission")
        @Override
        public void sendStickyBroadcast(Intent intent) {
            mBaseContext.sendStickyBroadcast(intent);
        }

        @SuppressLint("MissingPermission")
        @Override
        public void sendStickyOrderedBroadcast(Intent intent, BroadcastReceiver resultReceiver, @Nullable Handler scheduler, int initialCode, @Nullable String initialData, @Nullable Bundle initialExtras) {
            mBaseContext.sendStickyOrderedBroadcast(intent, resultReceiver, scheduler, initialCode, initialData, initialExtras);
        }

        @SuppressLint("MissingPermission")
        @Override
        public void removeStickyBroadcast(Intent intent) {
            mBaseContext.removeStickyBroadcast(intent);
        }

        @SuppressLint("MissingPermission")
        @Override
        public void sendStickyBroadcastAsUser(Intent intent, UserHandle user) {
            mBaseContext.sendStickyBroadcastAsUser(intent, user);
        }

        @SuppressLint("MissingPermission")
        @Override
        public void sendStickyOrderedBroadcastAsUser(Intent intent, UserHandle user, BroadcastReceiver resultReceiver, @Nullable Handler scheduler, int initialCode, @Nullable String initialData, @Nullable Bundle initialExtras) {
            mBaseContext.sendStickyOrderedBroadcastAsUser(intent, user, resultReceiver, scheduler, initialCode, initialData, initialExtras);
        }

        @SuppressLint("MissingPermission")
        @Override
        public void removeStickyBroadcastAsUser(Intent intent, UserHandle user) {
            mBaseContext.removeStickyBroadcastAsUser(intent, user);
        }

        @Nullable
        @Override
        public Intent registerReceiver(@Nullable BroadcastReceiver receiver, IntentFilter filter) {
            return mBaseContext.registerReceiver(receiver, filter);
        }

        @RequiresApi(api = Build.VERSION_CODES.O)
        @Nullable
        @Override
        public Intent registerReceiver(@Nullable BroadcastReceiver receiver, IntentFilter filter, int flags) {
            return mBaseContext.registerReceiver(receiver, filter, flags);
        }

        @Nullable
        @Override
        public Intent registerReceiver(BroadcastReceiver receiver, IntentFilter filter, @Nullable String broadcastPermission, @Nullable Handler scheduler) {
            return mBaseContext.registerReceiver(receiver, filter, broadcastPermission, scheduler);
        }

        @RequiresApi(api = Build.VERSION_CODES.O)
        @Nullable
        @Override
        public Intent registerReceiver(BroadcastReceiver receiver, IntentFilter filter, @Nullable String broadcastPermission, @Nullable Handler scheduler, int flags) {
            return mBaseContext.registerReceiver(receiver, filter, broadcastPermission, scheduler, flags);
        }

        @Override
        public void unregisterReceiver(BroadcastReceiver receiver) {
            mBaseContext.unregisterReceiver(receiver);
        }

        @Nullable
        @Override
        public ComponentName startService(Intent service) {
            return mBaseContext.startService(service);
        }

        @RequiresApi(api = Build.VERSION_CODES.O)
        @Nullable
        @Override
        public ComponentName startForegroundService(Intent service) {
            return mBaseContext.startForegroundService(service);
        }

        @Override
        public boolean stopService(Intent service) {
            return mBaseContext.stopService(service);
        }

        @Override
        public boolean bindService(Intent service, @NonNull ServiceConnection conn, int flags) {
            return mBaseContext.bindService(service, conn, flags);
        }

        @Override
        public void unbindService(@NonNull ServiceConnection conn) {
            mBaseContext.unbindService(conn);
        }

        @Override
        public boolean startInstrumentation(@NonNull ComponentName className, @Nullable String profileFile, @Nullable Bundle arguments) {
            return mBaseContext.startInstrumentation(className, profileFile, arguments);
        }

        @Override
        public Object getSystemService(@NonNull String name) {
            return mBaseContext.getSystemService(name);
        }

        @RequiresApi(api = Build.VERSION_CODES.M)
        @Nullable
        @Override
        public String getSystemServiceName(@NonNull Class<?> serviceClass) {
            return mBaseContext.getSystemServiceName(serviceClass);
        }

        @Override
        public int checkPermission(@NonNull String permission, int pid, int uid) {
            return mBaseContext.checkPermission(permission, pid, uid);
        }

        @Override
        public int checkCallingPermission(@NonNull String permission) {
            return mBaseContext.checkCallingPermission(permission);
        }

        @Override
        public int checkCallingOrSelfPermission(@NonNull String permission) {
            return mBaseContext.checkCallingPermission(permission);
        }

        @RequiresApi(api = Build.VERSION_CODES.M)
        @Override
        public int checkSelfPermission(@NonNull String permission) {
            return mBaseContext.checkSelfPermission(permission);
        }

        @Override
        public void enforcePermission(@NonNull String permission, int pid, int uid, @Nullable String message) {
            mBaseContext.enforcePermission(permission, pid, uid, message);
        }

        @Override
        public void enforceCallingPermission(@NonNull String permission, @Nullable String message) {
            mBaseContext.enforceCallingPermission(permission, message);
        }

        @Override
        public void enforceCallingOrSelfPermission(@NonNull String permission, @Nullable String message) {
            mBaseContext.enforceCallingOrSelfPermission(permission, message);
        }

        @Override
        public void grantUriPermission(String toPackage, Uri uri, int modeFlags) {
            mBaseContext.grantUriPermission(toPackage, uri, modeFlags);
        }

        @Override
        public void revokeUriPermission(Uri uri, int modeFlags) {
            mBaseContext.revokeUriPermission(uri, modeFlags);
        }

        @RequiresApi(api = Build.VERSION_CODES.O)
        @Override
        public void revokeUriPermission(String toPackage, Uri uri, int modeFlags) {
            mBaseContext.revokeUriPermission(toPackage, uri, modeFlags);
        }

        @Override
        public int checkUriPermission(Uri uri, int pid, int uid, int modeFlags) {
            return mBaseContext.checkUriPermission(uri, pid, uid, modeFlags);
        }

        @Override
        public int checkCallingUriPermission(Uri uri, int modeFlags) {
            return mBaseContext.checkCallingUriPermission(uri, modeFlags);
        }

        @Override
        public int checkCallingOrSelfUriPermission(Uri uri, int modeFlags) {
            return mBaseContext.checkCallingOrSelfUriPermission(uri, modeFlags);
        }

        @Override
        public int checkUriPermission(@Nullable Uri uri, @Nullable String readPermission, @Nullable String writePermission, int pid, int uid, int modeFlags) {
            return mBaseContext.checkUriPermission(uri, readPermission, writePermission, pid, uid, modeFlags);
        }

        @Override
        public void enforceUriPermission(Uri uri, int pid, int uid, int modeFlags, String message) {
            mBaseContext.enforceUriPermission(uri, pid, uid, modeFlags, message);
        }

        @Override
        public void enforceCallingUriPermission(Uri uri, int modeFlags, String message) {
            mBaseContext.enforceCallingUriPermission(uri, modeFlags, message);
        }

        @Override
        public void enforceCallingOrSelfUriPermission(Uri uri, int modeFlags, String message) {
            mBaseContext.enforceCallingOrSelfUriPermission(uri, modeFlags, message);
        }

        @Override
        public void enforceUriPermission(@Nullable Uri uri, @Nullable String readPermission, @Nullable String writePermission, int pid, int uid, int modeFlags, @Nullable String message) {
            mBaseContext.enforceUriPermission(uri, readPermission, writePermission, pid, uid, modeFlags, message);
        }

        @Override
        public Context createPackageContext(String packageName, int flags) throws PackageManager.NameNotFoundException {
            return new DeviceProtectedStorageContextWrapper(mBaseContext.createPackageContext(packageName, flags));
        }

        @RequiresApi(api = Build.VERSION_CODES.O)
        @Override
        public Context createContextForSplit(String splitName) throws PackageManager.NameNotFoundException {
            return new DeviceProtectedStorageContextWrapper(mBaseContext.createContextForSplit(splitName));
        }

        @Override
        public Context createConfigurationContext(@NonNull Configuration overrideConfiguration) {
            return new DeviceProtectedStorageContextWrapper(mBaseContext.createConfigurationContext(overrideConfiguration));
        }

        @Override
        public Context createDisplayContext(@NonNull Display display) {
            return new DeviceProtectedStorageContextWrapper(mBaseContext.createDisplayContext(display));
        }

        @RequiresApi(api = Build.VERSION_CODES.N)
        @Override
        public Context createDeviceProtectedStorageContext() {
            return new DeviceProtectedStorageContextWrapper(mBaseContext.createDeviceProtectedStorageContext());
        }

        @RequiresApi(api = Build.VERSION_CODES.N)
        @Override
        public boolean isDeviceProtectedStorage() {
            return mBaseContext.isDeviceProtectedStorage();
        }

        @Override
        public void registerComponentCallbacks(ComponentCallbacks callback) {
            //这里要直接调用mAppContext的方法，super的registerComponentCallbacks会导致无限递归进而OOM
            mAppContext.registerComponentCallbacks(callback);
        }

        @Override
        public void unregisterComponentCallbacks(ComponentCallbacks callback) {
            //这里要直接调用mAppContext的方法，super的unregisterComponentCallbacks会导致无限递归进而OOM
            mAppContext.unregisterComponentCallbacks(callback);
        }
    }

}
