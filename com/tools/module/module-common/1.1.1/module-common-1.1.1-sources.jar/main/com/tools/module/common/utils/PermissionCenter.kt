package com.tools.module.common.utils

import android.Manifest
import android.app.Activity
import android.app.Application
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.result.ActivityResultLauncher
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.tools.module.common.BasePrefs
import com.tools.module.common.ext.ensureAnyNull

/**
 * PermissonCenter
 *
 * 
 * 
 */
object PermissionCenter {

    private const val PREFS_KEY_FIRST_REQUEST_PERMISSION = "first_request_permission_"

    private const val PERMISSIONS_REQUEST_AUDIO = 2
    val PERMISSIONS_AUDIO = arrayOf(
        Manifest.permission.MODIFY_AUDIO_SETTINGS,
        Manifest.permission.RECORD_AUDIO
    )

    private const val PERMISSIONS_REQUEST_LOCATION = 3
    val PERMISSIONS_LOCATION = arrayOf(
        Manifest.permission.ACCESS_COARSE_LOCATION,
        Manifest.permission.ACCESS_FINE_LOCATION
    )

    private const val PERMISSIONS_REQUEST_STORAGE = 4
    val PERMISSIONS_STORAGE: Array<String> = arrayOf(
        Manifest.permission.WRITE_EXTERNAL_STORAGE,
    )

    val PERMISSIONS_CAMERA: Array<String> = arrayOf(
        Manifest.permission.CAMERA,
    )

    val PERMISSIONS_CAMERA_STORAGE: Array<String> = arrayOf(
        Manifest.permission.CAMERA,
        Manifest.permission.WRITE_EXTERNAL_STORAGE,
    )

    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    val PERMISSIONS_NOTIFICATIONS: Array<String> = arrayOf(
        Manifest.permission.POST_NOTIFICATIONS,
    )

    // https://developer.android.com/google/play/requirements/target-sdk#pre12
    val PERMISSIONS_BLUETOOTH = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        arrayOf(
                Manifest.permission.BLUETOOTH,
                Manifest.permission.BLUETOOTH_ADMIN,
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_ADVERTISE,
                Manifest.permission.BLUETOOTH_CONNECT
        )
    } else {
        arrayOf(
                Manifest.permission.BLUETOOTH,
                Manifest.permission.BLUETOOTH_ADMIN,
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_FINE_LOCATION
        )
    }

    /** 允许 */
    private const val PERMISSION_CODE_GRANTED = 0

    /** 不可 */
    private const val PERMISSION_CODE_DENIED = -1

    /** 不再询问 */
    private const val PERMISSION_CODE_DENIED_ALLOW_ASK = -2

    fun isDenied(code: Int): Boolean {
        return code < PERMISSION_CODE_GRANTED
    }

    fun isDeniedAllowAsk(code: Int): Boolean {
        return code == PERMISSION_CODE_DENIED_ALLOW_ASK
    }

    fun isGranted(code: Int): Boolean {
        return code >= PERMISSION_CODE_GRANTED
    }

    fun ensureAudioPermission(context: Context?, prompt: Boolean?): Boolean {
        if (ensureAnyNull(context, prompt)) {
            return false
        }
        if (isGranted(checkPermissions(context, PERMISSIONS_AUDIO))) {
            return true
        }
        if (prompt == true) {
            promptPermissions(context, PERMISSIONS_AUDIO, PERMISSIONS_REQUEST_AUDIO)
        }
        return false
    }

    fun promptAudioPermission(context: Context?, requestCode: Int): Boolean {
        return promptPermissions(context, PERMISSIONS_AUDIO, requestCode)
    }

    fun promptStoragePermission(context: Context?, requestCode: Int): Boolean {
        return promptPermissions(context, PERMISSIONS_STORAGE, requestCode)
    }

    fun promptStoragePermission(fragment: Fragment?, requestCode: Int): Boolean {
        return promptPermissions(fragment, PERMISSIONS_STORAGE, requestCode)
    }

    fun promptLocationPermission(context: Context?, requestCode: Int): Boolean {
        return promptPermissions(context, PERMISSIONS_LOCATION, requestCode)
    }

    fun promptLocationPermission(fragment: Fragment?, requestCode: Int): Boolean {
        return promptPermissions(fragment, PERMISSIONS_LOCATION, requestCode)
    }

    fun promptCameraPermission(context: Context?, requestCode: Int): Boolean {
        return promptPermissions(context, PERMISSIONS_CAMERA, requestCode)
    }

    fun promptCameraPermission(fragment: Fragment?, requestCode: Int): Boolean {
        return promptPermissions(fragment, PERMISSIONS_CAMERA, requestCode)
    }

    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    fun promptNotificationsPermission(context: Context?, requestCode: Int): Boolean {
        return promptPermissions(context, PERMISSIONS_NOTIFICATIONS, requestCode)
    }

    fun promptBlueToothPermission(context: Context?, requestCode: Int): Boolean {
        return promptPermissions(context, PERMISSIONS_BLUETOOTH, requestCode)
    }

    fun promptBlueToothPermission(fragment: Fragment?, requestCode: Int): Boolean {
        return promptPermissions(fragment, PERMISSIONS_BLUETOOTH, requestCode)
    }

    fun ensureLocationPermission(context: Context?, prompt: Boolean?): Boolean {
        if (ensureAnyNull(context, prompt)) {
            return false
        }
        if (isGranted(checkPermissions(context, PERMISSIONS_LOCATION))) {
            return true
        }
        if (prompt == true) {
            promptPermissions(context, PERMISSIONS_LOCATION, PERMISSIONS_REQUEST_LOCATION)
        }
        return false
    }

    fun ensureLocationPermission(fragment: Fragment?, prompt: Boolean?): Boolean {
        if (ensureAnyNull(fragment, prompt)) {
            return false
        }
        if (isGranted(checkPermissions(fragment?.context, PERMISSIONS_LOCATION))) {
            return true
        }
        if (prompt == true) {
            promptPermissions(fragment, PERMISSIONS_LOCATION, PERMISSIONS_REQUEST_LOCATION)
        }
        return false
    }

    fun ensureStoragePermission(context: Context?, prompt: Boolean?): Boolean {
        if (ensureAnyNull(context, prompt)) {
            return false
        }
        if (isGranted(checkPermissions(context, PERMISSIONS_STORAGE))) {
            return true
        }
        if (prompt == true) {
            promptPermissions(context, PERMISSIONS_STORAGE, PERMISSIONS_REQUEST_STORAGE)
        }
        return false
    }

    fun ensureStoragePermission(fragment: Fragment?, prompt: Boolean?): Boolean {
        if (ensureAnyNull(fragment, prompt)) {
            return false
        }
        if (isGranted(checkPermissions(fragment?.context, PERMISSIONS_STORAGE))) {
            return true
        }
        if (prompt == true) {
            promptPermissions(fragment, PERMISSIONS_STORAGE, PERMISSIONS_REQUEST_STORAGE)
        }
        return false
    }

    //TODO  context要求是activity就应该直接定义activity , 有时间改掉
    fun checkPermissions(context: Context?, permissions: Array<String>?): Int {
        if (ensureAnyNull(context, permissions)) {
            return PERMISSION_CODE_DENIED
        }
        if (context !is Activity) {
            return PERMISSION_CODE_DENIED
        }
        for (permission in permissions!!) {
            // 关于 shouldShowRequestPermissionRationale 的说明
            // case1: 从未申请过该权限，shouldShowRequestPermissionRationale=false
            // case2: 拒绝该权限+未勾选不再提示 -> shouldShowRequestPermissionRationale=true
            // case3: 拒绝该权限后，再次申请该权限仍然被拒绝 -> shouldShowRequestPermissionRationale=false
            // case4: 拒绝该权限+勾选不再提示 -> shouldShowRequestPermissionRationale=false
            // case5: 同意该权限 -> shouldShowRequestPermissionRationale=false
            if (ContextCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                val shouldShowRationale = ActivityCompat.shouldShowRequestPermissionRationale(context, permission)
                val firstRequest = isFirstRequestPermission(permission)
                return if (shouldShowRationale || firstRequest) {
                    PERMISSION_CODE_DENIED_ALLOW_ASK
                } else {
                    PERMISSION_CODE_DENIED
                }
            }
        }
        return PERMISSION_CODE_GRANTED
    }

    /**
     * 通过Application拿权限
     */
    fun checkAppPermissions(context: Application, permissions: Array<String>?): Boolean {
        if (ensureAnyNull(permissions)) {
            return false
        }
        permissions?.forEach { permission->
            if (ContextCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                return false
            }
        }
        return true
    }

    fun verifyPermissions(context: Context?, permissions: Array<String>?): Array<String> {
        if (ensureAnyNull(context, permissions)) {
            return arrayOf()
        }

        var unPermission = arrayOf<String>()
        for (permission in permissions!!) {
            if (ContextCompat.checkSelfPermission(context!!, permission) != PackageManager.PERMISSION_GRANTED) {
                unPermission = unPermission.plus(permission)
            }
        }
        return unPermission
    }

    fun ActivityResultLauncher<Array<String>>.promptPermissions(permissions: Array<String>) {
        permissions.forEach { setFirstRequestPermission(it, false) }
        this.launch(permissions)
    }

    fun promptPermissions(
        context: Context?,
        permissions: Array<String>?,
        requestCode: Int
    ): Boolean {
        if (ensureAnyNull(context, permissions)) {
            return false
        }
        if (!(context is Activity)) {
            return false
        }
        ActivityCompat.requestPermissions(context, permissions!!, requestCode)
        permissions.forEach { setFirstRequestPermission(it, false) }
        return true
    }

    fun promptPermissions(
        fragment: Fragment?,
        permissions: Array<String>?,
        requestCode: Int
    ): Boolean {
        if (ensureAnyNull(fragment, permissions)) {
            return false
        }
        if (fragment !is Fragment) {
            return false
        }

        fragment.requestPermissions(permissions!!, requestCode)
        permissions.forEach { setFirstRequestPermission(it, false) }
        return true
    }

    fun isFirstRequestPermission(permissions: Array<String>?): Boolean {
        permissions?.forEach {
            if (!isFirstRequestPermission(it)) {
                return false
            }
        }
        return true
    }

    fun isFirstRequestPermission(permission: String?): Boolean {
        return BasePrefs.getBoolean("${PREFS_KEY_FIRST_REQUEST_PERMISSION}${permission}", true)
    }

    fun setFirstRequestPermissions(permissions: Array<String>?, value: Boolean?) {
        permissions?.forEach { setFirstRequestPermission(it, value) }
    }

    fun setFirstRequestPermission(permission: String?, value: Boolean?) {
        if (permission != null && value != null) {
            BasePrefs.putBoolean("${PREFS_KEY_FIRST_REQUEST_PERMISSION}${permission}", value)
        }
    }

    fun shouldShowRequestPermissionRationale(
        context: Context?,
        permissions: Array<String>?
    ): Boolean {
        if (ensureAnyNull(context, permissions)) {
            return false
        }

        if (context !is Activity) {
            return false
        }

        for (permission in permissions!!) {
            val shouldShowRationale = ActivityCompat.shouldShowRequestPermissionRationale(context, permission)
            val firstRequest = isFirstRequestPermission(permission)
            return shouldShowRationale || firstRequest
        }

        return true
    }

    fun shouldShowRequestPermissionRationale(
        fragment: Fragment?,
        permissions: Array<String>?
    ): Boolean {
        if (ensureAnyNull(fragment, permissions)) {
            return false
        }

        if (fragment !is Activity) {
            return false
        }

        for (permission in permissions!!) {
            val shouldShowRationale = fragment.shouldShowRequestPermissionRationale(permission)
            val firstRequest = isFirstRequestPermission(permission)
            return shouldShowRationale || firstRequest
        }
        return true
    }

}