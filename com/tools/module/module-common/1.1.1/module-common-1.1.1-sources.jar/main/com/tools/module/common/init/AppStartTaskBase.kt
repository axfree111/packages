package com.tools.module.common.init

import com.aice.appstartfaster.task.AppStartTask
import com.tools.module.common.ContextStore

/**
 * Date: 2024/11/25
 * Desc:
 *
 * author: jaje
 */
abstract class AppStartTaskBase: AppStartTask() {

    open val TAG: String = this::class.java.simpleName

    final override fun run() {
        if (needRunOnChildProcess()) {
            onRun()
        } else {
            if (ContextStore.isMainProcess()) {
                onRun()
            }
        }
    }

    open fun onRun() {
    }

    open fun needRunOnChildProcess(): Boolean {
        return false
    }
}