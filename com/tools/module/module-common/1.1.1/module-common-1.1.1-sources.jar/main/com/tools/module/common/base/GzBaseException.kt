package com.tools.module.common.base

/**
 *  author : guoshichao
 *  date : 2023/11/1 13:42
 *  description :
 */
open class GzBaseException(
    val sourceType: SourceType = SourceType.UNKNOWN,
    val errorCode: Int,
    val errorMsg: String?,
    val throwable: Throwable? = null
) : Exception(throwable) {
    override fun toString(): String {
        return if (errorMsg.isNullOrEmpty()) {
            "${this.javaClass.simpleName}{code=${errorCode}, throwable=${throwable.toString()}}"
        } else {
            "${this.javaClass.simpleName}{code=${errorCode}, msg=${errorMsg}, throwable=${throwable.toString()}}"
        }
    }
}

enum class SourceType(type: String) {
    UNKNOWN("unknown"),
    CLIENT("client"),
    SERVER("server"),
    TUYA("tuya"),
}