
package com.tools.module.common.utils;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;

import com.tools.module.common.security.MD5;

import java.io.File;
import java.io.FileInputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.UUID;

import androidx.annotation.NonNull;

public class DeviceInfoUtils {

    private static final String TAG = "DeviceInfoUtils";

    private static final boolean LOGD_ENABLED = false;
    private static final boolean LOGE_ENABLED = false;
    
    private static String verifyId = "";
    private final static String VERIFYID_KEY = "verifyId";

    public static String getSN(Context context) {
        Class<?> SystemProperties = ReflectUtils.getClass("android.os.SystemProperties");
        return ReflectUtils.invokeMethodReturnString(SystemProperties, null, "get", "", "ro.serialno");
    }

    public static String getWifiMac(Context context) {
        try {
            String ret = null;

            WifiManager wifiMgr = (WifiManager) context
                    .getSystemService(Context.WIFI_SERVICE);

            WifiInfo wifiInfo = wifiMgr.getConnectionInfo();

            if (wifiInfo != null) {
                ret = wifiInfo.getMacAddress();
                if (LOGD_ENABLED) {
                    Log.d(TAG, "WiFi Mac: " + ret);
                }
            }

            return ret;
        } catch (Exception e) {
            if (LOGE_ENABLED) {
                Log.e(TAG, "Failed to get the hw info.", e);
            }

            return "";
        }
    }


    /**
     * Requires Permission: READ_PHONE_STATE
     *
     * @param context
     * @return Returns the unique device ID, for example, the IMEI
     */
    @SuppressLint({"MissingPermission", "HardwareIds"})
    public static String getDeviceId(Context context) {
        try {
            TelephonyManager teleMgr = (TelephonyManager) context
                    .getSystemService(Context.TELEPHONY_SERVICE);
            if (LOGD_ENABLED) {
                Log.d(TAG, "DeviceId: " + teleMgr.getDeviceId());
            }
            return teleMgr.getDeviceId();
        } catch (Exception e) {
            if (LOGE_ENABLED) {
                Log.e(TAG, "Failed to get the hw info.", e);
            }
            return "";
        }
    }

    @SuppressLint("HardwareIds")
    public static String getAndroidId(Context context) {
        try {
            return Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
        } catch (Exception ignored) {
            return "";
        }
    }

    /**
     * @param context
     * @return Android Release Version
     */
    public static String getAndroidVersion(Context context) {
        try {
            return Build.VERSION.RELEASE;
        } catch (Exception e) {
            if (LOGE_ENABLED) {
                Log.e(TAG, "Failed to get the hw info.", e);
            }
            return "";
        }
    }

    public static int getAndroidSdk(Context context) {
        try {
            return Build.VERSION.SDK_INT;
        } catch (Exception e) {
            if (LOGE_ENABLED) {
                Log.e(TAG, "Failed to get the hw info.", e);
            }
            return -1;
        }
    }

    /**
     * Requires Permission: READ_PHONE_STATE
     *
     * @param context
     * @return
     */
    public static String getCarrier(Context context) {
        try {
            TelephonyManager teleMgr = (TelephonyManager) context
                    .getSystemService(Context.TELEPHONY_SERVICE);
            if (LOGD_ENABLED) {
                Log.d(TAG, "Carrier: " + teleMgr.getNetworkOperator());
            }
            return teleMgr.getNetworkOperator();
        } catch (Exception e) {
            if (LOGE_ENABLED) {
                Log.e(TAG, "Failed to get the hw info.", e);
            }

            return "";
        }
    }

    public static String getRam(Context context) {
        try {
            File root = Environment.getDataDirectory();
            StatFs sf = new StatFs(root.getPath());

            long blockSize = sf.getBlockSize();
            long blockCount = sf.getBlockCount();

            String ret = Long.toString(blockSize * blockCount);
            if (LOGD_ENABLED) {
                Log.d(TAG, "Ram: " + ret);
            }
            return ret;
        } catch (Exception e) {
            if (LOGE_ENABLED) {
                Log.e(TAG, "Failed to get the hw info.", e);
            }

            return "";
        }
    }

    public static String getModel(Context context) {
        try {
            return Build.MODEL;
        } catch (Exception e) {
            if (LOGE_ENABLED) {
                Log.e(TAG, "Failed to get the hw info.", e);
            }

            return "";
        }
    }

    public static String getProduct() {
        try {
            return Build.PRODUCT.toLowerCase();
        } catch (Exception e) {
            if (LOGE_ENABLED) {
                Log.e(TAG, "Failed to get the hw info.", e);
            }

            return "";
        }
    }

    public static String getResolution(Context context) {
        try {
            Display display = ((WindowManager) context.getSystemService(Context.WINDOW_SERVICE))
                    .getDefaultDisplay();
            DisplayMetrics metrics = new DisplayMetrics();
            display.getMetrics(metrics);

            String ret;
            if (metrics.widthPixels < metrics.heightPixels) {
                ret = metrics.widthPixels + "*" + metrics.heightPixels;
            } else {
                ret = metrics.heightPixels + "*" + metrics.widthPixels;
            }
            if (LOGD_ENABLED) {
                Log.d(TAG, "Resolution: " + ret);
            }
            return ret;
        } catch (Exception e) {
            if (LOGE_ENABLED) {
                Log.e(TAG, "Failed to get the hw info.", e);
            }

            return "";
        }
    }

    public static String getDpi(Context context) {
        try {
            Display display = ((WindowManager) context.getSystemService(Context.WINDOW_SERVICE))
                    .getDefaultDisplay();
            DisplayMetrics metrics = new DisplayMetrics();
            display.getMetrics(metrics);

            String ret = Integer.toString(metrics.densityDpi);
            if (LOGD_ENABLED) {
                Log.d(TAG, "Dpi: " + ret);
            }
            return ret;
        } catch (Exception e) {
            if (LOGE_ENABLED) {
                Log.e(TAG, "Failed to get the hw info.", e);
            }

            return "";
        }
    }

    public static String getManufacturer(Context context) {
        try {
            return Build.MANUFACTURER;
        } catch (Exception e) {
            if (LOGE_ENABLED) {
                Log.e(TAG, "Failed to get the hw info.", e);
            }

            return "";
        }
    }

    private static byte[] mBuffer = new byte[1024];

    private static long sTotalMemory = -1;

    /**
     * Returns the total usable memory
     *
     * @return Bytes of the total usable memory
     */
    public static long getTotalMemory() {
        if (sTotalMemory < 0) {
            sTotalMemory = getStatisticsFromFile("/proc/meminfo", new String[] {
                    "MemTotal"
            });
        }

        return sTotalMemory;
    }

    /**
     * Returns the free memory
     *
     * @return Bytes of free memory
     */
    public static long getAvailMemory(Context context) {
        return getStatisticsFromFile("/proc/meminfo", new String[] {
            "MemFree", "Cached", "Buffers"
        });
    }

    private static long getStatisticsFromFile(String fileName, String[] targets) {
        long[] fetchedValue = new long[targets.length];
        int fetchedCount = 0;

        FileInputStream is = null;
        try {
            is = new FileInputStream(fileName);
            int len = is.read(mBuffer);
            for (int i = 0; (i < len) && (fetchedCount != targets.length); i++) {
                for (int j = 0; j < targets.length; j++) {
                    if (matchText(mBuffer, len, i, targets[j])) {
                        i += targets[j].length();
                        fetchedValue[j] = extractMemValue(mBuffer, len, i);
                        fetchedCount++;
                        break;
                    }
                }
                while (i < len && mBuffer[i] != '\n') {
                    i++;
                }
            }
        } catch (Exception e) {
            if (LOGE_ENABLED) {
                Log.e(TAG, "getStatisticsFromFile error!", e);
            }
        } finally {
            IOUtils.closeStream(is);
        }

        long ret = 0;
        for (int i = 0; i < targets.length; i++) {
            ret += fetchedValue[i];
        }

        return ret;
    }

    private static boolean matchText(byte[] buffer, int len, int index, String text) {
        int length = text.length();
        if ((index + length) >= len) {
            return false;
        }
        for (int i = 0; i < length; i++) {
            if (buffer[index + i] != text.charAt(i)) {
                return false;
            }
        }
        return true;
    }

    private static long extractMemValue(byte[] buffer, int len, int index) {
        while (index < len && buffer[index] != '\n') {
            if (buffer[index] >= '0' && buffer[index] <= '9') {
                int start = index;
                index++;
                while (index < len && buffer[index] >= '0' && buffer[index] <= '9') {
                    index++;
                }
                @SuppressWarnings("deprecation")
                String str = new String(buffer, 0, start, index - start);
                return Long.parseLong(str) * 1024;
            }
            index++;
        }
        return 0;
    }
    
    public static String md5(String string) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(string.getBytes());
            byte b[] = md.digest();
            int i;
            StringBuffer buf = new StringBuffer("");
            for (int offset = 0; offset < b.length; offset++) {
                i = b[offset];
                if (i < 0)
                    i += 256;
                if (i < 16)
                    buf.append("0");
                buf.append(Integer.toHexString(i));
            }
            return buf.toString();
        } catch (Exception e) {
            return null;
        }
    }


    public static String getVerifyId(Context context) {
        if (!TextUtils.isEmpty(verifyId))
            return verifyId;
        if (context == null)
            return "";
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        String keepVerifyId = sharedPreferences.getString(VERIFYID_KEY, "");
        if (!TextUtils.isEmpty(keepVerifyId)) {
            verifyId = keepVerifyId;
            return verifyId;
        }
        String imei = getDeviceId(context);
        String android_id = android.provider.Settings.System.getString(context.getContentResolver(), "android_id");
        String serialNumber = getSN(context);
        String deviceID = md5(imei + android_id + serialNumber);
        verifyId = deviceID;
        sharedPreferences.edit().putString(VERIFYID_KEY,verifyId ).apply();
        return deviceID;
    }

    /**
     * 生成VERIFY_ID
     */
    public static String buildGlazeroVerifyId(@NonNull Context context) {
        /*
         * MAGIC（4位魔数)       = "gzvi" //GlaZero Verify ID
         * DEVICE_INFO(设备信息) = ANDROID_ID + Build.BRAND + Build.MANUFACTURER + Build.MODEL + Build.PRODUCT
         * MD5_DEVICE_INFO      = md5(DEVICE_INFO)
         * MD5_UUID             = md5(UUID).substring(12,20)
         *
         * VERIFY_ID            = MAGIC_NUMBER + MD5_UUID + md5(MAGIC_NUMBER + MD5_UUID + MD5_DEVICE_INFO).substring(12,20)
         *
         * VERIFY_ID特性：
         * 1. 由随机的UUID和设备信息共同构成，能保障一定不为空
         * 2. 重置系统/恢复出厂设置时失效，固件升级只要不清系统数据仍保持有效
         * 3. 支持校验是否为当前设备所生成，防止复制到其它设备使用
         */
        String magic = new String(new byte[]{0x67, 0x7a, 0x76, 0x69}, StandardCharsets.UTF_8);
        String deviceInfo = getAndroidId(context) + Build.BRAND + Build.MANUFACTURER + Build.MODEL + Build.PRODUCT;
        String uuid = MD5.encode8(UUID.randomUUID().toString());
        String sign = MD5.encode4((magic + uuid + deviceInfo).getBytes(StandardCharsets.UTF_8));
        return magic + uuid + sign;
    }

    /**
     * 检查VERIFY_ID是否来自于当前设备
     */
    public static boolean ensureGlazeroVerifyId(@NonNull Context context, String verifyId) {
        if (verifyId != null && verifyId.length() == 16) {
            String magic = new String(new byte[]{0x73, 0x74, 0x76, 0x69}, StandardCharsets.UTF_8);
            String deviceInfo = getAndroidId(context) + Build.BRAND + Build.MANUFACTURER + Build.MODEL + Build.PRODUCT;
            String uuid = verifyId.substring(4, 12);
            String sign = MD5.encode4((magic + uuid + deviceInfo).getBytes(StandardCharsets.UTF_8));
            String targetVerifyId = magic + uuid + sign;
            return TextUtils.equals(verifyId, targetVerifyId);
        }
        return false;
    }

    public static String buildTraceId() {
        return MD5.encode16(UUID.randomUUID().toString());
    }



    public static boolean isXiaoMi() {
        return "xiaomi".equals(Build.MANUFACTURER.toLowerCase());
    }

    public static boolean isMIUI8OrAbove() {
        if (isXiaoMi()) {
            final String miuiVersion = ReflectUtils.getProperty("ro.miui.ui.version.name").toUpperCase();
            if (!TextUtils.isEmpty(miuiVersion) && miuiVersion.startsWith("V")) {
                try {
                    return Integer.parseInt(miuiVersion.replace("V", "")) >= 8;
                } catch (Exception ignored) {
                }
            }
        }
        return false;
    }

    public static boolean isMIUI12OrAbove() {
        if (isXiaoMi()) {
            final String miuiVersion = ReflectUtils.getProperty("ro.miui.ui.version.name").toUpperCase();
            if (!TextUtils.isEmpty(miuiVersion) && miuiVersion.startsWith("V")) {
                try {
                    return Integer.parseInt(miuiVersion.replace("V", "")) >= 12;
                } catch (Exception ignored) {
                }
            }
        }
        return false;
    }

    public static boolean isHuawei() {
        return !TextUtils.isEmpty(ReflectUtils.getProperty("ro.build.version.emui"));
    }

    public static boolean isOppo() {
        return !TextUtils.isEmpty(ReflectUtils.getProperty("ro.build.version.opporom"));
    }

    public static boolean isVivo() {
        return !TextUtils.isEmpty(ReflectUtils.getProperty("ro.vivo.os.version"));
    }

}
