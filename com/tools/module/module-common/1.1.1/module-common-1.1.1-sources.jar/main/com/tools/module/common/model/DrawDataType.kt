package com.tools.module.common.model

/**
 * Date: 2025/3/27
 * Desc:
 *
 * author: jaje
 */
object DrawDataType {
    const val HANDWRITE: String = "handWrite"
    const val LINE: String = "line"
    const val MARKER: String = "marker"
    const val RECTANGLE: String = "rectangle"
    const val CIRCLE: String = "circle"
}