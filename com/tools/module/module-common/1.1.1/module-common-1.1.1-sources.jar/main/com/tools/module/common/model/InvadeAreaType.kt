package com.tools.module.common.model

/**
 * Date: 2025/3/27
 * Desc:
 *
 * author: jaje
 */
object InvadeAreaType {
    const val NO: Int = 0
    const val MONITOR_ATTACK: Int = 1
    const val MONITOR_WARNING: Int = 2
    const val MONITOR_DISCERN_AREA: Int = 3
    const val DISTRICT_FENCE_AREA: Int = 4
}