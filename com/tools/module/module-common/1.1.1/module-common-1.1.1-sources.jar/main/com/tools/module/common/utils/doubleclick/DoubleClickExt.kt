package com.tools.module.common.utils.doubleclick

import android.view.View

/**
 *  author : guoshichao
 *  date : 2023/6/5 14:20
 *  description :
 */
fun View.setOnDoubleClickListener(onceClick: ((view: View) -> Unit)? = null, doubleClick: (view: View) -> Unit) {
    setOnClickListener(DoubleClickListener(object : DoubleClickListener.OnDoubleClickListener {
        override fun onceClick(view: View) {
            onceClick?.invoke(view)
        }

        override fun doubleClick(view: View) {
            doubleClick.invoke(view)
        }
    }))
}