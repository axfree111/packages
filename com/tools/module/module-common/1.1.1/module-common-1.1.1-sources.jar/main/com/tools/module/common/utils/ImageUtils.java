package com.tools.module.common.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;

import androidx.annotation.DrawableRes;

import com.tools.module.common.log.XLog;

import java.io.File;

/**
 * ImageUtils
 *
 * 
 * 
 */
public class ImageUtils {

    private final static String TAG = "ImageUtils";

    public static Drawable clone(Context context, Drawable drawable) {
        if (drawable != null && drawable.getIntrinsicWidth() > 0 && drawable.getIntrinsicHeight() > 0) {
            final Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
            final Canvas canvas = new Canvas(bitmap);
            drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
            drawable.draw(canvas);
            return new BitmapDrawable(context.getResources(), bitmap);
        }
        return drawable;
    }

    public static Bitmap drawable2Bitmap(Context context, @DrawableRes int drawableResId) {
        return BitmapFactory.decodeResource(context.getResources(), drawableResId);
    }

    public static Bitmap drawable2Bitmap(Context context, Drawable drawable) {
        if (!(drawable instanceof BitmapDrawable)) {
            drawable = clone(context, drawable);
        }
        if (drawable instanceof BitmapDrawable) {
            return ((BitmapDrawable) drawable).getBitmap();
        }
        return null;
    }

    public static Bitmap getBitmap(String filePath) {
        if (TextUtils.isEmpty(filePath)) {
            return null;
        }

        Bitmap bitmap;
        BitmapFactory.Options options = new BitmapFactory.Options();
        try {
            XLog.d(TAG, "filePath:" + filePath);
            bitmap = BitmapFactory.decodeFile(new File(filePath).getAbsolutePath(), options);
        } catch (OutOfMemoryError e) {
            XLog.w(TAG, e.getMessage());
            options.inSampleSize = 2;
            bitmap = BitmapFactory.decodeFile(filePath, options);
        }

        return bitmap;
    }

    /*
     * Compute the sample size as a function of minSideLength
     * and maxNumOfPixels.
     * minSideLength is used to specify that minimal width or height of a
     * bitmap.
     * maxNumOfPixels is used to specify the maximal size in pixels that is
     * tolerable in terms of memory usage.
     *
     * The function returns a sample size based on the constraints.
     * Both size and minSideLength can be passed in as IImage.UNCONSTRAINED,
     * which indicates no care of the corresponding constraint.
     * The functions prefers returning a sample size that
     * generates a smaller bitmap, unless minSideLength = IImage.UNCONSTRAINED.
     *
     * Also, the function rounds up the sample size to a power of 2 or multiple
     * of 8 because BitmapFactory only honors sample size this way.
     * For example, BitmapFactory downsamples an image by 2 even though the
     * request is 3. So we round up the sample size to avoid OOM.
     */
    public static int computeSampleSize(BitmapFactory.Options options,
            int minSideLength, int maxNumOfPixels) {
        int initialSize = computeInitialSampleSize(options, minSideLength,
                maxNumOfPixels);

        int roundedSize;
        if (initialSize <= 8) {
            roundedSize = 1;
            while (roundedSize < initialSize) {
                roundedSize <<= 1;
            }
        } else {
            roundedSize = (initialSize + 7) / 8 * 8;
        }
        return roundedSize;
    }

    private static int computeInitialSampleSize(BitmapFactory.Options options,
            int minSideLength, int maxNumOfPixels) {
        double w = options.outWidth;
        double h = options.outHeight;
        XLog.d(TAG, "computeInitialSampleSize outWidth:" + w + "outHeight:" + h);
        int lowerBound = (maxNumOfPixels == -1) ? 1 :
                (int) Math.ceil(Math.sqrt(w * h / maxNumOfPixels));
        int upperBound = (minSideLength == -1) ? 128 :
                (int) Math.min(Math.floor(w / minSideLength),
                        Math.floor(h / minSideLength));

        if (upperBound < lowerBound) {
            // return the larger one when there is no overlapping zone.
            return lowerBound;
        }

        if ((maxNumOfPixels == -1) &&
                (minSideLength == -1)) {
            return 1;
        } else if (minSideLength == -1) {
            return lowerBound;
        } else {
            return upperBound;
        }
    }

}
