package com.tools.module.common.utils

import java.util.*

/**
 *  author : guoshichao
 *  date : 2023/1/5 17:08
 *  description :
 */
object LocaleUtils {

    fun isChina(): Boolean {
        return Locale.getDefault().country == "CN"
    }

}