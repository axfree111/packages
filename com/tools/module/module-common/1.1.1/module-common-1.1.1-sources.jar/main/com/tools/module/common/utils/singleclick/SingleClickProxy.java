package com.tools.module.common.utils.singleclick;

import android.view.View;

/**
 * Created by guoshichao on 2020/10/19
 * 防止多次点击代理类
 */
public final class SingleClickProxy implements View.OnClickListener {

    private View.OnClickListener origin;
    private long lastClick = 0;
    private long times = 1000; //ms
    private IClickAgain mIAgain;

    public SingleClickProxy(View.OnClickListener origin, long times, IClickAgain again) {
        this.origin = origin;
        this.mIAgain = again;
        this.times = times;
    }

    public SingleClickProxy(View.OnClickListener origin) {
        this.origin = origin;
    }

    @Override
    public void onClick(View v) {
        if (System.currentTimeMillis() - lastClick >= times) {
            origin.onClick(v);
            lastClick = System.currentTimeMillis();
        } else {
            if (mIAgain != null) {
                mIAgain.onAgain();
            }
        }
    }

}