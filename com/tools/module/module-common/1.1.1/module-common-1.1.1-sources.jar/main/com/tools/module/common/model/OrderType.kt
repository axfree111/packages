package com.tools.module.common.model

/**
 * Date: 2025/3/27
 * Desc: 指令类型 1迫降   2驱离 3停止
 *
 * author: jaje
 */
object OrderType {
    const val FIGHT_SHOT: Int = 1
    const val EXPEL: Int = 2
    const val STOP: Int = 3
}