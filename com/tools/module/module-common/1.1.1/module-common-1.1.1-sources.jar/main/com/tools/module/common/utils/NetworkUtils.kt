@file:JvmName("NetworkUtils")

package com.tools.module.common.utils

import android.Manifest.permission.INTERNET
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import androidx.annotation.RequiresPermission
import java.net.InetAddress
import java.net.UnknownHostException


/**
 *
 *@version v1.0
 *@date 2020/12/15 4:54 PM
 **/
fun isConnected(context: Context?): Boolean {
    if (context == null) return false
    try {
        val connManager: ConnectivityManager? = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        if (connManager != null) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
                val activeNetworkInfo = connManager.activeNetworkInfo
                return activeNetworkInfo != null && activeNetworkInfo.isConnected
            } else {
                val networkCapabilities = connManager.getNetworkCapabilities(connManager.activeNetwork)
                if (networkCapabilities != null) {
                    return networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                            || networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
                            || networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
                }
            }
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }
    return false
}

/**
 * Return whether network is available.
 * Must hold `<uses-permission android:name="android.permission.INTERNET" />`
 * @return `true`: yes<br></br>`false`: no
 * 注意⚠️： 判断不够准确，有时在wifi情况下，正在获取网络状态时，其实可以访问，但是返回了false，所以要在请求失败时再做判断，做出相对应的UI展示
 */
fun isAvailable(context: Context?): Boolean {
    val connectivityManager = context?.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager?
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
        val networkInfo = connectivityManager?.activeNetworkInfo
        return networkInfo?.isAvailable ?: false
    } else {
        val network = connectivityManager?.activeNetwork
        return network?.let {
            val networkCapabilities = connectivityManager.getNetworkCapabilities(it)
            //NetworkCapabilities.NET_CAPABILITY_INTERNET	表示是否连接上了互联网（不关心是否可以上网）
            //NetworkCapabilities.NET_CAPABILITY_VALIDATED	表示能够和互联网通信（这个为true表示能够上网）
            networkCapabilities?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) ?: false
        } ?: false
    }
}

/**
 * Return whether network is available using domain.
 *
 * Must hold `<uses-permission android:name="android.permission.INTERNET" />`
 *
 * @param domain The name of domain.
 * @return `true`: yes<br></br>`false`: no
 */
@RequiresPermission(INTERNET)
fun isAvailableByDns(domain: String?): Boolean {
    val realDomain = if (TextUtils.isEmpty(domain)) "www.baidu.com" else domain!!
    val inetAddress: InetAddress?
    return try {
        inetAddress = InetAddress.getByName(realDomain)
        inetAddress != null
    } catch (e: UnknownHostException) {
        e.printStackTrace()
        false
    }
}

fun isWifi(context: Context?): Boolean {
    if (context == null) return false
    try {
        val connManager: ConnectivityManager? = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        if (connManager != null) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
                val activeNetworkInfo = connManager.activeNetworkInfo
                return activeNetworkInfo != null && activeNetworkInfo.type == ConnectivityManager.TYPE_WIFI && activeNetworkInfo.isConnected
            } else {
                val networkCapabilities = connManager.getNetworkCapabilities(connManager.activeNetwork)
                if (networkCapabilities != null) {
                    return networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                }
            }
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }
    return false
}

fun getWifiGateWayAddress(context: Context?): InetAddress? {
    try {
        val wifiManager: WifiManager? = context?.applicationContext?.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        wifiManager?.dhcpInfo?.gateway?.let { gateway ->
            return@getWifiGateWayAddress InetAddress.getByAddress(BytesUtils.int32ToBytes(gateway))
        }
    } catch (ignored: Exception) {
    }
    return null
}

fun getWifiIpAddress(context: Context?): InetAddress? {
    try {
        val wifiManager: WifiManager? = context?.applicationContext?.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        wifiManager?.dhcpInfo?.ipAddress?.let { ip ->
            return@getWifiIpAddress InetAddress.getByAddress(BytesUtils.int32ToBytes(ip))
        }
    } catch (ignored: Exception) {
    }
    return null
}

fun getWifiDns1Address(context: Context?): InetAddress? {
    try {
        val wifiManager: WifiManager? = context?.applicationContext?.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        wifiManager?.dhcpInfo?.dns1?.let { dns ->
            return@getWifiDns1Address InetAddress.getByAddress(BytesUtils.int32ToBytes(dns))
        }
    } catch (ignored: Exception) {
    }
    return null
}

fun getWifiDns2Address(context: Context?): InetAddress? {
    try {
        val wifiManager: WifiManager? = context?.applicationContext?.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        wifiManager?.dhcpInfo?.dns2?.let { dns ->
            return@getWifiDns2Address InetAddress.getByAddress(BytesUtils.int32ToBytes(dns))
        }
    } catch (ignored: Exception) {
    }
    return null
}

fun isVpnConnected(context: Context?): Boolean {
    val connectivityManager = context?.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
    return connectivityManager?.getNetworkInfo(ConnectivityManager.TYPE_VPN)?.isConnected ?: false
}

fun dumpNetworkInfo(context: Context?): Map<String, Any> {
    return mutableMapOf<String, Any>().apply {
        put("vpn", isVpnConnected(context))
        put("wifi", "${isWifi(context)}${getWifiIpAddress(context)}")
        put("available", isAvailable(context))
    }
}
