package com.tools.module.common.utils

import android.widget.Toast
import com.tools.module.common.BaseApplication

/**
 * Package: com.tools.module.common.utils
 * Date:    2021/4/21
 * Desc:    com.tools.module.common.utils
 *
 * 
 */

fun showLongToast(msg: String) {
    Toast.makeText(BaseApplication.getContext(), msg, Toast.LENGTH_LONG).show()
}

fun showShortToast(msg: String) {
    Toast.makeText(BaseApplication.getContext(), msg, Toast.LENGTH_SHORT).show()
}