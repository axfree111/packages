package com.tools.module.common.utils.doubleclick

import android.view.View

/**
 *  author : guoshichao
 *  date : 2023/6/5 14:01
 *  description :
 */
class DoubleClickListener(private val doubleClickListener: OnDoubleClickListener) :
    View.OnClickListener {

    //记录上次点击时间
    private var lastClickTime = 0L

    //双击间隔时间
    private val doubleTime = 200L

    override fun onClick(v: View) {
        val clickTime = System.currentTimeMillis()
        if (clickTime - lastClickTime < doubleTime) {
            doubleClickListener.doubleClick(v)
            lastClickTime = 0L
        } else {
            doubleClickListener.onceClick(v)
            lastClickTime = clickTime
        }
    }

    interface OnDoubleClickListener {
        //点击一次的回调
        fun onceClick(view: View)

        //连续点击两次的回调
        fun doubleClick(view: View)
    }

}