package com.tools.module.common.utils

import android.Manifest.permission.EXPAND_STATUS_BAR
import android.R
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.res.Resources
import android.graphics.Point
import android.os.Build
import android.provider.Settings
import android.util.TypedValue
import android.view.*
import android.view.ViewGroup.MarginLayoutParams
import androidx.annotation.ColorInt
import androidx.annotation.NonNull
import androidx.annotation.RequiresApi
import androidx.annotation.RequiresPermission
import androidx.drawerlayout.widget.DrawerLayout
import com.tools.module.common.ContextStore
import java.lang.reflect.Method


/**
 * Package: com.tools.module.common.utils
 * Date:    2021/5/11
 * Desc:    com.tools.module.common.utils
 *
 * 
 */
object BarUtils {
    //////////////////////////////////////////////////////////////////////////
    // status bar
    ///////////////////////////////////////////////////////////////////////////

    //////////////////////////////////////////////////////////////////////////
    // status bar
    ///////////////////////////////////////////////////////////////////////////
    private val TAG_STATUS_BAR = "TAG_STATUS_BAR"
    private val TAG_OFFSET = "TAG_OFFSET"
    private val KEY_OFFSET = -123

    private fun BarUtils() {
        throw UnsupportedOperationException("u can't instantiate me...")
    }

    /**
     * Return the status bar's height.
     *
     * @return the status bar's height
     */
    fun getStatusBarHeight(): Int {
        val resources: Resources = ContextStore.getContext().resources
        val resourceId: Int = resources.getIdentifier("status_bar_height", "dimen", "android")
        return resources.getDimensionPixelSize(resourceId)
    }

    /**
     * Set the status bar's visibility.
     *
     * @param activity  The activity.
     * @param isVisible True to set status bar visible, false otherwise.
     */
    fun setStatusBarVisibility(activity: Activity, isVisible: Boolean) {
        setStatusBarVisibility(activity.window, isVisible)
    }

    /**
     * Set the status bar's visibility.
     *
     * @param window    The window.
     * @param isVisible True to set status bar visible, false otherwise.
     */
    fun setStatusBarVisibility(window: Window, isVisible: Boolean) {
        if (isVisible) {
            window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
            showStatusBarView(window)
            addMarginTopEqualStatusBarHeight(window)
        } else {
            window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
            hideStatusBarView(window)
            subtractMarginTopEqualStatusBarHeight(window)
        }
    }

    /**
     * Return whether the status bar is visible.
     *
     * @param activity The activity.
     * @return `true`: yes<br></br>`false`: no
     */
    fun isStatusBarVisible(activity: Activity): Boolean {
        val flags = activity.window.attributes.flags
        return flags and WindowManager.LayoutParams.FLAG_FULLSCREEN == 0
    }

    /**
     * Set the status bar's light mode.
     *
     * @param activity    The activity.
     * @param isLightMode True to set status bar light mode, false otherwise.
     */
    fun setStatusBarLightMode(activity: Activity, isLightMode: Boolean) {
        setStatusBarLightMode(activity.window, isLightMode)
    }

    /**
     * Set the status bar's light mode.
     *
     * @param window      The window.
     * @param isLightMode True to set status bar light mode, false otherwise.
     */
    fun setStatusBarLightMode(window: Window, isLightMode: Boolean) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val decorView: View = window.decorView
            var vis: Int = decorView.systemUiVisibility
            vis = if (isLightMode) {
                vis or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            } else {
                vis and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
            }
            decorView.systemUiVisibility = vis
        }
    }

    /**
     * Is the status bar light mode.
     *
     * @param activity The activity.
     * @return `true`: yes<br></br>`false`: no
     */
    fun isStatusBarLightMode(activity: Activity): Boolean {
        return isStatusBarLightMode(activity.window)
    }

    /**
     * Is the status bar light mode.
     *
     * @param window The window.
     * @return `true`: yes<br></br>`false`: no
     */
    fun isStatusBarLightMode(window: Window): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val decorView: View = window.getDecorView()
            val vis: Int = decorView.getSystemUiVisibility()
            return vis and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR !== 0
        }
        return false
    }

    /**
     * Add the top margin size equals status bar's height for view.
     *
     * @param view The view.
     */
    fun addMarginTopEqualStatusBarHeight(view: View) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT) return
        view.setTag(TAG_OFFSET)
        val haveSetOffset: Any = view.getTag(KEY_OFFSET)
        if (haveSetOffset != null && haveSetOffset as Boolean) return
        val layoutParams = view.getLayoutParams() as MarginLayoutParams
        layoutParams.setMargins(layoutParams.leftMargin, layoutParams.topMargin + getStatusBarHeight(), layoutParams.rightMargin,
                layoutParams.bottomMargin)
        view.setTag(KEY_OFFSET, true)
    }

    /**
     * Subtract the top margin size equals status bar's height for view.
     *
     * @param view The view.
     */
    fun subtractMarginTopEqualStatusBarHeight(view: View) {
        val haveSetOffset: Any = view.getTag(KEY_OFFSET)
        if (!(haveSetOffset as Boolean)) return
        val layoutParams = view.layoutParams as MarginLayoutParams
        layoutParams.setMargins(layoutParams.leftMargin, layoutParams.topMargin - getStatusBarHeight(), layoutParams.rightMargin,
                layoutParams.bottomMargin)
        view.setTag(KEY_OFFSET, false)
    }

    private fun addMarginTopEqualStatusBarHeight(window: Window) {
        val withTag: View = window.getDecorView()
            .findViewWithTag(TAG_OFFSET) ?: return
        addMarginTopEqualStatusBarHeight(withTag)
    }

    private fun subtractMarginTopEqualStatusBarHeight(window: Window) {
        val withTag: View = window.decorView.findViewWithTag(TAG_OFFSET) ?: return
        subtractMarginTopEqualStatusBarHeight(withTag)
    }

    /**
     * Set the status bar's color.
     *
     * @param window  The window.
     * @param color   The status bar's color.
     * @param statusBarIsIndependentSpace 表明状态栏是否占用独立空间, true表示页面由屏幕高度=状态栏+布局高度
     *                                     false表示状态栏悬浮在布局内容上屏幕高度=布局高度
     * false to add fake status bar in ContentView.
     */
    fun setStatusBarColor(window: Window,
                          @ColorInt
                          color: Int) {
        updateStatusBarColor(window, color, true)
    }

    /**
     * Set the status bar's color.
     *
     * @param window  The window.
     * @param color   The status bar's color.
     * @param isDecor True to add fake status bar in DecorView,
     * false to add fake status bar in ContentView.
     */
    fun setStatusBarColor(window: Window,
                          @ColorInt
                          color: Int, statusBarIsIndependentSpace: Boolean) {
        updateStatusBarColor(window, color, statusBarIsIndependentSpace)
    }

    /**
     * Set the status bar's color.
     *
     * @param fakeStatusBar The fake status bar view.
     * @param color         The status bar's color.
     */
    fun setStatusBarColor(window: Window,
                          @NonNull
                          fakeStatusBar: View,
                          @ColorInt
                          color: Int, statusBarIsIndependentSpace: Boolean) {
        updateStatusBarColor(window, color, statusBarIsIndependentSpace)
        fakeStatusBar.visibility = View.VISIBLE
        val layoutParams: ViewGroup.LayoutParams = fakeStatusBar.getLayoutParams()
        layoutParams.width = ViewGroup.LayoutParams.MATCH_PARENT
        layoutParams.height = getStatusBarHeight()
        fakeStatusBar.setBackgroundColor(color)
    }

    /**
     * Set the custom status bar.
     *
     * @param fakeStatusBar The fake status bar view.
     */
    fun setStatusBarCustom(window: Window,
                           @NonNull
                           fakeStatusBar: View,
                           @ColorInt
                           color: Int) {
        setStatusBarCustom(window, fakeStatusBar, color, true)
    }

    /**
     * Set the custom status bar.
     *
     * @param fakeStatusBar The fake status bar view.
     */
    fun setStatusBarCustom(window: Window,
                           @NonNull
                           fakeStatusBar: View,
                           @ColorInt
                           color: Int, statusBarIsIndependentSpace: Boolean) {
        updateStatusBarColor(window, color, statusBarIsIndependentSpace)
        fakeStatusBar.visibility = View.VISIBLE
        var layoutParams: ViewGroup.LayoutParams = fakeStatusBar.getLayoutParams()
        if (layoutParams == null) {
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, getStatusBarHeight())
            fakeStatusBar.setLayoutParams(layoutParams)
        } else {
            layoutParams.width = ViewGroup.LayoutParams.MATCH_PARENT
            layoutParams.height = getStatusBarHeight()
        }
    }

    fun setStatusBarColor4Drawer(window: Window,
                                 @NonNull
                                 drawer: DrawerLayout,
                                 @NonNull
                                 fakeStatusBar: View,
                                 @ColorInt
                                 color: Int) {
        setStatusBarColor4Drawer(window, drawer, fakeStatusBar, color, true)
    }

    /**
     * Set the status bar's color for DrawerLayout.
     *
     * DrawLayout must add `android:fitsSystemWindows="true"`
     *
     * @param drawer        The DrawLayout.
     * @param fakeStatusBar The fake status bar view.
     * @param color         The status bar's color.
     */
    fun setStatusBarColor4Drawer(window: Window,
                                 @NonNull
                                 drawer: DrawerLayout,
                                 @NonNull
                                 fakeStatusBar: View,
                                 @ColorInt
                                 color: Int, statusBarIsIndependentSpace: Boolean) {
        setStatusBarColor4Drawer(window, drawer, fakeStatusBar, color, statusBarIsIndependentSpace, false)
    }

    /**
     * Set the status bar's color for DrawerLayout.
     *
     * DrawLayout must add `android:fitsSystemWindows="true"`
     *
     * @param drawer        The DrawLayout.
     * @param fakeStatusBar The fake status bar view.
     * @param color         The status bar's color.
     * @param isTop         True to set DrawerLayout at the top layer, false otherwise.
     */
    fun setStatusBarColor4Drawer(window: Window,
                                 @NonNull
                                 drawer: DrawerLayout,
                                 @NonNull
                                 fakeStatusBar: View,
                                 @ColorInt
                                 color: Int, statusBarIsIndependentSpace: Boolean, isTop: Boolean) {
        drawer.fitsSystemWindows = false
        setStatusBarColor(window, fakeStatusBar, color, statusBarIsIndependentSpace)
        var i = 0
        val count: Int = drawer.childCount
        while (i < count) {
            drawer.getChildAt(i).fitsSystemWindows = false
            i++
        }
        if (isTop) {
            hideStatusBarView(window)
        } else {
            setStatusBarColor(window, color, false)
        }
    }

    private fun getStatusBarView(window: Window): View? {
        val parent = window.decorView as ViewGroup
        var fakeStatusBarView: View? = parent.findViewWithTag(TAG_STATUS_BAR)
        if (fakeStatusBarView != null) {
            if (fakeStatusBarView.visibility == View.GONE) {
                fakeStatusBarView.visibility = View.VISIBLE
            }
        } else {
            fakeStatusBarView = createStatusBarView(window.context)
            parent.addView(fakeStatusBarView)
        }
        return fakeStatusBarView
    }

    private fun hideStatusBarView(window: Window) {
        val decorView = window.getDecorView() as ViewGroup
        val fakeStatusBarView: View = decorView.findViewWithTag(TAG_STATUS_BAR) ?: return
        fakeStatusBarView.setVisibility(View.GONE)
    }

    private fun showStatusBarView(window: Window) {
        val decorView = window.getDecorView() as ViewGroup
        val fakeStatusBarView: View = decorView.findViewWithTag(TAG_STATUS_BAR) ?: return
        fakeStatusBarView.setVisibility(View.VISIBLE)
    }

    private fun createStatusBarView(context: Context): View? {
        val statusBarView = View(context)
        statusBarView.setLayoutParams(ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, getStatusBarHeight()))
        statusBarView.setTag(TAG_STATUS_BAR)
        return statusBarView
    }

    /**
     * statusBarIsIndependentSpace 表明状态栏是否占用独立空间
     */
    fun updateStatusBarColor(window: Window, color: Int, statusBarIsIndependentSpace: Boolean) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.statusBarColor = color
            if (statusBarIsIndependentSpace) {
                window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            // 本工程支持的最小版本已大于19，不会走到此逻辑
            window.setFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS, WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
            var fakeStatusBarView: View? = getStatusBarView(window)
            fakeStatusBarView?.setBackgroundColor(color)
        }
    }

    ///////////////////////////////////////////////////////////////////////////
    // action bar
    ///////////////////////////////////////////////////////////////////////////

    ///////////////////////////////////////////////////////////////////////////
    // action bar
    ///////////////////////////////////////////////////////////////////////////
    /**
     * Return the action bar's height.
     *
     * @return the action bar's height
     */
    fun getActionBarHeight(): Int {
        val tv = TypedValue()
        return if (ContextStore.getContext().theme.resolveAttribute(R.attr.actionBarSize, tv, true)) {
            TypedValue.complexToDimensionPixelSize(tv.data, ContextStore.getContext().resources.displayMetrics)
        } else 0
    }

    ///////////////////////////////////////////////////////////////////////////
    // notification bar
    ///////////////////////////////////////////////////////////////////////////

    ///////////////////////////////////////////////////////////////////////////
    // notification bar
    ///////////////////////////////////////////////////////////////////////////
    /**
     * Set the notification bar's visibility.
     *
     * Must hold `<uses-permission android:name="android.permission.EXPAND_STATUS_BAR" />`
     *
     * @param isVisible True to set notification bar visible, false otherwise.
     */
    @RequiresPermission(EXPAND_STATUS_BAR)
    fun setNotificationBarVisibility(isVisible: Boolean) {
        val methodName: String
        methodName = if (isVisible) {
            "expandNotificationsPanel"
        } else {
            "collapsePanels"
        }
        invokePanels(methodName)
    }

    private fun invokePanels(methodName: String) {
        try {
            @SuppressLint("WrongConstant")
            val service: Any = ContextStore.getContext()
                .getSystemService("statusbar")

            @SuppressLint("PrivateApi")
            val statusBarManager = Class.forName("android.app.StatusBarManager")
            val expand: Method = statusBarManager.getMethod(methodName)
            expand.invoke(service)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    ///////////////////////////////////////////////////////////////////////////
    // navigation bar
    ///////////////////////////////////////////////////////////////////////////

    ///////////////////////////////////////////////////////////////////////////
    // navigation bar
    ///////////////////////////////////////////////////////////////////////////
    /**
     * Return the navigation bar's height.
     *
     * @return the navigation bar's height
     */
    fun getNavBarHeight(): Int {
        val res: Resources = ContextStore.getContext().resources
        val resourceId: Int = res.getIdentifier("navigation_bar_height", "dimen", "android")
        return if (resourceId != 0) {
            res.getDimensionPixelSize(resourceId)
        } else {
            0
        }
    }

    fun getNavBarHeightIfSHow(activity: Activity?): Int {
        if (isNavBarVisible(activity)) {
            return getNavBarHeight()
        }

        return 0
    }

    /**
     * Set the navigation bar's visibility.
     *
     * @param activity  The activity.
     * @param isVisible True to set navigation bar visible, false otherwise.
     */
    fun setNavBarVisibility(activity: Activity, isVisible: Boolean) {
        setNavBarVisibility(activity.window, isVisible)
    }

    /**
     * Set the navigation bar's visibility.
     *
     * @param window    The window.
     * @param isVisible True to set navigation bar visible, false otherwise.
     */
    fun setNavBarVisibility(window: Window, isVisible: Boolean) {
        val decorView = window.decorView as ViewGroup
        //注释代码 适配时调整
        var i = 0
        val count = decorView.childCount
        while (i < count) {
            val child: View = decorView.getChildAt(i)
            val id: Int = child.getId()
            if (id != View.NO_ID) {
                val resourceEntryName = getResNameById(id)
                if ("navigationBarBackground" == resourceEntryName) {
                    child.setVisibility(if (isVisible) View.VISIBLE else View.INVISIBLE)
                }
            }
            i++
        }
        val uiOptions: Int = (View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)

        if (isVisible) {
            decorView.systemUiVisibility = decorView.systemUiVisibility and uiOptions.inv()
        } else {
            decorView.systemUiVisibility = decorView.systemUiVisibility or uiOptions
        }
    }

    /**
     * Return whether the navigation bar visible.
     *
     * Call it in onWindowFocusChanged will get right result.
     *
     * @param activity The activity.
     * @return `true`: yes<br></br>`false`: no
     */
    fun isNavBarVisible(activity: Activity?): Boolean {
        return isNavBarVisible(activity?.window)
    }

    /**
     * Return whether the navigation bar visible.
     *
     * Call it in onWindowFocusChanged will get right result.
     *
     * @param window The window.
     * @return `true`: yes<br></br>`false`: no
     */
    fun isNavBarVisible(window: Window?): Boolean {
        var isVisible = false
        val decorView = window?.decorView as ViewGroup
        var i = 0
        val count = decorView.childCount
        while (i < count) {
            val child: View = decorView.getChildAt(i)
            val id: Int = child.getId()
            if (id != View.NO_ID) {
                val resourceEntryName = getResNameById(id)
                if ("navigationBarBackground" == resourceEntryName && child.getVisibility() === View.VISIBLE) {
                    isVisible = true
                    break
                }
            }
            i++
        }
        if (isVisible) {
            // 对于三星手机，android10以下非OneUI2的版本，比如 s8，note8 等设备上，
            // 导航栏显示存在bug："当用户隐藏导航栏时显示输入法的时候导航栏会跟随显示"，会导致隐藏输入法之后判断错误
            // 这个问题在 OneUI 2 & android 10 版本已修复
            try {
                return Settings.Global.getInt(ContextStore.getContext().contentResolver, "navigationbar_hide_bar_enabled") === 0
            } catch (ignore: Exception) {
            }
            val visibility = decorView.systemUiVisibility
            isVisible = visibility and View.SYSTEM_UI_FLAG_HIDE_NAVIGATION === 0
        }
        return isVisible
    }

    private fun getResNameById(id: Int): String {
        return try {
            ContextStore.getContext().resources.getResourceEntryName(id)
        } catch (ignore: Exception) {
            ""
        }
    }

    /**
     * Set the navigation bar's color.
     *
     * @param activity The activity.
     * @param color    The navigation bar's color.
     */
    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    fun setNavBarColor(activity: Activity,
                       @ColorInt
                       color: Int) {
        setNavBarColor(activity.window, color)
    }

    /**
     * Set the navigation bar's color.
     *
     * @param window The window.
     * @param color  The navigation bar's color.
     */
    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    fun setNavBarColor(window: Window,
                       @ColorInt
                       color: Int) {
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window.setNavigationBarColor(color)
    }

    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    fun getNavBarColor(activity: Activity): Int {
        return getNavBarColor(activity.window)
    }

    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    fun getNavBarColor(window: Window): Int {
        return window.getNavigationBarColor()
    }

    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    fun getStatusBarColor(activity: Activity): Int {
        return getStatusBarColor(activity.window)
    }

    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    fun getStatusBarColor(window: Window): Int {
        return window.statusBarColor
    }

    /**
     * Return whether the navigation bar visible.
     *
     * @return `true`: yes<br></br>`false`: no
     */
    fun isSupportNavBar(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            val wm = ContextStore.getContext()
                .getSystemService(Context.WINDOW_SERVICE) as WindowManager ?: return false
            val display = wm.defaultDisplay
            val size = Point()
            val realSize = Point()
            display.getSize(size)
            display.getRealSize(realSize)
            return realSize.y !== size.y || realSize.x !== size.x
        }
        val menu = ViewConfiguration.get(ContextStore.getContext())
            .hasPermanentMenuKey()
        val back = KeyCharacterMap.deviceHasKey(KeyEvent.KEYCODE_BACK)
        return !menu && !back
    }

    /**
     * Set the nav bar's light mode.
     *
     * @param activity    The activity.
     * @param isLightMode True to set nav bar light mode, false otherwise.
     */
    fun setNavBarLightMode(activity: Activity, isLightMode: Boolean) {
        setNavBarLightMode(activity.window, isLightMode)
    }

    /**
     * Set the nav bar's light mode.
     *
     * @param window      The window.
     * @param isLightMode True to set nav bar light mode, false otherwise.
     */
    fun setNavBarLightMode(window: Window, isLightMode: Boolean) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val decorView: View = window.decorView
            var vis: Int = decorView.systemUiVisibility
            vis = if (isLightMode) {
                vis or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            } else {
                vis and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
            }
            decorView.systemUiVisibility = vis
        }
    }

    /**
     * Is the nav bar light mode.
     *
     * @param activity The activity.
     * @return `true`: yes<br></br>`false`: no
     */
    fun isNavBarLightMode(activity: Activity): Boolean {
        return isNavBarLightMode(activity.window)
    }

    /**
     * Is the nav bar light mode.
     *
     * @param window The window.
     * @return `true`: yes<br></br>`false`: no
     */
    fun isNavBarLightMode(window: Window): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val decorView: View = window.getDecorView()
            val vis: Int = decorView.getSystemUiVisibility()
            return vis and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR !== 0
        }
        return false
    }
}