package com.tools.module.common.task

import io.reactivex.rxjava3.core.Observable

/**
 * TaskManager
 *
 * 
 * 
 */
class TaskManager<Data>(description: String, maxParallelTaskNum: Int = 1) {

    private val queue = TaskQueue<Data>(description, maxParallelTaskNum)



    fun getTask(taskId: String?): ITask<Data>? {
        return queue.getTasks { it.id == taskId }.firstOrNull()
    }

    fun getRunningOrPendingTask(taskId: String?): ITask<Data>? {
        return getRunningOrPendingTasks().firstOrNull { it.id == taskId }
    }

    fun getTasks(predicate: (ITask<Data>) -> Boolean): List<ITask<Data>> {
        return queue.getTasks(predicate)
    }

    fun getIdleTasks(): List<ITask<Data>> {
        return queue.getTasks{ it.state == TaskState.IDLE }
    }

    fun getRunningTasks(): List<ITask<Data>> {
        return queue.getTasks{ it.state == TaskState.RUNNING }
    }

    fun getRunningOrPendingTasks(): List<ITask<Data>> {
        return queue.getTasks{ it.state == TaskState.RUNNING || it.state == TaskState.PENDING }
    }

    fun getStoppedTasks(): List<ITask<Data>> {
        return queue.getTasks{ it.state == TaskState.STOPPED }
    }

    fun getPausedTasks(): List<ITask<Data>> {
        return queue.getTasks{ it.state == TaskState.PAUSED }
    }

    fun getPausedOrPendingTasks(): List<ITask<Data>> {
        return queue.getTasks{ it.state == TaskState.PAUSED || it.state == TaskState.PENDING  }
    }

    fun getCompletedTasks(): List<ITask<Data>> {
        return queue.getTasks{ it.state == TaskState.COMPLETED }
    }

    fun getFailedTasks(): List<ITask<Data>> {
        return queue.getTasks{ it.state == TaskState.FAILED }
    }

    fun getAllTasks(): List<ITask<Data>> {
        return queue.getTasks { true }
    }

    fun addTask(task: ITask<Data>?) {
        task?.let { queue.addTask(it) }
    }

    fun addTaskIfAbsent(task: ITask<Data>?) {
        task?.let {
            val runningTask = getRunningOrPendingTask(task.id)
            if (runningTask == null) {
                queue.addTask(it)
            }
        }
    }

    fun addTasks(tasks: List<ITask<Data>>?) {
        tasks?.forEach { queue.addTask(it) }
    }

    fun removeTask(taskId: String?) {
        queue.removeTasks { it.id == taskId }
    }

    fun removeTasks(predicate: (ITask<Data>) -> Boolean) {
        queue.removeTasks(predicate)
    }

    fun clearAllTasks() {
        queue.removeTasks { true }
    }



    /**
     * 设置是否自动调度任务（默认为true）
     */
    fun setTaskScheduleEnabled(enabled: Boolean) {
        queue.setTaskScheduleEnabled(enabled)
    }



    fun observerTasksStateChanged(): Observable<ITask<Data>> {
        return queue.observerTasksStateChanged()
    }

    fun observerTasksProgressChanged(): Observable<ITask<Data>> {
        return queue.observerTasksProgressChanged()
    }

}