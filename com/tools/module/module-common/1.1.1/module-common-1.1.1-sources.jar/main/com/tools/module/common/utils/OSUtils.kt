@file:JvmName("OSkUtils")

package com.tools.module.common.utils

import android.app.Activity
import android.bluetooth.BluetoothManager
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationManagerCompat
import com.tools.module.common.AppStateMonitor
import com.tools.module.common.ContextStore
import com.tools.module.common.log.XLog
import java.io.File


/**
 * Package: com.tools.module.common.utils
 * Date:    6/10/21
 * Desc:    com.tools.module.common.utils
 *
 * 
 */

/**
 * 根据/system/bin/或/system/xbin目录下是否存在su文件判断是否已ROOT
 * @return true：已ROOT
 */

private const val TAG = "OSUtils"

fun isRoot(): Boolean {
    return try {
        File("/system/bin/su").exists() || File("/system/xbin/su").exists()
    } catch (e: Exception) {
        false
    }
}

fun isGpsEnable(): Boolean {
    return (ContextStore.getContext().applicationContext.getSystemService(Context.LOCATION_SERVICE)
            as LocationManager).isProviderEnabled(LocationManager.GPS_PROVIDER)
}

fun isBluetoothOpened(): Boolean {
    return (ContextStore.getContext().applicationContext.getSystemService(Context.BLUETOOTH_SERVICE)
            as BluetoothManager).adapter?.isEnabled == true
}

/**
 * 系统层面通知开关有没有开启
 * @param mContext
 * @return
 */
fun checkNotifyPermission(context: Context): Boolean {
    val manager: NotificationManagerCompat = NotificationManagerCompat.from(context)
    return manager.areNotificationsEnabled()
}

fun openSettingsPage() {
    val intent = Intent()
    intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    intent.data = Uri.parse("package:" + ContextStore.getContext().packageName)
    AppStateMonitor.getInstance().currentActivity.startActivity(intent)
}

@Deprecated(message = "使用新方法：activity?.openLocationPage()", replaceWith = ReplaceWith("activity?.openAppPermissionPage()", "openPermissionPage"))
fun openPermissionPage() {
    val intent = Intent()
    when {
//        DeviceInfoUtils.isXiaoMi() -> {
//            openXiaoMiPermissionPage(ContextStore.getContext())
//        }
//        DeviceInfoUtils.isHuawei() -> {
//            openHuaWeiPermissionPage(ContextStore.getContext())
//        }
        else -> {
            intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            intent.data = Uri.parse("package:" + ContextStore.getContext().packageName)
            AppStateMonitor.getInstance().currentActivity.startActivity(intent)
        }
    }
}

fun openNotifyPermissionPage() {
    val intent = Intent()
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        intent.action = Settings.ACTION_APP_NOTIFICATION_SETTINGS
    } else {
        intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
    }
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    //for Android 5-7
    intent.putExtra("app_package", ContextStore.getContext().packageName)
    intent.putExtra("app_uid", ContextStore.getApplicationId())

    // for Android 8 and above
    intent.putExtra("android.provider.extra.APP_PACKAGE", ContextStore.getContext().packageName)
    AppStateMonitor.getInstance().currentActivity.startActivity(intent)
}



fun openXiaoMiPermissionPage(context: Context): Intent {
    val intent = Intent()
    if (DeviceInfoUtils.isMIUI8OrAbove()) {
        intent.component = ComponentName("com.miui.securitycenter", "com.miui.permcenter.permissions.PermissionsEditorActivity")
        intent.putExtra("extra_pkgname", context.packageName)
    } else {
        intent.component = ComponentName("com.miui.securitycenter", "com.miui.permcenter.permissions.AppPermissionsEditorActivity")
        intent.putExtra("extra_pkgname", context.packageName)
    }

    AppStateMonitor.getInstance().currentActivity.startActivity(intent)
    return intent
}

fun openHuaWeiPermissionPage(context: Context): Intent {
    val intent = Intent()
    intent.component = ComponentName("com.huawei.systemmanager", "com.huawei.permissionmanager.ui.MainActivity")
    intent.putExtra("packageName", context.packageName)
    AppStateMonitor.getInstance().currentActivity.startActivity(intent)
    return intent
}

fun openAppStoreAppDetail(context: Context?, packageName: String) {
    try {
        val intent = Intent(Intent.ACTION_VIEW)
        intent.data = Uri.parse("market://details?id=" + context?.packageName)
        intent.setPackage(packageName)
        if (context?.packageManager != null &&
            intent.resolveActivity(context.packageManager) != null
        ) {
            context.startActivity(intent)
        } else {
            //没有AppStore，浏览器跳转
            intent.data = Uri.parse("https://play.google.com/store/apps/details?id=" + context?.packageName)
            if (context?.packageManager != null &&
                intent.resolveActivity(context.packageManager) != null
            ) {
                context.startActivity(intent)
            }
        }
    } catch (e: ActivityNotFoundException) {
        XLog.e(TAG, "Go app store failed ${e.message}")
    }
}

fun openBrowser(url: String) {
    val uri = Uri.parse(url)
    val intent = Intent(Intent.ACTION_VIEW, uri)
    AppStateMonitor.getInstance().currentActivity.startActivity(intent)
}

fun openPhoneDialPage(phoneNumber: String) {
    val uri = Uri.parse("tel:${phoneNumber}")
    val intent = Intent(Intent.ACTION_DIAL)
    intent.data = uri
    AppStateMonitor.getInstance().currentActivity.startActivity(intent)
}


fun openBluetoothPage() {
    val intent = Intent()
    intent.action = Settings.ACTION_BLUETOOTH_SETTINGS
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    AppStateMonitor.getInstance().currentActivity?.startActivity(intent)
}

fun Activity.openWifiSettingsPage() {
    val intent = Intent()
    intent.action = Settings.ACTION_WIFI_SETTINGS
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    startActivity(intent)
}

fun Activity.openLocationPage() {
    val intent = Intent()
    intent.action = Settings.ACTION_LOCATION_SOURCE_SETTINGS
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    startActivity(intent)
}

fun Activity.openAppPermissionPage() {
    val intent = Intent()
    when {
//        DeviceInfoUtils.isXiaoMi() -> {
//            openXiaoMiPermissionPage(ContextStore.getContext())
//        }
//        DeviceInfoUtils.isHuawei() -> {
//            openHuaWeiPermissionPage(ContextStore.getContext())
//        }
        else -> {
            intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            intent.data = Uri.parse("package:" + ContextStore.getContext().packageName)
            startActivity(intent)
        }
    }
}

@RequiresApi(Build.VERSION_CODES.UPSIDE_DOWN_CAKE)
fun Activity.openUserFullScreenIntent() {
    val intent = Intent()
    intent.action = Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    intent.data = Uri.parse("package:${ContextStore.getContext().packageName}")
    startActivity(intent)
}

fun isAndroid5(): Boolean {
    return Build.VERSION.SDK_INT == Build.VERSION_CODES.LOLLIPOP || Build.VERSION.SDK_INT == Build.VERSION_CODES.LOLLIPOP_MR1
}

fun isAndroid5OrAbove(): Boolean {
    return Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP
}

fun isAndroid6(): Boolean {
    return Build.VERSION.SDK_INT == Build.VERSION_CODES.M
}

fun isAndroid6OrAbove(): Boolean {
    return Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
}

fun isAndroid7(): Boolean {
    return Build.VERSION.SDK_INT == Build.VERSION_CODES.N || Build.VERSION.SDK_INT == Build.VERSION_CODES.N_MR1
}

fun isAndroid7OrAbove(): Boolean {
    return Build.VERSION.SDK_INT >= Build.VERSION_CODES.N
}

fun isAndroid8(): Boolean {
    return Build.VERSION.SDK_INT == Build.VERSION_CODES.O || Build.VERSION.SDK_INT == Build.VERSION_CODES.O_MR1
}

fun isAndroid8OrAbove(): Boolean {
    return Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
}

fun isAndroid9(): Boolean {
    return Build.VERSION.SDK_INT == Build.VERSION_CODES.P
}

fun isAndroid9OrAbove(): Boolean {
    return Build.VERSION.SDK_INT >= Build.VERSION_CODES.P
}

fun isAndroid10(): Boolean {
    return Build.VERSION.SDK_INT == Build.VERSION_CODES.Q
}

fun isAndroid10OrAbove(): Boolean {
    return Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
}

fun isAndroid11(): Boolean {
    return Build.VERSION.SDK_INT == Build.VERSION_CODES.R
}

fun isAndroid11OrAbove(): Boolean {
    return Build.VERSION.SDK_INT >= Build.VERSION_CODES.R
}

fun isAndroid12(): Boolean {
    return Build.VERSION.SDK_INT == Build.VERSION_CODES.S || Build.VERSION.SDK_INT == 32
}

fun isAndroid12OrAbove(): Boolean {
    return Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
}
