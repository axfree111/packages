package com.tools.module.common.utils.region

import com.tools.module.common.utils.GzDateUtils
import java.text.SimpleDateFormat
import java.util.*

/**
 * RegionUtils
 *
 * 
 * 
 */
object RegionUtils {

    /**
     * 东八区--->+08:00，获取的格式类似于“+08:00”
     * 已经包含了夏令时的处理
     */
    fun getTimeZone(): String {
        val calendar = Calendar.getInstance(GzDateUtils.getTimeZone("GMT"), Locale.getDefault())
        val timeZone: String = SimpleDateFormat("Z", Locale.getDefault()).format(calendar.time)
        return "" + timeZone.substring(0, 3) + ":" + timeZone.substring(3, 5)
    }

    /**
     * 格式类似于 "Asia/Shanghai"
     */
    fun getTimeZoneId(): String {
        return TimeZone.getDefault().id
    }

    fun getLanguageTag(): String {
        // https://en.wikipedia.org/wiki/IETF_language_tag

        // Android系统设置中，是先选语言，再选该语言下支持的区域
        // iOS系统设置中，语言和区域可以任意搭配选择
        // 以下为Android系统中的语言+区域样例：

        // zh-CN      语言=中文, 区域=中国大陆
        // zh-Hans-CN 语言=简体中文, 区域=中国大陆
        // zh-Hans-HK 语言=简体中文, 区域=香港
        // zh-Hant-HK 语言=繁体中文, 区域=香港
        // zh-Hant-TW 语言=繁体中文, 区域=台湾

        // en-US      语言=英语, 区域=美国
        // en-GB      语言=英语, 区域=英国
        // en-AU      语言=英语, 区域=澳大利亚

        // fr-FR      语言=法语, 区域=法国
        // fr-CA      语言=法语, 区域=加拿大

        // de-DE      语言=德语, 区域=德国
        // de-IT      语言=德语, 区域=意大利

        // es-ES      语言=西班牙语, 区域=西班牙
        // es-US      语言=西班牙语, 区域=美国

        // it-IT      语言=意大利语, 区域=意大利
        // it-CH      语言=意大利语, 区域=瑞士

        // ja-JP      语言=日语, 区域=日本

        return Locale.getDefault().toLanguageTag()
    }

    /**
     * 获取 zh-rCN 格式的资源Locale，格式参考 res/values-AA-rBB 中的 AA-rBB
     *
     * @return
     */
    fun getResourceLocale(): String {
        val language = Locale.getDefault().language
        val country = Locale.getDefault().country
        return "${language}-r${country}"
    }

    /**
     * 获取 zh 格式的资源Language，格式参考 res/values-AA-rBB 中的 AA
     *
     * @return
     */
    fun getResourceLanguage(): String {
        return Locale.getDefault().language
    }

    /**
     * 获取 zh 格式的资源Country，格式参考 res/values-AA-rBB 中的 BB
     *
     * @return
     */
    fun getResourceCountry(): String {
        return Locale.getDefault().country
    }

    fun getCountry(): String {
        return Locale.getDefault().country.toLowerCase(Locale.ENGLISH)
    }

}