package com.tools.module.common.base;

/**
 * ICallback4
 *
 * 
 * 
 */
public interface ICallback4<Data> {

    void onResult(Data data);
}
