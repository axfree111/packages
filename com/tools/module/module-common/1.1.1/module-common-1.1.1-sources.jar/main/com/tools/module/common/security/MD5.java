package com.tools.module.common.security;

import com.tools.module.common.utils.HexUtils;
import com.tools.module.common.utils.IOUtils;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

public class MD5 {

    private static final String MD5_DEFAULT = "00000000000000000000000000000000";



    public static String encode(String text) {
        return encode32(text);
    }

    public static String encode4(String text) {
        return encode32(text).substring(14, 18);
    }

    public static String encode8(String text) {
        return encode32(text).substring(12, 20);
    }

    public static String encode16(String text) {
        return encode32(text).substring(8, 24);
    }

    public static String encode32(String text) {
        try {
            return encode32(new ByteArrayInputStream(text.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception ignored) {
            return MD5_DEFAULT;
        }
    }



    public static String encode(byte[] bytes) {
        return encode32(bytes);
    }

    public static String encode4(byte[] bytes) {
        return encode32(bytes).substring(14, 18);
    }

    public static String encode8(byte[] bytes) {
        return encode32(bytes).substring(12, 20);
    }

    public static String encode16(byte[] bytes) {
        return encode32(bytes).substring(8, 24);
    }

    private static String encode32(byte[] bytes) {
        try {
            return encode32(new ByteArrayInputStream(bytes));
        } catch (Exception ignored) {
            return MD5_DEFAULT;
        }
    }



    public static String encode(File file) {
        return encode32(file);
    }

    public static String encode4(File file) {
        return encode32(file).substring(14, 18);
    }

    public static String encode8(File file) {
        return encode32(file).substring(12, 20);
    }

    public static String encode16(File file) {
        return encode32(file).substring(8, 24);
    }
	
    private static String encode32(File file) {
        try {
            return encode32(new FileInputStream(file));
        } catch (Exception ignored) {
            return MD5_DEFAULT;
        }
    }



    public static String encode(InputStream is) {
        return encode32(is);
    }

    public static String encode4(InputStream is) {
        return encode32(is).substring(14, 18);
    }

    public static String encode8(InputStream is) {
        return encode32(is).substring(12, 20);
    }

    public static String encode16(InputStream is) {
        return encode32(is).substring(8, 24);
    }

    private static String encode32(InputStream is) {
        try {
            MessageDigest md5Digest = MessageDigest.getInstance("MD5");
            byte[] buffer = new byte[8192];
            int length;
            while ((length = is.read(buffer)) > 0) {
                md5Digest.update(buffer, 0, length);
            }
            return HexUtils.bytesToHex(md5Digest.digest());
        } catch (Exception ignored) {
            return MD5_DEFAULT;
        } finally {
            IOUtils.closeStream(is);
        }
    }



    /**
     * Calculate The Content-MD5 Header Field
     * @param md5 MD5
     * @return Content-MD5
     * <p/>refs: https://tools.ietf.org/html/rfc1864
     */
    public static String convert2ContentMD5(String md5) {
        return Base64.encode(HexUtils.hex2Bytes(md5));
    }

}
