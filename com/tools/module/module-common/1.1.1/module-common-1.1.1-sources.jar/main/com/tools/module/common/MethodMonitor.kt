package com.tools.module.common

/**
 * Date: 2024/11/4
 * Desc:
 *
 * author: jaje
 */
@Retention(AnnotationRetention.RUNTIME)
@Target(AnnotationTarget.FUNCTION)
annotation class MethodMonitor(val value: String = "")
