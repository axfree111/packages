package com.tools.module.common.security;

import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.security.spec.KeySpec;

import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * AES
 *
 * 
 * 
 */
public class AES {

    private static final String KEY_ALGORITHM = "AES";

    private static final String SIGNATURE_ALGORITHM = "PBKDF2WithHmacSHA256";

    //部分环境下（如mac osx）没有PKCS7Padding，但对于AES而言，PKCS5Padding和PKCS7Padding的结果是相同的
    private static final String TRANSFORMATION = "AES/CBC/PKCS5Padding";

    /**
     * 迭代次数：65536
     */
    private static final int ITERATION_COUNT = 1 << 16;

    /**
     * 密钥长度（位）
     */
    private static final int KEY_SIZE = 256;
    private static final int IV_SIZE = 16;



    public static byte[] encrypt(byte[] data, String password, String salt) {
        try {
            KeySpec spec = new PBEKeySpec(password.toCharArray(), salt.getBytes(StandardCharsets.UTF_8), ITERATION_COUNT, KEY_SIZE);
            byte[] key = SecretKeyFactory.getInstance(SIGNATURE_ALGORITHM).generateSecret(spec).getEncoded();
            return encrypt(data, key);
        } catch (Exception ignored) {
        }
        return null;
    }

    public static byte[] decrypt(byte[] data, String password, String salt) {
        try {
            KeySpec spec = new PBEKeySpec(password.toCharArray(), salt.getBytes(StandardCharsets.UTF_8), ITERATION_COUNT, KEY_SIZE);
            byte[] key = SecretKeyFactory.getInstance(SIGNATURE_ALGORITHM).generateSecret(spec).getEncoded();
            return decrypt(data, key);
        } catch (Exception ignored) {
        }
        return null;
    }



    public static byte[] encrypt(byte[] data, byte[] key) {
        try {
            byte[] iv = new byte[IV_SIZE];
            new SecureRandom().nextBytes(iv);
            byte[] encrypted = encrypt(data, key, iv);
            byte[] output = new byte[iv.length + encrypted.length];
            System.arraycopy(iv, 0, output, 0, iv.length);
            System.arraycopy(encrypted, 0, output, iv.length, encrypted.length);
            return output;
        } catch (Exception ignored) {
        }
        return null;
    }

    public static byte[] decrypt(byte[] data, byte[] key) {
        try {
            byte[] iv = new byte[IV_SIZE];
            byte[] encrypted = new byte[data.length - iv.length];
            System.arraycopy(data, 0, iv, 0, iv.length);
            System.arraycopy(data, iv.length, encrypted, 0, encrypted.length);
            return decrypt(encrypted, key, iv);
        } catch (Exception ignored) {
        }
        return null;
    }



    public static byte[] encrypt(byte[] data, byte[] key, byte[] iv) {
        try {
            SecretKeySpec secretKey = new SecretKeySpec(key, KEY_ALGORITHM);
            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, new IvParameterSpec(iv));
            return cipher.doFinal(data);
        } catch (Exception ignored) {
        }
        return null;
    }

    public static byte[] decrypt(byte[] data, byte[] key, byte[] iv) {
        try {
            SecretKeySpec secretKey = new SecretKeySpec(key, KEY_ALGORITHM);
            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(Cipher.DECRYPT_MODE, secretKey, new IvParameterSpec(iv));
            return cipher.doFinal(data);
        } catch (Exception ignored) {
        }
        return null;
    }

}
