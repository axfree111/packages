package com.tools.module.common.utils.region;

import android.text.TextUtils;

/**
 * author : guoshichao
 * date : 2025/3/24 11:51
 * description : 注意：⚠️ 不要删除，在biz-iot中使用
 */
public enum GzRegionInfo {
    CN("CN", 0),
    US("US", 1);

    private String name;
    private int value;

    private GzRegionInfo(String name, int value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return this.name == null ? "" : this.name;
    }

    public int getValue() {
        return this.value;
    }

    public static int getValue(String name) {
        GzRegionInfo[] var1 = values();
        int var2 = var1.length;

        for(int var3 = 0; var3 < var2; ++var3) {
            GzRegionInfo info = var1[var3];
            if (TextUtils.equals(info.name.toLowerCase(), name.toLowerCase())) {
                return info.value;
            }
        }

        return -1;
    }
}
