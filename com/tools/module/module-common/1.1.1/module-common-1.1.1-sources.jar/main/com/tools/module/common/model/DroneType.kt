package com.tools.module.common.model

/**
 * Date: 2025/3/27
 * Desc:
 *
 * author: jaje
 */
object DroneType {
    const val DRONE_FROM_DJ: Int = 1 //大疆设备监测数据
    const val DRONE_FROM_OTHER2: Int = 2 //没定义类型
    const val DRONE_FROM_CAA: Int = 5 //民航侦测无人机
    const val DRONE_FROME_QIYE: Int = 6 //厂家企业无人机信息
    const val DRONE_FROM_OTHER3: Int = 7 //没定义类型
    const val DRONE_NONGYEZHIBAO: Int = 8 //农业植保机
    const val DRONE_FROM_TROOPSRADAR: Int = 9 //部队雷达信息
    const val DRONE_FROM_OTHER4: Int = 10 //没定义类型
    const val DRONE_POLICE: Int = 11 //军用无人机
    const val DRONE_FROM_OTHER5: Int = 12 //没定义类型
    const val DRONE_FROM_WUXIANDIAN: Int = 13 //无线电信息
    const val DRONE_FROM_OTHER6: Int = 14 //没定义类型
    const val DRONE_FROM_OTHER7: Int = 15 //没定义类型

    const val DRONE_FROM_OTHER1: Int = 23 //没定义类型
    const val DRONE_FROM_YUNSHAO: Int = 24 //云哨信息

    const val AIRCRAFT_AVIATION: Int = 3 //航空识别信息，此类型需要区别显示
    const val AIRCRAFT_FIGHTER: Int = 4 //战斗机
    const val AIRCRAFT_ZHISHENGJI: Int = 25 //直升机
    const val AIRCRAFT_TONGHANG: Int = 26 //通航
    const val AIRCRAFT_OTHER_DIKONGYOUREN: Int = 27 //其他低空有人飞机

    // 自身设备船舶
    const val SHIP_DISTURB_OWNER: Int = 28 //民用船舶
    const val SHIP_DISTURB_ENFORCE: Int = 29 //执法船舶
    const val SHIP_DISTURB_TROOPS: Int = 30 //军用船舶

    // 船舶类型
    const val SHIP_OFFICIAL: Int = 40 //公务船
    const val SHIP_CONTAINER: Int = 41 //集装船
    const val SHIP_PASSENGER: Int = 42 //客船
    const val SHIP_BULK: Int = 43 //散货舶
    const val SHIP_TUG: Int = 44 //拖船
    const val SHIP_CRUISE: Int = 45 //邮轮
    const val SHIP_OTHER: Int = 46 //其他

    const val MIN: Int = 1
    const val MAX: Int = 46
}