package com.tools.module.common.utils

import androidx.lifecycle.MutableLiveData

/**
 * Date: 2024/6/21
 * Desc:
 *
 * author: jaje
 */
open class CsfMutableLiveData<T> : MutableLiveData<T> {
    
    private var mDataChanged: ((value: T, methodName: String?) -> Unit)? = null
    private var mDataChangedNoStackInfo: ((value: T) -> Unit)? = null
    private var mDebug = false
    constructor(value: T, dataChanged: ((value: T, methodName: String?) -> Unit)? = null) : super(value) {
        mDataChanged = dataChanged
    }
    
    constructor(dataChanged: ((value: T, methodName: String?) -> Unit)? = null) : super() {
        mDataChanged = dataChanged
    }

    constructor(value: T, dataChanged: ((value: T) -> Unit)? = null) : super(value) {
        mDataChangedNoStackInfo = dataChanged
    }

    constructor(dataChanged: ((value: T) -> Unit)? = null) : super() {
        mDataChangedNoStackInfo = dataChanged
    }

    constructor() : super() {
    }

    fun setDebug(debug: Boolean): CsfMutableLiveData<T> {
        mDebug = debug
        return this
    }

    override fun postValue(value: T) {
        if (mDataChangedNoStackInfo != null) {
            mDataChangedNoStackInfo?.invoke(value)
        } else {
            var methodName = ""
            if (mDebug) {
                methodName = getMethodName()
            }
            mDataChanged?.invoke(value, methodName)
        }
        super.postValue(value)
    }
    
    override fun setValue(value: T) {
        if (mDataChangedNoStackInfo != null) {
            mDataChangedNoStackInfo?.invoke(value)
        } else {
            var methodName = ""
            if (mDebug) {
                methodName = getMethodName()
            }
            mDataChanged?.invoke(value, methodName)
        }
        super.setValue(value)
    }

    private fun getMethodName(): String {
        var methodName = "\n"
        val stackTrace = Thread.currentThread().stackTrace
        run {
            var startPrint = false
            stackTrace.forEachIndexed { index, it ->
                when {
                    it.className.contains(CsfMutableLiveData::class.simpleName.toString())
                            && (it.methodName.contains("setValue") || it.methodName.contains("postValue")) -> {
                        startPrint = true
                            }
                    startPrint -> {
                        methodName += stackTrace[index].toString() + "\n"
                    }
                }
            }
        }
        return methodName
    }
}