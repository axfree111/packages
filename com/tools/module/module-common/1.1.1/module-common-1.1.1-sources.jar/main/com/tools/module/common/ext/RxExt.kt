@file:JvmName("RxExt")

package com.tools.module.common.ext

import com.tools.module.common.log.XLog
import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers
import io.reactivex.rxjava3.core.Flowable
import io.reactivex.rxjava3.core.Observable
import io.reactivex.rxjava3.core.Single
import io.reactivex.rxjava3.disposables.Disposable
import io.reactivex.rxjava3.functions.Consumer
import io.reactivex.rxjava3.internal.functions.Functions
import io.reactivex.rxjava3.schedulers.Schedulers

/**
 * RxExt
 *
 */

/**
 * subscribe 自定义ErrorConsumer，不触发OnErrorNotImplementedException
 *
 * Observable原生的subscribe()方法，会在Observable onError时触发RxJavaException
 * io.reactivex.rxjava3.exceptions.OnErrorNotImplementedException: The exception was not handled due to missing onError handler in the subscribe() method call.
 *
 * 原因：subscribe()内部onError的默认实现是Functions.ON_ERROR_MISSING，而doOnError方法只是旁路监听，Observable仍会认为异常未处理
 *
 * 本方法将subscribe()中，onError的默认实现改为RxErrorLogConsumer，仅打印错误信息，不打印冗余的错误堆栈
 *
 * 本方法最佳实践：
 * 通过 doOnXXX 系列方法，按需，旁路监听 OnSubscribe、OnNext、OnError、OnComplete 事件
 * 这样使得代码更简洁，也不会触发未捕获的RxJavaException
 *
 * observable.doOnSubscribe {
 *     // do something, optional
 * }.doOnNext {
 *     // do something, optional
 * }.doOnError {
 *     // do something, optional
 * }.doOnComplete {
 *     // do something, optional
 * }.subscribeX()
 *
 * @param T
 * @return
 */
fun <T: Any> Observable<T>.subscribeX(): Disposable {
    //return this.subscribe(Functions.emptyConsumer(), Functions.ON_ERROR_MISSING, Functions.EMPTY_ACTION);
    return this.subscribe(Functions.emptyConsumer(), ERROR_LOG_CONSUMER, Functions.EMPTY_ACTION)
}

fun <T: Any> Observable<T>.subscribeOnIOThread(): Observable<T> {
    return this.subscribeOn(Schedulers.io())
}

fun <T: Any> Observable<T>.observeOnMainThread(): Observable<T> {
    return this.observeOn(AndroidSchedulers.mainThread())
}

fun <T: Any> Single<T>.subscribeX(): Disposable {
    //return subscribe(Functions.emptyConsumer(), Functions.ON_ERROR_MISSING);
    return this.subscribe(Functions.emptyConsumer(), ERROR_LOG_CONSUMER)
}

fun <T: Any> Single<T>.subscribeOnIOThread(): Single<T> {
    return this.subscribeOn(Schedulers.io())
}

fun <T: Any> Single<T>.observeOnMainThread(): Single<T> {
    return this.observeOn(AndroidSchedulers.mainThread())
}

fun <T: Any> Flowable<T>.subscribeX(): Disposable {
    //return subscribe(Functions.emptyConsumer(), Functions.ON_ERROR_MISSING);
    return this.subscribe(Functions.emptyConsumer(), ERROR_LOG_CONSUMER)
}

fun <T: Any> Flowable<T>.subscribeOnIOThread(): Flowable<T> {
    return this.subscribeOn(Schedulers.io())
}

fun <T: Any> Flowable<T>.observeOnMainThread(): Flowable<T> {
    return this.observeOn(AndroidSchedulers.mainThread())
}



val ERROR_LOG_CONSUMER: Consumer<Any> = RxErrorLogConsumer()

class RxErrorLogConsumer: Consumer<Any> {
    override fun accept(error: Any) {
        if (error is Throwable) {
            XLog.i("RxErrorLogConsumer", "handle error=${error}")
        }
    }
}