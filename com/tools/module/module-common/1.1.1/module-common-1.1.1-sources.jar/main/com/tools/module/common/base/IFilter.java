package com.tools.module.common.base;

/**
 * IFilter
 *
 * 
 * 
 */
public interface IFilter<T> {

    boolean accept(T obj);

}
