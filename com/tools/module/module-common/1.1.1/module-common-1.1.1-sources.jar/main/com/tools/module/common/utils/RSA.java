package com.tools.module.common.utils;

import android.util.Base64;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;

import javax.crypto.Cipher;


/** 
 * 
 * @version 1.0 
 * @created 2013-5-17 
 */  
public class RSA {

    /**
     * 得到公钥 
     * @param algorithm 
     * @param bysKey 
     * @return 
     */  
    private static PublicKey getPublicKeyFromX509(String algorithm, String bysKey) throws Exception {
        byte[] decodedKey = base64Decode(bysKey);
        X509EncodedKeySpec x509 = new X509EncodedKeySpec(decodedKey);
   
        KeyFactory keyFactory = KeyFactory.getInstance(algorithm);
        return keyFactory.generatePublic(x509);  
    }  
   
    /** 
     * 使用公钥加密 
     * @param content 
     * @param publicKey 公钥（base64编码）
     * @return
     */  
    public static String encryptByPublic(String content, String publicKey) {
        try {  
            PublicKey pubkey = getPublicKeyFromX509("RSA", publicKey);
   
            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            cipher.init(Cipher.ENCRYPT_MODE, pubkey);
   
            byte plaintext[] = content.getBytes(StandardCharsets.UTF_8);
            byte[] output = cipher.doFinal(plaintext);  
   
            return base64Encode(output);
   
        } catch (Exception e) {
            return null;
        }  
    }  
   
    /** 
    * 使用公钥解密 
    * @param content 密文 
    * @param publicKey 公钥（base64编码）
    * @return 解密后的字符串 
    */  
    public static String decryptByPublic(String content, String publicKey) {
        InputStream ins = null;
        ByteArrayOutputStream writer = null;
        try {  
            PublicKey pubkey = getPublicKeyFromX509("RSA", publicKey);
            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            cipher.init(Cipher.DECRYPT_MODE, pubkey);
            ins = new ByteArrayInputStream(base64Decode(content));
            writer = new ByteArrayOutputStream();
            byte[] buf = new byte[128];  
            int bufl;  
            while ((bufl = ins.read(buf)) != -1) {  
                byte[] block = null;  
                if (buf.length == bufl) {  
                block = buf;  
                } else {  
                block = new byte[bufl];  
                for (int i = 0; i < bufl; i++) {  
                    block[i] = buf[i];  
                }  
                }  
                writer.write(cipher.doFinal(block));  
            }  
            return new String(writer.toByteArray(), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return null;  
        }  finally {
            try {
                if (ins != null)
                    ins.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if (writer != null)
                    writer.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    public static String base64Encode(byte[] bytes) throws Exception {
        return new String(Base64.encode(bytes, Base64.NO_WRAP));
    }

    public static byte[] base64Decode(String base64) throws Exception {
        return Base64.decode(base64.getBytes(), Base64.NO_WRAP);
    }


}