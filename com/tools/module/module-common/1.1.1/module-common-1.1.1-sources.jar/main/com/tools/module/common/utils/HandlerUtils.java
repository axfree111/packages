package com.tools.module.common.utils;

import android.os.Handler;
import android.os.Looper;

import com.google.gson.Gson;

public class HandlerUtils {

    private static Gson gson = null;
    private static Handler uiHandler = null;
    private static Handler threadHanlder = null;
    private static Handler twinkleHanlder = null;
    private static Handler scanHanlder = null;
    private static Handler shipDataHandler = null;
    private static Handler dataHandler = null;
    public static void initLocalEnv() {
        if (null == gson) {
            gson = new Gson();
        }
        if (null == uiHandler) {
            uiHandler = new Handler(Looper.getMainLooper());
        }
        if (null == threadHanlder) {
            threadHanlder = new Handler(HandlerThreadUtils.getInstance().getOtherHandlerThread().getLooper());
        }
        if (null == twinkleHanlder) {
            twinkleHanlder = new Handler(HandlerThreadUtils.getInstance().getTwinkleHandlerThread().getLooper());
        }
        if (null == scanHanlder) {
            scanHanlder = new Handler(HandlerThreadUtils.getInstance().getScanHanlderThread().getLooper());
        }
        if (null == shipDataHandler) {
            shipDataHandler = new Handler(HandlerThreadUtils.getInstance().getDataShipAndPlaneHandlerThread().getLooper());
        }
        if (null == dataHandler) {
            dataHandler = new Handler(HandlerThreadUtils.getInstance().getDataShipAndPlaneHandlerThread().getLooper());
        }
    }


    public static Gson getGson() {
        return gson;
    }
    public static Handler getUIHandler() {
        return uiHandler;
    }

    public static Handler getThreadHanlder() {
        return threadHanlder;
    }

    public static Handler getTwinkleHanlder() {
        return twinkleHanlder;
    }

    public static Handler getScanHanlder() {
        return scanHanlder;
    }

    public static Handler getShipDataHandler() {
        return shipDataHandler;
    }

    public static Handler getDataHandler() {
        return dataHandler;
    }

}
