package com.tools.module.common.utils;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Build;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.graphics.ColorUtils;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.OnLifecycleEvent;

/**
 * StatusBarUtils
 *
 * 
 * 
 */
@SuppressLint("ObsoleteSdkInt")
public class StatusBarUtils {

    private static int status_bar_height = 0;

    private StatusBarUtils() {
    }

    public static void setTransparent(Activity activity) {
        setTransparent(activity, false);
    }

    public static void setTransparent(Activity activity, boolean isTextLight) {
        if (activity != null && shouldShowTransparentStatusBar()) {
            transparentStatusBar(activity, isTextLight);
        }
    }

    public static void setStatusWhite(Activity activity) {
        if (activity != null && shouldShowTransparentStatusBar()) {
            Window window = activity.getWindow();
            if (window != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    window.setStatusBarColor(Color.WHITE);
                }
                changeStatusTextColorDark(window.getDecorView(), false, false);
            }
        }
    }

    public static void setStatusColor(Activity activity, int color) {
        if (activity != null && shouldShowTransparentStatusBar()) {
            Window window = activity.getWindow();
            if (window != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    window.setStatusBarColor(color);
                }
            }
        }
    }

    @TargetApi(Build.VERSION_CODES.KITKAT)
    private static void transparentStatusBar(Activity activity, boolean isTextLight) {
        Window window = activity.getWindow();
        if (window != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
                window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
                int visibility = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
                window.getDecorView().setSystemUiVisibility(visibility);
                window.setStatusBarColor(Color.TRANSPARENT);
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                // 解决5.0到6.0之间系统，状态栏透明后，白色字体看不清
                activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
                activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
                activity.getWindow().setStatusBarColor(ColorUtils.blendARGB(Color.TRANSPARENT, Color.BLACK, 0.36f));
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                window.setFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS, WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            }
            changeStatusTextColorDark(window.getDecorView(), isTextLight, true);
        }
    }

    @SuppressLint("AnnotateVersionCheck")
    public static boolean shouldShowTransparentStatusBar() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT;
    }

    private static void changeStatusTextColorDark(View decorView, boolean isTextLight, boolean needFullScreen) {
        if (decorView != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                int visibility = decorView.getSystemUiVisibility();
                if (needFullScreen) {
                    visibility |= View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN;
                }
                if (isTextLight) {
                    visibility &= (~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
                } else {
                    visibility |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                }
                decorView.setSystemUiVisibility(visibility);
            }
        }
    }

    @SuppressLint("InternalInsetResource")
    public static int getStatusBarHeight(Context context) {
        if (status_bar_height <= 0) {
            Resources resources = context.getResources();
            int resourceId = resources.getIdentifier("status_bar_height", "dimen", "android");
            if (resourceId > 0) {
                status_bar_height = resources.getDimensionPixelSize(resourceId);
            }
        }
        return status_bar_height;
    }


    /**
     * 适配沉浸式状态栏：在沉浸式状态下，contentView内部padding出状态栏高度
     */
    public static void fitStatusBar(LifecycleOwner lifeOwner,
                                    boolean immersive,
                                    View container,
                                    View contentView) {
        // e.g. XXXFragment
        //
        // override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        //     return super.onCreateView(inflater, container, savedInstanceState).also {
        //         StatusBarUtils.fitStatusBar(this, true, container, it)
        //     }
        // }
        if (lifeOwner != null && container != null) {
            final LifecycleObserver observer = new StatusBarAdapter(
                    lifeOwner.getLifecycle(),
                    immersive,
                    container,
                    contentView
            );
            lifeOwner.getLifecycle().addObserver(observer);
        }
    }

    private static class StatusBarAdapter implements LifecycleObserver {
        private final Lifecycle lifecycle;
        private final boolean immersive;
        private final View container;
        private final View contentView;

        private final int originContainerPaddingTop;

        StatusBarAdapter(@NonNull Lifecycle lifecycle,
                         boolean immersive,
                         @NonNull View container,
                         @Nullable View contentView) {
            this.lifecycle = lifecycle;
            this.immersive = immersive;
            this.container = container;
            this.contentView = contentView;

            this.originContainerPaddingTop = container.getPaddingTop();
        }

        @OnLifecycleEvent(Lifecycle.Event.ON_CREATE)
        void onCreate() {
            final int statusBarHeight = getStatusBarHeight(container.getContext());
            if (immersive) {
                container.setPadding(0, 0, 0, 0);
                if (contentView != null) {
                    contentView.setPadding(0, statusBarHeight, 0, 0);
                }
            } else {
                container.setPadding(0, statusBarHeight, 0, 0);
            }
        }

        @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        void onDestroy() {
            container.setPadding(0, originContainerPaddingTop, 0, 0);
            lifecycle.removeObserver(this);
        }
    }

}
