package com.tools.module.common;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Bundle;

import com.tools.module.common.log.XLog;

import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;

/**
 * <p>需要在 Application onCreate 中初始化
 */
public class AppStateMonitor {

    private static final String TAG = "AppStateMonitor";
    private final AppStateCallbacks mAppStateCallbacks = new AppStateCallbacks();

    //是否初始化成功，收到过onActivityStarted表示初始化成功
    //如果不是在 Application onCreate中初始化的，可能收不到第一个Activity的onStart，只有收到其他Activity的onStart之后，才能准确判断前后台状态
    private volatile boolean mInitSucceeded = false;

    private int mFrontActivityCount = 0;  //前台的Activity个数
    private String mFrontAppPage; //前台的Activity或Fragment名称
    private int mFrontAppPageHashCode; //前台的Activity hashcode
    private Activity mCurrentActivity; //前台Activity实例

    private Set<OnAppStateChangedListener> mListeners = new CopyOnWriteArraySet<>();

    public enum AppState {
        FOREGROUND, BACKGROUND, UNKNOWN
    }

    private AppStateMonitor() {
    }

    private static class SingletonHolder {
        static final AppStateMonitor INSTANCE = new AppStateMonitor();
    }

    public static AppStateMonitor getInstance() {
        return SingletonHolder.INSTANCE;
    }



    public void init(Context context) {
        final Context appContext = context.getApplicationContext();
        if (appContext instanceof Application) {
            ((Application)appContext).registerActivityLifecycleCallbacks(mAppStateCallbacks);
        }
    }

    public AppState getAppState() {
        final boolean initedSucc = mInitSucceeded;
        final int frontActivityCount = mFrontActivityCount;
        if (initedSucc) {
            return frontActivityCount > 0 ? AppState.FOREGROUND : AppState.BACKGROUND;
        }
        return AppState.UNKNOWN;
    }

    public boolean isAppForeground() {
        return getAppState() == AppState.FOREGROUND;
    }

    public boolean isAppBackground() {
        return getAppState() == AppState.BACKGROUND;
    }

    public String getFrontAppPage() {
        return mFrontAppPage;
    }

    public void setFrontAppPage(String page) {
        XLog.d(TAG, "mFrontAppPage=" + page);
        mFrontAppPage = page;
    }

    public void setFrontAppPageHashCode(int page) {
        XLog.d(TAG, "mFrontAppPageHashCode=" + page);
        mFrontAppPageHashCode = page;
    }

    public Activity getCurrentActivity() {
        return mCurrentActivity;
    }



    public interface OnAppStateChangedListener {
        void onAppStateChanged(AppState state);
        default void onAppPageChanged(String page) {}
        default void onAppPageCreated(String currPage) {}
        default void onAppPageDestroyed(String currPage) {}
    }

    public void addOnAppStateChangedListener(OnAppStateChangedListener listener) {
        if (listener != null) {
            mListeners.add(listener);
        }
    }

    public void removeOnAppStateChangedListener(OnAppStateChangedListener listener) {
        if (listener != null) {
            mListeners.remove(listener);
        }
    }

    private void notifyAppStateChanged(AppState state) {
//        XLog.d(TAG, "notifyAppStateChanged=" + state);
        for (OnAppStateChangedListener listener : mListeners) {
            listener.onAppStateChanged(state);
        }
    }

    private void notifyAppPageChanged(String page) {
//        XLog.d(TAG, "notifyAppPageChanged=" + page);
        for (OnAppStateChangedListener listener : mListeners) {
            listener.onAppPageChanged(page);
        }
    }
    private void onAppPageCreated(String currPage) {
//        XLog.d(TAG, "onAppPageCreated=" + currPage);
        for (OnAppStateChangedListener listener : mListeners) {
            listener.onAppPageCreated(currPage);
        }
    }

    private void onAppPageDestroyed(String page) {
//        XLog.d(TAG, "onAppPageDestroyed=" + page);
        for (OnAppStateChangedListener listener : mListeners) {
            listener.onAppPageDestroyed(page);
        }
    }

    private class AppStateCallbacks implements Application.ActivityLifecycleCallbacks {
        @Override
        public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
            final String currAppPage = activity.getClass().getSimpleName();
            onAppPageCreated(currAppPage);
        }

        @Override
        public void onActivityStarted(Activity activity) {
            mInitSucceeded = true;

            ++mFrontActivityCount;
            if (mFrontActivityCount == 1) {
                notifyAppStateChanged(AppState.FOREGROUND);
            }

            final String appPage = activity.getClass().getSimpleName();
            final int appPageHashCode = activity.hashCode();
            if (mFrontAppPageHashCode != appPageHashCode) {
                setFrontAppPageHashCode(appPageHashCode);
                setFrontAppPage(appPage);
                mCurrentActivity = activity;
                notifyAppPageChanged(getFrontAppPage());
            }
        }

        @Override
        public void onActivityResumed(Activity activity) {
            final String appPage = activity.getClass().getSimpleName();
            final int appPageHashCode = activity.hashCode();
            if (mFrontAppPageHashCode != appPageHashCode) {
                setFrontAppPageHashCode(appPageHashCode);
                setFrontAppPage(appPage);
                mCurrentActivity = activity;
                notifyAppPageChanged(getFrontAppPage());
            }
        }

        @Override
        public void onActivityPaused(Activity activity) {
        }

        @Override
        public void onActivityStopped(Activity activity) {
            mFrontActivityCount = mFrontActivityCount > 0 ? --mFrontActivityCount : 0;
            if (mFrontActivityCount == 0) {
                mFrontAppPage = null;
                mFrontAppPageHashCode = 0;
                mCurrentActivity = null;
                notifyAppStateChanged(AppState.BACKGROUND);
                notifyAppPageChanged(getFrontAppPage());
            }
        }

        @Override
        public void onActivitySaveInstanceState(Activity activity, Bundle outState) {
        }

        @Override
        public void onActivityDestroyed(Activity activity) {
            final String currAppPage = activity.getClass().getSimpleName();
            onAppPageDestroyed(currAppPage);
        }
    }

}
