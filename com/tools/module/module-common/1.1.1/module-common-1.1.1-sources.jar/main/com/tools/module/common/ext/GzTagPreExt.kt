package com.tools.module.common.ext

/**
 * Date: 2023/7/31
 * Desc:
 *
 * author: jaje
 */

val SETTING_PRE = "setting_"

val DP_PRE = "dp_"

val SETTING_DP_PRE = SETTING_PRE + DP_PRE

const val CLOUD_TAG_PRE = "Cloud_"
const val GUIDE_TAG_PRE = "Guide_"
const val PLAYBACK_TAG_PRE = "Playback_"
const val PLAYBACK_DATA_TAG_PRE = PLAYBACK_TAG_PRE + "Data_"
const val PLAYBACK_SDCARD_TAG_PRE = PLAYBACK_TAG_PRE + "Card_"
const val PLAYBACK_CLOUD_TAG_PRE = PLAYBACK_TAG_PRE + "Cloud_"
const val ACTIVATOR_TAG_PRE = "Activator_"