package com.tools.module.common.utils.region

import androidx.annotation.StringDef

/**
 *  author : guoshichao
 *  date : 2025/3/14 13:42
 *  description :
 */
object RegionConstant {

    /**
     * 大区：中国
     */
    const val REGION_CN: String = "cn"

    /**
     * 大区：美洲
     */
    const val REGION_US: String = "us"

    /**
     * 大区：欧洲
     */
    const val REGION_EU: String = "eu"

    /**
     * 大区：亚太
     */
    const val REGION_AP: String = "ap"

    @StringDef(
        REGION_CN,
        REGION_US,
        REGION_EU,
        REGION_AP
    )
    @Retention(AnnotationRetention.SOURCE)
    annotation class Region

}