package com.tools.module.common.utils;

/**
 * Created by jiajie on 2020-03-08.
 */
public class MathUtils {

    public static double getArcsin(int current, int total) {
        return Math.asin(current * 1.0f / (total - 1) * 2 / Math.PI);
    }
}
