package com.tools.module.common.utils;

import android.content.ContentResolver;
import android.content.res.AssetManager;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.text.TextUtils;

import com.tools.module.common.ContextStore;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

import androidx.annotation.AnyRes;
import androidx.annotation.ArrayRes;
import androidx.annotation.ColorInt;
import androidx.annotation.ColorRes;
import androidx.annotation.DimenRes;
import androidx.annotation.DrawableRes;
import androidx.annotation.RawRes;
import androidx.annotation.StringRes;
import androidx.core.content.ContextCompat;

import static android.view.View.NO_ID;

public class ResUtils {

    public static final int ID_NULL = 0; // Resources.ID_NULL

    /**
     * 获取资源ID
     *
     * @param name e.g. com.glazero.android:drawable/ic_launcher
     */
    public static int getResId(String name) {
        if (!TextUtils.isEmpty(name)) {
            return ContextStore.getContext().getResources().getIdentifier(name, null, null);
        }
        return ID_NULL;
    }

    /**
     * @param name       e.g. ic_launcher
     * @param defType    e.g. drawable
     * @param defPackage e.g. com.glazero.android
     */
    public static int getResId(String name, String defType, String defPackage) {
        if (!TextUtils.isEmpty(name)) {
            return ContextStore.getContext().getResources().getIdentifier(name, defType, defPackage);
        }
        return ID_NULL;
    }

    /**
     * @param resid resid
     */
    public static String getResName(@AnyRes int resid) {
        if (resid != NO_ID) {
            return ContextStore.getContext().getResources().getResourceName(resid);
        }
        return "";
    }

    public static String getString(@StringRes int resId) {
        return ContextStore.getContext().getString(resId);
    }

    public static String getString(@StringRes int resId, Object... formatArgs) {
        return ContextStore.getContext().getString(resId, formatArgs);
    }

    public static Drawable getDrawable(@DrawableRes int resId) {
        return ContextCompat.getDrawable(ContextStore.getContext(), resId);
    }

    @ColorInt
    public static int getColor(@ColorRes int id) {
        return ContextStore.getContext().getResources().getColor(id);
    }

    public static ColorStateList getColorStateList(@ColorRes int id, @androidx.annotation.Nullable Resources.Theme theme) {
        return ContextStore.getContext().getResources().getColorStateList(id, theme);
    }

    public static String getRaw(@RawRes int rewId) {
        InputStream inputStream = ContextStore.getContext().getResources().openRawResource(rewId);
        InputStreamReader inputStreamReader = null;
        inputStreamReader = new InputStreamReader(inputStream, StandardCharsets.UTF_8);

        BufferedReader reader = new BufferedReader(inputStreamReader);
        String line = "";
        StringBuilder result = new StringBuilder();
        try {
            while ((line = reader.readLine()) != null) {
                // 添加代码
                result.append(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return result.toString();
    }

    /**
     * 获取raw目录的资源Uri
     * 注意：通知铃声场景需要通过resName生成Uri，以保障每次给到系统的Uri不随打包变化
     *
     * @param resName 资源名称
     * @return android.resource://com.glazero.android/raw/xxx
     */
    public static Uri getRawResourceUri(String resName) {
        return Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE + "://" + ContextStore.getApplicationId() + "/raw/" + resName);
    }

    /**
     * 获取raw目录的资源Uri
     * 注意：通知铃声场景需要通过resName生成Uri，以保障每次给到系统的Uri不随打包变化
     *
     * @param resId 资源ID
     * @return android.resource://com.glazero.android/raw/xxx
     */
    public static Uri getRawResourceUri(@RawRes int resId) {
        // com.glazero.android:raw/xxx
        final String resName = ContextStore.getContext().getResources().getResourceName(resId);
        // android.resource://com.glazero.android/raw/xxx
        return Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE + "://" + resName.replace(":", "/"));
    }

    public static int getDimenPixel(@DimenRes int dimenResId) {
        return ContextStore.getContext().getResources().getDimensionPixelSize(dimenResId);
    }

    public static float getDimenDp(@DimenRes int dimenResId) {
        final Resources resources = ContextStore.getContext().getResources();
        return resources.getDimension(dimenResId) / resources.getDisplayMetrics().density;
    }

    public static float getDimenSp(@DimenRes int dimenResId) {
        final Resources resources = ContextStore.getContext().getResources();
        return resources.getDimension(dimenResId) / resources.getDisplayMetrics().scaledDensity;
    }


    public static String[] getStringArray(@ArrayRes int arrayResId) {
        return ContextStore.getContext().getResources().getStringArray(arrayResId);
    }

    public static int[] getIntArray(@ArrayRes int arrayResId) {
        return ContextStore.getContext().getResources().getIntArray(arrayResId);
    }

    public static String getAssetFileAsString(String assetName) {
        final StringBuilder sb = new StringBuilder();
        try {
            final AssetManager assetManager = ContextStore.getContext().getAssets();
            final BufferedReader br = new BufferedReader(new InputStreamReader(assetManager.open(assetName)));
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
        } catch (Exception ignored) {
        }
        return sb.toString();
    }

}
