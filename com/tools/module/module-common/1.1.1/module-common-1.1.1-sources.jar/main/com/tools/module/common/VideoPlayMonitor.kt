package com.tools.module.common

import android.os.Handler
import android.os.Looper

/**
 * Package: com.tools.module.common
 * Date:    7/20/21
 * Desc:    com.tools.module.common
 *
 * 
 */
class VideoPlayMonitor {
    var callBack: CallBack? = null
    private val HANDLER = Handler(
            Looper.getMainLooper()
    ) {
        when (it.what) {
            MSG_PLAY_PAUSE -> {
                callBack?.playLoading()
            }
            MSG_PLAY_TIMEOUT -> {
                callBack?.playTimeout()
            }
        }

        true
    }

    companion object {
        const val MSG_PLAY_PAUSE = 110
        const val MSG_PLAY_TIMEOUT = 111

        //2 seconds
        const val PLAY_PAUSE_MONITOR_DURATION: Long = 2000

        //1*60*1000 minutes
        const val PLAY_TIME_MONITOR_DURATION: Long = 1 * 60 * 1000

        val instance by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
            VideoPlayMonitor()
        }
    }

    fun monitorStart() {
        monitorStart(PLAY_PAUSE_MONITOR_DURATION)
    }

    fun monitorStart(monitorDuration: Long) {
        removePlayPauseMessage()
        HANDLER.sendEmptyMessageDelayed(MSG_PLAY_PAUSE, monitorDuration)
        startPlayTimeoutMonitor()
    }

    private fun startPlayTimeoutMonitor() {
        removePlayTimeoutMessage()
        HANDLER.sendEmptyMessageDelayed(MSG_PLAY_TIMEOUT, PLAY_TIME_MONITOR_DURATION)
    }

    fun monitorCancel() {
        removePlayPauseMessage()
        removePlayTimeoutMessage()
    }

    private fun removePlayPauseMessage() {
        HANDLER.removeMessages(MSG_PLAY_PAUSE)
    }

    private fun removePlayTimeoutMessage() {
        HANDLER.removeMessages(MSG_PLAY_TIMEOUT)
    }

    fun terminal() {
        callBack = null
        monitorCancel()
    }

    interface CallBack {
        fun playLoading()
        fun playTimeout()
    }
}