package com.tools.module.common.model

/**
 * Date: 2025/3/27
 * Desc:
 *
 * author: jaje
 */
object UserLevel {
    /**
     * 0 超级管理员
     * 1 管理员
     * 2 操作员
     */
    const val SUPER_USER: Int = 0
    const val MANAGE_USER: Int = 1
    const val OPERATOR_USER: Int = 2
}