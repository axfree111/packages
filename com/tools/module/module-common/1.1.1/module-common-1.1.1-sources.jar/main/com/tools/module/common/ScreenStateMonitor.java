package com.tools.module.common;

import android.app.KeyguardManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;

import com.tools.module.common.log.XLog;

import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;

/**
 * ScreenStateMonitor
 *
 */
public class ScreenStateMonitor {
    private static final String TAG = "ScreenStateMonitor";

    public interface IScreenEventListener {
        void onScreenOn(Context context);
        void onScreenOff(Context context);
        void onScreenUnlocked(Context context);
    }

    private final Set<IScreenEventListener> mListeners = new CopyOnWriteArraySet<>();
    private KeyguardManager mKeyguardManager;



    private ScreenStateMonitor() {
    }

    private static class SingletonHolder {
        static final ScreenStateMonitor INSTANCE = new ScreenStateMonitor();
    }

    public static ScreenStateMonitor getInstance() {
        return SingletonHolder.INSTANCE;
    }

    public void init(Context context) {
        new ScreenEventReceiver().register(context);
        mKeyguardManager = (KeyguardManager)context.getSystemService(Context.KEYGUARD_SERVICE);
    }



    public void addScreenEventListener(IScreenEventListener listener) {
        mListeners.add(listener);
    }

    public void removeScreenEventListener(IScreenEventListener listener) {
        mListeners.remove(listener);
    }

    public boolean isScreenLocked() {
        return mKeyguardManager.isKeyguardLocked();
    }



    private void dispatchScreenOn(Context context) {
        XLog.i(TAG, "dispatchScreenOn isScreenLocked=" + isScreenLocked());
        for (IScreenEventListener listener : mListeners) {
            listener.onScreenOn(context);
        }
    }

    private void dispatchScreenOff(Context context) {
        XLog.i(TAG, "dispatchScreenOff isScreenLocked=" + isScreenLocked());
        for (IScreenEventListener listener : mListeners) {
            listener.onScreenOff(context);
        }
    }

    private void dispatchScreenUnlocked(Context context) {
        XLog.i(TAG, "dispatchScreenUnlocked isScreenLocked=" + isScreenLocked());
        for (IScreenEventListener listener : mListeners) {
            listener.onScreenUnlocked(context);
        }
    }

    private final class ScreenEventReceiver extends BroadcastReceiver {
        final IntentFilter filter = new IntentFilter();

        ScreenEventReceiver() {
            filter.addAction(Intent.ACTION_SCREEN_ON);
            filter.addAction(Intent.ACTION_SCREEN_OFF);
            filter.addAction(Intent.ACTION_USER_PRESENT);
        }

        void register(Context context) {
            context.registerReceiver(this, filter);
        }

        void unregister(Context context) {
            context.unregisterReceiver(this);
        }

        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent == null || intent.getAction() == null) {
                return;
            }
            switch (intent.getAction()) {
                case Intent.ACTION_SCREEN_ON:
                    dispatchScreenOn(context);
                    break;
                case Intent.ACTION_SCREEN_OFF:
                    dispatchScreenOff(context);
                    break;
                case Intent.ACTION_USER_PRESENT:
                    dispatchScreenUnlocked(context);
                    break;
            }
        }
    }

}
