package com.tools.module.common.base;

/**
 * SerialTask
 *
 * 
 * 
 */
public interface AntiBlockTask extends Runnable {
    void onTaskIgnored();
}
