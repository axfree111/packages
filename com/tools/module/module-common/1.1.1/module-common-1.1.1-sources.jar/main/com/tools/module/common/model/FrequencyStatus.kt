package com.tools.module.common.model

/**
 * Date: 2025/3/27
 * Desc:
 *
 * author: jaje
 */
object FrequencyStatus {
    /**
     * 频段状态
     * -1 过温
     * -2 过功率
     * -3 驻波告警
     * -4 输出欠功率
     * -5 过流
     * -6 欠压告警
     * -7 过压告警
     * -8 参数错误
     * -9
     * 0 正常
     */

    const val NORMAL: Int = 0
    const val OVER_TEMPERATURE: Int = -1
    const val OVER_POWER: Int = -2
    const val STANDING_WAVE_WARN: Int = -3
    const val OUTPUT_UNDER_POWER: Int = -4
    const val OVER_ELECTRICITY: Int = -5
    const val UNDER_WARN: Int = -6
    const val OVER_WARN: Int = -7
    const val PARAMETER_ERROR: Int = -8
    const val OTHER: Int = -9
}