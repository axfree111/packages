package com.tools.module.common.utils;

import android.os.HandlerThread;

/**
 * Created by jiajie on 2019-08-28.
 */
public class HandlerThreadUtils {

    private static HandlerThreadUtils instance;

    private HandlerThreadUtils() {
        initHandler();
    }

    public static HandlerThreadUtils getInstance() {
        if (instance == null) {
            synchronized (HandlerThreadUtils.class) {
                if (instance == null) {
                    instance = new HandlerThreadUtils();
                }
            }
        }
        return instance;
    }

    private HandlerThread dataHandlerThread;
    private HandlerThread dataShipAndPlaneHandlerThread;
    private HandlerThread dataVideoHandlerThread;
    private HandlerThread logHandlerThread;
    private HandlerThread otherHandlerThread;
    private HandlerThread timingHandlerThread;
    private HandlerThread twinkleHandlerThread;
    private HandlerThread scanHanlderThread;
    private HandlerThread twinkleTvHandlerThread;
    private void initHandler() {
        if (dataHandlerThread == null) {
            dataHandlerThread = new HandlerThread(THREAD_NAME_DATA);
            dataHandlerThread.start();
        }
        if (dataShipAndPlaneHandlerThread == null) {
            dataShipAndPlaneHandlerThread = new HandlerThread(THREAD_NAME_SHIP_DATA);
            dataShipAndPlaneHandlerThread.start();
        }
        if (dataVideoHandlerThread == null) {
            dataVideoHandlerThread = new HandlerThread(THREAD_NAME_VIDEO_DATA);
            dataVideoHandlerThread.start();
        }
        if (logHandlerThread == null) {
            logHandlerThread = new HandlerThread(THREAD_NAME_LOG);
            logHandlerThread.start();
        }
        if (otherHandlerThread == null) {
            otherHandlerThread = new HandlerThread(THREAD_NAME_OTHER);
            otherHandlerThread.start();
        }
        if (timingHandlerThread == null) {
            timingHandlerThread = new HandlerThread(THREAD_NAME_TIMING);
            timingHandlerThread.start();
        }
        if (twinkleHandlerThread == null) {
            twinkleHandlerThread = new HandlerThread(THREAD_NAME_TWINKLE);
            twinkleHandlerThread.start();
        }
        if (scanHanlderThread == null) {
            scanHanlderThread = new HandlerThread(THREAD_NAME_SCAN);
            scanHanlderThread.start();
        }
        if (twinkleTvHandlerThread == null) {
            twinkleTvHandlerThread = new HandlerThread(THREAD_NAME_TWINKLE_TV);
            twinkleTvHandlerThread.start();
        }
    }

    public HandlerThread getDataHandlerThread() {
        return dataHandlerThread;
    }

    public HandlerThread getDataVideoHandlerThread() {
        return dataVideoHandlerThread;
    }

    public HandlerThread getDataShipAndPlaneHandlerThread() {
        return dataShipAndPlaneHandlerThread;
    }

    public HandlerThread getLogHandlerThread() {
        return logHandlerThread;
    }

    public HandlerThread getOtherHandlerThread() {
        return otherHandlerThread;
    }

    public HandlerThread getTimingHandlerThread() {
        return timingHandlerThread;
    }

    public HandlerThread getTwinkleHandlerThread() {
        return twinkleHandlerThread;
    }

    public HandlerThread getTwinkleTvHandlerThread() {
        return twinkleTvHandlerThread;
    }

    public HandlerThread getScanHanlderThread() {
        return scanHanlderThread;
    }

    public static final String THREAD_NAME_LOG = "drone_log";
    public static final String THREAD_NAME_DATA = "drone_data_dispose";
    public static final String THREAD_NAME_SHIP_DATA = "drone_data_ship_dispose";
    public static final String THREAD_NAME_VIDEO_DATA = "drone_data_video_dispose";
    public static final String THREAD_NAME_OTHER = "drone_other";
    public static final String THREAD_NAME_TIMING = "timing_thread";
    public static final String THREAD_NAME_TWINKLE = "twinkle_thread";
    public static final String THREAD_NAME_TWINKLE_TV = "twinkle_tv_thread";
    public static final String THREAD_NAME_SCAN = "scan_thread";
}
