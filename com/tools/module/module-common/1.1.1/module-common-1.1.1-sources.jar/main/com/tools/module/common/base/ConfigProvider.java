package com.tools.module.common.base;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.tools.module.common.utils.GsonUtils;

import java.io.File;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;

/**
 * ConfigProvider
 *
 * 
 * 
 */
public class ConfigProvider {

    private static Config sDefaultConfig = new ConfigEmptyImpl();

    public interface Config {
        File getFile();

        Map<String, Object> getAll();

        void putAll(Map<String, Object> attrs);

        void clear();

        <T> T get(String key, Class<T> valueType, T defaultValue);

        <T> void put(String key, T value);

        default String getString(String key, String defaultValue) {
            return get(key, String.class, defaultValue);
        }

        default void putString(String key, String value) {
            put(key, value);
        }

        default long getLong(String key, long defaultValue) {
            return get(key, Long.class, defaultValue);
        }

        default void putLong(String key, long value) {
            put(key, value);
        }

        default int getInt(String key, int defaultValue) {
            return get(key, Integer.class, defaultValue);
        }

        default void putInt(String key, int value) {
            put(key, value);
        }

        default float getFloat(String key, float defaultValue) {
            return get(key, Float.class, defaultValue);
        }

        default void putFloat(String key, float value) {
            put(key, value);
        }

        default double getDouble(String key, double defaultValue) {
            return get(key, Double.class, defaultValue);
        }

        default void putDouble(String key, double value) {
            put(key, value);
        }

        default boolean getBoolean(String key, boolean defaultValue) {
            return get(key, boolean.class, defaultValue);
        }

        default void putBoolean(String key, boolean value) {
            put(key, value);
        }
    }

    public static void initDefault(File configFile) {
        sDefaultConfig = create(configFile);
    }

    public static Config getDefault() {
        return sDefaultConfig;
    }

    public static Config create(File configFile) {
        return new ConfigImpl(configFile);
    }

    public static Config createMemory() {
        return new MemoryConfigImpl();
    }

    private static class ConfigImpl implements Config {
        private static final Gson GSON = GsonUtils.createPretty();
        private static final Type TYPE = new TypeToken<Map<String, Object>>() {
        }.getType();
        private static final ExecutorService SERVICE = BaseExecutors.newSingleThreadExecutor("cfg", BaseExecutors.EXCEPTION_HANDLER);

        private final File mFile;
        private final Map<String, Object> mConfig;

        ConfigImpl(File file) {
            mFile = file;
            Map<String, Object> configCached = GsonUtils.loadFromFile(GSON, mFile, TYPE);
            mConfig = configCached != null ? configCached : new HashMap<>();
        }

        @Override
        public File getFile() {
            return mFile;
        }

        @Override
        public Map<String, Object> getAll() {
            return new HashMap<>(mConfig);
        }

        @Override
        public void putAll(Map<String, Object> attrs) {
            if (mConfig != null && attrs != null) {
                mConfig.putAll(attrs);
                apply();
            }
        }

        @Override
        public void clear() {
            if (mConfig != null) {
                mConfig.clear();
                apply();
            }
        }

        @SuppressWarnings("unchecked")
        @Override
        public <T> T get(String key, Class<T> valueType, T defaultValue) {
            Object value = key != null && mConfig != null ? mConfig.get(key) : null;
            if (value != null) {
                try {
                    if (value instanceof Number) {
                        if (valueType == Long.class) {
                            return (T) Long.valueOf(((Number) value).longValue());
                        } else if (valueType == Integer.class) {
                            return (T) Integer.valueOf(((Number) value).intValue());
                        } else if (valueType == Float.class) {
                            return (T) Float.valueOf(((Number) value).floatValue());
                        } else if (valueType == Double.class) {
                            return (T) Double.valueOf(((Number) value).doubleValue());
                        }
                    }
                    return (T) value;
                } catch (Exception ignored) {
                }
            }
            return defaultValue;
        }

        @Override
        public <T> void put(String key, T value) {
            if (mConfig != null) {
                mConfig.put(key, value);
                apply();
            }
        }

        private void apply() {
            SERVICE.submit(() -> {
                GsonUtils.write2File(GSON, mFile, mConfig);
            });
        }
    }

    private static class MemoryConfigImpl implements Config {
        private static final Gson GSON = GsonUtils.createPretty();
        private static final Type TYPE = new TypeToken<Map<String, Object>>() {
        }.getType();
        private static final ExecutorService SERVICE = BaseExecutors.newSingleThreadExecutor("cfg", BaseExecutors.EXCEPTION_HANDLER);

        private final Map<String, Object> mConfig;

        MemoryConfigImpl() {
            mConfig = new HashMap<>();
        }

        @Override
        public File getFile() {
            return null;
        }

        @Override
        public Map<String, Object> getAll() {
            return new HashMap<>(mConfig);
        }

        @Override
        public void putAll(Map<String, Object> attrs) {
            if (mConfig != null && attrs != null) {
                mConfig.putAll(attrs);
            }
        }

        @Override
        public void clear() {
            if (mConfig != null) {
                mConfig.clear();
            }
        }

        @SuppressWarnings("unchecked")
        @Override
        public <T> T get(String key, Class<T> valueType, T defaultValue) {
            Object value = key != null && mConfig != null ? mConfig.get(key) : null;
            if (value != null) {
                try {
                    if (value instanceof Number) {
                        if (valueType == Long.class) {
                            return (T) Long.valueOf(((Number) value).longValue());
                        } else if (valueType == Integer.class) {
                            return (T) Integer.valueOf(((Number) value).intValue());
                        } else if (valueType == Float.class) {
                            return (T) Float.valueOf(((Number) value).floatValue());
                        } else if (valueType == Double.class) {
                            return (T) Double.valueOf(((Number) value).doubleValue());
                        }
                    }
                    return (T) value;
                } catch (Exception ignored) {
                }
            }
            return defaultValue;
        }

        @Override
        public <T> void put(String key, T value) {
            if (mConfig != null) {
                mConfig.put(key, value);
            }
        }
    }

    public static class ConfigEmptyImpl implements Config {
        @Override
        public File getFile() {
            return null;
        }

        @Override
        public Map<String, Object> getAll() {
            return new HashMap<>();
        }

        @Override
        public void putAll(Map<String, Object> attrs) {
        }

        @Override
        public void clear() {
        }

        @Override
        public <T> T get(String key, Class<T> valueType, T defaultValue) {
            return defaultValue;
        }

        @Override
        public <T> void put(String key, T value) {
        }
    }

}
