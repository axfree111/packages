package com.tools.module.common.utils;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.text.TextUtils;

import com.tools.module.common.ContextStore;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.Charset;
import java.util.List;

/**
 * Created by jiajie on 2018/11/14.
 */

public class AppUtil {

    /**
     * 获取应用程序名称
     */

    public static synchronized String getAppName(Context context) {
        try {
            PackageManager packageManager = context.getPackageManager();
            PackageInfo packageInfo = packageManager.getPackageInfo(context.getPackageName(), 0);
            int labelRes = packageInfo.applicationInfo.labelRes;
            return context.getResources().getString(labelRes);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    /**
     * 获得APP版本号
     *
     * @return 版本号
     */
    public static String getVersionName() {
        try {
            PackageManager pm = ContextStore.getContext().getPackageManager();
            PackageInfo pi = pm.getPackageInfo(ContextStore.getContext().getPackageName(), 0);
            return pi.versionName;
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    /**
     * 获得APP版本号
     *
     * @return 版本号
     */
    public static long getVersionCode() {
        try {
            PackageManager pm = ContextStore.getContext().getPackageManager();
            PackageInfo pi = pm.getPackageInfo(ContextStore.getContext().getPackageName(), 0);
            return pi.versionCode;
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        }
    }

    /**
     * 获取异常log
     *
     * @param ex
     * @return
     */
    public static String getExceptionString(Throwable ex) {
        if (ex == null) {
            return null;
        } else {
            String log = null;
            try {
                StringWriter stringWriter = new StringWriter();
                PrintWriter printWriter = new PrintWriter(stringWriter);
                ex.printStackTrace(printWriter);

                for (Throwable cause = ex.getCause(); cause != null; cause = cause.getCause()) {
                    cause.printStackTrace(printWriter);
                }
                log = stringWriter.toString();
                printWriter.close();
                stringWriter.close();
            } catch (Exception error) {
                error.printStackTrace();
            }
            return log;
        }
    }

    /**
     * 执行具体的静默安装逻辑，需要手机ROOT。
     *
     * @param apkPath 要安装的apk文件的路径
     * @return 安装成功返回true，安装失败返回false。
     */
    public static boolean install(String apkPath) {
        boolean result = false;
        DataOutputStream dataOutputStream = null;
        BufferedReader errorStream = null;
        try {
            // 申请su权限
            Process process = Runtime.getRuntime().exec("su");
            dataOutputStream = new DataOutputStream(process.getOutputStream());
            // 执行pm install命令
            String command = "pm install -r " + apkPath + "\n";
            dataOutputStream.write(command.getBytes(Charset.forName("utf-8")));
            dataOutputStream.flush();
            dataOutputStream.writeBytes("exit\n");
            dataOutputStream.flush();
            process.waitFor();
            errorStream = new BufferedReader(new InputStreamReader(process.getErrorStream()));
            String msg = "";
            String line;
            // 读取命令的执行结果
            while ((line = errorStream.readLine()) != null) {
                msg += line;
            }
            XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_OTHER, "install msg is " + msg);
            // 如果执行结果中包含Failure字样就认为是安装失败，否则就认为安装成功
            if (!msg.contains("Failure")) {
                result = true;
            }
        } catch (Exception e) {
            XAppLogger.getInstance().writeError(e);
        } finally {
            try {
                if (dataOutputStream != null) {
                    dataOutputStream.close();
                }
                if (errorStream != null) {
                    errorStream.close();
                }
            } catch (IOException e) {
                XAppLogger.getInstance().writeError(e);
            }
        }
        XAppLogger.getInstance().writeLog(XAppLogger.LOG_TYPE.TYPE_OTHER, "result:%b" + result);
        return result;
    }

    /**
     * 是否支持该intent的处理
     *
     * @param intent
     * @return
     */
    public static boolean canHandleIntent(Intent intent) {
        final PackageManager packageManager = ContextStore.getContext().getPackageManager();
        List<ResolveInfo> supportList = packageManager.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
        if (supportList != null && supportList.size() > 0) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 关闭InputStream
     */
    public static void closeQuietly(InputStream is) {
        try {
            if (is != null) {
                is.close();
            }
        } catch (Exception e) {
        }
    }

    /**
     * 关闭InputStream
     */
    public static void closeQuietly(OutputStream os) {
        try {
            if (os != null) {
                os.close();
            }
        } catch (Exception e) {
        }
    }

    public static final String ACTIVITY_RELEASE_ALIAS = ".icon";
    public static final String ACTIVITY_DEBUG_ALIAS = ".icon1";

    public static void setIcon(String alias) {
//        Context ctx = AppContext.getContext();
//        PackageManager pm = ctx.getPackageManager();
//        ActivityManager am = (ActivityManager) ctx.getSystemService(Activity.ACTIVITY_SERVICE);
//
//        // Enable/disable activity-aliases
//        pm.setComponentEnabledSetting(
//                new ComponentName(ctx, ctx.getPackageName() + ACTIVITY_RELEASE_ALIAS),
//                ACTIVITY_RELEASE_ALIAS.equals(alias) ? PackageManager.COMPONENT_ENABLED_STATE_ENABLED
//                        : PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
//                PackageManager.DONT_KILL_APP);
//        pm.setComponentEnabledSetting(
//                new ComponentName(ctx, ctx.getPackageName() + ACTIVITY_DEBUG_ALIAS),
//                ACTIVITY_DEBUG_ALIAS.equals(alias) ? PackageManager.COMPONENT_ENABLED_STATE_ENABLED
//                        : PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
//                PackageManager.DONT_KILL_APP);
//
//        // Find launcher and kill it
//        Intent i = new Intent(Intent.ACTION_MAIN);
//        i.addCategory(Intent.CATEGORY_HOME);
//        i.addCategory(Intent.CATEGORY_DEFAULT);
//        List<ResolveInfo> resolves = pm.queryIntentActivities(i, 0);
//        for (ResolveInfo res : resolves) {
//            if (res.activityInfo != null) {
//                am.killBackgroundProcesses(res.activityInfo.packageName);
//            }
//        }
    }

    private static String channelName;

    /**
     * 获取渠道名
     *
     * @return 如果没有获取成功，那么返回值为空
     */
    public static String getChannelName() {
        if (ContextStore.getContext() == null) {
            return null;
        }
        if (!TextUtils.isEmpty(channelName)) {
            return channelName;
        }
        try {
            PackageManager packageManager = ContextStore.getContext().getPackageManager();
            if (packageManager != null) {
                //注意此处为ApplicationInfo 而不是 ActivityInfo,因为友盟设置的meta-data是在application标签中，而不是某activity标签中，所以用ApplicationInfo
                ApplicationInfo applicationInfo = packageManager.
                        getApplicationInfo(ContextStore.getContext().getPackageName(), PackageManager.GET_META_DATA);
                if (applicationInfo != null) {
                    if (applicationInfo.metaData != null) {
                        channelName = String.valueOf(applicationInfo.metaData.get("UMENG_CHANNEL"));
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return channelName;
    }

    /**
     * 获取缓存的百分比大小
     *
     * @param percent
     * @return
     */
    public static int getMemCacheSizeByPercent(float percent) {
        if (percent < 0.05f || percent > 0.8f) {
            throw new IllegalArgumentException(
                    "setMemCacheSizePercent - percent must be "
                            + "between 0.05 and 0.8 (inclusive)");
        }
        return Math.round(percent * Runtime.getRuntime().maxMemory());
    }
}