package com.tools.module.common

import android.app.Activity
import android.app.Application
import android.os.Bundle

/**
 * Package: com.tools.module.common
 * Date:    2021/4/30
 * Desc:    com.tools.module.common
 *
 * 
 */

private var resumed = 0
private var paused = 0
private var started = 0
private var stoped = 0

class MyLifecycleHandler : Application.ActivityLifecycleCallbacks {

    override fun onActivityPaused(activity: Activity) {
        ++paused
    }

    override fun onActivityStarted(activity: Activity) {
        ++started
    }

    override fun onActivityDestroyed(activity: Activity) {

    }

    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {

    }

    override fun onActivityStopped(activity: Activity) {
        ++stoped
    }

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {

    }

    override fun onActivityResumed(activity: Activity) {
        ++resumed
    }

    companion object {
        fun isAppVisible(): Boolean {
            return started > stoped
        }

        fun isAppForeground(): Boolean {
            return resumed > paused
        }
    }
}