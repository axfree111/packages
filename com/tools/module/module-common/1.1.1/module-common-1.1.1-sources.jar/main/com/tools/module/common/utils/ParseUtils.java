package com.tools.module.common.utils;

import android.text.TextUtils;

/**
 * Created by Snser on 2017/5/3.
 */

public class ParseUtils {

    /**
     * equals to Integer.parseInt(String), throws no exception
     * @param string the string representation of a int value.
     * @param defaultValue the value to be returned when parse fail
     * @return int value
     */
    public static int parseInt(String string, int defaultValue) {
        int ret = defaultValue;
        if (!TextUtils.isEmpty(string)) {
            try {
                ret = Integer.parseInt(string);
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
        return ret;
    }

    /**
     * equals to Long.parseLong(String), throws no exception
     * @param string the string representation of a long value.
     * @param defaultValue the value to be returned when parse fail
     * @return int value
     */
    public static long parseLong(String string, long defaultValue) {
        long ret = defaultValue;
        if (!TextUtils.isEmpty(string)) {
            try {
                ret = Long.parseLong(string);
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
        return ret;
    }

    /**
     * parse charSequence into string，return empty string if charSequence is null
     * @param charSequence charSequence
     * @return string
     */
    public static String parseCharSequence(CharSequence charSequence) {
        return charSequence != null ? charSequence.toString() : "";
    }

}
