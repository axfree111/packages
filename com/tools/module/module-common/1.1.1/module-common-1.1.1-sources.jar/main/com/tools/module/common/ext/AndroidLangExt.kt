@file:JvmName("AndroidLangExt")

package com.tools.module.common.ext

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.res.Resources
import android.view.View
import androidx.lifecycle.MutableLiveData
import kotlin.math.pow
import kotlin.math.roundToLong

/**
 * AndroidLangExt
 *
 * 
 * 
 */

fun Context?.dp2px(value: Int): Int {
    return ((this?.resources?.displayMetrics?.density?: 0.0f) * 1.0f * value + 0.5f).toInt()
}

fun Context?.dp2px(value: Float): Int {
    return ((this?.resources?.displayMetrics?.density?: 0.0f) * 1.0f * value + 0.5f).toInt()
}

fun Int.dp(): Int {
    return dp2px()
}

fun Int.dp2px(): Int {
    return (Resources.getSystem().displayMetrics.density * this + 0.5f).toInt()
}

fun Int.px2dp(): Int {
    return (this / Resources.getSystem().displayMetrics.density + 0.5f).toInt()
}

fun Float.dp(): Int {
    return dp2px()
}

fun Float.dp2px(): Int {
    return (Resources.getSystem().displayMetrics.density * this + 0.5f).toInt()
}

fun Float.px2dp(): Int {
    return (this / Resources.getSystem().displayMetrics.density + 0.5f).toInt()
}



fun Context?.isAppDebuggable(): Boolean {
    return ((this?.getApplicationInfo()?.flags ?: 0) and ApplicationInfo.FLAG_DEBUGGABLE) != 0
}

fun Float.roundDecimalPart(digits: Int): Float {
    if (digits > 0) {
        val round: Long = 10.toDouble().pow(digits.toDouble()).toLong()
        return (this * round).roundToLong().toFloat() / round
    }
    return this
}

fun Double.roundDecimalPart(digits: Int): Double {
    if (digits > 0) {
        val round: Long = 10.toDouble().pow(digits.toDouble()).toLong()
        return (this * round).roundToLong().toDouble() / round
    }
    return this
}

/**
 * 转换为加密的字符串
 * plainCharCount：起始&结尾的明文字符长度
 *
 * e.g. 明文=abcdefg, plainCharCount=1, output=a*****g
 */
fun String?.securityString(plainCharCount: Int): String {
    return securityString(plainCharCount, plainCharCount)
}

/**
 * 转换为加密的字符串
 * plainCharCountStart：起始的明文字符长度
 * plainCharCountEnd：  结尾的明文字符长度
 *
 * e.g. 明文=abcdefg, numPlainTextStart=1, numPlainTextStart=2, output=a****fg
 */
fun String?.securityString(plainCharCountStart: Int, plainCharCountEnd: Int): String {
    val start = kotlin.math.max(plainCharCountStart, 0)
    val end = kotlin.math.max(plainCharCountEnd, 0)
    if (this != null && this.length >= start + end) {
        val sb = StringBuilder()
        sb.appendRange(this, 0, start)
        for (i in start until this.length - end) {
            sb.append("*")
        }
        sb.appendRange(this, this.length - end, this.length)
        return sb.toString()
    }
    return this ?: "null"
}

fun <T> MutableLiveData<T>.notify(){
    this.value = this.value
}

fun <T> MutableLiveData<T>.setValueNotRepeat(value:T){
    if(this.value != value){
        this.value = value
    }
}

fun <T> MutableLiveData<T>.postValueNotRepeat(value:T){
    if(this.value != value){
        this.postValue(value)
    }
}

/**
 * 过滤快速点击，300ms内点击两次，只响应第一次
 * @receiver View
 * @param onClickListener OnClickListener?
 */
fun View.setNoRepeatOnClickListener(duration: Long = 3000, onClickListener: View.OnClickListener?) {
    if (onClickListener == null) {
        this.setOnClickListener(null)
    } else {
        this.setOnClickListener(object : View.OnClickListener {
            private var lastClickTime = 0L
            override fun onClick(v: View?) {
                if (System.currentTimeMillis() - lastClickTime < duration) {
                    return
                }
                lastClickTime = System.currentTimeMillis()
                onClickListener.onClick(v)
            }
        })
    }
}

fun <K,V> Map<K,V>.copy():Map<K,V>{
    val copy = mutableMapOf<K,V>()
    copy.putAll(this)
    return copy
}