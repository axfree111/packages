package com.tools.module.common.base;

/**
 * ICallback2
 *
 */
public interface ICallback2<Data1, Data2> {

    void onSuccess(Data1 data1, Data2 data2);
    void onFail(Integer errorCode, String errorMsg);

}
