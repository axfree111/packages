package com.tools.module.common.model

/**
 * Date: 2025/3/27
 * Desc:
 *
 * author: jaje
 */
object WarningAreaType {
    const val CIRCLE: Int = 0
    const val POLYGON: Int = 1
}