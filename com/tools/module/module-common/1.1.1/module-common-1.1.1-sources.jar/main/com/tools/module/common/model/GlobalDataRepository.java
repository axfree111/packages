package com.tools.module.common.model;

/**
 * Date: 2025/3/27
 * Desc:
 * <p>
 * author: jaje
 */
public class GlobalDataRepository {

    private static GlobalDataRepository instance;
    public static GlobalDataRepository getInstance() {
        if (instance == null) {
            synchronized (GlobalDataRepository.class) {
                if (instance == null) {
                    instance = new GlobalDataRepository();
                }
            }
        }
        return instance;
    }

    private boolean isStartData = false;

    private boolean isMainPage = false;
    private boolean isStop = false;

    public boolean isMainPage() {
        return isMainPage;
    }

    public boolean isStop() {
        return isStop;
    }

    public boolean isStartData() {
        return isStartData;
    }
}
