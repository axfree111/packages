package com.tools.module.common.model

/**
 * Date: 2025/3/27
 * Desc:
 *
 * author: jaje
 */
object FightControl {
    const val MANUAL: Int = 0
    const val SEMIAUTOMATIC: Int = 1
    const val AUTOMATIC: Int = 2
}