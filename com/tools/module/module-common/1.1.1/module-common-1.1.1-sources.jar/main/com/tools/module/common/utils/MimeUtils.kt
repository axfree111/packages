package com.tools.module.common.utils

/**
 * Package: com.tools.module.common.utils
 * Date:    2021/5/18
 * Desc:    com.tools.module.common.utils
 *
 * 
 */
object MimeUtils {

    fun matchMimeTypeFromExtension(fileName: String): String {
        return when {
            fileName.contains(".png", true) -> {
                "image/png"
            }
            fileName.contains(".jpeg", true) -> {
                "image/jpeg"
            }
            fileName.contains(".webp", true) -> {
                "image/webp"
            }
            fileName.contains(".gif", true) -> {
                "image/gif"
            }
            fileName.contains(".3gp", true) -> {
                "video/3gp"
            }
            fileName.contains(".avi", true) -> {
                "video/avi"
            }
            fileName.contains(".mp4", true) -> {
                "video/mp4"
            }
            else -> ""
        }

    }

    const val MIME_TYPE_IMAGE = "image/*"
    const val MIME_TYPE_VIDEO_MP4 = "video/mp4"
}