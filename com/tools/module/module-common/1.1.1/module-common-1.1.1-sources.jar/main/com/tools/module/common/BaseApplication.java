package com.tools.module.common;

import android.app.Application;
import android.content.Context;

/**
 * BaseApplication
 *
 * 
 * 
 */
public class BaseApplication extends Application {

    private static BaseApplication sApplication;



    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        sApplication = this;
        //attachBaseContext时机，能取到当前包名，但取不到applicationContext
        //此时setContext用于ContextStore初始化包名，使得ContentProvider静态成员变量初始化时可以取到当前包名
        ContextStore.setContext(this);
    }

    public void onCreate() {
        super.onCreate();
        //attachBaseContext时机，可以取不到applicationContext
        //此时setContext用于ContextStore初始化applicationContext
        ContextStore.setContext(this);
    }



    public static BaseApplication getApp() {
        return sApplication;
    }

    public static Context getContext() {
        return sApplication.getApplicationContext();
    }

}
