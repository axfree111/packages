package com.tools.module.common.model

/**
 * Date: 2025/3/27
 * Desc:
 *
 * author: jaje
 */
object ErrorCode {
    const val USER_NEEDLOGIN_ERROR: Int = -104
}