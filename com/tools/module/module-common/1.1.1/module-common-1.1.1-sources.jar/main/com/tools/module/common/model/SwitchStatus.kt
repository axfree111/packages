package com.tools.module.common.model

/**
 * Date: 2025/3/27
 * Desc:
 *
 * author: jaje
 */
object SwitchStatus {
    const val OFF: Int = 0
    const val ON: Int = 1
}