package com.tools.module.common.utils;

import com.tools.module.common.ContextStore;

import java.util.Locale;

public class AppLocal {

    public static String getLanguage() {
        Locale locale = ContextStore.getContext().getResources().getConfiguration().locale;//获得local对象
        return locale.getLanguage();
    }

    public static String getCountry() {
        Locale locale = ContextStore.getContext().getResources().getConfiguration().locale;//获得local对象
        return locale.getCountry();
    }

    public static Locale getDefault() {
        return ContextStore.getContext().getResources().getConfiguration().locale;//获得local对象
    }

    public static boolean isZh() {
        return "zh".equals(getLanguage());
    }
}
