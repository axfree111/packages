@file:JvmName("ThreadDispatcher")

package com.tools.module.common.executors

import com.tools.module.common.base.BaseExecutors
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.ThreadFactory

/**
 * ThreadDispatcher
 *
 */

val CommonExecutor: ExecutorService = Executors.newCachedThreadPool(object : ThreadFactory {
    var index = 0
    override fun newThread(r: Runnable?): Thread {
        val thread: Thread = Executors.defaultThreadFactory().newThread(r)
        thread.name = "CommonExecutor-pool-thread-" + index++
        return thread
    }
})

val JniExecutor: ExecutorService = BaseExecutors.newSingleThreadExecutor("pjni", BaseExecutors.EXCEPTION_HANDLER)

val SingleThreadExecutor: ExecutorService = BaseExecutors.newSingleThreadExecutor("SingleThreadExecutor-pool-thread", BaseExecutors.EXCEPTION_HANDLER)
