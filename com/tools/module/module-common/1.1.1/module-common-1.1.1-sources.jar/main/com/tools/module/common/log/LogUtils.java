package com.tools.module.common.log;

import com.tools.module.common.utils.EnvUtils;
import com.tools.module.common.utils.FormatUtils;
import com.tools.module.common.utils.GzDateUtils;
import com.tools.module.common.utils.IOUtils;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.TimeZone;

/**
 * LogUtils
 *
 * 
 * 
 */
public class LogUtils {

    public static String getStackTraceString(Throwable tr) {
        StringWriter sw = new StringWriter();
        try {
            PrintWriter pw = new PrintWriter(sw);
            tr.printStackTrace(pw);
            pw.flush();
        } catch (Exception ignored) {
        } finally {
            IOUtils.closeStream(sw);
        }
        return sw.toString();
    }

    public static String buildStackTraceString(StackTraceElement[] elements) {
        StringBuilder sb = new StringBuilder();
        if (elements != null) {
            for (StackTraceElement element : elements) {
                sb.append(element.toString()).append("\n");
            }
        }
        return sb.toString();
    }

    public static String formatLog(Level level, String tag, String msg, Throwable tr) {
        return FormatUtils.formatDateTimeMillis()
                + GzDateUtils.formatTimezone(TimeZone.getDefault())
                + " [" + tag + "/" + level.shortName() + "]"
                + " [" + EnvUtils.getProcessId() + ":" + EnvUtils.getThreadId() + ":" + EnvUtils.getThreadName() + "] "
                + msg
                + (tr != null ? (" e=" + getStackTraceString(tr)) : "");
    }

}
