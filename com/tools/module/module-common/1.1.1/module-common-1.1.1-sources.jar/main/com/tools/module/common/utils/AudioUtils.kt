package com.tools.module.common.utils

import android.content.Context
import android.media.AudioManager
import com.tools.module.common.log.XLog

/**
 * AudioUtils
 *
 * 
 * 
 */
object AudioUtils {

    private const val TAG = "AudioUtils"

    fun requestAudioModeNormal(context: Context?): Boolean {
        // mode=0
        return requestAudioMode(context, AudioManager.MODE_NORMAL)
    }

    fun requestAudioModeInCommunication(context: Context?): Boolean {
        // mode=3
        return requestAudioMode(context, AudioManager.MODE_IN_COMMUNICATION)
    }

    fun requestAudioMode(context: Context?, mode: Int): Boolean {
        if (context == null) {
            XLog.w(TAG, "requestAudioMode fail, context=null")
            return false
        }
        try {
            XLog.i(TAG, "requestAudioMode mode=$mode")
            // pixel: adb log -s DeviceStateHelper
            // samsung: adb log -s BatteryService
            // 可以查看mode生效情况，DeviceStateHelper/BatteryService是某个系统方法
            // 三星手机需要在手机 系统设置 - 声音和振动 - 音量 中，开启 "使用音量键控制媒体音量"
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            audioManager.mode = mode
        } catch (e: Throwable) {
            XLog.w(TAG, "requestAudioMode mode=$mode fail, e=$e")
            return false
        }
        return true
    }

}