package com.tools.module.common.utils;

import java.lang.reflect.Method;

/**
 * EnvUtils
 *
 * 
 * 
 */
public class EnvUtils {

    private static final Environment ENV = initEnv();

    private static Method ANDROID_PROCESS_MYPID;

    static {
        switch (ENV) {
            case ANDROID:
                initAndroidEnv();
                break;
            case JAVA:
                break;
            default:
                break;
        }
    }

    public enum Environment {
        JAVA,
        ANDROID,
        UNKNOWN
    }




    private static Environment initEnv() {
        try {
            if (Class.forName("android.os.Process") != null) {
                return Environment.ANDROID;
            }
        } catch (Throwable ignored) {
        }
        try {
            if (Class.forName("java.lang.management.ManagementFactory") != null) {
                return Environment.JAVA;
            }
        } catch (Throwable ignored) {
        }
        return Environment.UNKNOWN;
    }

    private static void initAndroidEnv() {
        try {
            ANDROID_PROCESS_MYPID = Class.forName("android.os.Process").getMethod("myPid");
        } catch (Throwable ignored) {
            ignored.printStackTrace();
        }
    }

    public static Environment getEnvironment() {
        return ENV;
    }




    public static int getProcessId() {
        try {
            switch (EnvUtils.getEnvironment()) {
                case JAVA:
                    //String name = ManagementFactory.getRuntimeMXBean().getName(); // "pid@hostname"
                    //return Integer.parseInt(name.substring(0, name.indexOf("@")));
                    break;
                case ANDROID:
                    return (Integer)ANDROID_PROCESS_MYPID.invoke(null);
            }
        } catch (Throwable ignored) {
        }
        return -1;
    }

    public static long getThreadId() {
        return Thread.currentThread().getId();
    }

    public static String getThreadName() {
        return Thread.currentThread().getName();
    }

}
