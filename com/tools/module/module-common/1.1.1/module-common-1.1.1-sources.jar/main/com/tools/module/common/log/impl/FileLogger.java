package com.tools.module.common.log.impl;

import com.tools.module.common.base.BaseExecutors;
import com.tools.module.common.log.ILogger;
import com.tools.module.common.log.Level;
import com.tools.module.common.log.LogUtils;
import com.tools.module.common.utils.GzDateUtils;
import com.tools.module.common.utils.FileUtils;
import com.tools.module.common.utils.FormatUtils;
import com.tools.module.common.utils.IOUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;

/**
 * FileLogger
 *
 * 
 * 
 */
public final class FileLogger implements ILogger {

    private static final String TAG = "FileLogger";

    private final File mLogPath;
    private final String mLogFilePrefix;
    private final int mLogExpiredDays;
    private volatile Level mLevel = Level.DEBUG;

    private final ExecutorService mService;

    private long mDetectExpiredLogTick;



    public FileLogger(File logPath) {
        this(logPath, "log", Level.INFO, Integer.MAX_VALUE);
    }

    @SuppressWarnings("ResultOfMethodCallIgnored")
    public FileLogger(File logPath, String logFilePrefix, Level level, int logExpiredDays) {
        mLogPath = logPath;
        mLogPath.mkdirs();
        mLogFilePrefix = logFilePrefix;
        mLogExpiredDays = Math.max(logExpiredDays, 1);
        mService = BaseExecutors.newSingleThreadExecutor("flog" + logFilePrefix);
        setLogLevel(level);
    }

    @Override
    public void setLogLevel(Level level) {
        if (level != null) {
            mLevel = level;
        }
    }

    @Override
    public void d(String tag, String msg) {
        log(Level.DEBUG, tag, msg, null);
    }

    @Override
    public void i(String tag, String msg) {
        log(Level.INFO, tag, msg, null);
    }

    @Override
    public void w(String tag, String msg) {
        log(Level.WARN, tag, msg, null);
    }

    @Override
    public void e(String tag, String msg) {
        log(Level.ERROR, tag, msg, null);
    }

    @Override
    public void e(String tag, String msg, Throwable tr) {
        log(Level.ERROR, tag, msg, tr);
    }

    private void log(final Level level, final String tag, final String msg, final Throwable tr) {
        if (System.currentTimeMillis() - mDetectExpiredLogTick > GzDateUtils.HOUR_IN_MILLIS) {
            mService.submit(this::deleteExpiredLog);
            mDetectExpiredLogTick = System.currentTimeMillis();
        }
        if (level.getLevel() >= mLevel.getLevel()) {
            final String log = LogUtils.formatLog(level, tag, msg, tr);
            final String logFileName = "" + mLogFilePrefix + "_" + FormatUtils.formatDate() + ".log";
            final File logFile = new File(mLogPath, logFileName);
            mService.submit(() -> {
                FileOutputStream fos = null;
                try {
                    fos = new FileOutputStream(logFile, true);
                    final OutputStreamWriter osw = new OutputStreamWriter(fos, StandardCharsets.UTF_8);
                    osw.write(log);
                    osw.write("\n");
                    osw.flush();
                    osw.close();
                } catch (Exception ignored) {
                } finally {
                    IOUtils.closeStream(fos);
                }
            });
        }
    }

    private void deleteExpiredLog() {
        final long today = GzDateUtils.getTodayTick(0, 0).getTimeInMillis();
        final File[] files = mLogPath.listFiles();
        if (files != null && files.length > 0) {
            for (File file : files) {
                try {
                    final String filename = file.getName();
                    if (file.isFile() && filename.endsWith(".log")) {
                        String dateStr = filename.substring(filename.lastIndexOf("_") + 1, filename.lastIndexOf("."));
                        long date = FormatUtils.parseDate(dateStr,null);
                        if ((today - date) / GzDateUtils.DAY_IN_MILLIS >= mLogExpiredDays) {
                            this.i(TAG, "deleteExpiredLog file=" + file.getAbsolutePath());
                            FileUtils.deleteQuietly(file);
                        }
                    }
                } catch (Exception ignored) {
                }
            }
        }
    }

}
