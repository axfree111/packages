package com.tools.module.common.model

/**
 * Date: 2025/3/27
 * Desc: 自定义类型用于点击时方便判断是属于那种设备
 *
 * author: jaje
 */
object DeviceType {
    const val DISTURB_CAR: Int = 1 //车载
    const val DISTURB_PORTABLE_8QX360B01: Int = 2 //全向便携
    const val DISTURB_PORTABLE_09B01: Int = 3 //便携设备
    const val DISTURB_HAND_06S01: Int = 4 //手持设备
    const val DISTURB_PISTOL: Int = 5 //枪式设备
    const val DISTURB_PORTABLE_09B02: Int = 6 //便携设备
    const val DISTURB_SHIP_ON: Int = 7 //船载设备
    const val DISTURB_PORTABLE_PL120D01: Int = 8 //便携设备
    const val DISTURB_PORTABLE_CK120D01: Int = 9 //便携设备
    const val DISTURB_PORTABLE_CK120D02: Int = 10 //便携设备
    const val DISTURB_RAILWAY_PROTECTION: Int = 24 //铁路布防
    const val WEAPON: Int = 11

    const val DETECT_GPS: Int = 12
    const val DETECT_YUNSHAO: Int = 13
    const val DETECT_WEIBO: Int = 14
    const val DETECT_LEIDA: Int = 15
    const val DETECT_YUNTAI_PORTABLE: Int = 50

    const val WEAPON_GUANGDIAN: Int = 16
    const val WEAPON_ACOUSTICAL_SOUNDING: Int = 17
    const val WEAPON_OPTICAL_DETECTION: Int = 18

    const val DETECT_ABS_B: Int = 19

    const val COMMAND_CENTER_PRIMARY: Int = 20
    const val COMMAND_CENTER_SECONDARY: Int = 21
    const val COMMAND_CENTER_TERTIARY: Int = 22

    // 模拟设备
    const val ANALOG_DEVICES: Int = 52

    const val MIN: Int = 1
    const val MAX: Int = 52
}