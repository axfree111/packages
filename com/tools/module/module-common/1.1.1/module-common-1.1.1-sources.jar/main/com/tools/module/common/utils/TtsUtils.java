package com.tools.module.common.utils;

import com.tools.module.common.R;

/**
 * TtsUtils
 *
 * 
 * 
 */
public class TtsUtils {

    private static final String[] TTS_DIGITS_NORMAL = ResUtils.getStringArray(R.array.tts_number_normal);
    private static final String[] TTS_DIGITS_PHONE = ResUtils.getStringArray(R.array.tts_number_phone);


    /**
     * 替换字符串中的数字为：零/一/二/三/四/五/六/七/八/九/
     */
    public static String buildDigitNormalTTS(String text) {
        return buildDigitTTS(text, TTS_DIGITS_NORMAL);
    }

    /**
     * 替换字符串中的数字为：零/幺/二/三/四/五/六/七/八/九/
     */
    public static String buildDigitPhoneTTS(String text) {
        return buildDigitTTS(text, TTS_DIGITS_PHONE);
    }

    /**
     * 构建验证码、号码的TTS播报语音，以免被系统TTS按照数字读成xx万xx千。
     * e.g. 验证码的"1"会读成"一"，号码的"1"会读成"幺"。
     */
    private static String buildDigitTTS(String digits, String[] digitTTSMap) {
        final StringBuilder sb = new StringBuilder();
        if (digits != null) {
            for (int i = 0; i != digits.length(); ++i) {
                final String ch = String.valueOf(digits.charAt(i));
                try {
                    final int digit = Integer.parseInt(ch);
                    if (digit >= 0 && digit <= 9) {
                        sb.append(digitTTSMap[digit]);
                        continue;
                    }
                } catch (NumberFormatException ignored) {
                }
                sb.append(ch);
            }
        }
        return sb.toString();
    }

}
