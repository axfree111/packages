package com.tools.module.common.model

/**
 * Date: 2025/3/27
 * Desc:
 *
 * author: jaje
 */
object MapType {
    const val BAIDU_MAP: Int = -1
    const val A_MAP: Int = 0
    const val GOOGLE_MAP: Int = 1
}