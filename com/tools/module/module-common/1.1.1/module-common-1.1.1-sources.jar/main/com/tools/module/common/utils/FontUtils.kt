package com.tools.module.common.utils

import android.content.Context
import android.content.res.Configuration
import android.os.RemoteException
import com.tools.module.common.log.XLog

/**
 * Package: com.tools.module.common.utils
 * Date:    1/4/22
 * Desc:    com.tools.module.common.utils
 *
 * 
 */
object FontUtils {
    const val TAG = "FontUtils"

    fun getFontScale(context: Context): Float {
        return getFontScale(context.resources.configuration)
    }

    fun getFontScale(configuration: Configuration): Float {
        val mCurConfig = Configuration()
        try {
            mCurConfig.updateFrom(configuration)
        } catch (e: RemoteException) {
            XLog.w(TAG, "getFontSize exception :${e.localizedMessage}")
        }
        return mCurConfig.fontScale
    }
}